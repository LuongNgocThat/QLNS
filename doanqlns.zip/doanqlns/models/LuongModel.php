<?php
include_once(__DIR__ . '/../config/Database.php');
class LuongModel {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getAllLuong() {
        $query = "SELECT * FROM LUONG l INNER JOIN 
        NHAN_VIEN nv ON l.id_nhan_vien = nv.id_nhan_vien";
        $result = $this->conn->query($query);

        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $users;
    }
    
}
?>
