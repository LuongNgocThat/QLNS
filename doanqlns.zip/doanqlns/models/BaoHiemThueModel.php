<?php
include_once(__DIR__ . '/../config/Database.php');
class BaoHiemThueModel {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getAllBaoHiemThue() {
        $query = "SELECT * FROM BAO_HIEM_THUE_TNCN join NHAN_VIEN on BAO_HIEM_THUE_TNCN.id_nhan_vien = NHAN_VIEN.id_nhan_vien";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $users;
    }
    public function deleteBaoHiemThue($id) {
        $query = "DELETE FROM BAO_HIEM_THUE_TNCN WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
    
    public function updateBaoHiemThue($id, $data) {
        // Query to update the BAO_HIEM_THUE_TNCN table and join with the NHANVIEN table
        $query = "UPDATE BAO_HIEM_THUE_TNCN bht
                  JOIN NHAN_VIEN nv ON bht.id_nhan_vien = nv.id_nhan_vien
                  SET bht.thang = :thang, 
                      bht.bhxh = :bhxh, 
                      bht.bhyt = :bhyt, 
                      bht.bhtn = :bhtn, 
                      bht.thue_tncn = :thue_tncn
                  WHERE bht.id = :id";
    
        // Prepare the query
        $stmt = $this->conn->prepare($query);
    
        // Bind parameters
        $stmt->bindParam(":thang", $data['thang']);
        $stmt->bindParam(":bhxh", $data['bhxh']);
        $stmt->bindParam(":bhyt", $data['bhyt']);
        $stmt->bindParam(":bhtn", $data['bhtn']);
        $stmt->bindParam(":thue_tncn", $data['thue_tncn']);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
    
        // Execute the query and return the result
        return $stmt->execute();
    }
    
    
}
?>
