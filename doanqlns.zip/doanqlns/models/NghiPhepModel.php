<?php
class NghiPhepModel {
    private $conn;

    public function __construct() {
        $this->conn = new mysqli("localhost", "root", "", "doanqlns");
        if ($this->conn->connect_error) {
            error_log("Kết nối cơ sở dữ liệu thất bại: " . $this->conn->connect_error);
            throw new Exception("Không thể kết nối đến cơ sở dữ liệu");
        }
    }

    public function getAllNghiPhep() {
        try {
            $query = "SELECT p.*, nv.ho_ten, nv.gioi_tinh, nv.ngay_sinh, nv.email, nv.so_dien_thoai, nv.dia_chi, 
                             pb.ten_phong_ban AS phong_ban, cv.ten_chuc_vu AS chuc_vu 
                      FROM NGHI_PHEP p 
                      INNER JOIN NHAN_VIEN nv ON p.id_nhan_vien = nv.id_nhan_vien 
                      LEFT JOIN PHONG_BAN pb ON nv.id_phong_ban = pb.id_phong_ban 
                      LEFT JOIN CHUC_VU cv ON nv.id_chuc_vu = cv.id_chuc_vu";
            $result = $this->conn->query($query);
            if (!$result) {
                error_log("Lỗi truy vấn SQL: " . $this->conn->error);
                throw new Exception("Lỗi truy vấn cơ sở dữ liệu: " . $this->conn->error);
            }
            $records = [];
            while ($row = $result->fetch_assoc()) {
                $records[] = $row;
            }
            return $records;
        } catch (Exception $e) {
            error_log("Lỗi trong getAllNghiPhep: " . $e->getMessage());
            throw $e;
        }
    }

    public function updateNghiPhep($id, $trangThai, $idNguoiDuyet, $ngayDuyet) {
        try {
            $query = "UPDATE NGHI_PHEP SET trang_thai1 = ?, id_nguoi_duyet = ?, ngay_duyet = ? WHERE id_nghi_phep = ?";
            $stmt = $this->conn->prepare($query);
            if (!$stmt) {
                throw new Exception("Lỗi chuẩn bị truy vấn: " . $this->conn->error);
            }
            $stmt->bind_param("sisi", $trangThai, $idNguoiDuyet, $ngayDuyet, $id);
            if ($stmt->execute()) {
                $stmt->close();
                return true;
            } else {
                error_log("Lỗi SQL khi cập nhật NGHI_PHEP: " . $stmt->error);
                $stmt->close();
                return false;
            }
        } catch (Exception $e) {
            error_log("Lỗi trong updateNghiPhep: " . $e->getMessage());
            throw $e;
        }
    }

    public function deleteNghiPhep($id) {
        try {
            $stmt = $this->conn->prepare("DELETE FROM NGHI_PHEP WHERE id_nghi_phep = ?");
            if (!$stmt) {
                throw new Exception("Lỗi chuẩn bị truy vấn: " . $this->conn->error);
            }
            $stmt->bind_param("i", $id);
            $result = $stmt->execute();
            if (!$result) {
                error_log("Lỗi SQL khi xóa NGHI_PHEP: " . $stmt->error);
            }
            $stmt->close();
            return $result;
        } catch (Exception $e) {
            error_log("Lỗi trong deleteNghiPhep: " . $e->getMessage());
            throw $e;
        }
    }
}
?>