<?php include('includes/header.php'); ?>
<?php include('includes/sidebar.php'); ?>

<!-- Nội dung chính -->
<!-- Your page content goes here -->

<?php include('includes/footer.php'); ?>
