<?php
require_once 'config/Database.php';
require_once 'EmployeeRepository.php';

// Khởi tạo kết nối database
$database = new Database();
$conn = $database->getConnection();

// Kiểm tra kết nối
if (!$conn) {
    error_log("Failed to connect to the database.");
    die("Không thể kết nối đến cơ sở dữ liệu. Vui lòng thử lại sau.");
}

// Khởi tạo repository
$employeeRepo = new EmployeeRepository($conn);

// Tính tổng số nhân viên
$totalEmployees = $employeeRepo->getTotalEmployees();

// Tính tỷ lệ đi làm đúng giờ
$punctuality = $employeeRepo->getPunctualityComparison();

// Tính số đơn xin nghỉ phép chờ xét duyệt
$leaveCount = $employeeRepo->getPendingLeaveCount();

// Tính số nhân viên mới
$newEmployees = $employeeRepo->getNewEmployees();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Quản Lý Nhân Sự</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .main-content { padding: 20px; }
        .page-header { display: flex; justify-content: space-between; align-items: center; }
        .dashboard-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
        .card { border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .card-primary { background: rgb(255, 206, 206); color: white; }
        .card-success { background: rgb(255, 253, 205); color: white; }
        .card-warning { background: rgb(199, 255, 248); color: white; }
        .card-danger { background: rgb(253, 199, 255); color: white; }
        .card-body { padding: 20px; }
        .card-icon { font-size: 24px; margin-bottom: 10px; }
        .card-value { font-size: 32px; font-weight: bold; }
        .card-description { font-size: 14px; margin-top: 5px; }
        .card-footer { padding: 10px; background: rgba(0,0,0,0.1); }
        .quick-actions { margin-top: 30px; }
        .action-buttons { display: flex; gap: 10px; flex-wrap: wrap; }
        .action-btn { padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="main-content">
        <div class="page-header">
            <h1>Dashboard Quản Lý Nhân Sự</h1>
            <div class="user-profile">
                <div class="user-info">
                    <span class="user-name">Công nghệ mới</span>
                    <span class="user-role">Quản trị hệ thống</span>
                </div>
            </div>
        </div>

        <div class="dashboard-cards">
            <div class="card card-primary">
                <div class="card-body">
                    <div class="card-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3 class="card-title">Tổng nhân viên</h3>
                    <div class="card-value"><?php echo number_format($totalEmployees); ?></div>
                    <div class="card-description">+<?php echo $newEmployees; ?> so với tháng trước</div>
                </div>
                <div class="card-footer">
                <i class="fas fa-clock"></i> Cập nhật: <span class="datetime"></span>

                </div>
            </div>

            <div class="card card-success">
                <div class="card-body">
                    <div class="card-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <h3 class="card-title">Đi làm đúng giờ</h3>
                    <div class="card-value"><?php echo $punctuality['current']; ?>%</div>
                    <div class="card-description">
                        <?php
                        $diff = abs($punctuality['difference']);
                        if ($diff > 0) {
                            echo ($punctuality['difference'] >= 0 ? '↑' : '↓') . ' ' . $diff . '% so với tháng trước';
                        } else {
                            echo 'Không thay đổi so với tháng trước';
                        }
                        ?>
                    </div>
                </div>
                <div class="card-footer">
                <i class="fas fa-clock"></i> Cập nhật: <span class="datetime"></span>
                </div>
            </div>

            <div class="card card-warning">
                <div class="card-body">
                    <div class="card-icon">
                        <i class="fas fa-calendar-times"></i>
                    </div>
                    <h3 class="card-title">Nghỉ phép</h3>
                    <div class="card-value"><?php echo number_format($leaveCount); ?></div>
                    <div class="card-description">Đơn xin nghỉ chờ xét duyệt</div>
                </div>
                <div class="card-footer">
                <i class="fas fa-clock"></i> Cập nhật: <span class="datetime"></span>
                </div>
            </div>

            <div class="card card-danger">
                <div class="card-body">
                    <div class="card-icon">
                        <i class="fas fa-user-clock"></i>
                    </div>
                    <h3 class="card-title">Nhân viên mới</h3>
                    <div class="card-value"><?php echo number_format($newEmployees); ?></div>
                    <div class="card-description">Trong tháng này</div>
                </div>
                <div class="card-footer">
                <i class="fas fa-clock"></i> Cập nhật: <span class="datetime"></span>
                </div>
            </div>
        </div>

        <div class="quick-actions">
            <h3 class="section-title"><i class="fas fa-bolt"></i> Thao tác nhanh</h3>
            <div class="action-buttons">
                <button class="action-btn" onclick="window.location.href='users.php'">
                    <i class="fas fa-user-plus"></i>
                    <span>Thêm nhân viên</span>
                </button>
                <button class="action-btn">
                    <i class="fas fa-file-import"></i>
                    <span>Nhập dữ liệu</span>
                </button>
                <button class="action-btn">
                    <i class="fas fa-file-export"></i>
                    <span>Xuất báo cáo</span>
                </button>
                <button class="action-btn">
                    <i class="fas fa-envelope"></i>
                    <span>Gửi thông báo</span>
                </button>
                <button class="action-btn">
                    <i class="fas fa-calendar-alt"></i>
                    <span>Lịch làm việc</span>
                </button>
                <button class="action-btn">
                    <i class="fas fa-calculator"></i>
                    <span>Tính lương</span>
                </button>
            </div>
        </div>
    </div>

    <script>
        document.querySelectorAll('.action-btn').forEach(button => {
            button.addEventListener('click', function() {
                this.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 150);
            });
        });

        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function() {
                document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
                this.classList.add('active');
            });
        });
        setInterval(() => {
  const now = new Date().toLocaleString('vi-VN');
  document.querySelectorAll('.datetime').forEach(el => {
    el.innerText = now;
  });
}, 1000);

    </script>
</body>
</html>
