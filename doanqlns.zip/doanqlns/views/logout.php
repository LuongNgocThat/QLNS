<?php
require_once __DIR__ . '/controllers/AuthController.php';

$auth = new AuthController();
$result = $auth->logout();

header('Location: /login.php');
exit();
?>