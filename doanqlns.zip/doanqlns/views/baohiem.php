<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HRM Pro - Bảng Bảo Hiểm và Thuế TNCN</title>

  <!-- Font Awesome & Google Fonts -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

  <!-- CSS chính -->
  <link rel="stylesheet" href="../css/style.css">

  <style>
    /* CSS nội bộ cho bảng và modal */
    body {
      font-family: 'Roboto', sans-serif;
      background: #f4f6f9;
      margin: 0;
      padding: 0;
    }
    .main-content {
      margin-left: 240px;
      padding: 20px;
    }
    h3 {
      font-size: 26px;
      margin-bottom: 20px;
      color: #333;
      text-align: center;
    }
    table {
      border-collapse: collapse;
      width: 100%;
      max-width: 1200px;
      margin: 0 auto 20px;
      background: #fff;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    th, td {
      padding: 8px 10px;
      border-bottom: 1px solid #ddd;
      text-align: left;
      font-size: 0.9rem;
    }
    th {
      background: #007bff;
      color: #fff;
      font-weight: 500;
    }
    tr:nth-child(even) { background: #f9f9f9; }
    tr:hover { background: #eef3f7; }
    .btn-edit, .btn-delete {
      border: none;
      background: none;
      cursor: pointer;
      margin: 0 3px;
      font-size: 0.9rem;
    }
    .btn-edit { color: #007bff; }
    .btn-delete { color: #dc3545; }
    .btn-edit:hover, .btn-delete:hover { opacity: 0.8; }
    input[readonly], input[disabled] {
        background-color: #e9ecef;
        cursor: not-allowed;
        }

    /* Modal */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0; top: 0;
      width: 100%; height: 100%;
      background-color: rgba(0,0,0,0.5);
      justify-content: center;
      align-items: center;
    }
    .modal-content {
      background: #fff;
      padding: 20px;
      width: 90%;
      max-width: 500px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
      position: relative;
    }
    .close {
      position: absolute;
      top: 10px; right: 15px;
      font-size: 28px;
      cursor: pointer;
      color: #aaa;
    }
    .close:hover { color: black; }
    .modal-header {
      font-size: 1.4rem;
      margin-bottom: 15px;
      font-weight: bold;
      text-align: center;
    }
    .modal-body label {
      margin-top: 10px;
      display: block;
      font-weight: 500;
    }
    .modal-body input {
      width: 100%;
      padding: 8px;
      margin-top: 5px;
      margin-bottom: 10px;
      font-size: 0.9rem;
      border: 1px solid #ddd;
      border-radius: 5px;
    }
    .modal-footer {
      text-align: center;
    }
    .modal-footer button {
      padding: 10px 20px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    .modal-footer button:hover {
      background-color: #0056b3;
    }
  </style>
</head>

<body>

<?php include('../includes/sidebar.php'); ?>

<div class="main-content">
  <h3>Bảng Bảo Hiểm và Thuế TNCN</h3>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Nhân Viên</th>
        <th>Tháng</th>
        <th>BHXH</th>
        <th>BHYT</th>
        <th>BHTN</th>
        <th>Thuế TNCN</th>
        <th>Tổng Khoản Trừ</th>
        <th>Hành động</th>
      </tr>
    </thead>
    <tbody id="baoHiemThueTableBody">
      <tr><td colspan="9">Đang tải dữ liệu...</td></tr>
    </tbody>
  </table>
</div>

<!-- Modal -->
<div id="editModal" class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <div class="modal-header">Sửa Thông Tin</div>
    <div class="modal-body">
      <label for="ho_ten">Tên Nhân Viên:</label>
      <input type="text" id="ho_ten" disabled>

      <label for="thang">Tháng:</label>
      <input type="text" id="thang" required>

      <label for="bhxh">BHXH:</label>
      <input type="text" id="bhxh" required>

      <label for="bhyt">BHYT:</label>
      <input type="text" id="bhyt" required>

      <label for="bhtn">BHTN:</label>
      <input type="text" id="bhtn" required>

      <label for="thue_tncn">Thuế TNCN:</label>
      <input type="text" id="thue_tncn" required>

      <label for="tong_khoan_tru">Tổng Khoản Trừ:</label>
      <input type="text" id="tong_khoan_tru" readonly>
    </div>
    <div class="modal-footer">
      <button id="updateBtn">Cập Nhật</button>
    </div>
  </div>
</div>

<script>
let currentEditId = null;

// Load bảng khi mở trang
fetch("http://localhost/doanqlns/index.php/api/baohiem")
  .then(response => response.json())
  .then(data => {
    const tableBody = document.getElementById("baoHiemThueTableBody");
    tableBody.innerHTML = "";

    if (Array.isArray(data) && data.length > 0) {
      data.forEach(record => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${record.id}</td>
          <td>${record.ho_ten}</td>
          <td>${record.thang}</td>
          <td>${formatNumber(record.bhxh)}</td>
          <td>${formatNumber(record.bhyt)}</td>
          <td>${formatNumber(record.bhtn)}</td>
          <td>${formatNumber(record.thue_tncn)}</td>
          <td>${formatNumber(record.tong_khoan_tru)}</td>
          <td>
            <button class="btn-edit" onclick="openEditModal(${record.id}, '${record.ho_ten}', '${record.thang}', '${record.bhxh}', '${record.bhyt}', '${record.bhtn}', '${record.thue_tncn}')"><i class="fas fa-edit"></i></button>
            <button class="btn-delete" onclick="deleteBaoHiemThuetncn(${record.id})"><i class="fas fa-trash-alt"></i></button>
          </td>
        `;
        tableBody.appendChild(row);
      });

    } else {
      tableBody.innerHTML = '<tr><td colspan="9">Không có dữ liệu</td></tr>';
    }
  })
  .catch(error => {
    console.error("Lỗi khi tải dữ liệu:", error);
    document.getElementById("baoHiemThueTableBody").innerHTML = '<tr><td colspan="9">Lỗi khi tải dữ liệu</td></tr>';
  });

// Mở modal
function openEditModal(id, ho_ten, thang, bhxh, bhyt, bhtn, thue_tncn) {
  currentEditId = id;
  document.getElementById("ho_ten").value = ho_ten;
  document.getElementById("thang").value = thang;
  document.getElementById("bhxh").value = bhxh;
  document.getElementById("bhyt").value = bhyt;
  document.getElementById("bhtn").value = bhtn;
  document.getElementById("thue_tncn").value = thue_tncn;
  calculateTongKhoanTru();
  document.getElementById("editModal").style.display = "flex";
}


// Đóng modal
document.querySelector(".close").onclick = () => {
  document.getElementById("editModal").style.display = "none";
};

window.onclick = (e) => {
  if (e.target === document.getElementById("editModal")) {
    document.getElementById("editModal").style.display = "none";
  }
};
function formatNumber(num) {
  return Number(num).toLocaleString('en-US');
}

// Tính tổng khoản trừ
function calculateTongKhoanTru() {
  const bhxh = parseFloat(document.getElementById("bhxh").value.replace(/,/g, '')) || 0;
  const bhyt = parseFloat(document.getElementById("bhyt").value.replace(/,/g, '')) || 0;
  const bhtn = parseFloat(document.getElementById("bhtn").value.replace(/,/g, '')) || 0;
  const thue = parseFloat(document.getElementById("thue_tncn").value.replace(/,/g, '')) || 0;
  const tong = bhxh + bhyt + bhtn + thue;
  document.getElementById("tong_khoan_tru").value = tong.toLocaleString('en-US');
}



// Khi nhập các ô liên quan thì tính lại
['bhxh', 'bhyt', 'bhtn', 'thue_tncn'].forEach(id => {
  document.getElementById(id).addEventListener('input', calculateTongKhoanTru);
});

// Cập nhật bản ghi
document.getElementById("updateBtn").onclick = () => {
  if (!currentEditId) {
    alert("Không xác định ID cần cập nhật!");
    return;
  }

  const data = {
  thang: document.getElementById("thang").value,
  bhxh: document.getElementById("bhxh").value,
  bhyt: document.getElementById("bhyt").value,
  bhtn: document.getElementById("bhtn").value,
  thue_tncn: document.getElementById("thue_tncn").value,
  tong_khoan_tru: document.getElementById("tong_khoan_tru").value.replace(/,/g, '') // bỏ dấu phẩy
};


  fetch(`http://localhost/doanqlns/index.php/api/baohiem?id=${currentEditId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  })
  .then(response => response.json())
  .then(result => {
    if (result.success) {
      alert("Cập nhật thành công!");
      location.reload();
    } else {
      alert("Cập nhật thất bại!");
    }
  })
  .catch(error => {
    console.error("Lỗi cập nhật:", error);
    alert("Có lỗi xảy ra!");
  });
};

// Xóa bản ghi
function deleteBaoHiemThuetncn(id) {
  if (!confirm("Bạn chắc chắn muốn xóa bản ghi này?")) return;

  fetch(`http://localhost/doanqlns/index.php/api/baohiem?id=${id}`, {
    method: 'DELETE'
  })
  .then(response => response.json())
  .then(result => {
    if (result.success) {
      alert("Xóa thành công!");
      location.reload();
    } else {
      alert("Xóa thất bại!");
    }
  })
  .catch(error => {
    console.error("Lỗi khi xóa:", error);
    alert("Có lỗi xảy ra!");
  });
}
</script>

</body>
</html>
