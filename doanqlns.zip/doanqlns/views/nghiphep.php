<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Bảng Nghỉ Phép</title>

    <!-- Font Awesome & Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- CSS chính -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/stylenghiphep.css">

    <!-- CSS riêng -->
    <style>
      
    </style>
</head>

<body>


<?php include('../includes/sidebar.php'); ?>

<div class="main-content">
    <h3>Bảng Nghỉ Phép</h3>
    <table>
        <thead>
            <tr>
                <th>ID Nghỉ Phép</th>
                <th>Nhân Viên</th>
                <th>Ngày Bắt Đầu</th>
                <th>Ngày Kết Thúc</th>
                <!-- <th>Loại Nghỉ</th> -->
                <th>Lý Do</th>
                <th>Trạng Thái</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody id="nghiPhepTableBody">
            <tr><td colspan="8">Đang tải dữ liệu...</td></tr>
        </tbody>
    </table>
   
<!-- Modal chi tiết đơn nghỉ phép -->
<div id="detailNghiPhepModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Chi tiết đơn nghỉ phép</h2>
            <span class="close" onclick="closeDetailModal()">&times;</span>
        </div>
        <div class="modal-body">
            <div class="info-group">
                <label>Họ và tên:</label>
                <span id="detailHoTen" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Giới tính:</label>
                <span id="detailGioiTinh" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Ngày sinh:</label>
                <span id="detailNgaySinh" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Email:</label>
                <span id="detailEmail" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Số điện thoại:</label>
                <span id="detailSoDienThoai" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Địa chỉ:</label>
                <span id="detailDiaChi" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Phòng ban:</label>
                <span id="detailPhongBan" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Chức vụ:</label>
                <span id="detailChucVu" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Loại nghỉ:</label>
                <span id="detailLoaiNghi" class="info-value"></span>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-close" onclick="closeDetailModal()">Đóng</button>
        </div>
    </div>
</div>

    <!-- Modal Sửa Trạng Thái -->
    <div id="editNghiPhepModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Sửa Trạng Thái Đơn Nghỉ Phép</h2>
                <button class="modal-close" onclick="closeEditModal()">×</button>
            </div>
            <div class="modal-body">
                <label for="editStatus">Trạng Thái:</label>
                <select id="editStatus">
                    <option value="Chờ duyệt">Chờ duyệt</option>
                    <option value="Từ chối">Từ chối</option>
                    <option value="Duyệt">Duyệt</option>
                </select>
                <input type="hidden" id="editIdNghiPhep">
                <input type="hidden" id="editIdNhanVien">
                <input type="hidden" id="editNgayBatDau">
                <input type="hidden" id="editNgayKetThuc">
            </div>
            <div class="modal-footer">
                <button class="btn-save" onclick="saveNghiPhepStatus()">Lưu</button>
            </div>
        </div>
    </div>
</div>

<script>
// Dữ liệu nghỉ phép
// Dữ liệu nghỉ phép
let nghiPhepData = [];

// Tải dữ liệu nghỉ phép
async function loadNghiPhepData() {
    try {
        const response = await fetch("http://localhost/doanqlns/index.php/api/nghiphep");
        if (!response.ok) throw new Error("Lỗi khi tải dữ liệu: " + response.status);
        const data = await response.json();
        if (!Array.isArray(data)) throw new Error("Dữ liệu không hợp lệ");
        
        nghiPhepData = data;
        renderNghiPhepTable(data);
    } catch (error) {
        console.error("Lỗi khi tải dữ liệu:", error);
        document.getElementById("nghiPhepTableBody").innerHTML = '<tr><td colspan="8">Lỗi khi tải dữ liệu</td></tr>';
    }
}

// Hiển thị bảng nghỉ phép
function renderNghiPhepTable(data) {
    const tableBody = document.getElementById("nghiPhepTableBody");
    tableBody.innerHTML = "";

    if (data && Array.isArray(data) && data.length > 0) {
        data.forEach(record => {
            const row = document.createElement("tr");
            let statusClass = "";
            let displayStatus = record.trang_thai1;
            switch (record.trang_thai1.toLowerCase()) {
                case "đã duyệt":
                    statusClass = "daduyet";
                    displayStatus = "Duyệt";
                    break;
                case "từ chối":
                    statusClass = "tuchoi";
                    break;
                case "chờ xét duyệt":
                    statusClass = "choxetduyet";
                    displayStatus = "Chờ duyệt";
                    break;
                default:
                    statusClass = "choxetduyet";
                    displayStatus = "Chờ duyệt";
                    break;
            }
            row.innerHTML = `
                <td>${record.id_nghi_phep}</td>
                <td style="cursor: pointer;" onclick="showDetailNghiPhep(${record.id_nghi_phep})">${record.ho_ten}</td>
                <td>${record.ngay_bat_dau}</td>
                <td>${record.ngay_ket_thuc}</td>
                
                <td>${record.ly_do}</td>
                <td><span class="status ${statusClass}">${displayStatus}</span></td>
                <td>
                    <button class="btn-edit" onclick="editNghiPhep(${record.id_nghi_phep}, ${record.id_nhan_vien}, '${record.ngay_bat_dau}', '${record.ngay_ket_thuc}', '${record.trang_thai1}')" title="Chỉnh sửa trạng thái">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-delete" onclick="deleteNghiPhep(${record.id_nghi_phep})" title="Xóa đơn nghỉ phép">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    } else {
        tableBody.innerHTML = '<tr><td colspan="7">Không có dữ liệu</td></tr>';
    }
}

// Hiển thị modal chi tiết
function showDetailNghiPhep(idNghiPhep) {
    const record = nghiPhepData.find(r => r.id_nghi_phep == idNghiPhep);
    if (record) {
        document.getElementById('detailHoTen').textContent = record.ho_ten || 'N/A';
        document.getElementById('detailGioiTinh').textContent = record.gioi_tinh || 'N/A';
        document.getElementById('detailNgaySinh').textContent = record.ngay_sinh || 'N/A';
        document.getElementById('detailEmail').textContent = record.email || 'N/A';
        document.getElementById('detailSoDienThoai').textContent = record.so_dien_thoai || 'N/A';
        document.getElementById('detailDiaChi').textContent = record.dia_chi || 'N/A';
        document.getElementById('detailPhongBan').textContent = record.phong_ban || 'N/A';
        document.getElementById('detailChucVu').textContent = record.chuc_vu || 'N/A';
        document.getElementById('detailLoaiNghi').textContent = record.loai_nghi || 'N/A';
        document.getElementById('detailNghiPhepModal').style.display = 'flex';
    } else {
        alert("Không tìm thấy thông tin đơn nghỉ phép!");
    }
}

// Đóng modal chi tiết
function closeDetailModal() {
    document.getElementById('detailNghiPhepModal').style.display = 'none';
}

// (Giữ nguyên các hàm khác: editNghiPhep, saveNghiPhepStatus, updateChamCong, deleteNghiPhep...)

// Đóng modal khi nhấp ra ngoài
document.getElementById('detailNghiPhepModal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('detailNghiPhepModal')) {
        closeDetailModal();
    }
});

// Tải dữ liệu khi trang được tải
loadNghiPhepData();

// Hiển thị modal sửa trạng thái
function editNghiPhep(id, idNhanVien, ngayBatDau, ngayKetThuc, trangThai) {
    document.getElementById('editIdNghiPhep').value = id;
    document.getElementById('editIdNhanVien').value = idNhanVien;
    document.getElementById('editNgayBatDau').value = ngayBatDau;
    document.getElementById('editNgayKetThuc').value = ngayKetThuc;
    const displayStatus = trangThai.toLowerCase() === 'đã duyệt' ? 'Duyệt' : 
                         (trangThai.toLowerCase() === 'chờ xét duyệt' ? 'Chờ duyệt' : trangThai);
    document.getElementById('editStatus').value = displayStatus;
    document.getElementById('editNghiPhepModal').style.display = 'flex';
}

// Đóng modal
function closeEditModal() {
    document.getElementById('editNghiPhepModal').style.display = 'none';
}

// Trong hàm saveNghiPhepStatus
async function saveNghiPhepStatus() {
    const idNghiPhep = document.getElementById('editIdNghiPhep').value;
    const idNhanVien = document.getElementById('editIdNhanVien').value;
    const ngayBatDau = document.getElementById('editNgayBatDau').value;
    const ngayKetThuc = document.getElementById('editNgayKetThuc').value;
    let trangThai = document.getElementById('editStatus').value;

    // Map frontend status to backend status for NGHI_PHEP
    const trangThaiForBackend = trangThai === 'Duyệt' ? 'Đã duyệt' : 
                               (trangThai === 'Chờ duyệt' ? 'Chờ xét duyệt' : trangThai);

    try {
        // Chỉ gửi id_nguoi_duyet cho Đã duyệt và Từ chối
        const idNguoiDuyet = (trangThai === 'Duyệt' || trangThai === 'Từ chối') ? 1 : null;

        // Log payload
        const payload = {
            trang_thai1: trangThaiForBackend,
            id_nguoi_duyet: idNguoiDuyet
        };
        console.log('PUT Payload:', payload);

        // Cập nhật trạng thái đơn nghỉ phép bằng phương thức PUT
        const response = await fetch(`http://localhost/doanqlns/index.php/api/nghiphep?id=${idNghiPhep}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            throw new Error(`Lỗi HTTP: ${response.status} ${response.statusText}`);
        }

        const result = await response.json();
        console.log('PUT Response:', result);

        if (result.success) {
            // Cập nhật bảng chấm công
            await updateChamCong(idNhanVien, ngayBatDau, ngayKetThuc, trangThai);
            
            // Tải lại dữ liệu nghỉ phép
            await loadNghiPhepData();
            closeEditModal();
            alert("Cập nhật trạng thái thành công!");
        } else {
            throw new Error(result.message || "Lỗi khi cập nhật trạng thái");
        }
    } catch (error) {
        console.error("Lỗi khi cập nhật trạng thái:", error, error.stack);
        alert("Lỗi khi cập nhật trạng thái: " + error.message);
    }
}

// Cập nhật bảng chấm công dựa trên trạng thái đơn nghỉ phép
async function updateChamCong(idNhanVien, ngayBatDau, ngayKetThuc, trangThai) {
    const startDate = new Date(ngayBatDau);
    const endDate = new Date(ngayKetThuc);
    const dates = [];

    // Tạo danh sách các ngày trong khoảng thời gian nghỉ phép
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
        const dateStr = `${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, '0')}-${d.getDate().toString().padStart(2, '0')}`;
        const isSunday = d.getDay() === 0;

        // Bỏ qua ngày Chủ nhật
        if (!isSunday) {
            dates.push(dateStr);
        }
    }

    // Xác định trạng thái chấm công
    let chamCongStatus;
    switch (trangThai.toLowerCase()) {
        case "duyệt":
            chamCongStatus = "Có phép";
            break;
        case "từ chối":
            chamCongStatus = "Không phép";
            break;
        case "chờ duyệt":
            chamCongStatus = "Chưa điểm danh";
            break;
        default:
            chamCongStatus = "Chưa điểm danh";
            break;
    }

    // Cập nhật hoặc thêm mới trạng thái chấm công cho từng ngày
    for (const date of dates) {
        const data = {
            id_nhan_vien: idNhanVien,
            ngay_lam_viec: date,
            gio_vao: '00:00:00',
            gio_ra: '00:00:00',
            gio_lam_them: 0,
            trang_thai: chamCongStatus,
            ghi_chu: '',
            month: parseInt(date.split('-')[1]),
            year: parseInt(date.split('-')[0])
        };

        try {
            // Gửi POST request để thêm hoặc cập nhật
            const response = await fetch("http://localhost/doanqlns/index.php/api/chamcong", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            console.log(`POST ChamCong Response for ${date}:`, result);
            if (!result.success) {
                throw new Error(result.message || `Lỗi khi cập nhật chấm công cho ngày ${date}`);
            }
        } catch (error) {
            console.error(`Lỗi khi cập nhật chấm công cho ngày ${date}:`, error);
            alert(`Lỗi khi cập nhật chấm công cho ngày ${date}: ${error.message}`);
        }
    }
}


// Hàm Xóa
async function deleteNghiPhep(id) {
    if (confirm("Bạn có chắc chắn muốn xóa đơn nghỉ phép ID " + id + " không?")) {
        try {
            const response = await fetch(`http://localhost/doanqlns/index.php/api/nghiphep?id=${id}`, {
                method: 'DELETE'
            });
            const result = await response.json();

            if (result.success) {
                await loadNghiPhepData();
                alert("Đã xóa đơn nghỉ phép với ID: " + id);
            } else {
                throw new Error(result.message || "Lỗi khi xóa đơn nghỉ phép");
            }
        } catch (error) {
            console.error("Lỗi khi xóa đơn nghỉ phép:", error);
            alert("Lỗi khi xóa đơn nghỉ phép: " + error.message);
        }
    }
}

// Đóng modal khi nhấp ra ngoài
document.getElementById('editNghiPhepModal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('editNghiPhepModal')) {
        closeEditModal();
    }
});

// Tải dữ liệu khi trang được tải
loadNghiPhepData();
</script>

</body>
</html>