<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Bảng Lương</title>

    <!-- Font Awesome & Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- CSS chính -->
    <link rel="stylesheet" href="../css/style.css">

    <!-- CSS riêng -->
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 0;
        }
        .main-content {
            margin-left: 240px;
            padding: 20px;
            overflow-x: auto;
        }
        h3 {
            font-size: 26px;
            margin-bottom: 20px;
            color: #333;
            text-align: center;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            max-width: 1300px;
            margin: 0 auto 20px;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 14px 16px;
            border-bottom: 1px solid #ddd;
            text-align: left;
            word-wrap: break-word;
        }
        th {
            background: #007bff;
            color: #fff;
            font-weight: 500;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        tr:hover {
            background: #eef3f7;
        }
        .btn-edit, .btn-delete {
            border: none;
            background: none;
            cursor: pointer;
            margin: 0 5px;
            font-size: 1rem;
        }
        .btn-edit {
            color: #007bff;
        }
        .btn-delete {
            color: #dc3545;
        }
        .btn-edit:hover, .btn-delete:hover {
            opacity: 0.8;
        }
        @media (max-width: 768px) {
            table {
                width: 100%;
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }
            th, td {
                padding: 10px;
            }
            h3 {
                font-size: 22px;
            }
        }
    </style>
</head>

<body>

<?php include('../includes/sidebar.php'); ?>

<div class="main-content">
    <h3>Bảng Lương</h3>
    <table>
        <thead>
            <tr>
                <th>Mã Lương</th>
                <th>Tên Nhân Viên</th>
                <th>Tháng</th>
                <th>Số Ngày Công</th>
                <th>Lương Cơ Bản</th>
                <th>Phụ Cấp</th>
                <th>Lương Làm Thêm</th>
                
               
                
                <th>Tiền Thưởng</th>
                <th>Các Khoản Trừ</th>
                <th>Lương Thực Nhận</th>
                <!-- <th>Hành động</th> -->
            </tr>
        </thead>
        <tbody id="luongTableBody">
            <tr><td colspan="11">Đang tải dữ liệu...</td></tr>
        </tbody>
    </table>
</div>
<script>
function formatCurrency(value) {
    if (value == null || value == undefined) return '0';
    return Number(value).toLocaleString('en-US'); // <-- dấu phẩy
}

fetch("http://localhost/doanqlns/index.php/api/luong")
    .then(response => response.json())
    .then(data => {
        const tableBody = document.getElementById("luongTableBody");
        tableBody.innerHTML = ""; // Xóa dòng đang tải

        if (data && Array.isArray(data)) {
            data.forEach(record => {
                const row = document.createElement("tr");
                row.innerHTML = `
                    <td>${record.id_luong}</td>
                    <td>${record.ho_ten}</td>
                    <td>${record.thang}</td>
                    <td>${record.so_ngay_cong}</td>
                    <td>${formatCurrency(record.luong_co_ban)}</td>
                    <td>${formatCurrency(record.phu_cap_chuc_vu)}</td>
                    <td>${formatCurrency(record.luong_lam_them)}</td>
                    <td>${formatCurrency(record.tien_thuong)}</td>
                    <td>${formatCurrency(record.cac_khoan_tru)}</td>
                    <td>${formatCurrency(record.luong_thuc_nhan)}</td>
                `;
                tableBody.appendChild(row);
            });
        } else {
            tableBody.innerHTML = '<tr><td colspan="11">Không có dữ liệu</td></tr>';
        }
    })
    .catch(error => {
        console.error("Lỗi khi tải dữ liệu:", error);
        document.getElementById("luongTableBody").innerHTML = '<tr><td colspan="11">Lỗi khi tải dữ liệu</td></tr>';
    });
</script>

</body>
</html>
