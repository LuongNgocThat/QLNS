<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Bảng Chấm Công</title>

    <!-- Font Awesome & Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- CSS chính -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/stylechamcong.css">
    <style>
       
    </style>
</head>

<body>
    <?php include('../includes/sidebar.php'); ?>

    <div class="main-content">
        <h3>Bảng Chấm Công</h3>

        <!-- Nút Điểm Danh -->
        <div class="action-container">
            <button class="btn-diemdanh" onclick="showDiemDanhModal()">
                <i class="fas fa-check-circle"></i> Điểm Danh
            </button>
        </div>

        <!-- Điều hướng ngày -->
        <div class="date-navigation">
            <button onclick="changeDate(-1)" aria-label="Ngày trước"><i class="fas fa-chevron-left"></i></button>
            <span id="selectedDate"></span>
            <button onclick="changeDate(1)" aria-label="Ngày sau"><i class="fas fa-chevron-right"></i></button>
        </div>

        <!-- Bảng chấm công chính -->
        <table>
            <thead>
                <tr>
                    <th>ID Chấm Công</th>
                    <th>Nhân Viên</th>
                    <th>Ngày Công</th>
                    <th>Giờ Vào</th>
                    <th>Giờ Ra</th>
                    <th>Trạng Thái</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody id="chamCongTableBody">
                <tr><td colspan="7">Chưa có dữ liệu. Vui lòng điểm danh để hiển thị.</td></tr>
            </tbody>
        </table>

        <!-- Modal Điểm Danh -->
        <div id="diemDanhModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">Điểm Danh Nhân Viên</h2>
                    <button class="modal-close" aria-label="Đóng modal">×</button>
                </div>
                <div class="modal-body">
                    <div class="filter-container">
                        <select id="selectMonth" onchange="updateAttendanceTable()" aria-label="Chọn tháng">
                            <option value="1">Tháng 1</option>
                            <option value="2">Tháng 2</option>
                            <option value="3">Tháng 3</option>
                            <option value="4" selected>Tháng 4</option>
                            <option value="5">Tháng 5</option>
                            <option value="6">Tháng 6</option>
                            <option value="7">Tháng 7</option>
                            <option value="8">Tháng 8</option>
                            <option value="9">Tháng 9</option>
                            <option value="10">Tháng 10</option>
                            <option value="11">Tháng 11</option>
                            <option value="12">Tháng 12</option>
                        </select>
                        <input type="number" id="selectYear" min="2000" max="2100" onchange="updateAttendanceTable()" aria-label="Nhập năm"/>
                    </div>
                    <div class="attendance-table-container">
                        <table class="attendance-table" id="attendanceTable">
                            <thead id="attendanceTableHead"></thead>
                            <tbody id="attendanceTableBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Loading indicator -->
        <div class="loading" id="loadingIndicator"></div>
    </div>

    <script>
        // Biến toàn cục
        let usersData = [];
        let attendanceData = [];
        let selectedDate = new Date(); // Ngày hiện tại

        // Tham chiếu đến các phần tử DOM
        const chamCongTableBody = document.getElementById("chamCongTableBody");
        const selectedDateElement = document.getElementById("selectedDate");
        const diemDanhModal = document.getElementById("diemDanhModal");
        const loadingIndicator = document.getElementById("loadingIndicator");

        // Hàm hiển thị loading
        function showLoading() {
            loadingIndicator.style.display = "flex";
        }

        // Hàm ẩn loading
        function hideLoading() {
            loadingIndicator.style.display = "none";
        }

        // Hàm lấy dữ liệu chấm công từ API
        async function loadAttendanceData() {
            showLoading();
            try {
                const response = await fetch("http://localhost/doanqlns/index.php/api/chamcong");
                if (!response.ok) throw new Error("Lỗi khi tải dữ liệu chấm công: " + response.status);
                const data = await response.json();
                if (!Array.isArray(data)) throw new Error("Dữ liệu chấm công không hợp lệ");
                attendanceData = data;
                console.log("Dữ liệu chấm công sau khi tải:", attendanceData);
                renderChamCongTable(data);
            } catch (error) {
                console.error("Lỗi khi tải dữ liệu:", error);
                chamCongTableBody.innerHTML = '<tr><td colspan="7">Lỗi khi tải dữ liệu</td></tr>';
            } finally {
                hideLoading();
            }
        }

        // Hàm lấy danh sách nhân viên từ API
        async function loadUsersData() {
            showLoading();
            try {
                const response = await fetch("http://localhost/doanqlns/index.php/api/users");
                if (!response.ok) throw new Error("Lỗi khi tải danh sách nhân viên: " + response.status);
                const data = await response.json();
                if (!Array.isArray(data)) throw new Error("Danh sách nhân viên không hợp lệ");
                usersData = data;
                console.log("Danh sách nhân viên:", usersData);
            } catch (error) {
                console.error("Lỗi khi tải danh sách nhân viên:", error);
            } finally {
                hideLoading();
            }
        }

        // Hàm hiển thị bảng chấm công chính
        function renderChamCongTable(data) {
            const selectedDateStr = `${selectedDate.getFullYear()}-${(selectedDate.getMonth() + 1).toString().padStart(2, '0')}-${selectedDate.getDate().toString().padStart(2, '0')}`;
            selectedDateElement.textContent = `${selectedDate.getDate().toString().padStart(2, '0')}/${(selectedDate.getMonth() + 1).toString().padStart(2, '0')}/${selectedDate.getFullYear()}`;

            const filteredData = data.filter(record => record.ngay_lam_viec === selectedDateStr);
            chamCongTableBody.innerHTML = "";

            if (filteredData.length > 0) {
                filteredData.forEach(record => {
                    const statusClass = {
                        "đúng giờ": "dadiemdanh",
                        "đi trễ": "ditre",
                        "có phép": "cophep",
                        "không phép": "khongphep",
                        "nghỉ việc": "nghiviec"
                    }[record.trang_thai.toLowerCase()] || "chuadiemdanh";

                    const row = document.createElement("tr");
                    row.innerHTML = `
                        <td>${record.id_cham_cong}</td>
                        <td>${record.ho_ten}</td>
                        <td>${record.ngay_lam_viec}</td>
                        <td>${record.gio_vao || ''}</td>
                        <td>${record.gio_ra || ''}</td>
                        <td><span class="status ${statusClass}">${record.trang_thai}</span></td>
                        <td>
                            <button class="btn-delete" onclick="deleteChamCong(${record.id_cham_cong})">
                                <i class="fas fa-trash-alt"></i> Xóa
                            </button>
                        </td>
                    `;
                    chamCongTableBody.appendChild(row);
                });
            } else {
                chamCongTableBody.innerHTML = `
                    <tr>
                        <td colspan="7">Chưa có dữ liệu cho ngày ${selectedDateElement.textContent}. Vui lòng điểm danh để hiển thị.</td>
                    </tr>
                `;
            }
        }

        // Hàm thay đổi ngày
        function changeDate(direction) {
            selectedDate.setDate(selectedDate.getDate() + direction);
            renderChamCongTable(attendanceData);
        }

        // Hàm hiển thị modal điểm danh
        async function showDiemDanhModal() {
            const currentDate = new Date();
            document.getElementById('selectMonth').value = currentDate.getMonth() + 1;
            document.getElementById('selectYear').value = currentDate.getFullYear();
            diemDanhModal.style.display = 'flex';
            await loadAttendanceData();
            updateAttendanceTable();
        }

        // Hàm tính thống kê chấm công
        function calculateAttendanceStats(userId, month, year) {
            const startDate = new Date(year, month - 1, 1);
            const endDate = new Date(year, month, 0);
            const records = attendanceData.filter(record => {
                const recordDate = new Date(record.ngay_lam_viec);
                return record.id_nhan_vien == userId && 
                       recordDate >= startDate && 
                       recordDate <= endDate;
            });

            let diemDanhDays = 0;
            let nghiDays = 0;

            for (let day = 1; day <= endDate.getDate(); day++) {
                const date = new Date(year, month - 1, day);
                const dateStr = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
                const isSunday = date.getDay() === 0;
                const record = records.find(r => r.ngay_lam_viec === dateStr);

                if (isSunday) {
                    diemDanhDays += 1;
                } else if (record) {
                    if (record.trang_thai === 'Đúng giờ') {
                        diemDanhDays += 1;
                    } else if (record.trang_thai === 'Đi trễ') {
                        diemDanhDays += 0.25;
                    } else if (record.trang_thai === 'Có phép') {
                        nghiDays += 0.5;
                    } else if (record.trang_thai === 'Không phép') {
                        nghiDays += 1;
                    }
                }
            }

            const totalWorkDays = diemDanhDays - nghiDays;
            console.log(`Nhân viên ${userId}, tháng ${month}/${year}: Điểm danh=${diemDanhDays}, Nghỉ=${nghiDays}, Tổng công=${totalWorkDays}`);
            return { diemDanhDays, nghiDays, totalWorkDays };
        }

        // Hàm cập nhật bảng điểm danh trong modal
        async function updateAttendanceTable() {
            const month = parseInt(document.getElementById('selectMonth').value);
            const yearInput = document.getElementById('selectYear');
            const year = parseInt(yearInput.value) || new Date().getFullYear();
            const daysInMonth = new Date(year, month, 0).getDate();

            const tableHead = document.getElementById('attendanceTableHead');
            const tableBody = document.getElementById('attendanceTableBody');

            if (!yearInput.value) {
                yearInput.value = new Date().getFullYear();
            }

            const currentDate = new Date();
            const currentYear = currentDate.getFullYear();
            const currentMonth = currentDate.getMonth() + 1;
            const currentDay = currentDate.getDate();

            console.log(`Ngày hiện tại: ${currentDay}/${currentMonth}/${currentYear}`);
            console.log("Dữ liệu chấm công trước khi cập nhật bảng:", attendanceData);

            let headerRow = `
                <tr>
                    <th>ID Chấm Công</th>
                    <th>ID Nhân Viên</th>
                    <th>Họ Tên</th>
            `;
            for (let day = 1; day <= daysInMonth; day++) {
                const date = new Date(year, month - 1, day);
                const weekday = date.toLocaleDateString('vi-VN', { weekday: 'short' });
                // Kiểm tra nếu cột là ngày hiện tại
                const isCurrentDay = (year === currentYear && month === currentMonth && day === currentDay);
                headerRow += `
                    <th class="${isCurrentDay ? 'current-day-column' : ''}">
                        <div class="day-header">${day}</div>
                        <div class="weekday-header">${weekday}</div>
                    </th>
                `;
            }
            headerRow += `
                    <th>Điểm danh</th>
                    <th>Số ngày nghỉ</th>
                    <th>Tổng công</th>
                </tr>`;
            tableHead.innerHTML = headerRow;

            tableBody.innerHTML = '';

            if (!usersData || usersData.length === 0) {
                tableBody.innerHTML = `<tr><td colspan="${daysInMonth + 5}">Không có dữ liệu nhân viên</td></tr>`;
                return;
            }

            usersData.forEach(user => {
                const row = document.createElement('tr');
                let rowContent = `
                    <td>${user.id_nhan_vien * 1000 + 1}</td>
                    <td>${user.id_nhan_vien}</td>
                    <td>${user.ho_ten}</td>
                `;

                for (let day = 1; day <= daysInMonth; day++) {
                    const date = new Date(year, month - 1, day);
                    const dateStr = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
                    const isSunday = date.getDay() === 0;
                    const isFutureDate = year > currentYear ||
                        (year === currentYear && month > currentMonth) ||
                        (year === currentYear && month === currentMonth && day > currentDay);

                    const attendanceRecord = attendanceData.find(record =>
                        record.id_nhan_vien == user.id_nhan_vien &&
                        record.ngay_lam_viec === dateStr
                    );

                    let currentStatus = attendanceRecord ? attendanceRecord.trang_thai : 'Chưa điểm danh';
                    let isDisabled = isFutureDate;

                    if (isSunday) {
                        currentStatus = 'Đúng giờ';
                        isDisabled = true;

                        if (!attendanceRecord) {
                            const data = {
                                id_nhan_vien: user.id_nhan_vien,
                                ngay_lam_viec: dateStr,
                                gio_vao: '08:00:00',
                                gio_ra: '17:00:00',
                                trang_thai: 'Đúng giờ',
                                month: month,
                                year: year
                            };

                            fetch("http://localhost/doanqlns/index.php/api/chamcong", {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify(data)
                            })
                            .then(response => response.json())
                            .then(result => {
                                if (result.success) {
                                    console.log(`Tự động thêm điểm danh "Đúng giờ" cho Chủ nhật ${dateStr}, nhân viên ${user.id_nhan_vien}`);
                                } else {
                                    console.error("Thêm điểm danh thất bại:", result.message);
                                }
                            })
                            .catch(error => console.error("Lỗi khi tự động thêm điểm danh:", error));
                        }
                    }

                    // Kiểm tra nếu ô thuộc cột ngày hiện tại
                    const isCurrentDay = (year === currentYear && month === currentMonth && day === currentDay);
                    console.log(`Trạng thái cho nhân viên ${user.id_nhan_vien}, ngày ${dateStr}: ${currentStatus}`);
                    rowContent += `
                        <td class="${isCurrentDay ? 'current-day-cell' : ''}">
                            <select class="status-select" 
                                    data-id="${user.id_nhan_vien}" 
                                    data-date="${dateStr}" 
                                    onchange="updateAttendance(this)"
                                    ${isDisabled ? 'disabled' : ''}>
                                <option value="Chưa điểm danh" ${currentStatus === 'Chưa điểm danh' ? 'selected' : ''}>Chưa điểm danh</option>
                                <option value="Đúng giờ" ${currentStatus === 'Đúng giờ' ? 'selected' : ''}>Đúng giờ</option>
                                <option value="Đi trễ" ${currentStatus === 'Đi trễ' ? 'selected' : ''}>Đi trễ</option>
                                <option value="Có phép" ${currentStatus === 'Có phép' ? 'selected' : ''}>Có phép</option>
                                <option value="Không phép" ${currentStatus === 'Không phép' ? 'selected' : ''}>Không phép</option>
                            </select>
                        </td>
                    `;
                }

                const { diemDanhDays, nghiDays, totalWorkDays } = calculateAttendanceStats(user.id_nhan_vien, month, year);
                rowContent += `
                    <td class="diem-danh-days" data-id="${user.id_nhan_vien}">${diemDanhDays}</td>
                    <td class="nghi-days" data-id="${user.id_nhan_vien}">${nghiDays}</td>
                    <td class="total-work-days" data-id="${user.id_nhan_vien}">${totalWorkDays}</td>
                `;

                row.innerHTML = rowContent;
                tableBody.appendChild(row);
            });

            await loadAttendanceData();
        }

        // Hàm cập nhật trạng thái điểm danh
        async function updateAttendance(select) {
            const userId = select.getAttribute('data-id');
            const date = select.getAttribute('data-date');
            const status = select.value;
            const month = parseInt(document.getElementById('selectMonth').value);
            const year = parseInt(document.getElementById('selectYear').value);

            console.log(`Cập nhật điểm danh: Nhân viên ${userId}, Ngày ${date}, Trạng thái ${status}`);
            showLoading();

            const data = {
                id_nhan_vien: userId,
                ngay_lam_viec: date,
                gio_vao: status === 'Đúng giờ' ? '08:00:00' : (status === 'Đi trễ' ? '09:00:00' : '00:00:00'),
                gio_ra: (status === 'Đúng giờ' || status === 'Đi trễ') ? '17:00:00' : '00:00:00',
                trang_thai: status,
                month: month,
                year: year
            };

            try {
                const response = await fetch("http://localhost/doanqlns/index.php/api/chamcong", {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const result = await response.json();

                if (result.success) {
                    await loadAttendanceData();
                    const updatedRecord = attendanceData.find(record => 
                        record.id_nhan_vien == userId && 
                        record.ngay_lam_viec === date
                    );
                    if (updatedRecord && updatedRecord.trang_thai === status) {
                        console.log("Bản ghi đã được cập nhật thành công:", updatedRecord);
                        updateAttendanceTable();
                    } else {
                        throw new Error("Trạng thái không được lưu vào cơ sở dữ liệu");
                    }
                } else {
                    throw new Error('Lỗi từ API: ' + (result.message || 'Không rõ nguyên nhân'));
                }
            } catch (error) {
                console.error("Lỗi khi cập nhật điểm danh:", error);
                alert(error.message || "Lỗi khi cập nhật điểm danh");
                select.value = attendanceData.find(record => 
                    record.id_nhan_vien == userId && record.ngay_lam_viec === date
                )?.trang_thai || 'Chưa điểm danh';
            } finally {
                hideLoading();
            }
        }

        // Hàm xóa chấm công
        async function deleteChamCong(id) {
            if (!confirm(`Bạn có chắc chắn muốn xóa chấm công ID ${id} không?`)) return;

            showLoading();
            try {
                const response = await fetch(`http://localhost/doanqlns/index.php/api/chamcong?id=${id}`, {
                    method: 'DELETE'
                });
                const result = await response.json();

                if (result.success) {
                    await loadAttendanceData();
                    updateAttendanceTable();
                    alert(`Đã xóa chấm công với ID: ${id}`);
                } else {
                    throw new Error("Lỗi khi xóa chấm công: " + (result.message || "Không rõ nguyên nhân"));
                }
            } catch (error) {
                console.error("Lỗi khi xóa chấm công:", error);
                alert(error.message || "Lỗi khi xóa chấm công");
            } finally {
                hideLoading();
            }
        }

        // Sự kiện đóng modal
        document.querySelector('#diemDanhModal .modal-close').addEventListener('click', () => {
            diemDanhModal.style.display = 'none';
        });

        diemDanhModal.addEventListener('click', (e) => {
            if (e.target === diemDanhModal) {
                diemDanhModal.style.display = 'none';
            }
        });

        // Khởi tạo khi trang được tải
        document.addEventListener('DOMContentLoaded', async () => {
            const selectedDateElement = document.getElementById("selectedDate");
            
            // Hiển thị ngày hiện tại dưới định dạng DD/MM/YYYY
            selectedDateElement.textContent = `${selectedDate.getDate().toString().padStart(2, '0')}/${(selectedDate.getMonth() + 1).toString().padStart(2, '0')}/${selectedDate.getFullYear()}`;
            
            // Tải dữ liệu
            await loadUsersData();
            await loadAttendanceData();
        });
        
    </script>
</body>
</html>