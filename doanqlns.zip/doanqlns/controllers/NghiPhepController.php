<?php
include_once(__DIR__ . '/../models/NghiPhepModel.php');

class NghiPhepController {
    private $nghiPhepModel;

    public function __construct() {
        $this->nghiPhepModel = new NghiPhepModel();
    }

    public function getAllNghiPhep() {
        $records = $this->nghiPhepModel->getAllNghiPhep();
        echo json_encode($records);
    }

    public function updateNghiPhep($id, $data) {
        if (!isset($data['trang_thai1'])) {
            echo json_encode(["success" => false, "message" => "Thiếu tham số trang_thai1"]);
            return;
        }

        $trangThai = $data['trang_thai1'];
        $idNguoiDuyet = isset($data['id_nguoi_duyet']) ? $data['id_nguoi_duyet'] : null;
        $ngayDuyet = ($trangThai === 'Đã duyệt' || $trangThai === 'Từ chối') ? date('Y-m-d H:i:s') : null;

        $validStatuses = ['Chờ xét duyệt', 'Đã duyệt', 'Từ chối'];
        if (!in_array($trangThai, $validStatuses)) {
            echo json_encode(["success" => false, "message" => "Trạng thái không hợp lệ: $trangThai"]);
            return;
        }

        $result = $this->nghiPhepModel->updateNghiPhep($id, $trangThai, $idNguoiDuyet, $ngayDuyet);

        if ($result) {
            echo json_encode(["success" => true, "message" => "Cập nhật trạng thái thành công"]);
        } else {
            echo json_encode(["success" => false, "message" => "Lỗi khi cập nhật trạng thái"]);
        }
    }

    public function deleteNghiPhep($id) {
        $result = $this->nghiPhepModel->deleteNghiPhep($id);
        if ($result) {
            echo json_encode(["success" => true, "message" => "Xóa thành công"]);
        } else {
            echo json_encode(["success" => false, "message" => "Lỗi khi xóa"]);
        }
    }

    public function addNghiPhep($data) {
        echo json_encode(["success" => false, "message" => "Chức năng thêm mới chưa được triển khai"]);
    }
}