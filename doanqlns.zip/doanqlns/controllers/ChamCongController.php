<?php
require_once __DIR__ . '/../config/database.php';

class ChamCongController {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getAllChamCong() {
        try {
            $stmt = $this->conn->prepare("
                SELECT cc.id_cham_cong, cc.id_nhan_vien, nv.ho_ten, cc.ngay_lam_viec, cc.gio_vao, cc.gio_ra, cc.trang_thai, cc.ghi_chu
                FROM cham_cong cc
                JOIN nhan_vien nv ON cc.id_nhan_vien = nv.id_nhan_vien
            ");
            $stmt->execute();
            $chamCong = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($chamCong);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    public function addOrUpdateChamCong($data) {
        try {
            $this->conn->beginTransaction();

            // 1. Kiểm tra dữ liệu đầu vào
            if (!isset($data['id_nhan_vien'], $data['ngay_lam_viec'], $data['trang_thai'], $data['month'], $data['year'])) {
                throw new Exception('Thiếu thông tin cần thiết');
            }

            // Log dữ liệu đầu vào
            error_log("Dữ liệu gửi đến API: " . json_encode($data));

            // 2. Kiểm tra xem bản ghi đã tồn tại chưa
            $stmt = $this->conn->prepare("
                SELECT id_cham_cong FROM cham_cong 
                WHERE id_nhan_vien = :id_nhan_vien AND ngay_lam_viec = :ngay_lam_viec
            ");
            $stmt->bindParam(':id_nhan_vien', $data['id_nhan_vien']);
            $stmt->bindParam(':ngay_lam_viec', $data['ngay_lam_viec']);
            $stmt->execute();
            $existingRecord = $stmt->fetch(PDO::FETCH_ASSOC);

            // 3. Xử lý thêm hoặc cập nhật bản ghi
            if ($existingRecord) {
                // Cập nhật bản ghi hiện có
                if ($data['trang_thai'] === 'Chưa điểm danh') {
                    error_log("Xóa bản ghi: id_cham_cong = " . $existingRecord['id_cham_cong']);
                    $stmt = $this->conn->prepare("
                        DELETE FROM cham_cong 
                        WHERE id_cham_cong = :id_cham_cong
                    ");
                    $stmt->bindParam(':id_cham_cong', $existingRecord['id_cham_cong']);
                    $stmt->execute();
                } else {
                    error_log("Cập nhật bản ghi: id_cham_cong = " . $existingRecord['id_cham_cong']);
                    $stmt = $this->conn->prepare("
                        UPDATE cham_cong 
                        SET gio_vao = :gio_vao, gio_ra = :gio_ra, trang_thai = :trang_thai, ghi_chu = :ghi_chu
                        WHERE id_cham_cong = :id_cham_cong
                    ");
                    $stmt->bindParam(':id_cham_cong', $existingRecord['id_cham_cong']);
                    $gio_vao = isset($data['gio_vao']) ? $data['gio_vao'] : null;
                    $gio_ra = isset($data['gio_ra']) ? $data['gio_ra'] : null;
                    $stmt->bindParam(':gio_vao', $gio_vao);
                    $stmt->bindParam(':gio_ra', $gio_ra);
                    $stmt->bindParam(':trang_thai', $data['trang_thai']);
                    $ghi_chu = isset($data['ghi_chu']) ? $data['ghi_chu'] : null;
                    $stmt->bindParam(':ghi_chu', $ghi_chu);
                    $stmt->execute();

                    // Kiểm tra xem bản ghi đã được cập nhật chưa
                    $stmt = $this->conn->prepare("
                        SELECT trang_thai FROM cham_cong 
                        WHERE id_cham_cong = :id_cham_cong
                    ");
                    $stmt->bindParam(':id_cham_cong', $existingRecord['id_cham_cong']);
                    $stmt->execute();
                    $updatedRecord = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($updatedRecord['trang_thai'] !== $data['trang_thai']) {
                        throw new Exception("Lỗi: Trạng thái không được cập nhật đúng trong cơ sở dữ liệu");
                    }
                }
            } else {
                // Thêm bản ghi mới nếu trạng thái không phải "Chưa điểm danh"
                if ($data['trang_thai'] !== 'Chưa điểm danh') {
                    error_log("Thêm bản ghi mới cho id_nhan_vien = " . $data['id_nhan_vien']);
                    $stmt = $this->conn->prepare("
                        INSERT INTO cham_cong (id_nhan_vien, ngay_lam_viec, gio_vao, gio_ra, trang_thai, ghi_chu)
                        VALUES (:id_nhan_vien, :ngay_lam_viec, :gio_vao, :gio_ra, :trang_thai, :ghi_chu)
                    ");
                    $stmt->bindParam(':id_nhan_vien', $data['id_nhan_vien']);
                    $stmt->bindParam(':ngay_lam_viec', $data['ngay_lam_viec']);
                    $gio_vao = isset($data['gio_vao']) ? $data['gio_vao'] : null;
                    $gio_ra = isset($data['gio_ra']) ? $data['gio_ra'] : null;
                    $stmt->bindParam(':gio_vao', $gio_vao);
                    $stmt->bindParam(':gio_ra', $gio_ra);
                    $stmt->bindParam(':trang_thai', $data['trang_thai']);
                    $ghi_chu = isset($data['ghi_chu']) ? $data['ghi_chu'] : null;
                    $stmt->bindParam(':ghi_chu', $ghi_chu);
                    $stmt->execute();

                    // Kiểm tra xem bản ghi đã được thêm chưa
                    $stmt = $this->conn->prepare("
                        SELECT trang_thai FROM cham_cong 
                        WHERE id_nhan_vien = :id_nhan_vien AND ngay_lam_viec = :ngay_lam_viec
                    ");
                    $stmt->bindParam(':id_nhan_vien', $data['id_nhan_vien']);
                    $stmt->bindParam(':ngay_lam_viec', $data['ngay_lam_viec']);
                    $stmt->execute();
                    $newRecord = $stmt->fetch(PDO::FETCH_ASSOC);
                    if (!$newRecord || $newRecord['trang_thai'] !== $data['trang_thai']) {
                        throw new Exception("Lỗi: Bản ghi không được thêm đúng vào cơ sở dữ liệu");
                    }
                } else {
                    error_log("Không thêm bản ghi vì trạng thái là 'Chưa điểm danh'");
                }
            }

            // 4. Tính tổng công trong tháng
            $month = sprintf("%02d", $data['month']);
            $year = $data['year'];
            $startDate = "$year-$month-01";
            $endDate = "$year-$month-" . (new DateTime("$year-$month-01"))->format('t');

            $stmt = $this->conn->prepare("
                SELECT trang_thai, COUNT(*) as count
                FROM cham_cong
                WHERE id_nhan_vien = :id_nhan_vien
                AND ngay_lam_viec BETWEEN :start_date AND :end_date
                AND trang_thai IN ('Đúng giờ', 'Đi trễ', 'Có phép', 'Không phép')
                GROUP BY trang_thai
            ");
            $stmt->bindParam(':id_nhan_vien', $data['id_nhan_vien']);
            $stmt->bindParam(':start_date', $startDate);
            $stmt->bindParam(':end_date', $endDate);
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $diemDanhDays = 0;
            $nghiDays = 0;

            foreach ($results as $result) {
                if ($result['trang_thai'] === 'Đúng giờ') {
                    $diemDanhDays += $result['count'];
                } elseif ($result['trang_thai'] === 'Đi trễ') {
                    $diemDanhDays += $result['count'] * 0.5;
                } elseif ($result['trang_thai'] === 'Có phép') {
                    $nghiDays += $result['count'] * 0.5;
                } elseif ($result['trang_thai'] === 'Không phép') {
                    $nghiDays += $result['count'];
                }
            }

            // Tổng công = Điểm danh - Số ngày nghỉ
            $totalWorkDays = $diemDanhDays - $nghiDays;

            // 5. Cập nhật bảng luong
            $thang = "$year-$month";
            $stmt = $this->conn->prepare("
                SELECT id_luong FROM luong 
                WHERE id_nhan_vien = :id_nhan_vien AND thang = :thang
            ");
            $stmt->bindParam(':id_nhan_vien', $data['id_nhan_vien']);
            $stmt->bindParam(':thang', $thang);
            $stmt->execute();
            $existingLuong = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($existingLuong) {
                $stmt = $this->conn->prepare("
                    UPDATE luong 
                    SET so_ngay_cong = :so_ngay_cong
                    WHERE id_luong = :id_luong
                ");
                $stmt->bindParam(':id_luong', $existingLuong['id_luong']);
                $stmt->bindParam(':so_ngay_cong', $totalWorkDays);
                $stmt->execute();
            } else {
                $stmt = $this->conn->prepare("
                    INSERT INTO luong (id_nhan_vien, thang, so_ngay_cong, luong_co_ban, phu_cap_chuc_vu, luong_lam_them, tien_thuong, cac_khoan_tru, luong_thuc_nhan, ngay_cham_cong, trang_thai)
                    VALUES (:id_nhan_vien, :thang, :so_ngay_cong, 0, 0, 0, 0, 0, 0, NOW(), 'Chưa xử lý')
                ");
                $stmt->bindParam(':id_nhan_vien', $data['id_nhan_vien']);
                $stmt->bindParam(':thang', $thang);
                $stmt->bindParam(':so_ngay_cong', $totalWorkDays);
                $stmt->execute();
            }

            // 6. Cập nhật bảng tong_hop_cong_thang
            $stmt = $this->conn->prepare("
                SELECT id_tong_hop FROM tong_hop_cong_thang 
                WHERE id_nhan_vien = :id_nhan_vien AND thang = :thang
            ");
            $stmt->bindParam(':id_nhan_vien', $data['id_nhan_vien']);
            $stmt->bindParam(':thang', $thang);
            $stmt->execute();
            $existingTongHop = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($existingTongHop) {
                $stmt = $this->conn->prepare("
                    UPDATE tong_hop_cong_thang 
                    SET tong_cong = :tong_cong, cong_chinh = :cong_chinh
                    WHERE id_tong_hop = :id_tong_hop
                ");
                $stmt->bindParam(':id_tong_hop', $existingTongHop['id_tong_hop']);
                $stmt->bindParam(':tong_cong', $totalWorkDays);
                $stmt->bindParam(':cong_chinh', $totalWorkDays);
                $stmt->execute();
            } else {
                $stmt = $this->conn->prepare("
                    INSERT INTO tong_hop_cong_thang (id_nhan_vien, thang, tong_cong, cong_chinh, lam_them, ngay_lam_viec, ngay_nghi_phep)
                    VALUES (:id_nhan_vien, :thang, :tong_cong, :cong_chinh, 0, 0, 0)
                ");
                $stmt->bindParam(':id_nhan_vien', $data['id_nhan_vien']);
                $stmt->bindParam(':thang', $thang);
                $stmt->bindParam(':tong_cong', $totalWorkDays);
                $stmt->bindParam(':cong_chinh', $totalWorkDays);
                $stmt->execute();
            }

            $this->conn->commit();
            echo json_encode(['success' => true, 'message' => 'Cập nhật chấm công thành công']);
        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Lỗi Exception: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        } catch (PDOException $e) {
            $this->conn->rollBack();
            error_log("Lỗi SQL: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi SQL: ' . $e->getMessage()]);
        }
    }

    public function deleteChamCong($id) {
        try {
            $this->conn->beginTransaction();

            $stmt = $this->conn->prepare("
                SELECT id_nhan_vien, ngay_lam_viec 
                FROM cham_cong 
                WHERE id_cham_cong = :id
            ");
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            $record = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$record) {
                throw new Exception('Bản ghi chấm công không tồn tại');
            }

            $stmt = $this->conn->prepare("DELETE FROM cham_cong WHERE id_cham_cong = :id");
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();

            $month = date('m', strtotime($record['ngay_lam_viec']));
            $year = date('Y', strtotime($record['ngay_lam_viec']));
            $startDate = "$year-$month-01";
            $endDate = "$year-$month-" . (new DateTime("$year-$month-01"))->format('t');

            $stmt = $this->conn->prepare("
                SELECT trang_thai, COUNT(*) as count
                FROM cham_cong
                WHERE id_nhan_vien = :id_nhan_vien
                AND ngay_lam_viec BETWEEN :start_date AND :end_date
                AND trang_thai IN ('Đúng giờ', 'Đi trễ', 'Có phép', 'Không phép')
                GROUP BY trang_thai
            ");
            $stmt->bindParam(':id_nhan_vien', $record['id_nhan_vien']);
            $stmt->bindParam(':start_date', $startDate);
            $stmt->bindParam(':end_date', $endDate);
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $diemDanhDays = 0;
            $nghiDays = 0;

            foreach ($results as $result) {
                if ($result['trang_thai'] === 'Đúng giờ') {
                    $diemDanhDays += $result['count'];
                } elseif ($result['trang_thai'] === 'Đi trễ') {
                    $diemDanhDays += $result['count'] * 0.5;
                } elseif ($result['trang_thai'] === 'Có phép') {
                    $nghiDays += $result['count'] * 0.5;
                } elseif ($result['trang_thai'] === 'Không phép') {
                    $nghiDays += $result['count'];
                }
            }

            $totalWorkDays = $diemDanhDays - $nghiDays;

            $thang = "$year-$month";
            $stmt = $this->conn->prepare("
                UPDATE luong 
                SET so_ngay_cong = :so_ngay_cong
                WHERE id_nhan_vien = :id_nhan_vien AND thang = :thang
            ");
            $stmt->bindParam(':id_nhan_vien', $record['id_nhan_vien']);
            $stmt->bindParam(':thang', $thang);
            $stmt->bindParam(':so_ngay_cong', $totalWorkDays);
            $stmt->execute();

            $stmt = $this->conn->prepare("
                UPDATE tong_hop_cong_thang 
                SET tong_cong = :tong_cong, cong_chinh = :cong_chinh
                WHERE id_nhan_vien = :id_nhan_vien AND thang = :thang
            ");
            $stmt->bindParam(':id_nhan_vien', $record['id_nhan_vien']);
            $stmt->bindParam(':thang', $thang);
            $stmt->bindParam(':tong_cong', $totalWorkDays);
            $stmt->bindParam(':cong_chinh', $totalWorkDays);
            $stmt->execute();

            $this->conn->commit();
            echo json_encode(['success' => true, 'message' => 'Xóa chấm công thành công']);
        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Lỗi Exception: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        } catch (PDOException $e) {
            $this->conn->rollBack();
            error_log("Lỗi SQL: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi SQL: ' . $e->getMessage()]);
        }
    }
}
?>