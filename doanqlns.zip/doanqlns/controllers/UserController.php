<?php
require_once __DIR__ . '/../config/Database.php';

class UserController {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getAllUsers() {
        try {
            $stmt = $this->conn->prepare("
                SELECT 
                    nv.id_nhan_vien, nv.ho_ten, nv.gioi_tinh, nv.ngay_sinh, nv.email, nv.so_dien_thoai,
                    nv.dia_chi, nv.can_cuoc_cong_dan, nv.ngay_cap, nv.noi_cap, nv.que_quan, nv.hinh_anh,
                    pb.ten_phong_ban, cv.ten_chuc_vu, nv.loai_hop_dong, nv.luong_co_ban,
                    nv.ngay_vao_lam, nv.ngay_nghi_viec, nv.trang_thai
                FROM nhan_vien nv
                LEFT JOIN phong_ban pb ON nv.id_phong_ban = pb.id_phong_ban
                LEFT JOIN chuc_vu cv ON nv.id_chuc_vu = cv.id_chuc_vu
            ");
            $stmt->execute();
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($users);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    public function getUserById($id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT 
                    nv.id_nhan_vien, nv.ho_ten, nv.gioi_tinh, nv.ngay_sinh, nv.email, nv.so_dien_thoai,
                    nv.dia_chi, nv.can_cuoc_cong_dan, nv.ngay_cap, nv.noi_cap, nv.que_quan, nv.hinh_anh,
                    pb.ten_phong_ban, cv.ten_chuc_vu, nv.loai_hop_dong, nv.luong_co_ban,
                    nv.ngay_vao_lam, nv.ngay_nghi_viec, nv.trang_thai
                FROM nhan_vien nv
                LEFT JOIN phong_ban pb ON nv.id_phong_ban = pb.id_phong_ban
                LEFT JOIN chuc_vu cv ON nv.id_chuc_vu = cv.id_chuc_vu
                WHERE nv.id_nhan_vien = :id
            ");
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                echo json_encode($user);
            } else {
                http_response_code(404);
                echo json_encode(['message' => 'Nhân viên không tồn tại']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    public function deleteUser($id) {
        try {
            $stmt = $this->conn->prepare("DELETE FROM nhan_vien WHERE id_nhan_vien = :id");
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => true, 'message' => 'Xóa nhân viên thành công']);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Nhân viên không tồn tại']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    public function updateUser($id, $data) {
        try {
            // Chuẩn bị câu lệnh SQL để cập nhật
            $stmt = $this->conn->prepare("
                UPDATE nhan_vien 
                SET 
                    ho_ten = :ho_ten,
                    gioi_tinh = :gioi_tinh,
                    ngay_sinh = :ngay_sinh,
                    email = :email,
                    so_dien_thoai = :so_dien_thoai,
                    dia_chi = :dia_chi,
                    can_cuoc_cong_dan = :can_cuoc_cong_dan,
                    ngay_cap = :ngay_cap,
                    noi_cap = :noi_cap,
                    que_quan = :que_quan,
                    loai_hop_dong = :loai_hop_dong,
                    luong_co_ban = :luong_co_ban,
                    ngay_vao_lam = :ngay_vao_lam,
                    ngay_nghi_viec = :ngay_nghi_viec,
                    trang_thai = :trang_thai
                WHERE id_nhan_vien = :id
            ");

            // Gán giá trị vào các tham số
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->bindParam(':ho_ten', $data['ho_ten']);
            $stmt->bindParam(':gioi_tinh', $data['gioi_tinh']);
            $stmt->bindParam(':ngay_sinh', $data['ngay_sinh']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':so_dien_thoai', $data['so_dien_thoai']);
            $stmt->bindParam(':dia_chi', $data['dia_chi']);
            $stmt->bindParam(':can_cuoc_cong_dan', $data['can_cuoc_cong_dan']);
            $stmt->bindParam(':ngay_cap', $data['ngay_cap']);
            $stmt->bindParam(':noi_cap', $data['noi_cap']);
            $stmt->bindParam(':que_quan', $data['que_quan']);
            $stmt->bindParam(':loai_hop_dong', $data['loai_hop_dong']);
            $stmt->bindParam(':luong_co_ban', $data['luong_co_ban']);
            $stmt->bindParam(':ngay_vao_lam', $data['ngay_vao_lam']);
            $stmt->bindParam(':ngay_nghi_viec', $data['ngay_nghi_viec']);
            $stmt->bindParam(':trang_thai', $data['trang_thai']);

            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => true, 'message' => 'Cập nhật nhân viên thành công']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Nhân viên không tồn tại hoặc không có thay đổi']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }
}
?>