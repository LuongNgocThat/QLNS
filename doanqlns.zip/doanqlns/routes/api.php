<?php
// Thiết lập header ngay đầu file
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

include_once(__DIR__ . '/../controllers/UserController.php');
include_once(__DIR__ . '/../controllers/ChamCongController.php');
include_once(__DIR__ . '/../controllers/NghiPhepController.php');
include_once(__DIR__ . '/../controllers/LuongController.php');
include_once(__DIR__ . '/../controllers/BaoHiemController.php');

$userController = new UserController();
$chamCongController = new ChamCongController();
$nghiPhepController = new NghiPhepController();
$luongController = new LuongController();
$baoHiemController = new BaoHiemThueController();

// Xử lý lỗi toàn cục
try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/users') {
            $userController->getAllUsers();
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/user\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $userId = intval($matches[1]);
            $userController->getUserById($userId);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/chamcong') {
            $chamCongController->getAllChamCong();
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/nghiphep') {
            $nghiPhepController->getAllNghiPhep();
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/luong') {
            $luongController->getAllLuong();
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/baohiem') {
            $baoHiemController->getAllBaoHiemThue();
        } else {
            http_response_code(404);
            echo json_encode(["message" => "Invalid route"]);
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
        if (preg_match('/\/doanqlns\/index\.php\/api\/user\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $userId = intval($matches[1]);
            $userController->deleteUser($userId);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/chamcong\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $chamCongId = intval($matches[1]);
            $chamCongController->deleteChamCong($chamCongId);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/nghiphep\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $nghiPhepId = intval($matches[1]);
            $nghiPhepController->deleteNghiPhep($nghiPhepId);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/baohiem\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $baoHiemId = intval($matches[1]);
            $baoHiemController->deleteBaoHiemThue($baoHiemId);
        } else {
            http_response_code(404);
            echo json_encode(["message" => "Invalid route"]);
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
        if (preg_match('/\/doanqlns\/index\.php\/api\/user\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $userId = intval($matches[1]);
            $data = json_decode(file_get_contents("php://input"), true);
            $userController->updateUser($userId, $data);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/nghiphep\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $nghiPhepId = intval($matches[1]);
            $data = json_decode(file_get_contents("php://input"), true);
            $nghiPhepController->updateNghiPhep($nghiPhepId, $data);
        } else if (preg_match('/\/doanqlns\/index\.php\/api\/baohiem\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $baoHiemId = intval($matches[1]);
            $data = json_decode(file_get_contents("php://input"), true);
            $baoHiemController->updateBaoHiemThue($baoHiemId, $data);
        } else {
            http_response_code(404);
            echo json_encode(["message" => "Invalid route"]);
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/chamcong') {
            $data = json_decode(file_get_contents("php://input"), true);
            $chamCongController->addOrUpdateChamCong($data);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/nghiphep') {
            $data = json_decode(file_get_contents("php://input"), true);
            if (isset($data['action']) && $data['action'] === 'update') {
                $nghiPhepController->updateNghiPhep($data['id_nghi_phep'], $data);
            } else {
                $nghiPhepController->addNghiPhep($data);
            }
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/user') {
            $data = json_decode(file_get_contents("php://input"), true);
            $userController->addUser($data);
        }else {
            http_response_code(404);
            echo json_encode(["message" => "Invalid route"]);
        }
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Lỗi server: " . $e->getMessage()]);
}
?>