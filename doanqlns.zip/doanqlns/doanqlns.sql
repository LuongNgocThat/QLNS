-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th4 21, 2025 lúc 07:18 PM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `doanqlns`
--

DELIMITER $$
--
-- Thủ tục
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ApproveLeaveRequest` (IN `p_id_nghi_phep` INT, IN `p_id_nguoi_duyet` INT, IN `p_trang_thai` ENUM('Đã duyệt','Từ chối'))   BEGIN
  DECLARE v_id_nhan_vien INT;
  DECLARE v_thang VARCHAR(7);

  -- Lấy thông tin nhân viên và tháng
  SELECT `id_nhan_vien`, DATE_FORMAT(`ngay_bat_dau`, '%Y-%m')
  INTO v_id_nhan_vien, v_thang
  FROM `nghi_phep`
  WHERE `id_nghi_phep` = p_id_nghi_phep;

  -- Cập nhật yêu cầu nghỉ phép
  UPDATE `nghi_phep`
  SET
    `trang_thai` = p_trang_thai,
    `id_nguoi_duyet` = p_id_nguoi_duyet,
    `ngay_duyet` = NOW()
  WHERE `id_nghi_phep` = p_id_nghi_phep;

  -- Tính lại ngày nghỉ nếu được duyệt
  IF p_trang_thai = 'Đã duyệt' THEN
    CALL `CalculateLeaveDays`(v_id_nhan_vien, v_thang);
  END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculateInsuranceAndTax` (IN `p_id_nhan_vien` INT, IN `p_thang` VARCHAR(7), IN `p_luong_co_ban` DECIMAL(12,2))   BEGIN
  DECLARE v_bhxh DECIMAL(12,2);
  DECLARE v_bhyt DECIMAL(12,2);
  DECLARE v_bhtn DECIMAL(12,2);
  DECLARE v_thue_tncn DECIMAL(12,2);
  DECLARE v_thu_nhap_chiu_thue DECIMAL(12,2);

  -- Tính các khoản bảo hiểm
  SET v_bhxh = p_luong_co_ban * 0.08; -- 8% bảo hiểm xã hội
  SET v_bhyt = p_luong_co_ban * 0.015; -- 1.5% bảo hiểm y tế
  SET v_bhtn = p_luong_co_ban * 0.01; -- 1% bảo hiểm thất nghiệp

  -- Tính thu nhập chịu thuế
  SET v_thu_nhap_chiu_thue = p_luong_co_ban - v_bhxh - v_bhyt - v_bhtn;

  -- Tính thuế TNCN theo biểu lũy tiến (đơn giản hóa)
  SET v_thue_tncn = CASE
    WHEN v_thu_nhap_chiu_thue <= 0 THEN 0
    WHEN v_thu_nhap_chiu_thue <= 5000000 THEN v_thu_nhap_chiu_thue * 0.05
    WHEN v_thu_nhap_chiu_thue <= 10000000 THEN v_thu_nhap_chiu_thue * 0.10
    WHEN v_thu_nhap_chiu_thue <= 18000000 THEN v_thu_nhap_chiu_thue * 0.15
    WHEN v_thu_nhap_chiu_thue <= 32000000 THEN v_thu_nhap_chiu_thue * 0.20
    WHEN v_thu_nhap_chiu_thue <= 52000000 THEN v_thu_nhap_chiu_thue * 0.25
    WHEN v_thu_nhap_chiu_thue <= 80000000 THEN v_thu_nhap_chiu_thue * 0.30
    ELSE v_thu_nhap_chiu_thue * 0.35
  END;

  -- Cập nhật hoặc chèn vào bao_hiem_thue_tncn
  INSERT INTO `bao_hiem_thue_tncn` (
    `id_nhan_vien`, `thang`, `bhxh`, `bhyt`, `bhtn`, `thue_tncn`
  )
  VALUES (
    p_id_nhan_vien, p_thang, v_bhxh, v_bhyt, v_bhtn, v_thue_tncn
  )
  ON DUPLICATE KEY UPDATE
    `bhxh` = v_bhxh,
    `bhyt` = v_bhyt,
    `bhtn` = v_bhtn,
    `thue_tncn` = v_thue_tncn;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculateLeaveDays` (IN `p_id_nhan_vien` INT, IN `p_thang` VARCHAR(7))   BEGIN
  DECLARE v_ngay_nghi_phep INT DEFAULT 0;
  DECLARE v_ngay_nghi_khong_phep INT DEFAULT 0;

  -- Tính số ngày nghỉ có phép
  SELECT COUNT(DISTINCT DATE(`ngay_bat_dau`)) INTO v_ngay_nghi_phep
  FROM `nghi_phep`
  WHERE `id_nhan_vien` = p_id_nhan_vien
    AND `trang_thai` = 'Đã duyệt'
    AND `loai_nghi` = 'Có phép'
    AND `ngay_bat_dau` LIKE CONCAT(p_thang, '%');

  -- Tính số ngày nghỉ không phép
  SELECT COUNT(DISTINCT DATE(`ngay_bat_dau`)) INTO v_ngay_nghi_khong_phep
  FROM `nghi_phep`
  WHERE `id_nhan_vien` = p_id_nhan_vien
    AND `trang_thai` = 'Đã duyệt'
    AND `loai_nghi` = 'Không phép'
    AND `ngay_bat_dau` LIKE CONCAT(p_thang, '%');

  -- Cập nhật tong_hop_cong_thang
  UPDATE `tong_hop_cong_thang`
  SET
    `ngay_nghi_phep` = v_ngay_nghi_phep
  WHERE `id_nhan_vien` = p_id_nhan_vien
    AND `thang` = p_thang;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculateMonthlyAttendance` (IN `p_id_nhan_vien` INT, IN `p_thang` VARCHAR(7))   BEGIN
  DECLARE v_tong_cong DECIMAL(5,2) DEFAULT 0.00;
  DECLARE v_cong_chinh DECIMAL(5,2) DEFAULT 0.00;
  DECLARE v_lam_them DECIMAL(5,2) DEFAULT 0.00;
  DECLARE v_ngay_lam_viec INT DEFAULT 0;
  DECLARE v_ngay_nghi_phep INT DEFAULT 0;

  -- Tính số ngày làm việc
  SELECT COUNT(*) INTO v_ngay_lam_viec
  FROM `cham_cong`
  WHERE `id_nhan_vien` = p_id_nhan_vien
    AND `ngay_lam_viec` LIKE CONCAT(p_thang, '%')
    AND `trang_thai` IN ('Đúng giờ', 'Đi trễ', 'Làm thêm');

  -- Tính số ngày nghỉ phép
  SELECT COUNT(DISTINCT DATE(`ngay_bat_dau`)) INTO v_ngay_nghi_phep
  FROM `nghi_phep`
  WHERE `id_nhan_vien` = p_id_nhan_vien
    AND `trang_thai` = 'Đã duyệt'
    AND `ngay_bat_dau` LIKE CONCAT(p_thang, '%');

  -- Tính tổng giờ làm thêm
  SELECT SUM(`gio_lam_them`) INTO v_lam_them
  FROM `cham_cong`
  WHERE `id_nhan_vien` = p_id_nhan_vien
    AND `ngay_lam_viec` LIKE CONCAT(p_thang, '%')
    AND `trang_thai` = 'Làm thêm';

  SET v_cong_chinh = v_ngay_lam_viec;
  SET v_tong_cong = v_cong_chinh + COALESCE(v_lam_them / 8, 0); -- Quy đổi giờ làm thêm thành ngày

  -- Cập nhật hoặc chèn vào tong_hop_cong_thang
  INSERT INTO `tong_hop_cong_thang` (
    `id_nhan_vien`, `thang`, `tong_cong`, `cong_chinh`, `lam_them`, `ngay_lam_viec`, `ngay_nghi_phep`
  )
  VALUES (
    p_id_nhan_vien, p_thang, v_tong_cong, v_cong_chinh, COALESCE(v_lam_them, 0), v_ngay_lam_viec, v_ngay_nghi_phep
  )
  ON DUPLICATE KEY UPDATE
    `tong_cong` = v_tong_cong,
    `cong_chinh` = v_cong_chinh,
    `lam_them` = COALESCE(v_lam_them, 0),
    `ngay_lam_viec` = v_ngay_lam_viec,
    `ngay_nghi_phep` = v_ngay_nghi_phep;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculatePayroll` (IN `p_id_nhan_vien` INT, IN `p_thang` VARCHAR(7), IN `p_tien_thuong` DECIMAL(12,0), IN `p_ngay_cham_cong` DATE)   BEGIN
  DECLARE v_luong_co_ban DECIMAL(12,0);
  DECLARE v_phu_cap_chuc_vu DECIMAL(12,0);
  DECLARE v_luong_lam_them DECIMAL(12,0) DEFAULT 0.00;
  DECLARE v_cac_khoan_tru DECIMAL(12,0);
  DECLARE v_so_ngay_cong INT;
  DECLARE v_lam_them DECIMAL(5,0);

  -- Lấy thông tin nhân viên
  SELECT n.luong_co_ban, COALESCE(cv.phu_cap, 0)
  INTO v_luong_co_ban, v_phu_cap_chuc_vu
  FROM nhan_vien n
  LEFT JOIN chuc_vu cv ON n.id_chuc_vu = cv.id_chuc_vu
  WHERE n.id_nhan_vien = p_id_nhan_vien;

  -- Lấy thông tin chấm công
  SELECT ngay_lam_viec, lam_them
  INTO v_so_ngay_cong, v_lam_them
  FROM tong_hop_cong_thang
  WHERE id_nhan_vien = p_id_nhan_vien
    AND thang = p_thang;

  -- Tính lương làm thêm (1.5x lương giờ làm bình thường) và làm tròn
  SET v_luong_lam_them = ROUND((v_luong_co_ban / 26 / 8) * COALESCE(v_lam_them, 0) * 1.5, 2);

  -- Lấy các khoản trừ
  SELECT tong_khoan_tru INTO v_cac_khoan_tru
  FROM bao_hiem_thue_tncn
  WHERE id_nhan_vien = p_id_nhan_vien
    AND thang = p_thang;

  -- Cập nhật hoặc chèn vào bảng luong
  INSERT INTO luong (
    id_nhan_vien, thang, so_ngay_cong, luong_co_ban, phu_cap_chuc_vu,
    luong_lam_them, tien_thuong, cac_khoan_tru, trang_thai
  )
  VALUES (
    p_id_nhan_vien, p_thang, v_so_ngay_cong, v_luong_co_ban, v_phu_cap_chuc_vu,
    v_luong_lam_them, p_tien_thuong, COALESCE(v_cac_khoan_tru, 0), 'Tạm tính'
  )
  ON DUPLICATE KEY UPDATE
    so_ngay_cong = v_so_ngay_cong,
    luong_co_ban = v_luong_co_ban,
    phu_cap_chuc_vu = v_phu_cap_chuc_vu,
    luong_lam_them = v_luong_lam_them,
    tien_thuong = p_tien_thuong,
    cac_khoan_tru = COALESCE(v_cac_khoan_tru, 0),
    trang_thai = 'Tạm tính';


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateAttendanceStatus` (IN `p_id_cham_cong` INT)   BEGIN
  DECLARE v_trang_thai ENUM('Đúng giờ','Đi trễ','Có phép','Không phép','Làm thêm');
  DECLARE v_gio_lam_them DECIMAL(5,2);

  -- Lấy giờ làm thêm
  SELECT `gio_lam_them` INTO v_gio_lam_them
  FROM `cham_cong`
  WHERE `id_cham_cong` = p_id_cham_cong;

  -- Kiểm tra trạng thái nghỉ phép
  IF EXISTS (
    SELECT 1
    FROM `nghi_phep` np
    WHERE np.`id_nhan_vien` = (SELECT `id_nhan_vien` FROM `cham_cong` WHERE `id_cham_cong` = p_id_cham_cong)
      AND np.`trang_thai` = 'Đã duyệt'
      AND np.`ngay_bat_dau` <= (SELECT `ngay_lam_viec` FROM `cham_cong` WHERE `id_cham_cong` = p_id_cham_cong)
      AND np.`ngay_ket_thuc` >= (SELECT `ngay_lam_viec` FROM `cham_cong` WHERE `id_cham_cong` = p_id_cham_cong)
  ) THEN
    SET v_trang_thai = 'Có phép';
  ELSE
    -- Kiểm tra làm thêm
    IF v_gio_lam_them > 0 THEN
      SET v_trang_thai = 'Làm thêm';
    ELSE
      -- Kiểm tra dữ liệu vào/ra
      IF EXISTS (
        SELECT 1
        FROM `cham_cong`
        WHERE `id_cham_cong` = p_id_cham_cong
          AND `gio_vao` IS NOT NULL
          AND `gio_ra` IS NOT NULL
      ) THEN
        SET v_trang_thai = 'Đúng giờ';
      ELSE
        SET v_trang_thai = 'Không phép';
      END IF;
    END IF;
  END IF;

  -- Cập nhật trạng thái chấm công
  UPDATE `cham_cong`
  SET `trang_thai` = v_trang_thai
  WHERE `id_cham_cong` = p_id_cham_cong;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bao_hiem_thue_tncn`
--

CREATE TABLE `bao_hiem_thue_tncn` (
  `id` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `thang` varchar(7) NOT NULL,
  `bhxh` decimal(12,0) NOT NULL DEFAULT 0,
  `bhyt` decimal(12,0) NOT NULL DEFAULT 0,
  `bhtn` decimal(12,0) NOT NULL DEFAULT 0,
  `thue_tncn` decimal(12,0) NOT NULL DEFAULT 0,
  `tong_khoan_tru` decimal(12,0) GENERATED ALWAYS AS (`bhxh` + `bhyt` + `bhtn` + `thue_tncn`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `bao_hiem_thue_tncn`
--

INSERT INTO `bao_hiem_thue_tncn` (`id`, `id_nhan_vien`, `thang`, `bhxh`, `bhyt`, `bhtn`, `thue_tncn`) VALUES
(1, 1, '2025-04', 200000, 30000, 60000, 70000),
(2, 2, '2025-04', 80000, 150000, 100000, 200000),
(3, 3, '2025-04', 60000, 180000, 120000, 100000),
(4, 4, '2025-04', 40000, 50000, 50000, 300000),
(5, 5, '2025-04', 240000, 45000, 30000, 134250),
(6, 6, '2025-04', 20000, 50000, 90000, 80000),
(7, 7, '2025-04', 100000, 22000, 150000, 1000000),
(8, 8, '2025-04', 60000, 120000, 80000, 70000),
(9, 9, '2025-04', 880000, 165000, 110000, 984500),
(10, 10, '2025-04', 240000, 45000, 30000, 134250),
(11, 11, '2025-04', 600000, 112500, 75000, 671250),
(12, 12, '2025-04', 760000, 142500, 95000, 850250),
(13, 13, '2025-04', 1040000, 195000, 130000, 1745250),
(14, 14, '2025-04', 480000, 90000, 60000, 537000),
(15, 15, '2025-04', 240000, 45000, 30000, 134250),
(16, 16, '2025-04', 680000, 127500, 85000, 760750),
(17, 17, '2025-04', 1120000, 210000, 140000, 1879500),
(18, 18, '2025-04', 560000, 105000, 70000, 626500),
(19, 19, '2025-04', 960000, 180000, 120000, 1611000),
(20, 20, '2025-04', 240000, 45000, 30000, 134250);

--
-- Bẫy `bao_hiem_thue_tncn`
--
DELIMITER $$
CREATE TRIGGER `capnhat_cac_khoan_tru` AFTER UPDATE ON `bao_hiem_thue_tncn` FOR EACH ROW BEGIN
  UPDATE luong
  SET cac_khoan_tru = NEW.tong_khoan_tru
  WHERE id_nhan_vien = NEW.id_nhan_vien AND thang = NEW.thang;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cham_cong`
--

CREATE TABLE `cham_cong` (
  `id_cham_cong` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `ngay_lam_viec` date NOT NULL,
  `gio_vao` time DEFAULT NULL,
  `gio_ra` time DEFAULT NULL,
  `gio_lam_them` decimal(5,2) DEFAULT 0.00,
  `trang_thai` enum('Đúng giờ','Đi trễ','Có phép','Không phép','Làm thêm') DEFAULT NULL,
  `ghi_chu` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `cham_cong`
--

INSERT INTO `cham_cong` (`id_cham_cong`, `id_nhan_vien`, `ngay_lam_viec`, `gio_vao`, `gio_ra`, `gio_lam_them`, `trang_thai`, `ghi_chu`) VALUES
(1, 1, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(2, 1, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(3, 1, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(4, 2, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(5, 2, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(6, 2, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(7, 3, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(8, 1, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(9, 3, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(10, 3, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(11, 3, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(12, 2, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(13, 4, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(14, 4, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(15, 4, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(16, 5, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(17, 4, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(18, 5, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(19, 5, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(20, 5, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(21, 6, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(22, 6, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(23, 6, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(24, 7, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(25, 6, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(26, 7, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(27, 7, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(28, 8, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(29, 8, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(30, 8, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(31, 8, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(32, 9, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(33, 7, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(34, 10, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(35, 9, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(36, 9, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(37, 10, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(38, 9, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(39, 10, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(40, 11, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(41, 10, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(42, 11, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(43, 11, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(44, 12, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(45, 11, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(46, 12, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(47, 12, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(48, 12, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(49, 13, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(50, 13, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(51, 13, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(52, 13, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(53, 14, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(54, 14, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(55, 14, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(56, 14, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(57, 15, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(58, 15, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(59, 15, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(60, 16, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(61, 16, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(62, 16, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(63, 16, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(64, 17, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(65, 17, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(66, 17, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(67, 18, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(68, 18, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(69, 17, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(70, 15, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(71, 19, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(72, 19, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(73, 18, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(74, 19, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(75, 20, '2025-04-06', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(76, 18, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(77, 20, '2025-04-13', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(78, 20, '2025-04-27', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(79, 20, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(80, 19, '2025-04-20', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(85, 1, '2025-04-01', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(90, 1, '2025-04-02', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(99, 2, '2025-04-02', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(108, 1, '2025-04-18', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(121, 1, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(126, 2, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(131, 3, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(136, 4, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(141, 5, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(146, 6, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(151, 7, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(156, 8, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(161, 9, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(166, 10, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(171, 11, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(176, 12, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(181, 13, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(186, 14, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(191, 15, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(196, 16, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(201, 17, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(206, 18, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(211, 19, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(216, 20, '2025-04-21', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(228, 2, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(229, 3, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(230, 4, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(231, 5, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(232, 6, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(233, 7, '2025-04-22', '09:00:00', '17:00:00', 0.00, 'Đi trễ', NULL),
(234, 8, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(235, 9, '2025-04-22', '00:00:00', '00:00:00', 0.00, 'Có phép', NULL),
(236, 10, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(237, 11, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(238, 12, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(239, 13, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(240, 14, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(241, 15, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(242, 16, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(243, 17, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(244, 18, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(245, 19, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL),
(246, 20, '2025-04-22', '08:00:00', '17:00:00', 0.00, 'Đúng giờ', NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chuc_vu`
--

CREATE TABLE `chuc_vu` (
  `id_chuc_vu` int(11) NOT NULL,
  `ten_chuc_vu` varchar(100) NOT NULL,
  `mo_ta` text DEFAULT NULL,
  `phu_cap` decimal(12,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `chuc_vu`
--

INSERT INTO `chuc_vu` (`id_chuc_vu`, `ten_chuc_vu`, `mo_ta`, `phu_cap`) VALUES
(1, 'Nhân viên', 'Nhân viên cấp cơ sở', 0.00),
(3, 'Phó trưởng phòng', 'Quản lý phòng ban', 5000000.00),
(4, 'Trưởng phòng', 'Quản lý cấp cao', 10000000.00),
(5, 'Thực tập sinh', 'Nhân viên thực tập', 0.00);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `luong`
--

CREATE TABLE `luong` (
  `id_luong` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `thang` varchar(7) NOT NULL,
  `so_ngay_cong` int(11) NOT NULL,
  `luong_co_ban` decimal(12,0) NOT NULL,
  `phu_cap_chuc_vu` decimal(12,0) DEFAULT 0,
  `luong_lam_them` decimal(12,0) DEFAULT 0,
  `tien_thuong` decimal(12,0) DEFAULT 0,
  `cac_khoan_tru` decimal(12,0) DEFAULT 0,
  `luong_thuc_nhan` decimal(12,0) GENERATED ALWAYS AS (`luong_co_ban` * `so_ngay_cong` / 26 + `phu_cap_chuc_vu` + `luong_lam_them` + `tien_thuong` - `cac_khoan_tru`) STORED,
  `ngay_cham_cong` date NOT NULL,
  `trang_thai` enum('Tạm tính','Đã thanh toán') DEFAULT 'Tạm tính'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `luong`
--

INSERT INTO `luong` (`id_luong`, `id_nhan_vien`, `thang`, `so_ngay_cong`, `luong_co_ban`, `phu_cap_chuc_vu`, `luong_lam_them`, `tien_thuong`, `cac_khoan_tru`, `ngay_cham_cong`, `trang_thai`) VALUES
(1, 1, '2025-04', 8, 7000000, 0, 0, 500000, 360000, '2025-04-20', 'Tạm tính'),
(2, 2, '2025-04', 7, 10000000, 0, 576923, 1000000, 530000, '2025-04-20', 'Tạm tính'),
(3, 3, '2025-04', 6, 12000000, 5000000, 0, 1500000, 460000, '2025-04-20', 'Tạm tính'),
(4, 4, '2025-04', 6, 5000000, 0, 288462, 300000, 440000, '2025-04-20', 'Tạm tính'),
(5, 5, '2025-04', 6, 3000000, 0, 0, 200000, 449250, '2025-04-20', 'Tạm tính'),
(6, 6, '2025-04', 6, 9000000, 0, 0, 800000, 240000, '2025-04-20', 'Tạm tính'),
(7, 7, '2025-04', 6, 15000000, 10000000, 0, 2000000, 1272000, '2025-04-20', 'Tạm tính'),
(8, 8, '2025-04', 6, 8000000, 0, 0, 600000, 330000, '2025-04-20', 'Tạm tính'),
(9, 9, '2025-04', 5, 11000000, 5000000, 0, 1200000, 2139500, '2025-04-20', 'Tạm tính'),
(10, 10, '2025-04', 6, 3000000, 0, 0, 200000, 449250, '2025-04-20', 'Tạm tính'),
(11, 11, '2025-04', 6, 7500000, 0, 0, 500000, 1458750, '2025-04-20', 'Tạm tính'),
(12, 12, '2025-04', 6, 9500000, 0, 0, 800000, 1847750, '2025-04-20', 'Tạm tính'),
(13, 13, '2025-04', 6, 13000000, 5000000, 0, 1500000, 3110250, '2025-04-20', 'Tạm tính'),
(14, 14, '2025-04', 6, 6000000, 0, 0, 400000, 1167000, '2025-04-20', 'Tạm tính'),
(15, 15, '2025-04', 6, 3000000, 0, 0, 200000, 449250, '2025-04-20', 'Tạm tính'),
(16, 16, '2025-04', 6, 8500000, 0, 0, 700000, 1653250, '2025-04-20', 'Tạm tính'),
(17, 17, '2025-04', 6, 14000000, 10000000, 0, 1800000, 3349500, '2025-04-20', 'Tạm tính'),
(18, 18, '2025-04', 6, 7000000, 0, 0, 500000, 1361500, '2025-04-20', 'Tạm tính'),
(19, 19, '2025-04', 6, 12000000, 5000000, 0, 1500000, 2871000, '2025-04-20', 'Tạm tính'),
(20, 20, '2025-04', 6, 3000000, 0, 0, 200000, 449250, '2025-04-20', 'Tạm tính');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nghi_phep`
--

CREATE TABLE `nghi_phep` (
  `id_nghi_phep` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `ngay_bat_dau` date NOT NULL,
  `ngay_ket_thuc` date NOT NULL,
  `loai_nghi` enum('Có phép','Không phép') DEFAULT 'Có phép',
  `ly_do` text DEFAULT NULL,
  `trang_thai1` enum('Chờ duyệt','Đã duyệt','Từ chối') DEFAULT 'Chờ duyệt',
  `id_nguoi_duyet` int(11) DEFAULT NULL,
  `ngay_duyet` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `nghi_phep`
--

INSERT INTO `nghi_phep` (`id_nghi_phep`, `id_nhan_vien`, `ngay_bat_dau`, `ngay_ket_thuc`, `loai_nghi`, `ly_do`, `trang_thai1`, `id_nguoi_duyet`, `ngay_duyet`) VALUES
(1, 1, '2025-04-03', '2025-04-03', 'Có phép', 'Nghỉ ốm', 'Đã duyệt', 3, '2025-04-02 10:00:00'),
(2, 2, '2025-04-05', '2025-04-06', 'Có phép', 'Việc gia đình', 'Chờ duyệt', NULL, NULL),
(3, 3, '2025-04-07', '2025-04-07', 'Không phép', 'Nghỉ không lý do', 'Từ chối', 7, '2025-04-06 15:00:00'),
(4, 4, '2025-04-10', '2025-04-11', 'Có phép', 'Nghỉ phép năm', 'Đã duyệt', 9, '2025-04-09 09:00:00'),
(5, 5, '2025-04-15', '2025-04-15', 'Có phép', 'Nghỉ ốm', 'Chờ duyệt', NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nguoi_dung`
--

CREATE TABLE `nguoi_dung` (
  `id_nguoi_dung` int(11) NOT NULL,
  `ten_dang_nhap` varchar(50) NOT NULL,
  `mat_khau` varchar(255) NOT NULL,
  `vai_tro` enum('Admin','Quản lý') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `nguoi_dung`
--

INSERT INTO `nguoi_dung` (`id_nguoi_dung`, `ten_dang_nhap`, `mat_khau`, `vai_tro`) VALUES
(1, 'admin', '0192023a7bbd73250516f069df18b500', 'Admin'),
(2, 'quanly1', '0a2f0c8d3a2e0a3d3e3f2f8e2b3a1f5b', 'Quản lý'),
(3, 'quanly2', 'e2b3a1f5b0a2f0c8d3a2e0a3d3e3f2f8', 'Quản lý');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nhan_vien`
--

CREATE TABLE `nhan_vien` (
  `id_nhan_vien` int(11) NOT NULL,
  `ho_ten` varchar(100) NOT NULL,
  `gioi_tinh` enum('Nam','Nữ','Khác') DEFAULT NULL,
  `ngay_sinh` date DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `so_dien_thoai` varchar(20) DEFAULT NULL,
  `dia_chi` varchar(200) DEFAULT NULL,
  `can_cuoc_cong_dan` varchar(20) DEFAULT NULL,
  `ngay_cap` date DEFAULT NULL,
  `noi_cap` varchar(100) DEFAULT NULL,
  `que_quan` varchar(200) DEFAULT NULL,
  `hinh_anh` varchar(255) DEFAULT NULL,
  `id_phong_ban` int(11) DEFAULT NULL,
  `id_chuc_vu` int(11) DEFAULT NULL,
  `loai_hop_dong` enum('Toàn thời gian','Bán thời gian','Thực tập') NOT NULL,
  `luong_co_ban` decimal(12,2) NOT NULL,
  `ngay_vao_lam` date NOT NULL,
  `ngay_nghi_viec` date DEFAULT NULL,
  `trang_thai` enum('Đang làm việc','Nghỉ phép','Đã nghỉ việc') DEFAULT 'Đang làm việc'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `nhan_vien`
--

INSERT INTO `nhan_vien` (`id_nhan_vien`, `ho_ten`, `gioi_tinh`, `ngay_sinh`, `email`, `so_dien_thoai`, `dia_chi`, `can_cuoc_cong_dan`, `ngay_cap`, `noi_cap`, `que_quan`, `hinh_anh`, `id_phong_ban`, `id_chuc_vu`, `loai_hop_dong`, `luong_co_ban`, `ngay_vao_lam`, `ngay_nghi_viec`, `trang_thai`) VALUES
(1, 'Nguyễn Văn An', 'Nam', '1990-01-15', 'an.nguyen@example.com', '0901234561', '123 Đường Láng, Hà Nội', '123456789001', '2015-01-10', 'Hà Nội', 'Hà Nội', NULL, 1, 1, 'Toàn thời gian', 7000000.00, '2023-01-01', NULL, 'Đang làm việc'),
(2, 'Trần Thị Bình', 'Nữ', '1992-03-20', 'binh.tran@example.com', '0901234562', '45 Nguyễn Huệ, TP.HCM', '123456789002', '2016-02-15', 'TP.HCM', 'TP.HCM', NULL, 2, 1, 'Toàn thời gian', 10000000.00, '2023-02-01', NULL, 'Đang làm việc'),
(3, 'Lê Văn Cường', 'Nam', '1988-05-10', 'cuong.le@example.com', '0901234563', '78 Lê Lợi, Đà Nẵng', '123456789003', '2014-03-20', 'Đà Nẵng', 'Đà Nẵng', NULL, 3, 3, 'Toàn thời gian', 12000000.00, '2023-03-01', NULL, 'Đang làm việc'),
(4, 'Phạm Thị Dung', 'Nữ', '1995-07-25', 'dung.pham@example.com', '0901234564', '12 Trần Phú, Hà Nội', '123456789004', '2017-04-25', 'Hà Nội', 'Hà Nội', NULL, 4, 1, 'Bán thời gian', 5000000.00, '2023-04-01', NULL, 'Đang làm việc'),
(5, 'Hoàng Văn Em', 'Nam', '1993-09-30', 'em.hoang@example.com', '0901234565', '56 Nguyễn Trãi, TP.HCM', '123456789005', '2018-05-30', 'TP.HCM', 'TP.HCM', NULL, 5, 5, 'Thực tập', 3000000.00, '2023-05-01', NULL, 'Đang làm việc'),
(6, 'Nguyễn Thị Fleur', 'Nữ', '1991-11-05', 'fleur.nguyen@example.com', '0901234566', '89 Hai Bà Trưng, Hà Nội', '123456789006', '2015-06-05', 'Hà Nội', 'Hà Nội', NULL, 1, 1, 'Toàn thời gian', 9000000.00, '2023-06-01', NULL, 'Đang làm việc'),
(7, 'Trần Văn Giang', 'Nam', '1989-12-12', 'giang.tran@example.com', '0901234567', '34 Lê Duẩn, Đà Nẵng', '123456789007', '2016-07-10', 'Đà Nẵng', 'Đà Nẵng', NULL, 2, 4, 'Toàn thời gian', 15000000.00, '2023-07-01', NULL, 'Đang làm việc'),
(8, 'Lê Thị Hà', 'Nữ', '1994-02-18', 'ha.le@example.com', '0901234568', '67 Nguyễn Văn Cừ, TP.HCM', '123456789008', '2017-08-15', 'TP.HCM', 'TP.HCM', NULL, 3, 1, 'Toàn thời gian', 8000000.00, '2023-08-01', NULL, 'Đang làm việc'),
(9, 'Phạm Văn Inh', 'Nam', '1990-04-22', 'inh.pham@example.com', '0901234569', '23 Lý Thường Kiệt, Hà Nội', '123456789009', '2018-09-20', 'Hà Nội', 'Hà Nội', NULL, 4, 3, 'Toàn thời gian', 11000000.00, '2023-09-01', NULL, 'Đang làm việc'),
(10, 'Hoàng Thị Kim', 'Nữ', '1996-06-28', 'kim.hoang@example.com', '0901234570', '45 Phạm Ngọc Thạch, TP.HCM', '123456789010', '2019-10-25', 'TP.HCM', 'TP.HCM', NULL, 5, 5, 'Thực tập', 3000000.00, '2023-10-01', NULL, 'Đang làm việc'),
(11, 'Nguyễn Văn Long', 'Nam', '1987-08-03', 'long.nguyen@example.com', '0901234571', '78 Hùng Vương, Đà Nẵng', '123456789011', '2014-11-30', 'Đà Nẵng', 'Đà Nẵng', NULL, 1, 1, 'Toàn thời gian', 7500000.00, '2023-11-01', NULL, 'Đang làm việc'),
(12, 'Trần Thị Mai', 'Nữ', '1993-10-09', 'mai.tran@example.com', '0901234572', '12 Nguyễn Đình Chiểu, Hà Nội', '123456789012', '2015-12-05', 'Hà Nội', 'Hà Nội', NULL, 2, 1, 'Toàn thời gian', 9500000.00, '2023-12-01', NULL, 'Đang làm việc'),
(13, 'Lê Văn Nam', 'Nam', '1991-12-15', 'nam.le@example.com', '0901234573', '56 Trần Hưng Đạo, TP.HCM', '123456789013', '2016-01-10', 'TP.HCM', 'TP.HCM', NULL, 3, 3, 'Toàn thời gian', 13000000.00, '2024-01-01', NULL, 'Đang làm việc'),
(14, 'Phạm Thị Oanh', 'Nữ', '1988-02-20', 'oanh.pham@example.com', '0901234574', '89 Nguyễn Thị Minh Khai, Hà Nội', '123456789014', '2017-02-15', 'Hà Nội', 'Hà Nội', NULL, 4, 1, 'Bán thời gian', 6000000.00, '2024-02-01', NULL, 'Đang làm việc'),
(15, 'Hoàng Văn Phát', 'Nam', '1995-04-25', 'phat.hoang@example.com', '0901234575', '34 Lê Văn Sỹ, TP.HCM', '123456789015', '2018-03-20', 'TP.HCM', 'TP.HCM', NULL, 5, 5, 'Thực tập', 3000000.00, '2024-03-01', NULL, 'Đang làm việc'),
(16, 'Nguyễn Thị Quyên', 'Nữ', '1992-06-30', 'quyen.nguyen@example.com', '0901234576', '67 Bà Triệu, Hà Nội', '123456789016', '2019-04-25', 'Hà Nội', 'Hà Nội', NULL, 1, 1, 'Toàn thời gian', 8500000.00, '2024-04-01', NULL, 'Đang làm việc'),
(17, 'Trần Văn Sơn', 'Nam', '1989-08-05', 'son.tran@example.com', '0901234577', '23 Tôn Đức Thắng, Đà Nẵng', '123456789017', '2015-05-30', 'Đà Nẵng', 'Đà Nẵng', NULL, 2, 4, 'Toàn thời gian', 14000000.00, '2023-01-01', '2024-12-31', 'Đã nghỉ việc'),
(18, 'Lê Thị Thanh', 'Nữ', '1994-10-10', 'thanh.le@example.com', '0901234578', '45 Nguyễn Văn Trỗi, TP.HCM', '123456789018', '2016-06-05', 'TP.HCM', 'TP.HCM', NULL, 3, 1, 'Toàn thời gian', 7000000.00, '2023-02-01', NULL, 'Đang làm việc'),
(19, 'Phạm Văn Uy', 'Nam', '1990-12-15', 'uy.pham@example.com', '0901234579', '78 Lê Đại Hành, Hà Nội', '123456789019', '2017-07-10', 'Hà Nội', 'Hà Nội', NULL, 4, 3, 'Toàn thời gian', 12000000.00, '2023-03-01', NULL, 'Đang làm việc'),
(20, 'Hoàng Thị Vân', 'Nữ', '1996-02-20', 'van.hoang@example.com', '0901234580', '12 Võ Văn Tần, TP.HCM', '123456789020', '2018-08-15', 'TP.HCM', 'TP.HCM', NULL, 5, 5, 'Thực tập', 3000000.00, '2023-04-01', NULL, 'Đang làm việc');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `phong_ban`
--

CREATE TABLE `phong_ban` (
  `id_phong_ban` int(11) NOT NULL,
  `ten_phong_ban` varchar(100) NOT NULL,
  `mo_ta` text DEFAULT NULL,
  `trang_thai` enum('Hoạt động','Ngừng hoạt động') DEFAULT 'Hoạt động'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `phong_ban`
--

INSERT INTO `phong_ban` (`id_phong_ban`, `ten_phong_ban`, `mo_ta`, `trang_thai`) VALUES
(1, 'Nhân sự', 'Quản lý nhân sự và tuyển dụng', 'Hoạt động'),
(2, 'Kế toán', 'Quản lý tài chính và kế toán', 'Hoạt động'),
(3, 'Công nghệ', 'Phát triển phần mềm và công nghệ', 'Hoạt động'),
(4, 'Kinh doanh', 'Phát triển kinh doanh và bán hàng', 'Hoạt động'),
(5, 'Marketing', 'Quảng bá thương hiệu và sản phẩm', 'Hoạt động');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tong_hop_cong_thang`
--

CREATE TABLE `tong_hop_cong_thang` (
  `id_tong_hop` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `thang` varchar(7) NOT NULL,
  `tong_cong` decimal(5,2) DEFAULT 0.00,
  `cong_chinh` decimal(5,2) DEFAULT 0.00,
  `lam_them` decimal(5,2) DEFAULT 0.00,
  `ngay_lam_viec` int(11) DEFAULT 0,
  `ngay_nghi_phep` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `tong_hop_cong_thang`
--

INSERT INTO `tong_hop_cong_thang` (`id_tong_hop`, `id_nhan_vien`, `thang`, `tong_cong`, `cong_chinh`, `lam_them`, `ngay_lam_viec`, `ngay_nghi_phep`) VALUES
(1, 1, '2025-04', 8.00, 8.00, 0.00, 19, 1),
(2, 2, '2025-04', 7.00, 7.00, 2.00, 20, 0),
(3, 3, '2025-04', 6.00, 6.00, 0.00, 19, 0),
(4, 4, '2025-04', 6.00, 6.00, 1.00, 20, 0),
(5, 5, '2025-04', 6.00, 6.00, 0.00, 20, 0),
(6, 6, '2025-04', 6.00, 6.00, 0.00, 20, 0),
(7, 7, '2025-04', 5.50, 5.50, 0.00, 20, 0),
(8, 8, '2025-04', 6.00, 6.00, 0.00, 20, 0),
(9, 9, '2025-04', 4.50, 4.50, 0.00, 20, 0),
(10, 10, '2025-04', 6.00, 6.00, 0.00, 20, 0),
(11, 11, '2025-04', 6.00, 6.00, 0.00, 20, 0),
(12, 12, '2025-04', 6.00, 6.00, 0.00, 20, 0),
(13, 13, '2025-04', 6.00, 6.00, 0.00, 20, 0),
(14, 14, '2025-04', 6.00, 6.00, 0.00, 20, 0),
(15, 15, '2025-04', 6.00, 6.00, 0.00, 20, 0),
(16, 16, '2025-04', 6.00, 6.00, 0.00, 20, 0),
(17, 17, '2025-04', 6.00, 6.00, 0.00, 20, 0),
(18, 18, '2025-04', 6.00, 6.00, 0.00, 20, 0),
(19, 19, '2025-04', 6.00, 6.00, 0.00, 20, 0),
(20, 20, '2025-04', 6.00, 6.00, 0.00, 20, 0);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `bao_hiem_thue_tncn`
--
ALTER TABLE `bao_hiem_thue_tncn`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_nhan_vien_thang` (`id_nhan_vien`,`thang`);

--
-- Chỉ mục cho bảng `cham_cong`
--
ALTER TABLE `cham_cong`
  ADD PRIMARY KEY (`id_cham_cong`),
  ADD UNIQUE KEY `uk_nhan_vien_ngay` (`id_nhan_vien`,`ngay_lam_viec`),
  ADD KEY `idx_cham_cong_ngay_lam_viec` (`ngay_lam_viec`);

--
-- Chỉ mục cho bảng `chuc_vu`
--
ALTER TABLE `chuc_vu`
  ADD PRIMARY KEY (`id_chuc_vu`);

--
-- Chỉ mục cho bảng `luong`
--
ALTER TABLE `luong`
  ADD PRIMARY KEY (`id_luong`),
  ADD UNIQUE KEY `uk_nhan_vien_thang` (`id_nhan_vien`,`thang`),
  ADD KEY `idx_luong_thang` (`thang`);

--
-- Chỉ mục cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  ADD PRIMARY KEY (`id_nghi_phep`),
  ADD KEY `id_nhan_vien` (`id_nhan_vien`),
  ADD KEY `id_nguoi_duyet` (`id_nguoi_duyet`),
  ADD KEY `idx_nghi_phep_ngay_bat_dau` (`ngay_bat_dau`);

--
-- Chỉ mục cho bảng `nguoi_dung`
--
ALTER TABLE `nguoi_dung`
  ADD PRIMARY KEY (`id_nguoi_dung`),
  ADD UNIQUE KEY `uk_ten_dang_nhap` (`ten_dang_nhap`);

--
-- Chỉ mục cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  ADD PRIMARY KEY (`id_nhan_vien`),
  ADD UNIQUE KEY `uk_email` (`email`),
  ADD UNIQUE KEY `uk_can_cuoc_cong_dan` (`can_cuoc_cong_dan`),
  ADD KEY `idx_nhan_vien_phong_ban` (`id_phong_ban`),
  ADD KEY `idx_nhan_vien_chuc_vu` (`id_chuc_vu`);

--
-- Chỉ mục cho bảng `phong_ban`
--
ALTER TABLE `phong_ban`
  ADD PRIMARY KEY (`id_phong_ban`);

--
-- Chỉ mục cho bảng `tong_hop_cong_thang`
--
ALTER TABLE `tong_hop_cong_thang`
  ADD PRIMARY KEY (`id_tong_hop`),
  ADD UNIQUE KEY `uk_nhan_vien_thang` (`id_nhan_vien`,`thang`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `bao_hiem_thue_tncn`
--
ALTER TABLE `bao_hiem_thue_tncn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT cho bảng `cham_cong`
--
ALTER TABLE `cham_cong`
  MODIFY `id_cham_cong` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=247;

--
-- AUTO_INCREMENT cho bảng `chuc_vu`
--
ALTER TABLE `chuc_vu`
  MODIFY `id_chuc_vu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `luong`
--
ALTER TABLE `luong`
  MODIFY `id_luong` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=164;

--
-- AUTO_INCREMENT cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  MODIFY `id_nghi_phep` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `nguoi_dung`
--
ALTER TABLE `nguoi_dung`
  MODIFY `id_nguoi_dung` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  MODIFY `id_nhan_vien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT cho bảng `phong_ban`
--
ALTER TABLE `phong_ban`
  MODIFY `id_phong_ban` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `tong_hop_cong_thang`
--
ALTER TABLE `tong_hop_cong_thang`
  MODIFY `id_tong_hop` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `bao_hiem_thue_tncn`
--
ALTER TABLE `bao_hiem_thue_tncn`
  ADD CONSTRAINT `bao_hiem_thue_tncn_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `cham_cong`
--
ALTER TABLE `cham_cong`
  ADD CONSTRAINT `cham_cong_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `luong`
--
ALTER TABLE `luong`
  ADD CONSTRAINT `luong_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  ADD CONSTRAINT `nghi_phep_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE,
  ADD CONSTRAINT `nghi_phep_ibfk_2` FOREIGN KEY (`id_nguoi_duyet`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE SET NULL;

--
-- Các ràng buộc cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  ADD CONSTRAINT `nhan_vien_ibfk_1` FOREIGN KEY (`id_phong_ban`) REFERENCES `phong_ban` (`id_phong_ban`) ON DELETE SET NULL,
  ADD CONSTRAINT `nhan_vien_ibfk_2` FOREIGN KEY (`id_chuc_vu`) REFERENCES `chuc_vu` (`id_chuc_vu`) ON DELETE SET NULL;

--
-- Các ràng buộc cho bảng `tong_hop_cong_thang`
--
ALTER TABLE `tong_hop_cong_thang`
  ADD CONSTRAINT `tong_hop_cong_thang_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
