<?php

namespace Services;

use SendGrid;
use SendGrid\Mail\Mail;
use PHPMailer\PHPMailer\PHPMailer;
use Exception;

require_once __DIR__ . '/../config/email_config.php';
require 'vendor/autoload.php';

class EmailService {
    private $config;
    private $driver;
    private $sendgrid;

    public function __construct() {
        try {
            $this->config = require __DIR__ . '/../config/email.php';
            $this->driver = $this->config['driver'];
            
            if (!isset($this->config['sendgrid']['api_key'])) {
                throw new Exception("SendGrid API key không được cấu hình");
            }
            
            $this->sendgrid = new \SendGrid(SENDGRID_API_KEY);
            error_log("EmailService khởi tạo thành công với driver: " . $this->driver);
        } catch (Exception $e) {
            error_log("Lỗi khởi tạo EmailService: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Gửi email sử dụng driver được cấu hình
     */
    public function send($to, $subject, $content) {
        try {
            error_log("Bắt đầu gửi email đến: " . $to);
            error_log("Chủ đề: " . $subject);
            
            $email = new Mail();
            $email->setFrom($this->config['from_email'], $this->config['from_name']);
            $email->setReplyTo($this->config['reply_to']);
            $email->setSubject($subject);
            $email->addTo($to);
            $email->addContent("text/html", $content);

            error_log("Chuẩn bị gửi email qua SendGrid...");
            $response = $this->sendgrid->send($email);
            
            error_log("Phản hồi từ SendGrid - Status Code: " . $response->statusCode());
            error_log("Phản hồi từ SendGrid - Headers: " . print_r($response->headers(), true));
            error_log("Phản hồi từ SendGrid - Body: " . $response->body());
            
            if ($response->statusCode() >= 200 && $response->statusCode() < 300) {
                error_log("✓ Email gửi thành công đến: " . $to);
                return true;
            } else {
                $errorMessage = "Lỗi gửi email (Status: " . $response->statusCode() . "): " . $response->body();
                error_log("✗ " . $errorMessage);
                throw new Exception($errorMessage);
            }
        } catch (Exception $e) {
            $errorMessage = "Lỗi gửi email đến {$to}: " . $e->getMessage();
            error_log("✗ " . $errorMessage);
            error_log("Stack trace: " . $e->getTraceAsString());
            throw new Exception($errorMessage);
        }
    }

    /**
     * Gửi email sử dụng SendGrid API
     */
    private function sendWithSendGrid($to, $subject, $htmlContent, $attachments) {
        $email = new Mail();
        $email->setFrom($this->config['from_address'], $this->config['from_name']);
        $email->setSubject($subject);
        $email->addTo($to);
        $email->addContent("text/html", $htmlContent);

        // Thêm file đính kèm nếu có
        foreach ($attachments as $attachment) {
            if (isset($attachment['path']) && file_exists($attachment['path'])) {
                $email->addAttachment(
                    base64_encode(file_get_contents($attachment['path'])),
                    mime_content_type($attachment['path']),
                    basename($attachment['path']),
                    "attachment"
                );
            }
        }

        $response = $this->sendgrid->send($email);
        
        if ($response->statusCode() >= 400) {
            throw new Exception("Lỗi SendGrid: " . $response->body());
        }

        return true;
    }

    /**
     * Gửi email sử dụng SMTP (PHPMailer)
     */
    private function sendWithSMTP($to, $subject, $htmlContent, $attachments) {
        $mail = new PHPMailer(true);
        
        try {
            // Cấu hình SMTP
            $mail->isSMTP();
            $mail->Host = $this->config['smtp']['host'];
            $mail->SMTPAuth = true;
            $mail->Username = $this->config['smtp']['username'];
            $mail->Password = $this->config['smtp']['password'];
            $mail->SMTPSecure = $this->config['smtp']['encryption'];
            $mail->Port = $this->config['smtp']['port'];
            $mail->CharSet = 'UTF-8';

            // Cấu hình email
            $mail->setFrom($this->config['from']['address'], $this->config['from']['name']);
            $mail->addAddress($to);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $htmlContent;

            // Thêm file đính kèm
            foreach ($attachments as $attachment) {
                $mail->addAttachment($attachment['path'], $attachment['name']);
            }

            $mail->send();
            return true;
        } catch (Exception $e) {
            throw new Exception("Lỗi SMTP: " . $mail->ErrorInfo);
        }
    }

    public function verifyEmailConfig() {
        try {
            // Kiểm tra cấu hình cơ bản
            if (!isset($this->config['from_email']) || !filter_var($this->config['from_email'], FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Email người gửi không hợp lệ");
            }

            if (!isset($this->config['sendgrid']['api_key']) || empty($this->config['sendgrid']['api_key'])) {
                throw new Exception("SendGrid API key không được cấu hình");
            }

            // Gửi email test
            $testEmail = new Mail();
            $testEmail->setFrom($this->config['from_email'], $this->config['from_name']);
            $testEmail->setSubject("Test Email Configuration");
            $testEmail->addTo($this->config['from_email']);
            $testEmail->addContent("text/html", "<h1>Test Email</h1><p>Đây là email test để kiểm tra cấu hình.</p>");

            $response = $this->sendgrid->send($testEmail);
            
            if ($response->statusCode() >= 200 && $response->statusCode() < 300) {
                return [
                    'success' => true,
                    'message' => 'Cấu hình email hoạt động tốt'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Lỗi gửi email test: ' . $response->body()
                ];
            }
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Lỗi kiểm tra cấu hình: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Gửi email thông báo trạng thái đơn nghỉ phép
     */
    public function sendLeaveRequestNotification($recipientEmail, $recipientName, $status, $startDate, $endDate, $reason = null) {
        $email = new \SendGrid\Mail\Mail();
        $email->setFrom(EMAIL_FROM, EMAIL_FROM_NAME);
        $email->setSubject("Cập nhật trạng thái đơn nghỉ phép");
        
        // Xây dựng nội dung email
        $content = "Xin chào $recipientName,\n\n";
        $content .= "Đơn nghỉ phép của bạn từ ngày $startDate đến ngày $endDate đã được cập nhật.\n\n";
        $content .= "Trạng thái: $status\n";
        
        if ($reason && $status === 'Từ chối') {
            $content .= "Lý do từ chối: $reason\n";
        }
        
        $content .= "\nĐây là email tự động, vui lòng không trả lời email này.\n";
        $content .= "\nTrân trọng,\nHệ thống Quản lý nhân sự";
        
        $email->addTo($recipientEmail, $recipientName);
        $email->addContent("text/plain", $content);
        
        try {
            $response = $this->sendgrid->send($email);
            return [
                'success' => $response->statusCode() === 202,
                'message' => $response->statusCode() === 202 ? 'Email sent successfully' : 'Failed to send email'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error sending email: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Gửi email thông báo cho quản lý về đơn nghỉ phép mới
     */
    public function sendNewLeaveRequestNotification($managerEmail, $managerName, $employeeName, $startDate, $endDate, $reason) {
        $email = new \SendGrid\Mail\Mail();
        $email->setFrom(EMAIL_FROM, EMAIL_FROM_NAME);
        $email->setSubject("Đơn nghỉ phép mới cần duyệt");
        
        $content = "Xin chào $managerName,\n\n";
        $content .= "Có một đơn nghỉ phép mới cần được xét duyệt:\n\n";
        $content .= "Nhân viên: $employeeName\n";
        $content .= "Thời gian: Từ $startDate đến $endDate\n";
        $content .= "Lý do: $reason\n\n";
        $content .= "Vui lòng đăng nhập vào hệ thống để xét duyệt đơn nghỉ phép.\n\n";
        $content .= "Trân trọng,\nHệ thống Quản lý nhân sự";
        
        $email->addTo($managerEmail, $managerName);
        $email->addContent("text/plain", $content);
        
        try {
            $response = $this->sendgrid->send($email);
            return [
                'success' => $response->statusCode() === 202,
                'message' => $response->statusCode() === 202 ? 'Email sent successfully' : 'Failed to send email'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error sending email: ' . $e->getMessage()
            ];
        }
    }
} 