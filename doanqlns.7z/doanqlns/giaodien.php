<?php
require_once __DIR__ . '/includes/check_login.php';
include(__DIR__ . '/includes/header.php');
include(__DIR__ . '/includes/sidebar.php');

require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/EmployeeRepository.php';

// Khởi tạo kết nối database
$database = new Database();
$conn = $database->getConnection();

if (!$conn) {
    error_log("Failed to connect to the database.");
    die("Không thể kết nối đến cơ sở dữ liệu. Vui lòng thử lại sau.");
}

// Khởi tạo repository
$employeeRepo = new EmployeeRepository($conn);

// Tính tổng số nhân viên
$totalEmployees = $employeeRepo->getTotalEmployees();

// Tính tỷ lệ đi làm đúng giờ
$punctuality = $employeeRepo->getPunctualityComparison();

// Tính số đơn xin nghỉ phép chờ xét duyệt
$leaveCount = $employeeRepo->getPendingLeaveCount();

// Tính số nhân viên mới
$newEmployees = $employeeRepo->getNewEmployees();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Quản Lý Nhân Sự</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
   <style>
        .main-content { padding: 20px; }
        .page-header { display: flex; justify-content: space-between; align-items: center; }
        .dashboard-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
        .card { border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .card-primary { background: rgb(255, 206, 206); color: white; }
        .card-success { background: rgb(255, 253, 205); color: white; }
        .card-warning { background: rgb(199, 255, 248); color: white; }
        .card-danger { background: rgb(253, 199, 255); color: white; }
        .card-body { padding: 20px; }
        .card-icon { font-size: 24px; margin-bottom: 10px; }
        .card-value { font-size: 32px; font-weight: bold; }
        .card-description { font-size: 14px; margin-top: 5px; }
        .card-footer { padding: 10px; background: rgba(0,0,0,0.1); }
        .quick-actions { margin-top: 30px; }
        .action-buttons { display: flex; gap: 10px; flex-wrap: wrap; }
        .action-btn { padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
        .loading { display: none; text-align: center; padding: 20px; }
        .loading::after {
            content: '';
            border: 4px solid #f3f3f3;
            border-top: 4px solid #1fec56;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            animation: spin 1s linear infinite;
            display: inline-block;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        #fileInput { display: none; }

      #employeeModal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 1000;
    align-items: center;
    justify-content: center;
}
#employeeModal.show {
    display: flex;
}
#employeeModal > div {
    background: white;
    width: 400px;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}
#employeeSelect {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}  
    </style>
</head>
<body>
    <div class="main-content">
        <div class="page-header">
            <h1>Dashboard Quản Lý Nhân Sự</h1>
            <div class="user-profile">
                <div class="user-info">
                    <span class="user-name">Chào mừng <?= htmlspecialchars($_SESSION['username']) ?> đến với hệ thống</span>
                </div>
            </div>
        </div>

        <div class="dashboard-cards">
            <div class="card card-primary">
                <div class="card-body">
                    <div class="card-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3 class="card-title">Tổng nhân viên</h3>
                    <div class="card-value"><?php echo number_format($totalEmployees); ?></div>
                    <div class="card-description">+<?php echo $newEmployees; ?> so với tháng trước</div>
                </div>
                <div class="card-footer">
                    <i class="fas fa-clock"></i> Cập nhật: <span class="datetime"></span>
                </div>
            </div>

            <div class="card card-success">
                <div class="card-body">
                    <div class="card-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <h3 class="card-title">Đi làm đúng giờ</h3>
                    <div class="card-value"><?php echo $punctuality['current']; ?>%</div>
                    <div class="card-description">
                        <?php
                        $diff = abs($punctuality['difference']);
                        if ($diff > 0) {
                            echo ($punctuality['difference'] >= 0 ? '↑' : '↓') . ' ' . $diff . '% so với tháng trước';
                        } else {
                            echo 'Không thay đổi so với tháng trước';
                        }
                        ?>
                    </div>
                </div>
                <div class="card-footer">
                    <i class="fas fa-clock"></i> Cập nhật: <span class="datetime"></span>
                </div>
            </div>

            <div class="card card-warning">
                <div class="card-body">
                    <div class="card-icon">
                        <i class="fas fa-calendar-times"></i>
                    </div>
                    <h3 class="card-title">Nghỉ phép</h3>
                    <div class="card-value"><?php echo number_format($leaveCount); ?></div>
                    <div class="card-description">Đơn nghỉ phép chờ duyệt</div>
                </div>
                <div class="card-footer">
                    <i class="fas fa-clock"></i> Cập nhật: <span class="datetime"></span>
                </div>
            </div>

            <div class="card card-danger">
                <div class="card-body">
                    <div class="card-icon">
                        <i class="fas fa-user-clock"></i>
                    </div>
                    <h3 class="card-title">Nhân viên mới</h3>
                    <div class="card-value"><?php echo number_format($newEmployees); ?></div>
                    <div class="card-description">Trong tháng này</div>
                </div>
                <div class="card-footer">
                    <i class="fas fa-clock"></i> Cập nhật: <span class="datetime"></span>
                </div>
            </div>
        </div>

       <div class="quick-actions">
    <!-- Modal chọn nhân viên -->
    <div id="employeeModal">
        <div>
            <h3>Chọn Nhân Viên</h3>
            <select id="employeeSelect">
                <option value="">-- Chọn nhân viên --</option>
            </select>
            <div style="display: flex; justify-content: flex-end; gap: 10px;">
                <button onclick="closeEmployeeModal()" style="padding: 8px 16px; border: none; background: #ccc; border-radius: 5px; cursor: pointer;">Hủy</button>
                <button onclick="confirmEmployeeSelection()" style="padding: 8px 16px; border: none; background: #17a2b8; color: white; border-radius: 5px; cursor: pointer;">Xác nhận</button>
            </div>
        </div>
    </div>
    <h3 class="section-title"><i class="fas fa-bolt"></i> Thao tác nhanh</h3>
    <div class="action-buttons">
        <button class="action-btn" onclick="window.location.href='views/users.php?action=add'">
            <i class="fas fa-user-plus"></i>
            <span>Thêm nhân viên</span>
        </button>
        <button class="action-btn" onclick="exportPayrollToExcel()">
            <i class="fas fa-file-excel" style="color: #217346;"></i>
            <span>Xuất Excel Lương</span>
        </button>
        <button class="action-btn" onclick="exportAttendanceToExcel()">
            <i class="fas fa-file-excel" style="color: #217346;"></i>
            <span>Xuất Excel Chấm Công</span>
        </button>
        <button class="action-btn" onclick="triggerFileUpload()">
            <i class="fas fa-file-alt" style="color: #17a2b8;"></i>
            <span>Nhập Hồ Sơ Nhân Viên</span>
        </button>
        <!-- Input file -->
        <input type="file" id="fileInput" accept=".csv" onchange="handleFileUpload(event)" style="display: none;">
    </div>
    <!-- Loading indicator -->
    <div class="loading" id="loadingIndicator"></div>
</div>
<script>
// Hiển thị/Ẩn loading
function showLoading() {
    const loading = document.getElementById('loadingIndicator');
    if (loading) loading.style.display = 'block';
}

function hideLoading() {
    const loading = document.getElementById('loadingIndicator');
    if (loading) loading.style.display = 'none';
}

// Hàm định dạng tiền tệ
function formatCurrency(value) {
    if (value == null || value == undefined) return '0';
    return Number(value).toLocaleString('vi-VN', { style: 'currency', currency: 'VND' });
}

// Hàm định dạng số: loại bỏ .00 cho số nguyên
function formatNumber(number) {
    if (Number.isInteger(number)) {
        return number.toString();
    }
    return number.toFixed(2);
}

// Hàm mở modal chọn nhân viên
async function openEmployeeModal() {
    console.log('Opening employee modal...');
    try {
        const response = await fetch('http://localhost/doanqlns/index.php/api/users');
        if (!response.ok) {
            throw new Error(`Lỗi khi tải danh sách nhân viên: ${response.status}`);
        }
        const usersData = await response.json();
        console.log('Users data:', usersData);

        if (!Array.isArray(usersData)) {
            throw new Error('Dữ liệu nhân viên không hợp lệ, không phải mảng');
        }

        if (usersData.length === 0) {
            alert('Không có nhân viên nào trong hệ thống.');
            return;
        }

        const employeeSelect = document.getElementById('employeeSelect');
        if (!employeeSelect) {
            throw new Error('Không tìm thấy phần tử employeeSelect');
        }

        employeeSelect.innerHTML = '<option value="">-- Chọn nhân viên --</option>';
        usersData.forEach(user => {
            if (user.id_nhan_vien && user.ho_ten) {
                const option = document.createElement('option');
                option.value = user.id_nhan_vien;
                option.textContent = user.ho_ten;
                employeeSelect.appendChild(option);
            }
        });

        const modal = document.getElementById('employeeModal');
        if (!modal) {
            throw new Error('Không tìm thấy phần tử employeeModal');
        }

        modal.classList.add('show');
        console.log('Modal displayed');
    } catch (error) {
        console.error('Lỗi khi tải danh sách nhân viên:', error);
        alert('Lỗi khi tải danh sách nhân viên: ' + error.message);
    }
}

// Hàm đóng modal
function closeEmployeeModal() {
    const modal = document.getElementById('employeeModal');
    if (modal) {
        modal.classList.remove('show');
        console.log('Modal closed');
    }
}

// Hàm xác nhận chọn nhân viên và mở hộp thoại chọn file
function confirmEmployeeSelection() {
    console.log('Confirm employee selection called');
    const employeeSelect = document.getElementById('employeeSelect');
    const selectedEmployeeId = employeeSelect.value;

    if (!selectedEmployeeId) {
        alert('Vui lòng chọn một nhân viên!');
        return;
    }

    console.log('Selected employee ID:', selectedEmployeeId);
    closeEmployeeModal();

    const fileInput = document.getElementById('fileInput');
    if (fileInput) {
        fileInput.click();
        console.log('File input triggered');
    } else {
        console.error('Không tìm thấy phần tử fileInput');
        alert('Lỗi: Không tìm thấy input file');
    }
}

// Hàm triggerFileUpload
function triggerFileUpload() {
    console.log('Trigger file upload');
    openEmployeeModal();
}

// Hàm xử lý upload file
async function handleFileUpload(event) {
    const file = event.target.files[0];
    if (!file) {
        console.log('No file selected');
        return;
    }

    if (!file.name.endsWith('.csv')) {
        alert('Vui lòng chọn file .csv!');
        event.target.value = '';
        return;
    }

    const employeeSelect = document.getElementById('employeeSelect');
    const selectedEmployeeId = employeeSelect ? employeeSelect.value : '';

    if (!selectedEmployeeId) {
        alert('Vui lòng chọn một nhân viên trước khi nhập file!');
        event.target.value = '';
        return;
    }

    console.log('Uploading file for employeeId:', selectedEmployeeId);

    showLoading();
    try {
        const formData = new FormData();
        formData.append('csvFile', file);
        formData.append('employeeId', selectedEmployeeId);

        const response = await fetch('http://localhost/doanqlns/index.php/api/import_employees', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        console.log('Server response:', result);

        if (!response.ok) {
            throw new Error('Lỗi khi tải file lên server: ' + response.status);
        }

        if (result.success) {
            alert('Cập nhật hồ sơ nhân viên thành công!');
        } else {
            alert('Lỗi khi cập nhật hồ sơ: ' + result.message);
        }
    } catch (error) {
        console.error('Lỗi khi xử lý file:', error);
        alert('Lỗi khi nhập file: ' + error.message);
    } finally {
        hideLoading();
        event.target.value = '';
    }
}

// Hàm tải dữ liệu chấm công
async function loadAttendanceData(month, year) {
    try {
        const response = await fetch('http://localhost/doanqlns/index.php/api/chamcong');
        if (!response.ok) throw new Error(`Lỗi khi tải dữ liệu chấm công: ${response.status}`);
        const data = await response.json();
        if (!Array.isArray(data)) throw new Error('Dữ liệu chấm công không hợp lệ');

        const filteredData = data.filter(record => {
            const recordDate = new Date(record.ngay_lam_viec);
            return recordDate.getMonth() + 1 === month && recordDate.getFullYear() === year;
        });

        const attendanceByEmployee = {};
        const uniqueEmployeeIds = [...new Set(filteredData.map(record => record.id_nhan_vien))];

        uniqueEmployeeIds.forEach(userId => {
            const stats = calculateAttendanceStats(userId, month, year, filteredData);
            attendanceByEmployee[userId] = stats.totalWorkDays;
        });

        return attendanceByEmployee;
    } catch (error) {
        console.error('Lỗi khi tải dữ liệu chấm công:', error);
        return {};
    }
}

// Hàm tính thống kê chấm công
function calculateAttendanceStats(userId, month, year, data) {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);
    const records = data.filter(record => {
        const recordDate = new Date(record.ngay_lam_viec);
        return record.id_nhan_vien == userId &&
            recordDate >= startDate &&
            recordDate <= endDate;
    });

    let diemDanhDays = 0;
    let nghiDays = 0;
    let khongPhepCount = 0;

    for (let day = 1; day <= endDate.getDate(); day++) {
        const date = new Date(year, month - 1, day);
        const dateStr = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
        const isSunday = date.getDay() === 0;
        const record = records.find(r => r.ngay_lam_viec === dateStr);

        if (isSunday) {
            diemDanhDays += 1;
        } else if (record) {
            if (record.trang_thai === 'Đúng giờ') {
                diemDanhDays += 1;
            } else if (record.trang_thai === 'Đi trễ') {
                diemDanhDays += 0.75;
            } else if (record.trang_thai === 'Có phép') {
                diemDanhDays += 1;
                nghiDays -= 0.5;
                khongPhepCount += 0.5;
            } else if (record.trang_thai === 'Không phép') {
                diemDanhDays += 1;
                nghiDays -= 1;
                khongPhepCount += 1;
            }
        }
    }

    const totalWorkDays = diemDanhDays - khongPhepCount;
    return { diemDanhDays, nghiDays, totalWorkDays };
}

// Hàm tải dữ liệu thưởng
async function loadBonusData(month, year) {
    try {
        const response = await fetch('http://localhost/doanqlns/index.php/api/thuong');
        if (!response.ok) throw new Error(`Lỗi khi tải dữ liệu thưởng: ${response.status}`);
        const data = await response.json();
        if (!Array.isArray(data)) throw new Error('Dữ liệu thưởng không hợp lệ');
        return data.filter(record => {
            const recordDate = new Date(record.ngay);
            return recordDate.getMonth() + 1 === month && recordDate.getFullYear() === year;
        });
    } catch (error) {
        console.error('Lỗi khi tải dữ liệu thưởng:', error);
        return [];
    }
}

// Hàm tính tổng tiền thưởng
function calculateTotalBonus(bonusData, userId, month, year) {
    const records = bonusData.filter(record => {
        const recordDate = new Date(record.ngay);
        return record.id_nhan_vien == userId &&
            recordDate.getMonth() + 1 === month &&
            recordDate.getFullYear() === year;
    });

    const totalBonus = records.reduce((sum, record) => sum + (parseFloat(record.tien_thuong) || 0), 0);
    return totalBonus;
}

// Hàm xuất Excel bảng lương
async function exportPayrollToExcel() {
    const currentDate = new Date();
    const month = currentDate.getMonth() + 1;
    const year = currentDate.getFullYear();

    showLoading();
    try {
        const luongResponse = await fetch('http://localhost/doanqlns/index.php/api/luong');
        if (!luongResponse.ok) throw new Error(`Lỗi khi tải dữ liệu lương: ${luongResponse.status}`);
        let luongData = await luongResponse.json();
        if (!Array.isArray(luongData)) throw new Error('Dữ liệu lương không hợp lệ');

        luongData = luongData.filter(record => {
            const [recordYear, recordMonth] = record.thang.split('-').map(Number);
            return recordMonth === month && recordYear === year;
        });

        const attendanceByEmployee = await loadAttendanceData(month, year);
        const bonusData = await loadBonusData(month, year);

        if (luongData.length === 0) {
            throw new Error(`Không có dữ liệu lương cho tháng ${month}/${year}`);
        }

        const headers = [
            'Mã Lương',
            'Tên Nhân Viên',
            'Tháng',
            'Số Ngày Công',
            'Lương Tháng',
            'Phụ Cấp',
            'Tiền Thưởng',
            'Các Khoản Trừ',
            'Lương Thực Nhận'
        ];

        const csvRows = [headers.map(header => `"${header}"`).join(',')];

        luongData.forEach(record => {
            const adjustedBasicSalary = parseFloat(record.luong_co_ban) || 0;
            const totalBonus = calculateTotalBonus(bonusData, record.id_nhan_vien, month, year);
            const phuCapChucVu = parseFloat(record.phu_cap_chuc_vu) || 0;
            const cacKhoanTru = parseFloat(record.cac_khoan_tru) || 0;
            const soNgayCong = attendanceByEmployee[record.id_nhan_vien] || 0;
            const luongThucNhan = adjustedBasicSalary + phuCapChucVu + totalBonus - cacKhoanTru;

            const row = [
                record.id_luong || '',
                record.ho_ten || '',
                record.thang || `${month}/${year}`,
                formatNumber(soNgayCong),
                adjustedBasicSalary.toLocaleString('vi-VN'),
                phuCapChucVu.toLocaleString('vi-VN'),
                totalBonus.toLocaleString('vi-VN'),
                cacKhoanTru.toLocaleString('vi-VN'),
                luongThucNhan.toLocaleString('vi-VN')
            ].map(value => `"${value.toString().replace(/"/g> '""')}"`);

            csvRows.push(row.join(','));
        });

        const csvContent = '\uFEFF' + csvRows.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `BangLuong_Thang${month}_${year}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    } catch (error) {
        console.error('Lỗi khi xuất CSV:', error);
        alert('Lỗi khi xuất file CSV: ' + error.message);
    } finally {
        hideLoading();
    }
}

// Hàm xuất Excel chấm công
async function exportAttendanceToExcel() {
    const month = parseInt(document.getElementById('selectMonth')?.value || (new Date().getMonth() + 1));
    const year = parseInt(document.getElementById('selectYear')?.value || new Date().getFullYear());
    const daysInMonth = new Date(year, month, 0).getDate();

    showLoading();
    try {
        const usersResponse = await fetch('http://localhost/doanqlns/index.php/api/users');
        if (!usersResponse.ok) throw new Error('Lỗi khi tải danh sách nhân viên');
        const usersData = await usersResponse.json();
        if (!Array.isArray(usersData)) throw new Error('Danh sách nhân viên không hợp lệ');

        const attendanceResponse = await fetch('http://localhost/doanqlns/index.php/api/chamcong');
        if (!attendanceResponse.ok) throw new Error('Lỗi khi tải dữ liệu chấm công');
        const attendanceData = await attendanceResponse.json();
        if (!Array.isArray(attendanceData)) throw new Error('Dữ liệu chấm công không hợp lệ');

        if (!usersData || usersData.length === 0) {
            throw new Error('Không có dữ liệu nhân viên để xuất.');
        }

        const headers = [
            'ID Chấm Công',
            'ID Nhân Viên',
            'Họ Tên',
            ...Array.from({ length: daysInMonth }, (_, i) => `Ngày ${i + 1}`),
            'Điểm danh',
            'Số ngày nghỉ',
            'Tổng công'
        ];

        const csvRows = [headers.map(header => `"${header}"`).join(',')];

        usersData.forEach(user => {
            const row = [
                user.id_nhan_vien * 1000 + 1,
                user.id_nhan_vien,
                user.ho_ten
            ];

            for (let day = 1; day <= daysInMonth; day++) {
                const dateStr = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
                const attendanceRecord = attendanceData.find(record =>
                    record.id_nhan_vien == user.id_nhan_vien &&
                    record.ngay_lam_viec === dateStr
                );
                const status = attendanceRecord ? attendanceRecord.trang_thai : 'Chưa điểm danh';
                row.push(status);
            }

            const { diemDanhDays, nghiDays, totalWorkDays } = calculateAttendanceStats(user.id_nhan_vien, month, year, attendanceData);
            row.push(formatNumber(diemDanhDays));
            row.push(formatNumber(nghiDays));
            row.push(formatNumber(totalWorkDays));

            csvRows.push(row.map(value => `"${value.toString().replace(/"/g, '""')}"`).join(','));
        });

        const csvContent = '\uFEFF' + csvRows.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `BangChamCong_Thang${month}_${year}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    } catch (error) {
        console.error('Lỗi khi xuất CSV:', error);
        alert('Lỗi khi xuất file CSV: ' + error.message);
    } finally {
        hideLoading();
    }
}

// Cập nhật thời gian
setInterval(() => {
    const now = new Date().toLocaleString('vi-VN');
    document.querySelectorAll('.datetime').forEach(el => {
        el.innerText = now;
    });
}, 1000);

// Hiệu ứng nút
document.querySelectorAll('.action-btn').forEach(button => {
    button.addEventListener('click', function() {
        this.style.transform = 'scale(0.95)';
        setTimeout(() => {
            this.style.transform = '';
        }, 150);
    });
});

// Hiệu ứng active cho nav-link
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', function() {
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        this.classList.add('active');
    });
});
</script>
    <?php include(__DIR__ . '/includes/footer.php'); ?>
</body>
</html>