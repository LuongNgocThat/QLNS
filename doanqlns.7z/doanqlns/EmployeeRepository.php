<?php
require_once 'config/Database.php';

class EmployeeRepository {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function getPunctualityComparison() {
        try {
            $currentMonth = date('Y-m');
            $previousMonth = date('Y-m', strtotime('-1 month'));

            $currentRate = $this->getPunctualityRate($currentMonth);
            $previousRate = $this->getPunctualityRate($previousMonth);

            if ($currentRate === null) {
                $currentRate = 0;
            }
            if ($previousRate === null) {
                $previousRate = 0;
            }

            return [
                'current' => $currentRate,
                'difference' => $currentRate - $previousRate
            ];
        } catch (PDOException $e) {
            error_log("Error in getPunctualityComparison: " . $e->getMessage());
            return ['current' => 0, 'difference' => 0];
        }
    }

    public function getPunctualityRate($thang = null) {
        try {
            if ($thang === null) {
                $thang = date('Y-m');
            }
            
            $startDate = $thang . '-01';
            $endDate = date('Y-m-t', strtotime($startDate));
            
            $checkQuery = "SELECT COUNT(*) FROM cham_cong 
                          WHERE ngay_lam_viec BETWEEN :start_date AND :end_date";
            $stmt = $this->conn->prepare($checkQuery);
            $stmt->bindParam(':start_date', $startDate);
            $stmt->bindParam(':end_date', $endDate);
            $stmt->execute();
            
            if ($stmt->fetchColumn() == 0) {
                return 0;
            }
            
            $query = "SELECT 
                (SUM(CASE WHEN trang_thai = 'Đúng giờ' THEN 1 ELSE 0 END) / COUNT(*)) * 100 as rate
                FROM cham_cong 
                WHERE ngay_lam_viec BETWEEN :start_date AND :end_date";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':start_date', $startDate);
            $stmt->bindParam(':end_date', $endDate);
            $stmt->execute();
            
            return round($stmt->fetchColumn(), 1);
        } catch (PDOException $e) {
            error_log("Error in getPunctualityRate: " . $e->getMessage());
            return 0;
        }
    }

    public function getPendingLeaveCount() {
        try {
            $query = "SELECT COUNT(*) as leave_count FROM nghi_phep WHERE trang_thai = 'Chờ xét duyệt'";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("Error in getPendingLeaveCount: " . $e->getMessage());
            return 0;
        }
    }

    public function getTotalEmployees() {
        try {
            $query = "SELECT COUNT(*) as total FROM nhan_vien WHERE trang_thai = 'Đang làm việc'";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("Error in getTotalEmployees: " . $e->getMessage());
            return 0;
        }
    }

    public function getNewEmployees($month = null) {
        try {
            if ($month === null) {
                $month = date('Y-m');
            }
            $query = "SELECT COUNT(*) as new_employees 
                     FROM nhan_vien 
                     WHERE DATE_FORMAT(ngay_vao_lam, '%Y-%m') = :month 
                     AND ngay_vao_lam IS NOT NULL";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':month', $month);
            $stmt->execute();
            $count = (int)$stmt->fetchColumn();
            if ($count === 0) {
                error_log("No new employees found for month: $month");
            }
            return $count;
        } catch (PDOException $e) {
            error_log("Error in getNewEmployees: " . $e->getMessage());
            return 0;
        }
    }
}
?>