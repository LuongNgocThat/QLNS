<?php
require_once __DIR__ . '/../config/database.php';

class FingerprintController {
    private $conn;

    public function __construct() {
        try {
            $db = new Database();
            $this->conn = $db->getConnection();
            // Verify table exists
            $this->conn->query("DESCRIBE van_tay");
        } catch (Exception $e) {
            error_log("FingerprintController construct error: " . $e->getMessage());
            throw new Exception("Không thể kết nối cơ sở dữ liệu hoặc bảng van_tay không tồn tại");
        }
    }

    public function getAllFingerprints() {
        try {
            $sql = "SELECT vt.id, vt.id_nhan_vien, vt.du_lieu_van_tay, vt.trang_thai, 
                           vt.ngay_tao, vt.ngay_cap_nhat, nv.ho_ten AS ten_nhan_vien
                    FROM van_tay vt
                    LEFT JOIN nhan_vien nv ON vt.id_nhan_vien = nv.id_nhan_vien
                    ORDER BY vt.ngay_tao DESC";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->execute();
            $fingerprints = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Format dates and handle nulls
            foreach ($fingerprints as &$fingerprint) {
                // Format dates
                if (isset($fingerprint['ngay_tao'])) {
                    $fingerprint['ngay_tao'] = date('d/m/Y H:i:s', strtotime($fingerprint['ngay_tao']));
                }
                if (isset($fingerprint['ngay_cap_nhat']) && $fingerprint['ngay_cap_nhat']) {
                    $fingerprint['ngay_cap_nhat'] = date('d/m/Y H:i:s', strtotime($fingerprint['ngay_cap_nhat']));
                }
                
                // Handle fingerprint data
                if (isset($fingerprint['du_lieu_van_tay']) && $fingerprint['du_lieu_van_tay'] !== null) {
                    // Convert BLOB to base64
                    $fingerprint['du_lieu_van_tay'] = base64_encode($fingerprint['du_lieu_van_tay']);
                    $fingerprint['du_lieu_van_tay_size'] = strlen($fingerprint['du_lieu_van_tay']) . ' bytes';
                } else {
                    $fingerprint['du_lieu_van_tay'] = null;
                    $fingerprint['du_lieu_van_tay_size'] = 'Chưa có';
                }
                
                // Handle null values
                $fingerprint['ten_nhan_vien'] = $fingerprint['ten_nhan_vien'] ?? 'Chưa gán';
                $fingerprint['id_nhan_vien'] = $fingerprint['id_nhan_vien'] ?? 'Chưa gán';
            }

            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode([
                'success' => true,
                'data' => $fingerprints
            ]);
        } catch (PDOException $e) {
            error_log("Error in getAllFingerprints: " . $e->getMessage());
            header('Content-Type: application/json; charset=UTF-8');
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Lỗi khi lấy danh sách vân tay: ' . $e->getMessage()
            ]);
        }
    }

    public function startEnrollment() {
        try {
            error_log("Starting fingerprint enrollment");
            
            // Lấy dữ liệu từ request
            $data = json_decode(file_get_contents("php://input"), true);
            
            if (!isset($data['id_nhan_vien'])) {
                throw new Exception("Thiếu thông tin ID nhân viên");
            }

            if (!isset($data['du_lieu_van_tay']) || empty($data['du_lieu_van_tay'])) {
                throw new Exception("Dữ liệu vân tay không được để trống");
            }

            // Kiểm tra nhân viên tồn tại
            $checkSql = "SELECT id_nhan_vien FROM nhan_vien WHERE id_nhan_vien = ?";
            $checkStmt = $this->conn->prepare($checkSql);
            $checkStmt->execute([$data['id_nhan_vien']]);
            
            if (!$checkStmt->fetch()) {
                throw new Exception("Không tìm thấy nhân viên với ID: " . $data['id_nhan_vien']);
            }

            // Kiểm tra xem nhân viên đã có vân tay chưa
            $checkFingerprintSql = "SELECT id FROM van_tay WHERE id_nhan_vien = ? AND trang_thai != 'failed'";
            $checkFingerprintStmt = $this->conn->prepare($checkFingerprintSql);
            $checkFingerprintStmt->execute([$data['id_nhan_vien']]);
            
            if ($checkFingerprintStmt->fetch()) {
                throw new Exception("Nhân viên này đã có dữ liệu vân tay");
            }

            // Thêm bản ghi vân tay mới với dữ liệu vân tay
            $sql = "INSERT INTO van_tay (id_nhan_vien, du_lieu_van_tay, trang_thai, ngay_tao) VALUES (?, ?, ?, NOW())";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([
                $data['id_nhan_vien'],
                $data['du_lieu_van_tay'],
                'completed'
            ]);
            
            $enrollmentId = $this->conn->lastInsertId();

            // Verify the data was saved
            $verifySql = "SELECT du_lieu_van_tay FROM van_tay WHERE id = ?";
            $verifyStmt = $this->conn->prepare($verifySql);
            $verifyStmt->execute([$enrollmentId]);
            $verifyResult = $verifyStmt->fetch(PDO::FETCH_ASSOC);

            if (!$verifyResult || empty($verifyResult['du_lieu_van_tay'])) {
                throw new Exception("Lỗi khi lưu dữ liệu vân tay");
            }

            error_log("Enrollment completed successfully, ID: $enrollmentId");
            
            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode([
                'success' => true,
                'enrollment_id' => $enrollmentId,
                'message' => 'Đã lưu vân tay thành công'
            ]);
        } catch (PDOException $e) {
            error_log("Database error in startEnrollment: " . $e->getMessage());
            header('Content-Type: application/json; charset=UTF-8');
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Lỗi khi lưu vân tay: ' . $e->getMessage()
            ]);
        } catch (Exception $e) {
            error_log("Error in startEnrollment: " . $e->getMessage());
            header('Content-Type: application/json; charset=UTF-8');
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    public function checkStatus($enrollmentId) {
        try {
            $sql = "SELECT trang_thai FROM van_tay WHERE id = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([$enrollmentId]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                ob_end_clean();
                echo json_encode([
                    'success' => true,
                    'status' => $result['trang_thai']
                ]);
            } else {
                ob_end_clean();
                echo json_encode([
                    'success' => false,
                    'message' => 'Không tìm thấy thông tin vân tay'
                ]);
            }
        } catch (PDOException $e) {
            error_log("Error in checkStatus: " . $e->getMessage());
            ob_end_clean();
            echo json_encode([
                'success' => false,
                'message' => 'Lỗi khi kiểm tra trạng thái: ' . $e->getMessage()
            ]);
        }
    }

    public function updateFingerprint($fingerprintId, $data) {
        try {
            error_log("Starting updateFingerprint for ID: " . $fingerprintId);
            
            // Validate input data
            if (!isset($data['du_lieu_van_tay']) || empty($data['du_lieu_van_tay'])) {
                throw new Exception("Dữ liệu vân tay không được để trống");
            }

            // Handle binary fingerprint data
            $fingerprintData = $data['du_lieu_van_tay'];
            
            // Ensure the data is in base64 format
            if (!preg_match('/^[a-zA-Z0-9\/\r\n+]*={0,2}$/', $fingerprintData)) {
                throw new Exception("Dữ liệu vân tay phải ở định dạng base64");
            }

            // Decode base64 data
            $binaryData = base64_decode($fingerprintData, true);
            if ($binaryData === false) {
                throw new Exception("Không thể decode dữ liệu base64");
            }

            error_log("Binary data length: " . strlen($binaryData));

            // Begin transaction
            $this->conn->beginTransaction();

            try {
                // Verify fingerprint record exists
                $checkSql = "SELECT id FROM van_tay WHERE id = ? FOR UPDATE";
                $checkStmt = $this->conn->prepare($checkSql);
                $checkStmt->execute([$fingerprintId]);
                
                if (!$checkStmt->fetch()) {
                    throw new Exception("Không tìm thấy bản ghi vân tay với ID: " . $fingerprintId);
                }

                // Prepare the update statement
                $sql = "UPDATE van_tay 
                       SET du_lieu_van_tay = :fingerprint_data,
                           trang_thai = 'completed',
                           ngay_cap_nhat = NOW()
                       WHERE id = :id";

                $stmt = $this->conn->prepare($sql);

                // Bind parameters using the correct data type
                $stmt->bindParam(':id', $fingerprintId, PDO::PARAM_INT);
                $stmt->bindParam(':fingerprint_data', $binaryData, PDO::PARAM_LOB);

                // Execute the update
                $success = $stmt->execute();

                if (!$success) {
                    throw new Exception("Không thể cập nhật dữ liệu vân tay");
                }

                // Verify the update was successful
                $verifyStmt = $this->conn->prepare("SELECT LENGTH(du_lieu_van_tay) as len FROM van_tay WHERE id = ?");
                $verifyStmt->execute([$fingerprintId]);
                $verifyResult = $verifyStmt->fetch(PDO::FETCH_ASSOC);

                if (!$verifyResult || $verifyResult['len'] == 0) {
                    throw new Exception("Không thể xác minh dữ liệu vân tay sau khi lưu");
                }

                // Commit the transaction
                $this->conn->commit();

                error_log("Successfully updated fingerprint data. Length in DB: " . $verifyResult['len']);

                header('Content-Type: application/json; charset=UTF-8');
                echo json_encode([
                    'success' => true,
                    'message' => 'Cập nhật vân tay thành công',
                    'data_length' => $verifyResult['len']
                ]);

            } catch (Exception $e) {
                // Rollback on error
                $this->conn->rollBack();
                throw $e;
            }

        } catch (PDOException $e) {
            error_log("Database error in updateFingerprint: " . $e->getMessage());
            error_log("Database error code: " . $e->getCode());
            header('Content-Type: application/json; charset=UTF-8');
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Lỗi cơ sở dữ liệu khi cập nhật vân tay: ' . $e->getMessage()
            ]);
        } catch (Exception $e) {
            error_log("Error in updateFingerprint: " . $e->getMessage());
            header('Content-Type: application/json; charset=UTF-8');
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    public function deleteFingerprint($fingerprintId) {
        try {
            $sql = "DELETE FROM van_tay WHERE id = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([$fingerprintId]);

            if ($stmt->rowCount() > 0) {
                ob_end_clean();
                echo json_encode([
                    'success' => true,
                    'message' => 'Đã xóa vân tay thành công'
                ]);
            } else {
                ob_end_clean();
                echo json_encode([
                    'success' => false,
                    'message' => 'Không tìm thấy vân tay để xóa'
                ]);
            }
        } catch (PDOException $e) {
            error_log("Error in deleteFingerprint: " . $e->getMessage());
            ob_end_clean();
            echo json_encode([
                'success' => false,
                'message' => 'Lỗi khi xóa vân tay: ' . $e->getMessage()
            ]);
        }
    }

    public function getAllFingerprintsWithDetails() {
        try {
            error_log("Starting getAllFingerprintsWithDetails");
            
            $sql = "SELECT vt.id, vt.id_nhan_vien, vt.du_lieu_van_tay, vt.trang_thai, 
                           vt.ngay_tao, vt.ngay_cap_nhat, nv.ho_ten AS ten_nhan_vien
                    FROM van_tay vt
                    LEFT JOIN nhan_vien nv ON vt.id_nhan_vien = nv.id_nhan_vien
                    ORDER BY vt.ngay_tao DESC";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->execute();
            $fingerprints = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            error_log("Retrieved " . count($fingerprints) . " fingerprints");

            if (empty($fingerprints)) {
                error_log("No fingerprints found");
                header('Content-Type: application/json; charset=UTF-8');
                echo json_encode([
                    'success' => true,
                    'data' => [],
                    'message' => 'Không có dữ liệu vân tay'
                ]);
                return;
            }

            // Format data
            foreach ($fingerprints as &$fingerprint) {
                try {
                    // Format dates
                    if (isset($fingerprint['ngay_tao'])) {
                        $fingerprint['ngay_tao'] = date('d/m/Y H:i:s', strtotime($fingerprint['ngay_tao']));
                    }
                    if (isset($fingerprint['ngay_cap_nhat']) && $fingerprint['ngay_cap_nhat']) {
                        $fingerprint['ngay_cap_nhat'] = date('d/m/Y H:i:s', strtotime($fingerprint['ngay_cap_nhat']));
                    } else {
                        $fingerprint['ngay_cap_nhat'] = 'Chưa cập nhật';
                    }

                    // Format status
                    $fingerprint['trang_thai'] = match($fingerprint['trang_thai']) {
                        'pending' => 'Chờ xử lý',
                        'completed' => 'Hoàn thành',
                        'failed' => 'Thất bại',
                        default => 'Không xác định'
                    };

                    // Handle null values
                    $fingerprint['ten_nhan_vien'] = $fingerprint['ten_nhan_vien'] ?? 'Chưa gán';
                    $fingerprint['id_nhan_vien'] = $fingerprint['id_nhan_vien'] ?? 'Chưa gán';
                    $fingerprint['du_lieu_van_tay'] = isset($fingerprint['du_lieu_van_tay']) && $fingerprint['du_lieu_van_tay'] ? 'Đã lưu' : 'Chưa có';
                } catch (Exception $e) {
                    error_log("Error formatting fingerprint data: " . $e->getMessage());
                    error_log("Problematic record: " . json_encode($fingerprint));
                }
            }

            error_log("Formatted data successfully");
            
            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode([
                'success' => true,
                'data' => $fingerprints
            ]);
            
            error_log("Response sent successfully");
        } catch (Exception $e) {
            error_log("Error in getAllFingerprintsWithDetails: " . $e->getMessage());
            error_log("Stack trace: " . $e->getTraceAsString());
            
            header('Content-Type: application/json; charset=UTF-8');
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Lỗi khi lấy danh sách vân tay: ' . $e->getMessage()
            ]);
        }
    }
}
?>