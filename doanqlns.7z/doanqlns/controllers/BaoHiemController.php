<?php
include_once(__DIR__ . '/../models/BaoHiemThueModel.php');

class BaoHiemThueController {
    private $baoHiemThueModel;

    public function __construct() {
        $this->baoHiemThueModel = new BaoHiemThueModel();
    }

    public function getAllBaoHiemThue() {
        $records = $this->baoHiemThueModel->getAllBaoHiemThue();
        echo json_encode($records);
    }
}
?>
