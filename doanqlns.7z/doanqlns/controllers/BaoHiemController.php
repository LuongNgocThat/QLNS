<?php
include_once(__DIR__ . '/../models/BaoHiemThueModel.php');

class BaoHiemThueController {
    private $baoHiemThueModel;

    public function __construct() {
        $this->baoHiemThueModel = new BaoHiemThueModel();
    }

    public function getAllBaoHiemThue() {
        $records = $this->baoHiemThueModel->getAllBaoHiemThue();
        echo json_encode($records);
    }
    public function deleteBaoHiemThue($id) {
        $result = $this->baoHiemThueModel->deleteBaoHiemThue($id);
        echo json_encode(["success" => $result]);
    }
    
    public function updateBaoHiemThue($id, $data) {
        $result = $this->baoHiemThueModel->updateBaoHiemThue($id, $data);
        echo json_encode(["success" => $result]);
    }
    
    public function addBaoHiemThue($data) {
        $result = $this->baoHiemThueModel->addBaoHiemThue($data);
        echo json_encode(["success" => $result]);
    }
}
?>
