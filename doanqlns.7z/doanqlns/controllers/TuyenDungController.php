<?php
ob_start();
include_once(__DIR__ . '/../models/TuyenDungModel.php');
require_once(__DIR__ . '/../PHPMailer-master/src/PHPMailer.php');
require_once(__DIR__ . '/../PHPMailer-master/src/SMTP.php');
require_once(__DIR__ . '/../PHPMailer-master/src/Exception.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class TuyenDungController {
    private $tuyenDungModel;

    public function __construct() {
        $this->tuyenDungModel = new TuyenDungModel();
    }

    public function getAllData($month, $year) {
        try {
            $data = $this->tuyenDungModel->getAllData($month, $year);
            echo json_encode(['success' => true, 'data' => $data]);
        } catch (Exception $e) {
            error_log("Error in getAllData: " . $e->getMessage(), 3, __DIR__ . '/../logs/php_errors.log');
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi lấy dữ liệu: ' . $e->getMessage()]);
        }
    }

    public function getOptions() {
        try {
            $options = $this->tuyenDungModel->getOptions();
            echo json_encode($options);
        } catch (Exception $e) {
            error_log("Error in getOptions: " . $e->getMessage(), 3, __DIR__ . '/../logs/php_errors.log');
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi lấy options: ' . $e->getMessage()]);
        }
    }

    public function getRecordById($type, $id) {
        try {
            $record = $this->tuyenDungModel->getRecordById($type, $id);
            if ($record) {
                echo json_encode($record);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Không tìm thấy bản ghi']);
            }
        } catch (Exception $e) {
            error_log("Error in getRecordById: " . $e->getMessage(), 3, __DIR__ . '/../logs/php_errors.log');
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi lấy bản ghi: ' . $e->getMessage()]);
        }
    }

    public function getAllKeHoachTuyenDung() {
        try {
            $plans = $this->tuyenDungModel->getAllKeHoachTuyenDung();
            echo json_encode(['success' => true, 'data' => $plans]);
        } catch (Exception $e) {
            error_log("Error in getAllKeHoachTuyenDung: " . $e->getMessage(), 3, __DIR__ . '/../logs/php_errors.log');
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi lấy danh sách kế hoạch tuyển dụng: ' . $e->getMessage()]);
        }
    }

    public function getKeHoachTuyenDungById($id) {
        try {
            $plan = $this->tuyenDungModel->getRecordById('plan', $id);
            if ($plan) {
                echo json_encode(['success' => true, 'data' => $plan]);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Không tìm thấy kế hoạch tuyển dụng']);
            }
        } catch (Exception $e) {
            error_log("Error in getKeHoachTuyenDungById: " . $e->getMessage(), 3, __DIR__ . '/../logs/php_errors.log');
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi lấy kế hoạch tuyển dụng: ' . $e->getMessage()]);
        }
    }

    public function handleRequest($method, $data, $type = null, $id = null) {
        try {
            $action = isset($data['action']) ? $data['action'] : '';
            switch ($method) {

                case 'POST':
                    if (empty($action)) {
                        http_response_code(400);
                        echo json_encode(['success' => false, 'message' => 'Không có hành động được chỉ định']);
                        return;
                    }

                    switch ($action) {
                        case 'add_plan':
                            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền thêm kế hoạch tuyển dụng']);
                                return;
                            }
                            $result = $this->tuyenDungModel->addKeHoachTuyenDung($data);
                            $message = $result ? 'Thêm kế hoạch tuyển dụng thành công' : 'Không thể thêm kế hoạch tuyển dụng';
                            break;
                        case 'add_campaign':
                            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền thêm đợt tuyển dụng']);
                                return;
                            }
                            $result = $this->tuyenDungModel->addDotTuyenDung($data);
                            $message = $result ? 'Thêm đợt tuyển dụng thành công' : 'Không thể thêm đợt tuyển dụng';
                            break;

                        case 'add_candidate':
                            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền thêm ứng viên']);
                                return;
                            }
                            $result = $this->tuyenDungModel->addUngVien($data);
                            $message = $result ? 'Thêm ứng viên thành công' : 'Không thể thêm ứng viên';
                            break;

                        case 'add_interview':
                            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền thêm lịch hẹn']);
                                return;
                            }
                            $result = $this->tuyenDungModel->addLichHenUngVien($data);
                            $message = $result ? 'Thêm lịch hẹn thành công' : 'Không thể thêm lịch hẹn';
                            break;

                        case 'add_evaluation':
                            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền thêm đánh giá']);
                                return;
                            }
                            $result = $this->tuyenDungModel->addDanhGiaUngVien($data);
                            $message = $result ? 'Thêm đánh giá thành công' : 'Không thể thêm đánh giá';
                            break;

                        case 'add_cost':
                            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền thêm chi phí']);
                                return;
                            }
                            $result = $this->tuyenDungModel->addChiPhiTuyenDung($data);
                            $message = $result ? 'Thêm chi phí thành công' : 'Không thể thêm chi phí';
                            break;

                        case 'add_allocation':
                            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền thêm phân bổ']);
                                return;
                            }
                            $result = $this->tuyenDungModel->addPhanBoUngVien($data);
                            $message = $result ? 'Thêm phân bổ thành công' : 'Không thể thêm phân bổ';
                            break;

                        case 'delete_campaign':
                            if (!isset($_SESSION['quyen_xoa']) || !$_SESSION['quyen_xoa']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền xóa đợt tuyển dụng']);
                                return;
                            }
                            $result = $this->tuyenDungModel->deleteRecord('campaign', $data['id']);
                            $message = $result ? 'Xóa đợt tuyển dụng thành công' : 'Không thể xóa đợt tuyển dụng';
                            break;

                        case 'delete_candidate':
                            if (!isset($_SESSION['quyen_xoa']) || !$_SESSION['quyen_xoa']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền xóa ứng viên']);
                                return;
                            }
                            $result = $this->tuyenDungModel->deleteRecord('candidate', $data['id']);
                            $message = $result ? 'Xóa ứng viên thành công' : 'Không thể xóa ứng viên';
                            break;

                        case 'delete_interview':
                            if (!isset($_SESSION['quyen_xoa']) || !$_SESSION['quyen_xoa']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền xóa lịch hẹn']);
                                return;
                            }
                            $result = $this->tuyenDungModel->deleteRecord('interview', $data['id']);
                            $message = $result ? 'Xóa lịch hẹn thành công' : 'Không thể xóa lịch hẹn';
                            break;

                        case 'delete_evaluation':
                            if (!isset($_SESSION['quyen_xoa']) || !$_SESSION['quyen_xoa']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền xóa đánh giá']);
                                return;
                            }
                            $result = $this->tuyenDungModel->deleteRecord('evaluation', $data['id']);
                            $message = $result ? 'Xóa đánh giá thành công' : 'Không thể xóa đánh giá';
                            break;

                        case 'delete_cost':
                            if (!isset($_SESSION['quyen_xoa']) || !$_SESSION['quyen_xoa']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền xóa chi phí']);
                                return;
                            }
                            $result = $this->tuyenDungModel->deleteRecord('cost', $data['id']);
                            $message = $result ? 'Xóa chi phí thành công' : 'Không thể xóa chi phí';
                            break;

                        case 'delete_allocation':
                            if (!isset($_SESSION['quyen_xoa']) || !$_SESSION['quyen_xoa']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền xóa phân bổ']);
                                return;
                            }
                            $result = $this->tuyenDungModel->deleteRecord('allocation', $data['id']);
                            $message = $result ? 'Xóa phân bổ thành công' : 'Không thể xóa phân bổ';
                            break;

                        case 'update_allocation_status':
                            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền cập nhật trạng thái phân bổ']);
                                return;
                            }
                            $result = $this->tuyenDungModel->updateAllocationStatus($data['id_phan_bo'], $data['trang_thai']);
                            if ($result) {
                                $allocation = $this->tuyenDungModel->getRecordById('allocation', $data['id_phan_bo']);
                                if ($allocation) {
                                    $this->sendAllocationEmail($allocation, $data['trang_thai']);
                                } else {
                                    error_log("Không thể lấy thông tin phân bổ cho id_phan_bo: " . $data['id_phan_bo'], 3, __DIR__ . '/../logs/php_errors.log');
                                }
                            }
                            $message = $result ? 'Cập nhật trạng thái phân bổ thành công' : 'Không thể cập nhật trạng thái phân bổ';
                            break;

                        case 'update_interview_status':
                            if (!isset($data['id_lich_hen']) || !isset($data['trang_thai'])) {
                                http_response_code(400);
                                echo json_encode(['success' => false, 'message' => 'Thiếu id_lich_hen hoặc trang_thai']);
                                return;
                            }
                            $this->updateInterviewStatus($data['id_lich_hen'], $data['trang_thai']);
                            return; // Tránh gọi echo json_encode ở dưới

                        default:
                            http_response_code(400);
                            echo json_encode(['success' => false, 'message' => 'Hành động không hợp lệ']);
                            return;
                    }
                    echo json_encode(['success' => $result, 'message' => $message]);
                    break;

                case 'PUT':
                    if (!$type || !$id) {
                        http_response_code(400);
                        echo json_encode(['success' => false, 'message' => 'Thiếu type hoặc id']);
                        return;
                    }
                    switch ($action) {
                        case 'plan':
                            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền sửa kế hoạch tuyển dụng']);
                                return;
                            }
                            $result = $this->tuyenDungModel->updateKeHoachTuyenDung($id, $data);
                            $message = $result ? 'Cập nhật kế hoạch tuyển dụng thành công' : 'Không thể cập nhật kế hoạch tuyển dụng';
                            break;
                        case 'edit_campaign':
                            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền sửa đợt tuyển dụng']);
                                return;
                            }
                            $result = $this->tuyenDungModel->updateDotTuyenDung($id, $data);
                            $message = $result ? 'Cập nhật đợt tuyển dụng thành công' : 'Không thể cập nhật đợt tuyển dụng';
                            break;

                        case 'edit_candidate':
                            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền sửa ứng viên']);
                                return;
                            }
                            $result = $this->tuyenDungModel->updateUngVien($id, $data);
                            $message = $result ? 'Cập nhật ứng viên thành công' : 'Không thể cập nhật ứng viên';
                            break;

                        case 'edit_interview':
                            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền sửa lịch hẹn']);
                                return;
                            }
                            $result = $this->tuyenDungModel->updateLichHenUngVien($id, $data);
                            $message = $result ? 'Cập nhật lịch hẹn thành công' : 'Không thể cập nhật lịch hẹn';
                            break;

                        case 'edit_evaluation':
                            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền sửa đánh giá']);
                                return;
                            }
                            $result = $this->tuyenDungModel->updateDanhGiaUngVien($id, $data);
                            $message = $result ? 'Cập nhật đánh giá thành công' : 'Không thể cập nhật đánh giá';
                            break;

                        case 'edit_cost':
                            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền sửa chi phí']);
                                return;
                            }
                            $result = $this->tuyenDungModel->updateChiPhiTuyenDung($id, $data);
                            $message = $result ? 'Cập nhật chi phí thành công' : 'Không thể cập nhật chi phí';
                            break;

                        case 'edit_allocation':
                            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                                http_response_code(403);
                                echo json_encode(['success' => false, 'message' => 'Không có quyền sửa phân bổ']);
                                return;
                            }
                            $result = $this->tuyenDungModel->updatePhanBoUngVien($id, $data);
                            $message = $result ? 'Cập nhật phân bổ thành công' : 'Không thể cập nhật phân bổ';
                            break;

                        default:
                            http_response_code(400);
                            echo json_encode(['success' => false, 'message' => 'Hành động không hợp lệ']);
                            return;
                    }
                    echo json_encode(['success' => $result, 'message' => $message]);
                    break;

                case 'DELETE':
                    if (!$type || !$id) {
                        http_response_code(400);
                        echo json_encode(['success' => false, 'message' => 'Thiếu type hoặc id']);
                        return;
                    }
                    if (!isset($_SESSION['quyen_xoa']) || !$_SESSION['quyen_xoa']) {
                        http_response_code(403);
                        echo json_encode(['success' => false, 'message' => 'Không có quyền xóa']);
                        return;
                    }
                    $result = $this->tuyenDungModel->deleteRecord($type, $id);
                    $message = $result ? "Xóa $type thành công" : "Không thể xóa $type";
                    echo json_encode(['success' => $result, 'message' => $message]);
                    break;

                default:
                    http_response_code(405);
                    echo json_encode(['success' => false, 'message' => 'Phương thức không được hỗ trợ']);
                    return;
            }
        } catch (Exception $e) {
            error_log("Error in handleRequest: " . $e->getMessage(), 3, __DIR__ . '/../logs/php_errors.log');
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi xử lý yêu cầu: ' . $e->getMessage()]);
        }
    }

    public function getAllUngVien() {
        try {
            $ungVien = $this->tuyenDungModel->getAllUngVien();
            echo json_encode(['success' => true, 'data' => $ungVien]);
        } catch (Exception $e) {
            error_log("Error in getAllUngVien: " . $e->getMessage(), 3, __DIR__ . '/../logs/php_errors.log');
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi lấy danh sách ứng viên: ' . $e->getMessage()]);
        }
    }

    public function getDotTuyenDungById($id) {
        try {
            $dotTuyenDung = $this->tuyenDungModel->getDotTuyenDungById($id);
            if ($dotTuyenDung) {
                echo json_encode(['success' => true, 'data' => $dotTuyenDung]);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Không tìm thấy đợt tuyển dụng']);
            }
        } catch (Exception $e) {
            error_log("Error in getDotTuyenDungById: " . $e->getMessage(), 3, __DIR__ . '/../logs/php_errors.log');
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi lấy đợt tuyển dụng: ' . $e->getMessage()]);
        }
    }

    public function addUngVien($data) {
        try {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'Không có quyền thêm ứng viên']);
                return;
            }
            $result = $this->tuyenDungModel->addUngVien($data);
            echo json_encode(['success' => $result, 'message' => $result ? 'Thêm ứng viên thành công' : 'Không thể thêm ứng viên']);
        } catch (Exception $e) {
            error_log("Error in addUngVien: " . $e->getMessage(), 3, __DIR__ . '/../logs/php_errors.log');
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi thêm ứng viên: ' . $e->getMessage()]);
        }
    }

    private function updateInterviewStatus($id_lich_hen, $trang_thai) {
        try {
            // Kiểm tra quyền sửa
            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'Bạn không có quyền sửa dữ liệu']);
                return;
            }

            // Kiểm tra trạng thái hợp lệ
            $validStatuses = ['Đã duyệt', 'Từ chối'];
            if (!in_array($trang_thai, $validStatuses)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Trạng thái không hợp lệ']);
                return;
            }

            // Cập nhật trạng thái trong model
            $success = $this->tuyenDungModel->updateInterviewStatus($id_lich_hen, $trang_thai);

            if ($success) {
                // Lấy thông tin lịch hẹn để gửi email
                $interview = $this->tuyenDungModel->getRecordById('interview', $id_lich_hen);
                if ($interview) {
                    // Gửi email thông báo trạng thái đến ứng viên
                    $this->sendInterviewStatusEmail($interview, $trang_thai);
                    echo json_encode(['success' => true, 'message' => 'Cập nhật trạng thái lịch hẹn thành công']);
                } else {
                    error_log("Không thể lấy thông tin lịch hẹn với id_lich_hen: $id_lich_hen", 3, __DIR__ . '/../logs/php_errors.log');
                    echo json_encode(['success' => false, 'message' => 'Không thể lấy thông tin lịch hẹn']);
                }
            } else {
                error_log("Cập nhật trạng thái lịch hẹn thất bại với id_lich_hen: $id_lich_hen", 3, __DIR__ . '/../logs/php_errors.log');
                echo json_encode(['success' => false, 'message' => 'Cập nhật trạng thái thất bại']);
            }
        } catch (Exception $e) {
            error_log("Error in updateInterviewStatus: " . $e->getMessage(), 3, __DIR__ . '/../logs/php_errors.log');
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    public function updateUngVien($id, $data) {
        try {
            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'Không có quyền sửa ứng viên']);
                return;
            }
            $result = $this->tuyenDungModel->updateUngVien($id, $data);
            echo json_encode(['success' => $result, 'message' => $result ? 'Cập nhật ứng viên thành công' : 'Không thể cập nhật ứng viên']);
        } catch (Exception $e) {
            error_log("Error in updateUngVien: " . $e->getMessage(), 3, __DIR__ . '/../logs/php_errors.log');
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi cập nhật ứng viên: ' . $e->getMessage()]);
        }
    }

    public function deleteUngVien($id) {
        try {
            if (!isset($_SESSION['quyen_xoa']) || !$_SESSION['quyen_xoa']) {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'Không có quyền xóa ứng viên']);
                return;
            }
            $result = $this->tuyenDungModel->deleteRecord('candidate', $id);
            echo json_encode(['success' => $result, 'message' => $result ? 'Xóa ứng viên thành công' : 'Không thể xóa ứng viên']);
        } catch (Exception $e) {
            error_log("Error in deleteUngVien: " . $e->getMessage(), 3, __DIR__ . '/../logs/php_errors.log');
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi xóa ứng viên: ' . $e->getMessage()]);
        }
    }

    private function sendAllocationEmail($allocation, $status) {
        try {
            // Ghi log dữ liệu đầu vào
            error_log("sendAllocationEmail called with allocation: " . json_encode($allocation) . ", Status: $status", 3, __DIR__ . '/../logs/php_errors.log');

            // Kiểm tra thông tin phân bổ
            if (!$allocation || !isset($allocation['email']) || empty($allocation['email']) || !filter_var($allocation['email'], FILTER_VALIDATE_EMAIL)) {
                error_log("Không thể gửi email: Email ứng viên không hợp lệ hoặc rỗng. Email: " . ($allocation['email'] ?? 'null'), 3, __DIR__ . '/../logs/php_errors.log');
                return false;
            }

            // Kiểm tra bản ghi MX của tên miền
            $emailParts = explode('@', $allocation['email']);
            $domain = end($emailParts);
            if (!checkdnsrr($domain, 'MX')) {
                error_log("Không thể gửi email: Tên miền $domain không có bản ghi MX hợp lệ.", 3, __DIR__ . '/../logs/php_errors.log');
                return false;
            }

            // Chuẩn bị thông tin cho email
            $emailNhanVien = $allocation['email'];
            $hoTenNV = $allocation['ho_ten'] ?? 'Ứng viên';
            $phongBan = $allocation['ten_phong_ban'] ?? 'N/A';
            $chucVu = $allocation['ten_chuc_vu'] ?? 'N/A';
            $ngayPhanBo = isset($allocation['ngay_phan_bo']) ? date("d-m-Y", strtotime($allocation['ngay_phan_bo'])) : 'N/A';
            $hopDong = $allocation['hop_dong_thu_viec'] ?? 'Không có hợp đồng thử việc';
            $nguoiGui = "Lương Ngọc Thật";
            $emailNguoiGui = "ngocthach102017@gmail.com";
            $dienThoaiNguoiGui = "0349589914";
            $extNguoiGui = "505";
            $tenCongTy = "Quản Lý Nhân Sự";
            $ngayPhanHoi = date("d-m-Y", strtotime("+7 days"));
            $ngayKyHopDong = date("d-m-Y", strtotime($ngayPhanBo));
            $thoiGianLamViec = "8:00 - 17:00, Thứ Hai đến Thứ Sáu";

            // Ghi log thông tin email
            error_log("Chuẩn bị gửi email tới: $emailNhanVien, Tên: $hoTenNV, Phòng ban: $phongBan, Chức vụ: $chucVu, Trạng thái: $status", 3, __DIR__ . '/../logs/php_errors.log');

            // Khởi tạo PHPMailer
            $mail = new PHPMailer(true);
            $mail->IsSMTP();
            $mail->SMTPDebug = 2;
            $mail->Debugoutput = function($str, $level) {
                error_log("PHPMailer Debug [$level]: $str", 3, __DIR__ . '/../logs/php_errors.log');
            };
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = 'ssl';
            $mail->Host = "smtp.gmail.com";
            $mail->Port = 465;
            $mail->IsHTML(true);
            $mail->Username = "ngocthach102017@gmail.com";
            $mail->Password = "kwpaluqejzlvekcf";
            $mail->SetFrom("ngocthach102017@gmail.com", "HRM - $tenCongTy");
            $mail->CharSet = 'UTF-8';

            // Tùy chỉnh email dựa trên trạng thái
            if ($status === 'Đã duyệt') {
                $mail->Subject = "Thông báo trúng tuyển, vị trí $chucVu - Ứng viên $hoTenNV";
                $mail->Body = "
                <div style='font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9; border-radius: 8px;'>
                    <div style='background-color: #4CAF50; color: white; padding: 15px; text-align: center; border-top-left-radius: 8px; border-top-right-radius: 8px;'>
                        <h2 style='margin: 0; font-size: 22px;'>THÔNG BÁO TRÚNG TUYỂN</h2>
                    </div>
                    <div style='padding: 20px; background-color: #ffffff; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;'>
                        <p style='font-size: 16px; margin: 0 0 15px;'>Thân gửi Anh/Chị <strong>$hoTenNV</strong>,</p>
                        <p style='font-size: 15px; margin: 0 0 15px;'>Tôi tên là <strong>$nguoiGui</strong> – Trưởng phòng nhân sự $tenCongTy.</p>
                        <p style='font-size: 15px; margin: 0 0 15px;'>Thay mặt ban lãnh đạo công ty, tôi vui mừng thông báo Anh/Chị đã trúng tuyển trong đợt phỏng vấn vừa qua.</p>
                        <p style='font-size: 15px; margin: 0 0 15px;'>Anh/Chị sẽ:</p>
                        <ul style='font-size: 15px; margin: 0 0 15px; padding-left: 20px;'>
                            <li>Làm việc tại: <strong>$phongBan</strong></li>
                            <li>Chức danh: <strong>$chucVu</strong></li>
                            <li>Ngày nhận việc: <strong>$ngayPhanBo</strong></li>
                            <li>Thời gian làm việc: <strong>$thoiGianLamViec</strong></li>
                            <li>Hợp đồng lao động: <strong>$hopDong</strong></li>
                        </ul>
                        <p style='font-size: 15px; margin: 0 0 15px;'>Công ty đã đính kèm một tập tin chi tiết về hợp đồng lao động và công việc để Anh/Chị có thể xem qua trước khi đến làm việc.</p>
                        <p style='font-size: 15px; margin: 0 0 15px;'>Anh/Chị vui lòng phản hồi lại quyết định nhận việc của mình trước ngày <strong>$ngayPhanHoi</strong>. Nếu đồng ý:</p>
                        <ul style='font-size: 15px; margin: 0 0 15px; padding-left: 20px;'>
                            <li>Ngày ký hợp đồng sẽ là ngày <strong>$ngayKyHopDong</strong>.</li>
                            <li>Ngày bắt đầu làm việc sẽ là ngày <strong>$ngayPhanBo</strong>.</li>
                        </ul>
                        <p style='font-size: 15px; margin: 0 0 15px;'>Nếu Anh/Chị có bất kỳ câu hỏi gì, vui lòng liên lạc với tôi qua email <a href='mailto:$emailNguoiGui'>$emailNguoiGui</a> hoặc qua số điện thoại <strong>$dienThoaiNguoiGui - Ext: $extNguoiGui</strong>.</p>
                        <p style='font-size: 15px; margin: 0 0 15px;'>Hy vọng chúng ta sẽ có một sự hợp tác tốt đẹp, lâu bền trong tương lai.</p>
                        <p style='font-size: 15px; margin: 0;'>Trân trọng,<br><strong>$nguoiGui</strong><br>Trưởng phòng nhân sự<br>$tenCongTy<br>Email: $emailNguoiGui<br>Điện thoại: $dienThoaiNguoiGui - Ext: $extNguoiGui</p>
                    </div>
                </div>";
            } else {
                $mail->Subject = "Thông báo kết quả tuyển dụng - Ứng viên $hoTenNV";
                $mail->Body = "
                <div style='font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9; border-radius: 8px;'>
                    <div style='background-color: #f44336; color: white; padding: 15px; text-align: center; border-top-left-radius: 8px; border-top-right-radius: 8px;'>
                        <h2 style='margin: 0; font-size: 22px;'>THÔNG BÁO KẾT QUẢ TUYỂN DỤNG</h2>
                    </div>
                    <div style='padding: 20px; background-color: #ffffff; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;'>
                        <p style='font-size: 16px; margin: 0 0 15px;'>Thân gửi Anh/Chị <strong>$hoTenNV</strong>,</p>
                        <p style='font-size: 15px; margin: 0 0 15px;'>Tôi tên là <strong>$nguoiGui</strong> – Trưởng phòng nhân sự $tenCongTy.</p>
                        <p style='font-size: 15px; margin: 0 0 15px;'>Cảm ơn Anh/Chị đã tham gia đợt phỏng vấn tại $tenCongTy. Sau khi xem xét kỹ lưỡng, chúng tôi rất tiếc phải thông báo rằng Anh/Chị chưa phù hợp với vị trí <strong>$chucVu</strong> tại thời điểm này.</p>
                        <p style='font-size: 15px; margin: 0 0 15px;'>Chúng tôi rất trân trọng sự quan tâm và thời gian của Anh/Chị, và hy vọng sẽ có cơ hội hợp tác trong tương lai.</p>
                        <p style='font-size: 15px; margin: 0 0 15px;'>Nếu Anh/Chị có bất kỳ câu hỏi hoặc cần thêm thông tin, vui lòng liên lạc với tôi qua email <a href='mailto:$emailNguoiGui'>$emailNguoiGui</a> hoặc qua số điện thoại <strong>$dienThoaiNguoiGui - Ext: $extNguoiGui</strong>.</p>
                        <p style='font-size: 15px; margin: 0;'>Trân trọng,<br><strong>$nguoiGui</strong><br>Trưởng phòng nhân sự<br>$tenCongTy<br>Email: $emailNguoiGui<br>Điện thoại: $dienThoaiNguoiGui - Ext: $extNguoiGui</p>
                    </div>
                </div>";
            }

            // Thêm địa chỉ nhận
            if (!$mail->addAddress($emailNhanVien)) {
                error_log("Không thể thêm địa chỉ email: $emailNhanVien không hợp lệ", 3, __DIR__ . '/../logs/php_errors.log');
                return false;
            }

            // Gửi email
            $mail->Send();
            error_log("Email đã được gửi thành công tới: $emailNhanVien, Trạng thái: $status", 3, __DIR__ . '/../logs/php_errors.log');
            return true;
        } catch (Exception $e) {
            error_log("Lỗi trong sendAllocationEmail: " . $e->getMessage() . " | Email: " . ($allocation['email'] ?? 'null') . " | Trạng thái: $status", 3, __DIR__ . '/../logs/php_errors.log');
            return false;
        }
    }

    private function sendInterviewStatusEmail($interview, $trang_thai) {
        try {
            error_log("sendInterviewStatusEmail called with interview: " . json_encode($interview) . ", trang_thai: $trang_thai", 3, __DIR__ . '/../logs/php_errors.log');

            if (!isset($interview['candidate_email']) || empty($interview['candidate_email']) || !filter_var($interview['candidate_email'], FILTER_VALIDATE_EMAIL)) {
                error_log("Không thể gửi email: Email ứng viên không hợp lệ hoặc rỗng. Email: " . ($interview['candidate_email'] ?? 'null'), 3, __DIR__ . '/../logs/php_errors.log');
                return false;
            }

            $emailParts = explode('@', $interview['candidate_email']);
            $domain = end($emailParts);
            if (!checkdnsrr($domain, 'MX')) {
                error_log("Không thể gửi email: Tên miền $domain không có bản ghi MX hợp lệ.", 3, __DIR__ . '/../logs/php_errors.log');
                return false;
            }

            $emailUngVien = $interview['candidate_email'];
            $hoTenUV = $interview['ho_ten'] ?? 'Ứng viên';
            $ngayHen = isset($interview['ngay_hen']) ? date("d-m-Y", strtotime($interview['ngay_hen'])) : 'N/A';
            $gioHen = $interview['gio_hen'] ?? 'N/A';
            $diaDiem = $interview['dia_diem'] ?? 'N/A';
            $ghiChu = $interview['ghi_chu'] ?? 'Không có ghi chú';
            $nguoiGui = "Lương Ngọc Thật";
            $emailNguoiGui = "ngocthach102017@gmail.com";
            $dienThoaiNguoiGui = "0349589914";
            $extNguoiGui = "505";
            $tenCongTy = "Quản Lý Nhân Sự";

            $statusMessage = $trang_thai === 'Đã duyệt' ?
                "Chúng tôi xin thông báo lịch hẹn phỏng vấn của bạn đã được duyệt. Vui lòng tham gia đúng giờ." :
                "Chúng tôi rất tiếc thông báo lịch hẹn phỏng vấn của bạn đã bị từ chối. Cảm ơn bạn đã quan tâm đến $tenCongTy.";

            error_log("Chuẩn bị gửi email trạng thái tới ứng viên: $emailUngVien, Ứng viên: $hoTenUV, Trạng thái: $trang_thai", 3, __DIR__ . '/../logs/php_errors.log');

            $mail = new PHPMailer(true);
            $mail->IsSMTP();
            $mail->SMTPDebug = 2;
            $mail->Debugoutput = function($str, $level) {
                error_log("PHPMailer Debug [$level]: $str", 3, __DIR__ . '/../logs/php_errors.log');
            };
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = 'ssl';
            $mail->Host = "smtp.gmail.com";
            $mail->Port = 465;
            $mail->IsHTML(true);
            $mail->Username = "ngocthach102017@gmail.com";
            $mail->Password = "kwpaluqejzlvekcf";
            $mail->SetFrom("ngocthach102017@gmail.com", "HRM - $tenCongTy");
            $mail->CharSet = 'UTF-8';

            $mail->Subject = "Thông báo trạng thái lịch hẹn phỏng vấn - $hoTenUV";
            $mail->Body = "
            <div style='font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9; border-radius: 8px;'>
                <div style='background-color: #2196F3; color: white; padding: 15px; text-align: center; border-top-left-radius: 8px; border-top-right-radius: 8px;'>
                    <h2 style='margin: 0; font-size: 22px;'>THÔNG BÁO TRẠNG THÁI LỊCH HẸN PHỎNG VẤN</h2>
                </div>
                <div style='padding: 20px; background-color: #ffffff; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;'>
                    <p style='font-size: 16px; margin: 0 0 15px;'>Kính gửi $hoTenUV,</p>
                    <p style='font-size: 15px; margin: 0 0 15px;'>$statusMessage</p>
                    <p style='font-size: 15px; margin: 0 0 15px;'>Chi tiết lịch hẹn:</p>
                    <ul style='font-size: 15px; margin: 0 0 15px; padding-left: 20px;'>
                        <li>Ngày phỏng vấn: <strong>$ngayHen</strong></li>
                        <li>Giờ phỏng vấn: <strong>$gioHen</strong></li>
                        <li>Địa điểm: <strong>$diaDiem</strong></li>
                        <li>Ghi chú: <strong>$ghiChu</strong></li>
                    </ul>
                    <p style='font-size: 15px; margin: 0 0 15px;'>Nếu có câu hỏi, xin liên hệ qua email <a href='mailto:$emailNguoiGui'>$emailNguoiGui</a> hoặc số điện thoại <strong>$dienThoaiNguoiGui - Ext: $extNguoiGui</strong>.</p>
                    <p style='font-size: 15px; margin: 0;'>Trân trọng,<br><strong>$nguoiGui</strong><br>Trưởng phòng nhân sự<br>$tenCongTy</p>
                </div>
            </div>";

            if (!$mail->addAddress($emailUngVien)) {
                error_log("Không thể thêm địa chỉ email: $emailUngVien không hợp lệ", 3, __DIR__ . '/../logs/php_errors.log');
                return false;
            }

            $mail->Send();
            error_log("Email trạng thái lịch hẹn gửi thành công tới ứng viên: $emailUngVien, Ứng viên: $hoTenUV, Trạng thái: $trang_thai", 3, __DIR__ . '/../logs/php_errors.log');
            return true;
        } catch (Exception $e) {
            error_log("Lỗi trong sendInterviewStatusEmail: " . $e->getMessage() . " | Email: " . ($interview['candidate_email'] ?? 'null'), 3, __DIR__ . '/../logs/php_errors.log');
            return false;
        }
    }
}
ob_end_clean();
?>