<?php
include_once(__DIR__ . '/../models/ThuongModel.php');

class ThuongController {
    private $thuongModel;

    public function __construct() {
        $this->thuongModel = new ThuongModel();
    }

    public function getAllThuong() {
        $records = $this->thuongModel->getAllThuong();
        header('Content-Type: application/json');
        echo json_encode($records);
    }

    public function addThuong($data) {
        if (!isset($data['id_nhan_vien']) || !isset($data['noi_dung_thuong']) || !isset($data['ngay']) || !isset($data['loai'])) {
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Thiếu thông tin bắt buộc"]);
            return;
        }

        $result = $this->thuongModel->addThuong($data);
        if ($result) {
            http_response_code(201);
            echo json_encode(["success" => true, "message" => "Thêm thưởng thành công"]);
        } else {
            http_response_code(500);
            echo json_encode(["success" => false, "message" => "Thêm thưởng thất bại"]);
        }
    }

    public function updateThuong($thuongId, $data) {
        if (!isset($data['id_nhan_vien']) || !isset($data['noi_dung_thuong']) || !isset($data['ngay']) || !isset($data['loai'])) {
            http_response_code(400);
            echo json_encode(["success" => false, "message" => "Thiếu thông tin bắt buộc"]);
            return;
        }

        $result = $this->thuongModel->updateThuong($thuongId, $data);
        if ($result) {
            http_response_code(200);
            echo json_encode(["success" => true, "message" => "Cập nhật thưởng thành công"]);
        } else {
            http_response_code(500);
            echo json_encode(["success" => false, "message" => "Cập nhật thưởng thất bại"]);
        }
    }

    public function deleteThuong($thuongId) {
        $result = $this->thuongModel->deleteThuong($thuongId);
        if ($result) {
            http_response_code(200);
            echo json_encode(["success" => true, "message" => "Xóa thưởng thành công"]);
        } else {
            http_response_code(500);
            echo json_encode(["success" => false, "message" => "Xóa thưởng thất bại"]);
        }
    }

    public function getBonusTypes() {
        $types = $this->thuongModel->getBonusTypes();
        header('Content-Type: application/json');
        echo json_encode($types);
    }
}
?>