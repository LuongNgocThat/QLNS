<?php
require_once __DIR__ . '/../config/Database.php';

class AuthController {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function login($ten_dang_nhap, $mat_khau) {
        $query = "SELECT * FROM nguoi_dung WHERE ten_dang_nhap = :ten_dang_nhap";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':ten_dang_nhap', $ten_dang_nhap);
        $stmt->execute();

        if ($stmt->rowCount() == 1) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Kiểm tra trạng thái tài khoản
            if ($user['trang_thai'] === 'Không hoạt động') {
                return ['success' => false, 'message' => 'Tài khoản của bạn đã bị ngưng hoạt động'];
            }
            
            // Kiểm tra mật khẩu bằng MD5
            if (md5($mat_khau) === $user['mat_khau']) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['ten_dang_nhap'];
                $_SESSION['quyen_them'] = $user['quyen_them'];
                $_SESSION['quyen_sua'] = $user['quyen_sua'];
                $_SESSION['quyen_xoa'] = $user['quyen_xoa'];
                return ['success' => true, 'message' => 'Đăng nhập thành công'];
            }
        }
        return ['success' => false, 'message' => 'Tên đăng nhập hoặc mật khẩu không đúng'];
    }

    public function googleLogin($id_token) {
        // Xác minh ID token với Google
        $client_id = '725719363319-vtnuuo1goitapagommctgbf91g8f5741.apps.googleusercontent.com'; // Thay bằng Client ID thực tế từ Google Cloud Console
        $url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . urlencode($id_token);
        $response = @file_get_contents($url);
        
        if ($response === false) {
            return ['success' => false, 'message' => 'Không thể xác minh token'];
        }

        $payload = json_decode($response, true);
        
        if (!$payload || !isset($payload['sub']) || $payload['aud'] !== $client_id) {
            return ['success' => false, 'message' => 'Token không hợp lệ'];
        }

        $google_id = $payload['sub'];
        $email = $payload['email'];
        $ten_dang_nhap = $payload['name'] ?? $email;

        // Kiểm tra email trong cơ sở dữ liệu
        $query = "SELECT * FROM nguoi_dung WHERE email = :email";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() == 1) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Kiểm tra trạng thái tài khoản
            if ($user['trang_thai'] === 'Không hoạt động') {
                return ['success' => false, 'message' => 'Tài khoản của bạn đã bị ngưng hoạt động'];
            }
            
            // Cập nhật google_id nếu chưa có
            if (empty($user['google_id'])) {
                $update_query = "UPDATE nguoi_dung SET google_id = :google_id WHERE id = :id";
                $update_stmt = $this->db->prepare($update_query);
                $update_stmt->bindParam(':google_id', $google_id);
                $update_stmt->bindParam(':id', $user['id']);
                $update_stmt->execute();
            }

            // Thiết lập session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['ten_dang_nhap'];
            $_SESSION['quyen_them'] = $user['quyen_them'];
            $_SESSION['quyen_sua'] = $user['quyen_sua'];
            $_SESSION['quyen_xoa'] = $user['quyen_xoa'];

            return ['success' => true, 'message' => 'Đăng nhập thành công'];
        } else {
            return ['success' => false, 'message' => 'Bạn không phải là nhân sự của Công Ty  HRM'];
        }
    }
}
?>