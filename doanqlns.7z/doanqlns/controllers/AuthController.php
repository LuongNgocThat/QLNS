<?php
require_once __DIR__ . '/../config/Database.php';

class AuthController {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Đăng nhập
    public function login($ten_dang_nhap, $mat_khau) {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM nguoi_dung WHERE ten_dang_nhap = :ten_dang_nhap AND trang_thai = 1");
            $stmt->bindParam(':ten_dang_nhap', $ten_dang_nhap);
            $stmt->execute();
            
            if ($stmt->rowCount() == 1) {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (password_verify($mat_khau, $user['mat_khau'])) {
                    session_start();
                    $_SESSION['user_id'] = $user['id_nguoi_dung'];
                    $_SESSION['username'] = $user['ten_dang_nhap'];
                    $_SESSION['role'] = $user['vai_tro'];
                    
                    return ['success' => true, 'role' => $user['vai_tro']];
                }
            }
            
            return ['success' => false, 'message' => 'Tên đăng nhập hoặc mật khẩu không đúng'];
        } catch (PDOException $e) {
            return ['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()];
        }
    }

    // Đăng xuất
    public function logout() {
        session_start();
        session_unset();
        session_destroy();
        return ['success' => true];
    }

    // Kiểm tra quyền
    public static function checkPermission($requiredRole) {
        session_start();
        if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== $requiredRole) {
            header('Location: /login.php');
            exit();
        }
    }
}
?>