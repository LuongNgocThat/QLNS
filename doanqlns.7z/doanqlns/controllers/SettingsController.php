<?php
require_once __DIR__ . '/../config/database.php';

class SettingsController {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Lấy cài đặt chung
    public function getGeneralSettings() {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM settings LIMIT 1");
            $stmt->execute();
            $settings = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($settings) {
                echo json_encode(['success' => true, 'data' => $settings]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Không tìm thấy cài đặt']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    // Cập nhật cài đặt chung
    public function updateGeneralSettings($data) {
        try {
            $stmt = $this->conn->prepare("
                UPDATE settings 
                SET company_name = :company_name, timezone = :timezone, 
                    items_per_page = :items_per_page, date_format = :date_format
                WHERE id = 1
            ");
            $stmt->bindParam(':company_name', $data['company_name']);
            $stmt->bindParam(':timezone', $data['timezone']);
            $stmt->bindParam(':items_per_page', $data['items_per_page'], PDO::PARAM_INT);
            $stmt->bindParam(':date_format', $data['date_format']);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => true, 'message' => 'Cập nhật cài đặt chung thành công']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Không có thay đổi nào được thực hiện']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    // Lấy cài đặt bảo mật
    public function getSecuritySettings($userId) {
        try {
            $stmt = $this->conn->prepare("
                SELECT two_factor_auth, login_notify 
                FROM security_settings 
                WHERE user_id = :user_id
            ");
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            $settings = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($settings) {
                echo json_encode(['success' => true, 'data' => $settings]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Không tìm thấy cài đặt bảo mật']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    // Cập nhật cài đặt bảo mật
    public function updateSecuritySettings($userId, $data) {
        try {
            // Kiểm tra mật khẩu hiện tại
            $stmt = $this->conn->prepare("
                SELECT mat_khau FROM nhan_vien WHERE id_nhan_vien = :user_id
            ");
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user || !password_verify($data['current_password'], $user['mat_khau'])) {
                echo json_encode(['success' => false, 'message' => 'Mật khẩu hiện tại không đúng']);
                return;
            }

            // Cập nhật mật khẩu nếu có
            if (!empty($data['new_password'])) {
                if ($data['new_password'] !== $data['confirm_password']) {
                    echo json_encode(['success' => false, 'message' => 'Mật khẩu xác nhận không khớp']);
                    return;
                }
                $newPasswordHash = password_hash($data['new_password'], PASSWORD_DEFAULT);
                $stmt = $this->conn->prepare("
                    UPDATE nhan_vien 
                    SET mat_khau = :mat_khau 
                    WHERE id_nhan_vien = :user_id
                ");
                $stmt->bindParam(':mat_khau', $newPasswordHash);
                $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
                $stmt->execute();
            }

            // Cập nhật cài đặt bảo mật
            $stmt = $this->conn->prepare("
                INSERT INTO security_settings (user_id, two_factor_auth, login_notify)
                VALUES (:user_id, :two_factor_auth, :login_notify)
                ON DUPLICATE KEY UPDATE
                    two_factor_auth = :two_factor_auth,
                    login_notify = :login_notify
            ");
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':two_factor_auth', $data['two_factor_auth'], PDO::PARAM_BOOL);
            $stmt->bindParam(':login_notify', $data['login_notify'], PDO::PARAM_BOOL);
            $stmt->execute();

            echo json_encode(['success' => true, 'message' => 'Cập nhật cài đặt bảo mật thành công']);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    // Lấy cài đặt email
    public function getEmailSettings() {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM email_settings LIMIT 1");
            $stmt->execute();
            $settings = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($settings) {
                // Không trả về mật khẩu SMTP
                unset($settings['smtp_password']);
                echo json_encode(['success' => true, 'data' => $settings]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Không tìm thấy cài đặt email']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    // Cập nhật cài đặt email
    public function updateEmailSettings($data) {
        try {
            $stmt = $this->conn->prepare("
                UPDATE email_settings 
                SET smtp_host = :smtp_host, smtp_port = :smtp_port, 
                    smtp_username = :smtp_username, 
                    smtp_password = COALESCE(:smtp_password, smtp_password),
                    email_from = :email_from, email_from_name = :email_from_name,
                    smtp_auth = :smtp_auth, smtp_secure = :smtp_secure
                WHERE id = 1
            ");
            $stmt->bindParam(':smtp_host', $data['smtp_host']);
            $stmt->bindParam(':smtp_port', $data['smtp_port'], PDO::PARAM_INT);
            $stmt->bindParam(':smtp_username', $data['smtp_username']);
            $smtp_password = !empty($data['smtp_password']) ? $data['smtp_password'] : null;
            $stmt->bindParam(':smtp_password', $smtp_password);
            $stmt->bindParam(':email_from', $data['email_from']);
            $stmt->bindParam(':email_from_name', $data['email_from_name']);
            $stmt->bindParam(':smtp_auth', $data['smtp_auth'], PDO::PARAM_BOOL);
            $stmt->bindParam(':smtp_secure', $data['smtp_secure'], PDO::PARAM_BOOL);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => true, 'message' => 'Cập nhật cài đặt email thành công']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Không có thay đổi nào được thực hiện']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    // Lấy danh sách bản sao lưu
    public function getBackups() {
        try {
            $stmt = $this->conn->prepare("
                SELECT id, file_name, file_size, created_at 
                FROM backups 
                ORDER BY created_at DESC
            ");
            $stmt->execute();
            $backups = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'data' => $backups]);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    // Xóa bản sao lưu
    public function deleteBackup($id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT file_path FROM backups WHERE id = :id
            ");
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            $backup = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$backup) {
                echo json_encode(['success' => false, 'message' => 'Không tìm thấy bản sao lưu']);
                return;
            }

            // Xóa file vật lý
            if (file_exists($backup['file_path'])) {
                unlink($backup['file_path']);
            }

            // Xóa bản ghi trong database
            $stmt = $this->conn->prepare("DELETE FROM backups WHERE id = :id");
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();

            echo json_encode(['success' => true, 'message' => 'Xóa bản sao lưu thành công']);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    // Lấy danh sách bản sao lưu
    public function getAllUsers() {
        try {
            require_once __DIR__ . '/../models/settingmodal.php';
            $settingModal = new SettingModal();
            $users = $settingModal->getAllUsers();
            
            if ($users === false) {
                return ['success' => false, 'message' => 'Lỗi khi lấy danh sách người dùng'];
            }
            
            return ['success' => true, 'data' => $users];
        } catch (Exception $e) {
            error_log("Error in getAllUsers: " . $e->getMessage());
            return ['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()];
        }
    }

    public function updateUserPermissions($userId, $data) {
        try {
            require_once __DIR__ . '/../models/settingmodal.php';
            $settingModal = new SettingModal();
            $result = $settingModal->updateUserPermissions($userId, $data);
            
            if ($result === false) {
                return ['success' => false, 'message' => 'Lỗi khi cập nhật quyền người dùng'];
            }
            
            return ['success' => true, 'message' => 'Cập nhật quyền thành công'];
        } catch (Exception $e) {
            error_log("Error in updateUserPermissions: " . $e->getMessage());
            return ['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()];
        }
    }

    public function toggleUserStatus($userId) {
        try {
            require_once __DIR__ . '/../models/settingmodal.php';
            $settingModal = new SettingModal();
            $result = $settingModal->toggleUserStatus($userId);
            
            if ($result === false) {
                return ['success' => false, 'message' => 'Lỗi khi cập nhật trạng thái người dùng'];
            }
            
            return ['success' => true, 'message' => 'Cập nhật trạng thái thành công'];
        } catch (Exception $e) {
            error_log("Error in toggleUserStatus: " . $e->getMessage());
            return ['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()];
        }
    }

    public function registerRegularUser($data) {
        try {
            if (!isset($data['ten_dang_nhap']) || !isset($data['email']) || !isset($data['mat_khau']) || !isset($data['role'])) {
                return ['success' => false, 'message' => 'Thiếu thông tin bắt buộc'];
            }

            require_once __DIR__ . '/../models/settingmodal.php';
            require_once __DIR__ . "/../PHPMailer-master/src/PHPMailer.php";
            require_once __DIR__ . "/../PHPMailer-master/src/SMTP.php";
            require_once __DIR__ . "/../PHPMailer-master/src/Exception.php";
            
            $settingModal = new SettingModal();
            
            // Lưu mật khẩu gốc để gửi email
            $matKhauGoc = $data['mat_khau'];
            
            // Hash mật khẩu bằng MD5 trước khi lưu
            $hashedPassword = md5($data['mat_khau']);
            
            $result = $settingModal->registerRegularUser(
                $data['ten_dang_nhap'],
                $hashedPassword,
                $data['email'],
                $data['role']
            );

            if ($result['success']) {
                // Chuẩn bị dữ liệu cho email
                $userData = [
                    'email' => $data['email'],
                    'ten_dang_nhap' => $data['ten_dang_nhap'],
                    'mat_khau_goc' => $matKhauGoc
                ];

                // Gửi email thông báo
                $emailSent = $this->sendRegistrationEmail($userData);
                if (!$emailSent) {
                    error_log("Không thể gửi email thông báo đến: " . $data['email']);
                    // Vẫn trả về thành công vì tài khoản đã được tạo
                    $result['message'] .= ' nhưng không thể gửi email thông báo.';
                }
            }
            
            return $result;
        } catch (Exception $e) {
            error_log("Error in registerRegularUser: " . $e->getMessage());
            return ['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()];
        }
    }

    private function sendRegistrationEmail($userData) {
        try {
            if (!isset($userData['email']) || empty($userData['email']) || !filter_var($userData['email'], FILTER_VALIDATE_EMAIL)) {
                error_log("Không thể gửi email: Email người dùng không hợp lệ hoặc rỗng.");
                return false;
            }

            $emailNhanVien = $userData['email'];
            $tenDangNhap = $userData['ten_dang_nhap'];
            $matKhau = $userData['mat_khau_goc']; // Mật khẩu gốc trước khi mã hóa
            $nguoiGui = "Quản trị viên";
            $tenCongTy = "Quản Lý Nhân Sự";

            $mail = new PHPMailer\PHPMailer\PHPMailer();
            $mail->IsSMTP();
            $mail->SMTPDebug = 2;
            $mail->Debugoutput = function($str, $level) {
                error_log("PHPMailer Debug [$level]: $str");
            };
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = 'ssl';
            $mail->Host = "smtp.gmail.com";
            $mail->Port = 465;
            $mail->IsHTML(true);
            $mail->Username = "ngocthach102017@gmail.com";
            $mail->Password = "kwpaluqejzlvekcf";
            $mail->SetFrom("ngocthach102017@gmail.com", "HRM - $tenCongTy");
            $mail->Subject = "THÔNG TIN TÀI KHOẢN HỆ THỐNG QUẢN LÝ NHÂN SỰ";
            $mail->CharSet = 'UTF-8';

            $mail->Body = "
            <div style='font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9; border-radius: 8px;'>
                <div style='background: linear-gradient(135deg, #2196F3, #1976D2); color: white; padding: 20px; text-align: center; border-top-left-radius: 8px; border-top-right-radius: 8px;'>
                    <h2 style='margin: 0; font-size: 24px;'>THÔNG TIN TÀI KHOẢN</h2>
                    <p style='margin: 5px 0 0; font-size: 16px;'>Hệ thống quản lý nhân sự</p>
                </div>
                <div style='padding: 30px; background-color: #ffffff; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>
                    <p style='font-size: 16px; margin: 0 0 20px;'>Xin chào,</p>
                    <p style='font-size: 15px; margin: 0 0 20px;'>Tài khoản của bạn đã được tạo thành công trên hệ thống quản lý nhân sự. Dưới đây là thông tin đăng nhập của bạn:</p>
                    
                    <div style='background-color: #f5f5f5; padding: 20px; border-radius: 5px; margin: 20px 0;'>
                        <p style='margin: 0 0 10px; font-size: 15px;'><strong>Tên đăng nhập:</strong> $tenDangNhap</p>
                        <p style='margin: 0; font-size: 15px;'><strong>Mật khẩu:</strong> $matKhau</p>
                    </div>

                    <p style='font-size: 15px; margin: 20px 0; color: #1976D2;'>
                        <strong>Lưu ý:</strong> Bạn có thể đăng nhập bằng tài khoản email của mình
                    </p>

                    <div style='margin: 30px 0; padding: 15px; background-color: #e3f2fd; border-left: 4px solid #2196F3; border-radius: 4px;'>
                        <p style='margin: 0; font-size: 14px;'>
                            <strong>Để bảo mật tài khoản:</strong><br>
                            - Vui lòng đổi mật khẩu ngay sau khi đăng nhập lần đầu<br>
                            - Không chia sẻ thông tin đăng nhập với người khác
                        </p>
                    </div>

                    <p style='font-size: 15px; margin: 20px 0;'>
                        Nếu bạn gặp bất kỳ vấn đề nào trong quá trình đăng nhập, vui lòng liên hệ với quản trị viên để được hỗ trợ.
                    </p>

                    <hr style='border: none; border-top: 1px solid #eee; margin: 30px 0;'>

                    <p style='font-size: 14px; color: #666; margin: 0; text-align: center;'>
                        Email này được gửi tự động từ hệ thống. Vui lòng không trả lời email này.
                    </p>
                </div>
            </div>";

            $mail->AddAddress($emailNhanVien);
            
            if (!$mail->Send()) {
                error_log("Lỗi gửi email: " . $mail->ErrorInfo);
                return false;
            } else {
                error_log("Email đã được gửi thành công tới: $emailNhanVien");
                return true;
            }
        } catch (Exception $e) {
            error_log("Lỗi trong sendRegistrationEmail: " . $e->getMessage());
            return false;
        }
    }

    public function enrollFingerprint() {
        try {
            // Đọc dữ liệu JSON từ request
            $jsonData = file_get_contents('php://input');
            $data = json_decode($jsonData, true);

            if (!isset($data['id_nhan_vien']) || !isset($data['du_lieu_van_tay'])) {
                $this->sendJsonResponse(false, 'Thiếu thông tin bắt buộc');
                return;
            }

            require_once __DIR__ . '/../models/FingerprintModel.php';
            $fingerprintModel = new FingerprintModel();

            // Kiểm tra nhân viên tồn tại
            $employeeExists = $fingerprintModel->checkEmployeeExists($data['id_nhan_vien']);
            if (!$employeeExists) {
                $this->sendJsonResponse(false, 'Nhân viên không tồn tại');
                return;
            }

            // Tạo bản ghi vân tay mới
            $fingerprintData = [
                'id_nhan_vien' => $data['id_nhan_vien'],
                'du_lieu_van_tay' => $data['du_lieu_van_tay'],
                'trang_thai' => $data['trang_thai'] ?? 'pending'
            ];

            $fingerprintId = $fingerprintModel->create($fingerprintData);

            if ($fingerprintId) {
                $this->sendJsonResponse(true, 'Đã lưu vân tay thành công', [
                    'fingerprint_id' => $fingerprintId
                ]);
            } else {
                $this->sendJsonResponse(false, 'Không thể lưu vân tay');
            }
        } catch (Exception $e) {
            error_log("Error in enrollFingerprint: " . $e->getMessage());
            $this->sendJsonResponse(false, 'Lỗi khi lưu vân tay: ' . $e->getMessage());
        }
    }

    public function getAllFingerprints() {
        try {
            require_once __DIR__ . '/../models/FingerprintModel.php';
            $fingerprintModel = new FingerprintModel();
            $fingerprints = $fingerprintModel->getAllFingerprints();
            
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'message' => 'Lấy danh sách vân tay thành công',
                'data' => $fingerprints
            ]);
        } catch (Exception $e) {
            error_log("Error in getAllFingerprints: " . $e->getMessage());
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Lỗi khi lấy danh sách vân tay: ' . $e->getMessage()
            ]);
        }
    }

    private function sendJsonResponse($success, $message, $data = null) {
        header('Content-Type: application/json');
        $response = [
            'success' => $success,
            'message' => $message
        ];
        if ($data !== null) {
            $response['data'] = $data;
        }
        echo json_encode($response);
    }

    public function updateUserStatus($userId) {
        try {
            // Kiểm tra quyền
            if (!isset($_SESSION['user_id']) || !$_SESSION['quyen_sua']) {
                throw new Exception("Bạn không có quyền thực hiện thao tác này");
            }

            // Không cho phép thay đổi trạng thái của admin
            if ($userId == 1) {
                throw new Exception("Không thể thay đổi trạng thái của tài khoản admin");
            }

            // Lấy dữ liệu từ request
            $data = json_decode(file_get_contents("php://input"), true);
            
            if (!isset($data['trang_thai'])) {
                throw new Exception("Thiếu thông tin trạng thái");
            }

            $newStatus = $data['trang_thai'];
            
            // Kiểm tra giá trị trạng thái hợp lệ
            if (!in_array($newStatus, ['Hoạt động', 'Không hoạt động'])) {
                throw new Exception("Trạng thái không hợp lệ");
            }

            // Cập nhật trạng thái trong bảng nguoi_dung
            $sql = "UPDATE nguoi_dung SET trang_thai = ? WHERE id = ?";
            $stmt = $this->conn->prepare($sql);
            $success = $stmt->execute([$newStatus, $userId]);

            if (!$success) {
                throw new Exception("Không thể cập nhật trạng thái");
            }

            // Kiểm tra xem có bản ghi nào được cập nhật không
            if ($stmt->rowCount() === 0) {
                throw new Exception("Không tìm thấy người dùng hoặc không có thay đổi");
            }

            // Cập nhật trạng thái trong bảng nhan_vien nếu có liên kết
            $sql = "UPDATE nhan_vien SET trang_thai = ? WHERE id_nhan_vien = (SELECT id_nhan_vien FROM nguoi_dung WHERE id = ?)";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([$newStatus, $userId]);

            ob_clean(); // Xóa bất kỳ output buffer nào
            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode([
                'success' => true,
                'message' => "Đã cập nhật trạng thái thành công"
            ]);
            exit;

        } catch (Exception $e) {
            ob_clean(); // Xóa bất kỳ output buffer nào
            header('Content-Type: application/json; charset=UTF-8');
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => $e->getMessage()
            ]);
            exit;
        }
    }
}?>
