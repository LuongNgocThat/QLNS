<?php
ob_start();

include_once(__DIR__ . '/../models/NghiPhepModel.php');
include_once(__DIR__ . '/../models/ChamCongModel.php');
require_once(__DIR__ . '/../vendor/autoload.php');
require_once(__DIR__ . '/../services/EmailService.php');

class NghiPhepController {
    private $nghiPhepModel;
    private $chamCongModel;
    private $emailService;

    public function __construct() {
        try {
            $this->nghiPhepModel = new NghiPhepModel();
            $this->chamCongModel = new ChamCongModel();
            $this->emailService = new \Services\EmailService();
        } catch (Exception $e) {
            error_log("Lỗi khởi tạo controller: " . $e->getMessage());
            throw $e;
        }
    }

    public function getAllNghiPhep() {
        try {
            header('Content-Type: application/json; charset=utf-8');
            $records = $this->nghiPhepModel->getAllNghiPhep();
            
            if (!is_array($records)) {
                throw new Exception("Dữ liệu trả về không hợp lệ");
            }
            
            echo json_encode([
                'success' => true,
                'message' => 'Lấy dữ liệu thành công',
                'data' => $records
            ], JSON_UNESCAPED_UNICODE);
            
        } catch (Exception $e) {
            error_log("Lỗi trong getAllNghiPhep: " . $e->getMessage());
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => $e->getMessage()
            ], JSON_UNESCAPED_UNICODE);
        }
    }

    public function updateNghiPhep($id, $data) {
        try {
            if (!isset($data['trang_thai1'])) {
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "Thiếu tham số trang_thai1"]);
                return;
            }

            $donNghiPhep = $this->nghiPhepModel->getDonNghiPhep($id);
            if ($donNghiPhep['trang_thai1'] === 'Từ chối') {
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "Không thể chỉnh sửa đơn nghỉ phép đã bị từ chối"]);
                return;
            }

            $trangThai = $data['trang_thai1'];
            $idNguoiDuyet = isset($data['id_nguoi_duyet']) ? $data['id_nguoi_duyet'] : null;
            $lyDoTuChoi = isset($data['ly_do_tu_choi']) ? $data['ly_do_tu_choi'] : null;
            $ngayDuyet = ($trangThai === 'Đã duyệt' || $trangThai === 'Từ chối') ? date('Y-m-d H:i:s') : null;

            $validStatuses = ['Chờ xét duyệt', 'Đã duyệt', 'Từ chối'];
            if (!in_array($trangThai, $validStatuses)) {
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "Trạng thái không hợp lệ: $trangThai"]);
                return;
            }

            $result = $this->nghiPhepModel->updateNghiPhep($id, $trangThai, $idNguoiDuyet, $ngayDuyet, $lyDoTuChoi);

            if ($result) {
                // Nếu đơn được duyệt, cập nhật bảng chấm công
                if ($trangThai === 'Đã duyệt') {
                    $this->updateChamCongForApprovedLeave($result);
                }

                if ($trangThai === 'Đã duyệt' || $trangThai === 'Từ chối') {
                    $this->sendApprovalEmail($result, $trangThai, $lyDoTuChoi);
                }
                header('Content-Type: application/json');
                echo json_encode(["success" => true, "message" => "Cập nhật trạng thái thành công"]);
            } else {
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "Lỗi khi cập nhật trạng thái"]);
            }
        } catch (Exception $e) {
            error_log("Lỗi trong updateNghiPhep: " . $e->getMessage());
            header('Content-Type: application/json');
            echo json_encode(["success" => false, "message" => "Lỗi hệ thống: " . $e->getMessage()]);
        }
    }

    private function updateChamCongForApprovedLeave($donNghiPhep) {
        try {
            $idNhanVien = $donNghiPhep['id_nhan_vien'];
            $ngayBatDau = new DateTime($donNghiPhep['ngay_bat_dau']);
            $ngayKetThuc = new DateTime($donNghiPhep['ngay_ket_thuc']);
            $loaiNghi = $donNghiPhep['loai_nghi'];

            // Lặp qua từng ngày trong khoảng nghỉ phép
            while ($ngayBatDau <= $ngayKetThuc) {
                $ngayLamViec = $ngayBatDau->format('Y-m-d');

                // Bỏ qua ngày Chủ nhật
                if ($ngayBatDau->format('w') !== '0') {
                    $chamCongData = [
                        'id_nhan_vien' => $idNhanVien,
                        'ngay_lam_viec' => $ngayLamViec,
                        'gio_vao' => null,
                        'gio_ra' => null,
                        'trang_thai' => $loaiNghi, // Có phép, Không phép, hoặc Phép Năm
                        'ghi_chu' => 'Tự động cập nhật từ đơn nghỉ phép #' . $donNghiPhep['id_nghi_phep']
                    ];

                    // Thêm hoặc cập nhật bản ghi chấm công
                    $this->chamCongModel->addChamCong($chamCongData);
                }

                $ngayBatDau->modify('+1 day');
            }
        } catch (Exception $e) {
            error_log("Lỗi trong updateChamCongForApprovedLeave: " . $e->getMessage());
            throw $e;
        }
    }

    public function addNghiPhep($data) {
        try {
            if (!isset($data['id_nhan_vien']) || !isset($data['ngay_bat_dau']) || !isset($data['ngay_ket_thuc']) || 
                !isset($data['ly_do']) || !isset($data['loai_nghi']) || !isset($data['trang_thai1'])) {
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "Thiếu các tham số bắt buộc"]);
                return;
            }

            $idNhanVien = intval($data['id_nhan_vien']);
            $ngayBatDau = $data['ngay_bat_dau'];
            $ngayKetThuc = $data['ngay_ket_thuc'];
            $lyDo = $data['ly_do'];
            $loaiNghi = $data['loai_nghi'];
            $trangThai = $data['trang_thai1'];
            $lyDoTuChoi = isset($data['ly_do_tu_choi']) ? $data['ly_do_tu_choi'] : null;

            $validStatuses = ['Chờ xét duyệt', 'Đã duyệt', 'Từ chối'];
            $validLoaiNghi = ['Có phép', 'Không phép', 'Phép Năm'];
            if (!in_array($trangThai, $validStatuses)) {
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "Trạng thái không hợp lệ: $trangThai"]);
                return;
            }
            if (!in_array($loaiNghi, $validLoaiNghi)) {
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "Loại nghỉ không hợp lệ: $loaiNghi"]);
                return;
            }

            if (!is_numeric($idNhanVien) || $idNhanVien <= 0) {
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "ID nhân viên không hợp lệ"]);
                return;
            }

            if (strtotime($ngayKetThuc) < strtotime($ngayBatDau)) {
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "Ngày kết thúc phải lớn hơn hoặc bằng ngày bắt đầu"]);
                return;
            }

            if (empty($lyDo)) {
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "Lý do không được để trống"]);
                return;
            }

            // Kiểm tra số ngày phép năm còn lại
            if ($loaiNghi === 'Phép Năm') {
                $year = date('Y', strtotime($ngayBatDau));
                $usedDays = $this->nghiPhepModel->calculateUsedAnnualLeaveDays($idNhanVien, $year);
                $maxAnnualLeaveDays = 12;
                $remainingDays = $maxAnnualLeaveDays - $usedDays;

                // Tính số ngày nghỉ của đơn hiện tại (loại bỏ Chủ Nhật)
                $leaveDays = 0;
                $currentDate = new DateTime($ngayBatDau);
                $endDate = new DateTime($ngayKetThuc);
                while ($currentDate <= $endDate) {
                    if ($currentDate->format('w') !== '0') { // Bỏ qua Chủ Nhật
                        $leaveDays++;
                    }
                    $currentDate->modify('+1 day');
                }

                if ($remainingDays < $leaveDays) {
                    $hoTen = $this->nghiPhepModel->getEmployeeName($idNhanVien);
                    header('Content-Type: application/json');
                    echo json_encode(["success" => false, "message" => "$hoTen đã nghỉ hết phép năm"]);
                    return;
                }
            }

            error_log("addNghiPhep input: " . json_encode($data));
            $result = $this->nghiPhepModel->addNghiPhep($idNhanVien, $ngayBatDau, $ngayKetThuc, $lyDo, $loaiNghi, $trangThai, $lyDoTuChoi);

            if ($result) {
                header('Content-Type: application/json');
                echo json_encode(["success" => true, "message" => "Thêm đơn nghỉ phép thành công", "id_nghi_phep" => $result]);
            } else {
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "Lỗi khi thêm đơn nghỉ phép"]);
            }
        } catch (Exception $e) {
            error_log("Lỗi trong addNghiPhep: " . $e->getMessage());
            header('Content-Type: application/json');
            echo json_encode(["success" => false, "message" => "Lỗi hệ thống: " . $e->getMessage()]);
        }
    }

    public function addChamCong($data) {
        try {
            $validStatuses = ['Có phép', 'Không phép', 'Phép Năm', 'Chưa điểm danh'];
            if (!isset($data['id_nhan_vien']) || !isset($data['ngay_lam_viec']) || !isset($data['trang_thai'])) {
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "Thiếu các tham số bắt buộc"]);
                return;
            }

            if (!in_array($data['trang_thai'], $validStatuses)) {
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "Trạng thái chấm công không hợp lệ: " . $data['trang_thai']]);
                return;
            }

            $result = $this->chamCongModel->addChamCong($data);
            if ($result) {
                header('Content-Type: application/json');
                echo json_encode(["success" => true, "message" => "Thêm bản ghi chấm công thành công"]);
            } else {
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "Lỗi khi thêm bản ghi chấm công"]);
            }
        } catch (Exception $e) {
            error_log("Lỗi trong addChamCong: " . $e->getMessage());
            header('Content-Type: application/json');
            echo json_encode(["success" => false, "message" => "Lỗi hệ thống: " . $e->getMessage()]);
        }
    }

    private function sendApprovalEmail($thongTinDon, $trangThai, $lyDoTuChoi = null) {
        try {
            if (!$thongTinDon || !isset($thongTinDon['email']) || empty($thongTinDon['email'])) {
                error_log("Không thể gửi email: Email nhân viên không hợp lệ hoặc rỗng.");
                return;
            }

            $emailNhanVien = $thongTinDon['email'];
            $hoTenNV = $thongTinDon['ho_ten'] ?? 'Nhân viên';
            $ngayBatDau = isset($thongTinDon['ngay_bat_dau']) ? date("d-m-Y", strtotime($thongTinDon['ngay_bat_dau'])) : 'N/A';
            $ngayKetThuc = isset($thongTinDon['ngay_ket_thuc']) ? date("d-m-Y", strtotime($thongTinDon['ngay_ket_thuc'])) : 'N/A';
            $loaiNghi = $thongTinDon['loai_nghi'] ?? 'N/A';
            $lyDo = $thongTinDon['ly_do'] ?? 'Không có lý do';
            $lyDoTuChoiDisplay = $lyDoTuChoi ?? 'Không có lý do từ chối';

            $statusColor = $trangThai === 'Đã duyệt' ? '#4CAF50' : '#F44336';
            $statusMessage = $trangThai === 'Đã duyệt' ? 'ĐÃ ĐƯỢC DUYỆT' : 'BỊ TỪ CHỐI';
            $headerBgColor = $trangThai === 'Đã duyệt' ? 'linear-gradient(90deg, #4CAF50, #66BB6A)' : 'linear-gradient(90deg, #F44336, #EF5350)';

            $htmlContent = "
            <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;'>
                <div style='background: {$headerBgColor}; color: white; padding: 20px; text-align: center;'>
                    <h1 style='margin: 0;'>THÔNG BÁO ĐƠN NGHỈ PHÉP {$statusMessage}</h1>
                </div>
                <div style='padding: 20px; border: 1px solid #ddd;'>
                    <p><strong>Kính gửi:</strong> {$hoTenNV}</p>
                    <p>Đơn xin nghỉ phép của bạn đã được xử lý với thông tin như sau:</p>
                    <ul style='list-style: none; padding: 0;'>
                        <li><strong>Trạng thái:</strong> <span style='color: {$statusColor};'>{$trangThai}</span></li>
                        <li><strong>Loại nghỉ:</strong> {$loaiNghi}</li>
                        <li><strong>Thời gian:</strong> Từ {$ngayBatDau} đến {$ngayKetThuc}</li>
                        <li><strong>Lý do nghỉ:</strong> {$lyDo}</li>
                        " . ($trangThai !== 'Đã duyệt' ? "<li><strong>Lý do từ chối:</strong> {$lyDoTuChoiDisplay}</li>" : "") . "
                    </ul>
                    <p style='margin-top: 20px;'>Trân trọng,</p>
                    <p><strong>Phòng Nhân sự</strong></p>
                </div>
            </div>";

            $this->emailService->send(
                $emailNhanVien,
                "THÔNG BÁO DUYỆT ĐƠN NGHỈ PHÉP",
                $htmlContent
            );
            error_log("Email đã được gửi thành công tới: $emailNhanVien");

        } catch (Exception $e) {
            error_log("Lỗi gửi email thông báo nghỉ phép: " . $e->getMessage());
            // Không throw exception ở đây để không ảnh hưởng đến luồng chính
        }
    }

    public function deleteNghiPhep($id) {
        try {
            $result = $this->nghiPhepModel->deleteNghiPhep($id);
            header('Content-Type: application/json');
            if ($result) {
                echo json_encode(["success" => true, "message" => "Xóa thành công"]);
            } else {
                echo json_encode(["success" => false, "message" => "Lỗi khi xóa"]);
            }
        } catch (Exception $e) {
            header('Content-Type: application/json');
            echo json_encode(["success" => false, "message" => "Lỗi khi xóa: " . $e->getMessage()]);
        }
    }
}

ob_end_clean();
?>