<?php

class EmployeeController {
    private $db;

    public function __construct() {
        require_once(__DIR__ . '/../config/database.php');
        $this->db = new Database();
    }

    public function getProfile($userId) {
        try {
            if (!$userId) {
                throw new Exception("ID nhân viên không hợp lệ");
            }

            $conn = $this->db->getConnection();
            
            // Kiểm tra xem user_id có phải là id_nhan_vien hay không
            $checkSql = "SELECT id_nhan_vien FROM nguoi_dung WHERE id = ?";
            $checkStmt = $conn->prepare($checkSql);
            $checkStmt->execute([$userId]);
            $userData = $checkStmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$userData || !$userData['id_nhan_vien']) {
                throw new Exception("Không tìm thấy thông tin nhân viên cho tài khoản này");
            }

            $employeeId = $userData['id_nhan_vien'];
            
            $sql = "SELECT 
                    nv.id_nhan_vien, 
                    nv.ho_ten, 
                    nv.gioi_tinh, 
                    nv.ngay_sinh, 
                    nv.email, 
                    nv.so_dien_thoai,
                    nv.dia_chi, 
                    nv.can_cuoc_cong_dan, 
                    nv.ngay_cap, 
                    nv.noi_cap, 
                    nv.que_quan, 
                    nv.hinh_anh,
                    pb.ten_phong_ban, 
                    cv.ten_chuc_vu, 
                    nv.loai_hop_dong, 
                    nv.luong_co_ban,
                    nv.ngay_vao_lam, 
                    nv.ngay_nghi_viec, 
                    nv.trang_thai
                FROM nhan_vien nv
                LEFT JOIN phong_ban pb ON nv.id_phong_ban = pb.id_phong_ban
                LEFT JOIN chuc_vu cv ON nv.id_chuc_vu = cv.id_chuc_vu
                WHERE nv.id_nhan_vien = ?";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute([$employeeId]);
            $profile = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($profile) {
                // Xử lý đường dẫn ảnh giống như trong chitietnhansu.php
                if ($profile['hinh_anh']) {
                    $profile['hinh_anh'] = '/doanqlns/' . ltrim($profile['hinh_anh'], '/');
                } else {
                    $profile['hinh_anh'] = 'https://via.placeholder.com/150x150';
                }

                // Format dates
                $datesToFormat = ['ngay_sinh', 'ngay_vao_lam', 'ngay_nghi_viec', 'ngay_cap'];
                foreach ($datesToFormat as $dateField) {
                    if (!empty($profile[$dateField])) {
                        $profile[$dateField] = date('d/m/Y', strtotime($profile[$dateField]));
                    } else {
                        $profile[$dateField] = 'N/A';
                    }
                }

                // Format currency - luong_co_ban
                if (isset($profile['luong_co_ban']) && $profile['luong_co_ban'] !== null) {
                    $profile['luong_co_ban'] = number_format((float)$profile['luong_co_ban'], 0, ',', '.');
                } else {
                    $profile['luong_co_ban'] = '0';
                }

                // Format gender
                if ($profile['gioi_tinh'] !== null) {
                    $profile['gioi_tinh'] = ($profile['gioi_tinh'] === '1' || strtolower($profile['gioi_tinh']) === 'nam') ? 'Nam' : 'Nữ';
                } else {
                    $profile['gioi_tinh'] = 'N/A';
                }

                // Format status
                if ($profile['trang_thai'] === null) {
                    $profile['trang_thai'] = 'Đang làm việc';
                }

                // Format other fields
                $fieldsToCheck = ['email', 'so_dien_thoai', 'dia_chi', 'can_cuoc_cong_dan', 'noi_cap', 'que_quan', 'ten_phong_ban', 'ten_chuc_vu', 'loai_hop_dong'];
                foreach ($fieldsToCheck as $field) {
                    if (empty($profile[$field])) {
                        $profile[$field] = 'N/A';
                    }
                }

                echo json_encode([
                    "success" => true,
                    "data" => $profile
                ]);
            } else {
                throw new Exception("Không tìm thấy thông tin nhân viên");
            }
        } catch (PDOException $e) {
            error_log("Database Error in getProfile: " . $e->getMessage());
            http_response_code(500);
            echo json_encode([
                "success" => false,
                "message" => "Lỗi khi truy vấn dữ liệu: " . $e->getMessage()
            ]);
        } catch (Exception $e) {
            error_log("Error in getProfile: " . $e->getMessage());
            http_response_code(404);
            echo json_encode([
                "success" => false,
                "message" => $e->getMessage()
            ]);
        }
    }

    public function getSalary($userId, $month, $year) {
        try {
            $conn = $this->db->getConnection();
            
            // Debug log
            error_log("getSalary called with userId: $userId, month: $month, year: $year");
            
            // Lấy id_nhan_vien từ user_id
            $checkSql = "SELECT id_nhan_vien FROM nguoi_dung WHERE id = ?";
            $checkStmt = $conn->prepare($checkSql);
            $checkStmt->execute([$userId]);
            $userData = $checkStmt->fetch(PDO::FETCH_ASSOC);
            
            // Debug log
            error_log("User data: " . json_encode($userData));
            
            if (!$userData || !$userData['id_nhan_vien']) {
                throw new Exception("Không tìm thấy thông tin nhân viên cho tài khoản này");
            }

            $employeeId = $userData['id_nhan_vien'];
            
            // Debug log
            error_log("Employee ID: $employeeId");
            
            // Get salary information
            $sql = "SELECT 
                    nv.luong_co_ban as luong_co_ban_goc,
                    cv.phu_cap as phu_cap_chuc_vu,
                    COALESCE((SELECT SUM(tien_thuong) FROM thuong 
                     WHERE id_nhan_vien = nv.id_nhan_vien 
                     AND MONTH(ngay) = ? 
                     AND YEAR(ngay) = ?), 0) as tong_thuong,
                    COALESCE(bt.bhxh, 0) as bhxh,
                    COALESCE(bt.bhyt, 0) as bhyt,
                    COALESCE(bt.bhtn, 0) as bhtn,
                    COALESCE(bt.thue_tncn, 0) as thue_thu_nhap,
                    l.luong_co_ban,
                    l.luong_thuc_nhan
                FROM nhan_vien nv
                LEFT JOIN chuc_vu cv ON nv.id_chuc_vu = cv.id_chuc_vu
                LEFT JOIN bao_hiem_thue_tncn bt ON bt.id_nhan_vien = nv.id_nhan_vien 
                    AND bt.thang = CONCAT(?, '-', LPAD(?, 2, '0'))
                LEFT JOIN luong l ON l.id_nhan_vien = nv.id_nhan_vien
                    AND l.thang = CONCAT(?, '-', LPAD(?, 2, '0'))
                WHERE nv.id_nhan_vien = ?";
            
            // Debug log
            error_log("SQL Query: $sql");
            error_log("Parameters: month=$month, year=$year, employeeId=$employeeId");
            
            $stmt = $conn->prepare($sql);
            $stmt->execute([$month, $year, $year, $month, $year, $month, $employeeId]);
            $salary = $stmt->fetch(PDO::FETCH_ASSOC);

            // Debug log
            error_log("Salary data: " . json_encode($salary));

            if ($salary) {
                // Get all days in the month
                $startDate = "$year-$month-01";
                $endDate = date('Y-m-t', strtotime($startDate));
                
                // Get attendance records
                $attendanceQuery = "SELECT ngay_lam_viec, trang_thai
                    FROM cham_cong
                    WHERE id_nhan_vien = :id_nhan_vien
                    AND ngay_lam_viec BETWEEN :start_date AND :end_date";
                
                $stmtAttendance = $conn->prepare($attendanceQuery);
                $stmtAttendance->bindParam(':id_nhan_vien', $employeeId);
                $stmtAttendance->bindParam(':start_date', $startDate);
                $stmtAttendance->bindParam(':end_date', $endDate);
                $stmtAttendance->execute();
                $attendanceRecords = $stmtAttendance->fetchAll(PDO::FETCH_ASSOC);

                $diemDanhDays = 0;
                $nghiDays = 0;
                $khongPhepCount = 0;

                // Process each day in the month
                $currentDate = new DateTime($startDate);
                $lastDate = new DateTime($endDate);

                while ($currentDate <= $lastDate) {
                    $currentDateStr = $currentDate->format('Y-m-d');
                    $isSunday = $currentDate->format('w') == 0;

                    // Find attendance record for this day
                    $record = null;
                    foreach ($attendanceRecords as $attendance) {
                        if ($attendance['ngay_lam_viec'] === $currentDateStr) {
                            $record = $attendance;
                            break;
                        }
                    }

                    if ($isSunday) {
                        $diemDanhDays += 1; // Chủ nhật được tính là ngày điểm danh
                    } else if ($record) {
                        if ($record['trang_thai'] === 'Đúng giờ' || $record['trang_thai'] === 'Phép Năm' || $record['trang_thai'] === 'Nghỉ Lễ') {
                            $diemDanhDays += 1; // Đúng giờ, Phép Năm, Nghỉ Lễ đều tính 1 ngày điểm danh
                        } else if ($record['trang_thai'] === 'Đi trễ') {
                            $diemDanhDays += 0.75; // Đi trễ tính 0.75 ngày
                        } else if ($record['trang_thai'] === 'Có phép') {
                            $diemDanhDays += 1; // Có phép tính 1 ngày điểm danh
                            $nghiDays -= 0.5; // Trừ 0.5 ngày nghỉ
                            $khongPhepCount += 0.5; // Tăng đếm không phép
                        } else if ($record['trang_thai'] === 'Không phép') {
                            $diemDanhDays += 1; // Không phép tính 1 ngày điểm danh
                            $nghiDays -= 1; // Trừ 1 ngày nghỉ
                            $khongPhepCount += 1; // Tăng đếm không phép
                        }
                    }

                    $currentDate->modify('+1 day');
                }

                $soNgayCong = $diemDanhDays - $khongPhepCount;
                
                // Get other components
                $phuCapChucVu = floatval($salary['phu_cap_chuc_vu']);
                $tongThuong = floatval($salary['tong_thuong']);
                $bhxh = floatval($salary['bhxh']);
                $bhyt = floatval($salary['bhyt']);
                $bhtn = floatval($salary['bhtn']);
                $thueThuNhap = floatval($salary['thue_thu_nhap']);
                
                // Calculate total deductions
                $tongKhauTru = $bhxh + $bhyt + $bhtn + $thueThuNhap;

                // Format response data
                $response = [
                    'luong_co_ban' => number_format($salary['luong_co_ban_goc'], 0, ',', '.'),
                    'so_ngay_cong' => sprintf('%.2f', $soNgayCong),
                    'luong_theo_ngay_cong' => number_format($salary['luong_co_ban'], 0, ',', '.'),
                    'phu_cap' => number_format($phuCapChucVu, 0, ',', '.'),
                    'thuong' => number_format($tongThuong, 0, ',', '.'),
                    'bhxh' => number_format($bhxh, 0, ',', '.'),
                    'bhyt' => number_format($bhyt, 0, ',', '.'),
                    'bhtn' => number_format($bhtn, 0, ',', '.'),
                    'thue' => number_format($thueThuNhap, 0, ',', '.'),
                    'tong_khau_tru' => number_format($tongKhauTru, 0, ',', '.'),
                    'tong_luong' => number_format($salary['luong_thuc_nhan'], 0, ',', '.')
                ];
                
                echo json_encode([
                    "success" => true,
                    "data" => $response
                ]);
            } else {
                // Debug log
                error_log("No salary data found for employeeId: $employeeId, month: $month, year: $year");
                throw new Exception("Không tìm thấy thông tin lương cho tháng $month/$year");
            }
        } catch (Exception $e) {
            error_log("Error in getSalary: " . $e->getMessage());
            http_response_code(404);
            echo json_encode([
                "success" => false,
                "message" => $e->getMessage()
            ]);
        }
    }

    public function getLeaveHistory($userId) {
        try {
            $conn = $this->db->getConnection();
            
            $sql = "SELECT * FROM nghi_phep WHERE id_nhan_vien = ? ORDER BY ngay_bat_dau DESC";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$userId]);
            $leaveHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode([
                "success" => true,
                "data" => $leaveHistory
            ]);
        } catch (PDOException $e) {
            error_log($e->getMessage());
            http_response_code(500);
            echo json_encode([
                "success" => false,
                "message" => "Lỗi khi lấy lịch sử nghỉ phép"
            ]);
        }
    }

    public function submitLeaveRequest($userId, $data) {
        try {
            if (!isset($data['ngay_bat_dau']) || !isset($data['ngay_ket_thuc']) || 
                !isset($data['ly_do']) || !isset($data['loai_nghi'])) {
                http_response_code(400);
                echo json_encode([
                    "success" => false,
                    "message" => "Thiếu thông tin cần thiết"
                ]);
                return;
            }

            $conn = $this->db->getConnection();

            // Get employee ID from user ID
            $checkSql = "SELECT id_nhan_vien FROM nguoi_dung WHERE id = ?";
            $checkStmt = $conn->prepare($checkSql);
            $checkStmt->execute([$userId]);
            $userData = $checkStmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$userData || !$userData['id_nhan_vien']) {
                throw new Exception("Không tìm thấy thông tin nhân viên cho tài khoản này");
            }

            $employeeId = $userData['id_nhan_vien'];
            
            // Validate loai_nghi
            $validLoaiNghi = ['Có phép', 'Không phép', 'Phép Năm'];
            if (!in_array($data['loai_nghi'], $validLoaiNghi)) {
                http_response_code(400);
                echo json_encode([
                    "success" => false,
                    "message" => "Loại nghỉ không hợp lệ"
                ]);
                return;
            }

            // Check for annual leave days if type is "Phép Năm"
            if ($data['loai_nghi'] === 'Phép Năm') {
                $year = date('Y', strtotime($data['ngay_bat_dau']));
                
                // Get used annual leave days
                $usedDaysQuery = "SELECT ngay_bat_dau, ngay_ket_thuc 
                                FROM nghi_phep 
                                WHERE id_nhan_vien = ? 
                                AND loai_nghi = 'Phép Năm' 
                                AND trang_thai1 = 'Đã duyệt'
                                AND YEAR(ngay_bat_dau) = ?";
                $stmt = $conn->prepare($usedDaysQuery);
                $stmt->execute([$employeeId, $year]);
                $usedLeaves = $stmt->fetchAll(PDO::FETCH_ASSOC);

                // Calculate used days
                $usedDays = 0;
                foreach ($usedLeaves as $leave) {
                    $startDate = new DateTime($leave['ngay_bat_dau']);
                    $endDate = new DateTime($leave['ngay_ket_thuc']);
                    while ($startDate <= $endDate) {
                        if ($startDate->format('w') !== '0') { // Skip Sundays
                            $usedDays++;
                        }
                        $startDate->modify('+1 day');
                    }
                }

                // Calculate requested days
                $requestStart = new DateTime($data['ngay_bat_dau']);
                $requestEnd = new DateTime($data['ngay_ket_thuc']);
                $requestedDays = 0;
                while ($requestStart <= $requestEnd) {
                    if ($requestStart->format('w') !== '0') { // Skip Sundays
                        $requestedDays++;
                    }
                    $requestStart->modify('+1 day');
                }

                // Check if exceeding annual leave limit
                $maxAnnualLeaveDays = 12;
                if (($usedDays + $requestedDays) > $maxAnnualLeaveDays) {
                    http_response_code(400);
                    echo json_encode([
                        "success" => false,
                        "message" => "Bạn đã sử dụng hết số ngày phép năm cho phép"
                    ]);
                    return;
                }
            }
            
            $sql = "INSERT INTO nghi_phep (id_nhan_vien, ngay_bat_dau, ngay_ket_thuc, ly_do, loai_nghi, trang_thai1) 
                    VALUES (?, ?, ?, ?, ?, 'Chờ duyệt')";
            
            $stmt = $conn->prepare($sql);
            $success = $stmt->execute([
                $employeeId,
                $data['ngay_bat_dau'],
                $data['ngay_ket_thuc'],
                $data['ly_do'],
                $data['loai_nghi']
            ]);

            if ($success) {
                echo json_encode([
                    "success" => true,
                    "message" => "Đã gửi yêu cầu nghỉ phép thành công"
                ]);
            } else {
                throw new Exception("Không thể thêm yêu cầu nghỉ phép");
            }
        } catch (PDOException $e) {
            error_log($e->getMessage());
            http_response_code(500);
            echo json_encode([
                "success" => false,
                "message" => "Lỗi khi gửi yêu cầu nghỉ phép: " . $e->getMessage()
            ]);
        } catch (Exception $e) {
            error_log($e->getMessage());
            http_response_code(400);
            echo json_encode([
                "success" => false,
                "message" => $e->getMessage()
            ]);
        }
    }

    public function getLeaveRequests($userId) {
        try {
            $conn = $this->db->getConnection();

            // Get employee ID from user ID
            $checkSql = "SELECT id_nhan_vien FROM nguoi_dung WHERE id = ?";
            $checkStmt = $conn->prepare($checkSql);
            $checkStmt->execute([$userId]);
            $userData = $checkStmt->fetch(PDO::FETCH_ASSOC);

            if (!$userData || !$userData['id_nhan_vien']) {
                throw new Exception("Không tìm thấy thông tin nhân viên");
            }

            $employeeId = $userData['id_nhan_vien'];

            // Get leave requests for the employee
            $sql = "SELECT 
                    np.ngay_bat_dau,
                    np.ngay_ket_thuc,
                    np.ly_do,
                    np.loai_nghi,
                    np.trang_thai1,
                   
                    np.ly_do_tu_choi
                FROM nghi_phep np
                WHERE np.id_nhan_vien = ?
                ORDER BY np.ngay_bat_dau DESC";

            $stmt = $conn->prepare($sql);
            $stmt->execute([$employeeId]);
            $leaveRequests = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode([
                "success" => true,
                "data" => $leaveRequests
            ]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                "success" => false,
                "message" => $e->getMessage()
            ]);
        }
    }
} 