<?php
require_once __DIR__ . '/../config/Database.php';

class UserController {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    private function getPhongBanId($ten_phong_ban) {
        try {
            $stmt = $this->conn->prepare("SELECT id_phong_ban FROM phong_ban WHERE ten_phong_ban = :ten_phong_ban");
            $stmt->bindParam(':ten_phong_ban', $ten_phong_ban);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result ? $result['id_phong_ban'] : null;
        } catch (PDOException $e) {
            error_log("Lỗi khi lấy id_phong_ban: " . $e->getMessage());
            return null;
        }
    }

    private function getChucVuId($ten_chuc_vu) {
        try {
            $stmt = $this->conn->prepare("SELECT id_chuc_vu FROM chuc_vu WHERE ten_chuc_vu = :ten_chuc_vu");
            $stmt->bindParam(':ten_chuc_vu', $ten_chuc_vu);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result ? $result['id_chuc_vu'] : null;
        } catch (PDOException $e) {
            error_log("Lỗi khi lấy id_chuc_vu: " . $e->getMessage());
            return null;
        }
    }

    public function addUser($data) {
        // Giữ nguyên hàm addUser
        try {
            $required_fields = ['ho_ten', 'email', 'ngay_sinh', 'ten_phong_ban', 'ten_chuc_vu', 'ngay_vao_lam', 'luong_co_ban'];
            foreach ($required_fields as $field) {
                if (!isset($data[$field]) || empty(trim($data[$field]))) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => "Trường $field là bắt buộc"]);
                    return;
                }
            }

            if (!isset($data['gioi_tinh']) || !in_array($data['gioi_tinh'], ['Nam', 'Nữ'])) {
                $data['gioi_tinh'] = 'Nam';
            }

            if (!isset($data['trang_thai']) || !in_array($data['trang_thai'], ['Đang làm việc', 'Nghỉ việc'])) {
                $data['trang_thai'] = 'Đang làm việc';
            }

            $id_phong_ban = $this->getPhongBanId($data['ten_phong_ban']);
            $id_chuc_vu = $this->getChucVuId($data['ten_chuc_vu']);

            if (!$id_phong_ban || !$id_chuc_vu) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Phòng ban hoặc chức vụ không tồn tại']);
                return;
            }

            $hinh_anh_path = null;
            if (isset($data['hinh_anh']) && $data['hinh_anh']['error'] === UPLOAD_ERR_OK) {
                $allowed = ['jpg', 'jpeg', 'png'];
                $file_name = $data['hinh_anh']['name'];
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                $file_size = $data['hinh_anh']['size'];
                $file_tmp = $data['hinh_anh']['tmp_name'];

                if (!in_array($file_ext, $allowed)) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'File ảnh phải là JPG hoặc PNG']);
                    return;
                }

                if ($file_size > 2 * 1024 * 1024) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'message' => 'Kích thước file không được vượt quá 2MB']);
                    return;
                }

                $new_file_name = 'user_' . time() . '.' . $file_ext;
                $upload_path = __DIR__ . '/../img/' . $new_file_name;

                if (!move_uploaded_file($file_tmp, $upload_path)) {
                    http_response_code(500);
                    echo json_encode(['success' => false, 'message' => 'Lỗi khi lưu file ảnh']);
                    return;
                }

                $hinh_anh_path = '/img/' . $new_file_name;
            }

            $sql = "
                INSERT INTO nhan_vien (
                    ho_ten, gioi_tinh, ngay_sinh, can_cuoc_cong_dan, ngay_cap, noi_cap, que_quan,
                    email, so_dien_thoai, dia_chi, id_phong_ban, id_chuc_vu, loai_hop_dong,
                    ngay_vao_lam, trang_thai, luong_co_ban, hinh_anh
                ) VALUES (
                    :ho_ten, :gioi_tinh, :ngay_sinh, :can_cuoc_cong_dan, :ngay_cap, :noi_cap, :que_quan,
                    :email, :so_dien_thoai, :dia_chi, :id_phong_ban, :id_chuc_vu, :loai_hop_dong,
                    :ngay_vao_lam, :trang_thai, :luong_co_ban, :hinh_anh
                )";
            
            $stmt = $this->conn->prepare($sql);

            $stmt->bindParam(':ho_ten', $data['ho_ten']);
            $stmt->bindParam(':gioi_tinh', $data['gioi_tinh']);
            $stmt->bindParam(':ngay_sinh', $data['ngay_sinh']);
            $stmt->bindParam(':can_cuoc_cong_dan', $data['can_cuoc_cong_dan']);
            $stmt->bindParam(':ngay_cap', $data['ngay_cap']);
            $stmt->bindParam(':noi_cap', $data['noi_cap']);
            $stmt->bindParam(':que_quan', $data['que_quan']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':so_dien_thoai', $data['so_dien_thoai']);
            $stmt->bindParam(':dia_chi', $data['dia_chi']);
            $stmt->bindParam(':id_phong_ban', $id_phong_ban, PDO::PARAM_INT);
            $stmt->bindParam(':id_chuc_vu', $id_chuc_vu, PDO::PARAM_INT);
            $stmt->bindParam(':loai_hop_dong', $data['loai_hop_dong']);
            $stmt->bindParam(':ngay_vao_lam', $data['ngay_vao_lam']);
            $stmt->bindParam(':trang_thai', $data['trang_thai']);
            $stmt->bindParam(':luong_co_ban', $data['luong_co_ban'], PDO::PARAM_STR);
            $stmt->bindParam(':hinh_anh', $hinh_anh_path);

            $stmt->execute();

            echo json_encode(['success' => true, 'message' => 'Thêm nhân viên thành công']);
        } catch (PDOException $e) {
            error_log("Lỗi khi thêm nhân viên: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }
    
    public function getAllUsers() {
        try {
            $stmt = $this->conn->prepare("
                SELECT 
                    nv.id_nhan_vien, nv.ho_ten, nv.gioi_tinh, nv.ngay_sinh, nv.email, nv.so_dien_thoai,
                    nv.dia_chi, nv.can_cuoc_cong_dan, nv.ngay_cap, nv.noi_cap, nv.que_quan, nv.hinh_anh,
                    pb.ten_phong_ban, cv.ten_chuc_vu, nv.loai_hop_dong, nv.luong_co_ban,
                    nv.ngay_vao_lam, nv.ngay_nghi_viec, nv.trang_thai
                FROM nhan_vien nv
                LEFT JOIN phong_ban pb ON nv.id_phong_ban = pb.id_phong_ban
                LEFT JOIN chuc_vu cv ON nv.id_chuc_vu = cv.id_chuc_vu
            ");
            $stmt->execute();
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($users);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    public function getUserById($id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT 
                    nv.id_nhan_vien, nv.ho_ten, nv.gioi_tinh, nv.ngay_sinh, nv.email, nv.so_dien_thoai,
                    nv.dia_chi, nv.can_cuoc_cong_dan, nv.ngay_cap, nv.noi_cap, nv.que_quan, nv.hinh_anh,
                    pb.ten_phong_ban, cv.ten_chuc_vu, nv.loai_hop_dong, nv.luong_co_ban,
                    nv.ngay_vao_lam, nv.ngay_nghi_viec, nv.trang_thai
                FROM nhan_vien nv
                LEFT JOIN phong_ban pb ON nv.id_phong_ban = pb.id_phong_ban
                LEFT JOIN chuc_vu cv ON nv.id_chuc_vu = cv.id_chuc_vu
                WHERE nv.id_nhan_vien = :id
            ");
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                echo json_encode($user);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Nhân viên không tồn tại']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    public function deleteUser($id) {
        try {
            $stmt = $this->conn->prepare("SELECT hinh_anh FROM nhan_vien WHERE id_nhan_vien = :id");
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            $stmt = $this->conn->prepare("DELETE FROM nhan_vien WHERE id_nhan_vien = :id");
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                if ($user && $user['hinh_anh']) {
                    $file_path = __DIR__ . '/../' . $user['hinh_anh'];
                    if (file_exists($file_path)) {
                        unlink($file_path);
                    }
                }
                echo json_encode(['success' => true, 'message' => 'Xóa nhân viên thành công']);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Nhân viên không tồn tại']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    public function updateUser($id, $data) {
        try {
            $id_phong_ban = $this->getPhongBanId($data['ten_phong_ban']);
            $id_chuc_vu = $this->getChucVuId($data['ten_chuc_vu']);

            if (!$id_phong_ban || !$id_chuc_vu) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Phòng ban hoặc chức vụ không tồn tại']);
                return;
            }

            $sql = "
                UPDATE nhan_vien 
                SET 
                    ho_ten = :ho_ten,
                    gioi_tinh = :gioi_tinh,
                    ngay_sinh = :ngay_sinh,
                    email = :email,
                    so_dien_thoai = :so_dien_thoai,
                    dia_chi = :dia_chi,
                    can_cuoc_cong_dan = :can_cuoc_cong_dan,
                    ngay_cap = :ngay_cap,
                    noi_cap = :noi_cap,
                    que_quan = :que_quan,
                    id_phong_ban = :id_phong_ban,
                    id_chuc_vu = :id_chuc_vu,
                    loai_hop_dong = :loai_hop_dong,
                    luong_co_ban = :luong_co_ban,
                    ngay_vao_lam = :ngay_vao_lam,
                    ngay_nghi_viec = :ngay_nghi_viec,
                    trang_thai = :trang_thai
                WHERE id_nhan_vien = :id
            ";

            $stmt = $this->conn->prepare($sql);

            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->bindParam(':ho_ten', $data['ho_ten']);
            $stmt->bindParam(':gioi_tinh', $data['gioi_tinh']);
            $stmt->bindParam(':ngay_sinh', $data['ngay_sinh']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':so_dien_thoai', $data['so_dien_thoai']);
            $stmt->bindParam(':dia_chi', $data['dia_chi']);
            $stmt->bindParam(':can_cuoc_cong_dan', $data['can_cuoc_cong_dan']);
            $stmt->bindParam(':ngay_cap', $data['ngay_cap']);
            $stmt->bindParam(':noi_cap', $data['noi_cap']);
            $stmt->bindParam(':que_quan', $data['que_quan']);
            $stmt->bindParam(':id_phong_ban', $id_phong_ban, PDO::PARAM_INT);
            $stmt->bindParam(':id_chuc_vu', $id_chuc_vu, PDO::PARAM_INT);
            $stmt->bindParam(':loai_hop_dong', $data['loai_hop_dong']);
            $stmt->bindParam(':luong_co_ban', $data['luong_co_ban'], PDO::PARAM_STR);
            $stmt->bindParam(':ngay_vao_lam', $data['ngay_vao_lam']);
            $stmt->bindParam(':ngay_nghi_viec', $data['ngay_nghi_viec']);
            $stmt->bindParam(':trang_thai', $data['trang_thai']);

            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => true, 'message' => 'Cập nhật nhân viên thành công']);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Nhân viên không tồn tại hoặc không có thay đổi']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    public function getAllPhongBan() {
        try {
            $stmt = $this->conn->prepare("SELECT id_phong_ban, ten_phong_ban FROM phong_ban");
            $stmt->execute();
            $phong_ban = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($phong_ban);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

    public function getAllChucVu() {
        try {
            $stmt = $this->conn->prepare("SELECT id_chuc_vu, ten_chuc_vu FROM chuc_vu");
            $stmt->execute();
            $chuc_vu = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($chuc_vu);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi server: ' . $e->getMessage()]);
        }
    }

   public function importEmployeeFromCSV($data) {
        try {
            error_log("Starting importEmployeeFromCSV for employeeId: " . ($data['employeeId'] ?? 'null'));

            if (!isset($data['employeeId']) || empty($data['employeeId'])) {
                throw new Exception("ID nhân viên là bắt buộc.");
            }

            $requiredFields = ['ho_ten', 'gioi_tinh', 'ngay_sinh', 'so_dien_thoai', 'dia_chi', 'can_cuoc_cong_dan', 'ngay_cap', 'noi_cap', 'que_quan'];
            foreach ($requiredFields as $field) {
                if (!isset($data[$field]) || empty(trim($data[$field]))) {
                    throw new Exception("Trường '$field' là bắt buộc.");
                }
            }

            // Lấy thông tin hiện tại của nhân viên
            $stmt = $this->conn->prepare("
                SELECT email, id_phong_ban, id_chuc_vu 
                FROM nhan_vien 
                WHERE id_nhan_vien = :id
            ");
            $stmt->bindParam(':id', $data['employeeId'], PDO::PARAM_INT);
            $stmt->execute();
            $currentData = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$currentData) {
                throw new Exception("Nhân viên với ID {$data['employeeId']} không tồn tại.");
            }

            // Gán giá trị hiện tại nếu không có trong file CSV
            $data['email'] = !empty(trim($data['email'] ?? '')) ? $data['email'] : ($currentData['email'] ?? '');
            
            // Xử lý phòng ban
            $id_phong_ban = null;
            if (!empty(trim($data['ten_phong_ban'] ?? ''))) {
                $id_phong_ban = $this->getPhongBanId($data['ten_phong_ban']);
                if (!$id_phong_ban) {
                    throw new Exception("Phòng ban '{$data['ten_phong_ban']}' không tồn tại.");
                }
            } else {
                $id_phong_ban = $currentData['id_phong_ban'];
            }

            // Xử lý chức vụ
            $id_chuc_vu = null;
            if (!empty(trim($data['ten_chuc_vu'] ?? ''))) {
                $id_chuc_vu = $this->getChucVuId($data['ten_chuc_vu']);
                if (!$id_chuc_vu) {
                    throw new Exception("Chức vụ '{$data['ten_chuc_vu']}' không tồn tại.");
                }
            } else {
                $id_chuc_vu = $currentData['id_chuc_vu'];
            }

            // Kiểm tra hinh_anh
            if (!isset($data['hinh_anh'])) {
                $data['hinh_anh'] = '';
            }

            // Chuyển đổi định dạng ngày
            $ngay_sinh = DateTime::createFromFormat('Y-m-d', $data['ngay_sinh']);
            $ngay_cap = DateTime::createFromFormat('Y-m-d', $data['ngay_cap']);
            if ($ngay_sinh === false) {
                throw new Exception("Định dạng ngày không hợp lệ cho ngay_sinh: " . $data['ngay_sinh']);
            }
            if ($ngay_cap === false) {
                throw new Exception("Định dạng ngày không hợp lệ cho ngay_cap: " . $data['ngay_cap']);
            }

            $data['ngay_sinh'] = $ngay_sinh->format('Y-m-d');
            $data['ngay_cap'] = $ngay_cap->format('Y-m-d');

            // Gán giá trị mặc định cho các cột khác
            $data['loai_hop_dong'] = isset($data['loai_hop_dong']) ? $data['loai_hop_dong'] : 'Hợp đồng không xác định';
            $data['luong_co_ban'] = isset($data['luong_co_ban']) ? $data['luong_co_ban'] : '0';
            $data['ngay_vao_lam'] = isset($data['ngay_vao_lam']) ? $data['ngay_vao_lam'] : date('Y-m-d');
            $data['trang_thai'] = isset($data['trang_thai']) ? $data['trang_thai'] : 'Đang làm việc';

            $data['id_phong_ban'] = $id_phong_ban;
            $data['id_chuc_vu'] = $id_chuc_vu;

            error_log("Calling updateEmployeeFromCSV for employeeId: " . $data['employeeId']);
            $this->updateEmployeeFromCSV($data['employeeId'], $data);
        } catch (Exception $e) {
            error_log("Lỗi khi cập nhật nhân viên từ CSV: " . $e->getMessage());
            throw $e;
        }
    }

    public function updateEmployeeFromCSV($employeeId, $data) {
        try {
            error_log("Executing updateEmployeeFromCSV for employeeId: $employeeId");

            $sql = "
                UPDATE nhan_vien SET
                    ho_ten = :ho_ten,
                    gioi_tinh = :gioi_tinh,
                    ngay_sinh = :ngay_sinh,
                    so_dien_thoai = :so_dien_thoai,
                    dia_chi = :dia_chi,
                    can_cuoc_cong_dan = :can_cuoc_cong_dan,
                    ngay_cap = :ngay_cap,
                    noi_cap = :noi_cap,
                    que_quan = :que_quan,
                    hinh_anh = :hinh_anh,
                    email = :email,
                    id_phong_ban = :id_phong_ban,
                    id_chuc_vu = :id_chuc_vu,
                    loai_hop_dong = :loai_hop_dong,
                    ngay_vao_lam = :ngay_vao_lam,
                    trang_thai = :trang_thai,
                    luong_co_ban = :luong_co_ban
                WHERE id_nhan_vien = :id_nhan_vien
            ";

            $stmt = $this->conn->prepare($sql);
            $stmt->bindParam(':id_nhan_vien', $employeeId, PDO::PARAM_INT);
            $stmt->bindParam(':ho_ten', $data['ho_ten']);
            $stmt->bindParam(':gioi_tinh', $data['gioi_tinh']);
            $stmt->bindParam(':ngay_sinh', $data['ngay_sinh']);
            $stmt->bindParam(':so_dien_thoai', $data['so_dien_thoai']);
            $stmt->bindParam(':dia_chi', $data['dia_chi']);
            $stmt->bindParam(':can_cuoc_cong_dan', $data['can_cuoc_cong_dan']);
            $stmt->bindParam(':ngay_cap', $data['ngay_cap']);
            $stmt->bindParam(':noi_cap', $data['noi_cap']);
            $stmt->bindParam(':que_quan', $data['que_quan']);
            $stmt->bindParam(':hinh_anh', $data['hinh_anh']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':id_phong_ban', $data['id_phong_ban'], PDO::PARAM_INT);
            $stmt->bindParam(':id_chuc_vu', $data['id_chuc_vu'], PDO::PARAM_INT);
            $stmt->bindParam(':loai_hop_dong', $data['loai_hop_dong']);
            $stmt->bindParam(':ngay_vao_lam', $data['ngay_vao_lam']);
            $stmt->bindParam(':trang_thai', $data['trang_thai']);
            $stmt->bindParam(':luong_co_ban', $data['luong_co_ban'], PDO::PARAM_STR);

            $stmt->execute();

            if ($stmt->rowCount() === 0) {
                error_log("No rows updated for employeeId: $employeeId");
                throw new Exception("Không có thay đổi hoặc nhân viên không tồn tại.");
            }

            error_log("Successfully updated employeeId: $employeeId");
        } catch (PDOException $e) {
            error_log("Lỗi khi cập nhật nhân viên từ CSV: " . $e->getMessage());
            throw new Exception("Lỗi database: " . $e->getMessage());
        }
    }

    public function addEmployeeFromCSV($data) {
        try {
            error_log("Warning: addEmployeeFromCSV called with data: " . json_encode($data));
            throw new Exception("Hàm addEmployeeFromCSV không nên được gọi khi cập nhật nhân viên.");
        } catch (PDOException $e) {
            error_log("Lỗi khi thêm nhân viên từ CSV trong controller: " . $e->getMessage());
            throw new Exception("Lỗi database: " . $e->getMessage());
        }
    }
}
?>