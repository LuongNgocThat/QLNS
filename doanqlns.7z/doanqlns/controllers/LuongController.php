<?php
include_once(__DIR__ . '/../models/LuongModel.php');

class LuongController {
    private $luongModel;

    public function __construct() {
        $this->luongModel = new LuongModel();
    }

    public function getAllLuong() {
        $records = $this->luongModel->getAllLuong();
        echo json_encode($records);
    }
}
?>
