
<?php
include_once(__DIR__ . '/../models/LuongModel.php');

class LuongController {
    private $luongModel;

    public function __construct() {
        $this->luongModel = new LuongModel();
    }

    public function getAllLuong() {
        $month = isset($_GET['month']) ? (int)$_GET['month'] : date('m');
        $year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
        $records = $this->luongModel->getAllLuong($month, $year);
        header('Content-Type: application/json');
        echo json_encode($records);
    }

    public function updateLuongStatus($id_luong, $trang_thai) {
        $result = $this->luongModel->updateLuongStatus($id_luong, $trang_thai);
        header('Content-Type: application/json');
        echo json_encode($result);
    }

    public function updateLuongDetails($id_luong, $data) {
        $result = $this->luongModel->updateLuongDetails($id_luong, $data);
        header('Content-Type: application/json');
        echo json_encode($result);
    }
}
?>