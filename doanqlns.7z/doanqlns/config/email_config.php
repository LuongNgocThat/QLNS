<?php
define('SENDGRID_API_KEY', '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');
define('EMAIL_FROM', 'your-email@yourdomain.com');
define('EMAIL_FROM_NAME', 'HRM System');
?> 