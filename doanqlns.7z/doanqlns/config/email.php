<?php

return [
    'driver' => 'sendgrid',
    'from_email' => 'kingkai15032003@gmail.com',
    'from_name' => 'HRM - Ngọc Thật Lương',
    'reply_to' => 'ngocthach102017@gmail.com',
    'company' => [
        'name' => 'HRM',
        'address' => 'Đại học Công nghiệp Thực phẩm TP.HCM',
        'address2' => '140 Lê Trọng Tấn, Phường Tây Thạnh',
        'city' => 'TP.HCM',
        'state' => 'Hồ Chí Minh',
        'zip' => '700000',
        'country' => 'Vietnam'
    ],
    'sendgrid' => [
        'api_key' => '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',
        'account_id' => 'sgf24279e8cf9e5ae5bc33b3ee5ab74bed'
    ]
]; 