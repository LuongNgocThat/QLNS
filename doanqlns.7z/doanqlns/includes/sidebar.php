<div class="sidebar">
    <div class="sidebar-header">
        <h2><i class="fas fa-user-tie"></i> <span class="user-info"><?= htmlspecialchars($_SESSION['username']) ?></span></h2>
    </div>
    
    <?php if (isset($_SESSION['user_id'])): ?>
        <nav class="nav flex-column">
            <?php 
            // Kiểm tra xem người dùng có quyền quản trị không
            $is_admin = isset($_SESSION['quyen_them']) && $_SESSION['quyen_them'] && 
                       isset($_SESSION['quyen_sua']) && $_SESSION['quyen_sua'] && 
                       isset($_SESSION['quyen_xoa']) && $_SESSION['quyen_xoa'];
            
            // Kiểm tra xem người dùng có quyền quản lý không
            $is_manager = isset($_SESSION['quyen_them']) && $_SESSION['quyen_them'] && 
                         isset($_SESSION['quyen_sua']) && $_SESSION['quyen_sua'];
            
            // Nếu là admin hoặc manager, hiển thị menu quản lý
            if ($is_admin || $is_manager): 
            ?>
                <!-- Menu Trang chủ - Dành cho admin và manager -->
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'giaodien.php' ? 'active' : '' ?>" href="/doanqlns/giaodien.php">
                    <i class="fas fa-home"></i> <span>Trang chủ</span>
                </a>

                <!-- Menu quản lý - Chỉ hiển thị cho admin và manager -->
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : '' ?>" href="/doanqlns/views/users.php">
                    <i class="fas fa-users"></i> <span>Nhân sự</span>
                </a>
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'nghiphep.php' ? 'active' : '' ?>" href="/doanqlns/views/nghiphep.php">
                    <i class="fas fa-calendar-minus"></i> <span>Nghỉ phép</span>
                </a>
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'chamcong.php' ? 'active' : '' ?>" href="/doanqlns/views/chamcong.php">
                    <i class="fas fa-calendar-check"></i> <span>Chấm công</span>
                </a>
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'baohiem.php' ? 'active' : '' ?>" href="/doanqlns/views/baohiem.php">
                    <i class="fas fa-file-invoice-dollar"></i> <span>Bảo hiểm & Thuế</span>
                </a>
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'thuong.php' ? 'active' : '' ?>" href="/doanqlns/views/thuong.php">
                    <i class="fas fa-gift"></i> <span>Thưởng</span>
                </a>
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'luong.php' ? 'active' : '' ?>" href="/doanqlns/views/luong.php">
                    <i class="fas fa-coins"></i> <span>Lương</span>
                </a>
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'tuyendung.php' ? 'active' : '' ?>" href="/doanqlns/views/tuyendung.php">
                    <i class="fas fa-user-plus"></i> <span>Tuyển dụng</span>
                </a>
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'baocao.php' ? 'active' : '' ?>" href="/doanqlns/views/baocao.php">
                    <i class="fas fa-chart-line"></i> <span>Báo cáo quản trị/thống kê</span>
                </a>
            <?php else: ?>
                <!-- Menu Trang chủ - Dành cho nhân viên -->
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'giaodien.php' ? 'active' : '' ?>" href="/doanqlns/views/giaodien.php">
                    <i class="fas fa-home"></i> <span>Trang chủ</span>
                </a>

                <!-- Menu Cá nhân - Hiển thị cho nhân viên -->
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'hoso.php' ? 'active' : '' ?>" href="/doanqlns/views/hoso.php">
                    <i class="fas fa-user"></i> <span>Hồ sơ của tôi</span>
                </a>

                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'luongmy.php' ? 'active' : '' ?>" href="/doanqlns/views/luongmy.php">
                    <i class="fas fa-money-bill-wave"></i> <span>Lương của tôi</span>
                </a>

                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'nghiphepmy.php' ? 'active' : '' ?>" href="/doanqlns/views/nghiphepmy.php">
                    <i class="fas fa-calendar-alt"></i> <span>Nghỉ phép của tôi</span>
                </a>
            <?php endif; ?>

            <!-- Menu Cài đặt - Chỉ hiển thị cho admin -->
            <?php if ($is_admin): ?>
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'setting.php' ? 'active' : '' ?>" href="/doanqlns/views/setting.php">
                    <i class="fas fa-cog"></i> <span>Cài đặt</span>
                </a>
            <?php endif; ?>
        </nav>
        
        <div class="login-section">
            <a href="/doanqlns/views/logout.php" class="logout-btn" onclick="return confirmLogout()">
                <i class="fas fa-sign-out-alt"></i> <span>Đăng xuất</span>
            </a>
        </div>
    <?php else: ?>
        <div class="login-section">
            <a href="/doanqlns/views/login.php" class="login-btn">
                <i class="fas fa-sign-in-alt"></i> <span>Đăng nhập</span>
            </a>
        </div>
    <?php endif; ?>
</div>

<script>
function confirmLogout() {
    return confirm("Bạn có muốn đăng xuất không?");
}
</script>