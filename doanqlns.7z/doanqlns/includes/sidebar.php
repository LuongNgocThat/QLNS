<div class="sidebar">
    <div class="sidebar-header">
        <h2><i class="fas fa-user-tie"></i> <span>HRM Pro</span></h2>
    </div>
    <nav class="nav flex-column">
        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'giaodien.php' ? 'active' : ''; ?>" href="/doanqlns/giaodien.php">
            <i class="fas fa-home"></i>
            <span>Trang chủ</span>
        </a>
        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>" href="/doanqlns/views/users.php">
            <i class="fas fa-users"></i>
            <span>Nhân sự</span>
        </a>
        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'chamcong.php' ? 'active' : ''; ?>" href="/doanqlns/views/chamcong.php">
    <i class="fas fa-calendar-check"></i>
    <span>Chấm công</span>
</a>

<a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'nghiphep.php' ? 'active' : ''; ?>" href="/doanqlns/views/nghiphep.php">
    <i class="fas fa-calendar-minus"></i>
    <span>Nghỉ phép</span>
</a>

        <a class="nav-link  <?php echo basename($_SERVER['PHP_SELF']) == 'luong.php' ? 'active' : ''; ?>" href="/doanqlns/views/luong.php">
            <i class="fas fa-coins"></i>
            <span>Lương thưởng</span>
        </a>
        <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'baohiem.php' ? 'active' : ''; ?>" href="/doanqlns/views/baohiem.php">
            <i class="fas fa-file-invoice-dollar"></i>
            <span>Bảo hiểm & Thuế</span>
        </a>
        <a class="nav-link" href="#">
            <i class="fas fa-user-plus"></i>
            <span>Tuyển dụng</span>
        </a>
        <a class="nav-link" href="#">
            <i class="fas fa-chart-line"></i>
            <span>Báo cáo</span>
        </a>
        <a class="nav-link" href="#">
            <i class="fas fa-cog"></i>
            <span>Cài đặt</span>
        </a>
    </nav>
    <div class="login-section">
        <a href="#">
            <i class="fas fa-sign-out-alt"></i>
            <span>Đăng xuất</span>
        </a>
    </div>
</div>