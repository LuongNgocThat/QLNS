<?php
session_start();
require_once __DIR__ . '/../config/Database.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    header("Location: /doanqlns/views/login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();
$query = "SELECT quyen_them, quyen_sua, quyen_xoa FROM nguoi_dung WHERE id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    $_SESSION['quyen_them'] = $user['quyen_them'];
    $_SESSION['quyen_sua'] = $user['quyen_sua'];
    $_SESSION['quyen_xoa'] = $user['quyen_xoa'];
} else {
    header("Location: /doanqlns/views/logout.php");
    exit();
}
?>