-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th4 21, 2025 lúc 10:13 AM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `doanqlns`
--

DELIMITER $$
--
-- Thủ tục
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_DuyetNghiPhep` (IN `p_id_nghi_phep` INT, IN `p_trang_thai` VARCHAR(20), IN `p_id_nguoi_duyet` INT, IN `p_vai_tro_nguoi_duyet` ENUM('Admin','Quản lý','Nhân viên'))   BEGIN
    DECLARE v_id_nhan_vien INT;
    DECLARE v_ngay_bat_dau DATE;
    DECLARE v_ngay_ket_thuc DATE;
    DECLARE v_loai_nghi VARCHAR(20);
    DECLARE v_thang VARCHAR(7);
    
    -- Kiểm tra quyền duyệt
    IF p_vai_tro_nguoi_duyet NOT IN ('Admin', 'Quản lý') THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Chỉ Admin hoặc Quản lý được phép duyệt đơn nghỉ phép';
    END IF;
    
    -- Lấy thông tin đơn nghỉ phép
    SELECT id_nhan_vien, ngay_bat_dau, ngay_ket_thuc, loai_nghi
    INTO v_id_nhan_vien, v_ngay_bat_dau, v_ngay_ket_thuc, v_loai_nghi
    FROM nghi_phep
    WHERE id_nghi_phep = p_id_nghi_phep;
    
    -- Cập nhật trạng thái đơn
    UPDATE nghi_phep
    SET trang_thai = p_trang_thai,
        id_nguoi_duyet = p_id_nguoi_duyet,
        ngay_duyet = NOW()
    WHERE id_nghi_phep = p_id_nghi_phep;
    
    -- Nếu đơn được duyệt, cập nhật bảng chấm công
    IF p_trang_thai = 'Đã duyệt' THEN
        -- Lặp qua từng ngày trong khoảng thời gian nghỉ
        WHILE v_ngay_bat_dau <= v_ngay_ket_thuc DO
            -- Kiểm tra nếu ngày đó là ngày làm việc (không phải cuối tuần)
            IF DAYOFWEEK(v_ngay_bat_dau) NOT IN (1, 7) THEN
                -- Chèn hoặc cập nhật bảng chấm công
                INSERT INTO cham_cong (id_nhan_vien, ngay_lam_viec, trang_thai)
                VALUES (v_id_nhan_vien, v_ngay_bat_dau, 
                        CASE WHEN v_loai_nghi = 'Nghỉ không lương' THEN 'Nghỉ không phép'
                             ELSE 'Nghỉ có phép' END)
                ON DUPLICATE KEY UPDATE 
                    trang_thai = CASE WHEN v_loai_nghi = 'Nghỉ không lương' THEN 'Nghỉ không phép'
                                      ELSE 'Nghỉ có phép' END;
            END IF;
            
            SET v_ngay_bat_dau = DATE_ADD(v_ngay_bat_dau, INTERVAL 1 DAY);
        END WHILE;
        
        -- Cập nhật lại tổng hợp công cho tháng có đơn nghỉ
        SET v_thang = DATE_FORMAT(v_ngay_bat_dau, '%Y-%m');
        CALL sp_TinhCongLamViec(v_id_nhan_vien, v_thang);
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_TinhBaoHiemThueTNCN` (IN `p_id_nhan_vien` INT, IN `p_thang` VARCHAR(7))   BEGIN
    DECLARE v_bhxh DECIMAL(12,2);
    DECLARE v_bhyt DECIMAL(12,2);
    DECLARE v_bhtn DECIMAL(12,2);
    DECLARE v_thue_tncn DECIMAL(12,2);
    DECLARE v_luong_dong_bh DECIMAL(12,2);
    DECLARE v_so_nguoi_phu_thuoc INT;
    DECLARE v_giam_tru_ban_than DECIMAL(12,2) DEFAULT 11000000; -- 11 triệu
    DECLARE v_giam_tru_nguoi_phu_thuoc DECIMAL(12,2) DEFAULT 4400000; -- 4.4 triệu/người
    DECLARE v_luong_co_ban DECIMAL(12,2);
    DECLARE v_thu_nhap_tinh_thue DECIMAL(12,2);

    -- Lấy lương cơ bản của nhân viên
    SELECT luong_co_ban INTO v_luong_co_ban
    FROM nhan_vien
    WHERE id_nhan_vien = p_id_nhan_vien;
    
    -- Mức đóng bảo hiểm (8% BHXH, 1.5% BHYT, 1% BHTN)
    -- Giả định lương đóng BH là lương cơ bản, không vượt quá 20 lần lương tối thiểu
    SET v_luong_dong_bh = LEAST(v_luong_co_ban, 46800000); -- Giả sử mức tối đa là 46.8 triệu
    
    -- Tính các khoản bảo hiểm
    SET v_bhxh = v_luong_dong_bh * 0.08; -- 8% BHXH
    SET v_bhyt = v_luong_dong_bh * 0.015; -- 1.5% BHYT
    SET v_bhtn = v_luong_dong_bh * 0.01; -- 1% BHTN

    -- Tính thu nhập tính thuế (lương cơ bản - bảo hiểm)
    SET v_thu_nhap_tinh_thue = v_luong_co_ban - (v_bhxh + v_bhyt + v_bhtn) - v_giam_tru_ban_than;
    
    -- Tính thuế TNCN
    SET v_thue_tncn = v_thu_nhap_tinh_thue * 0.05; -- Giả sử thuế suất là 5%

    -- Trả về kết quả (bạn có thể trả về kết quả hoặc cập nhật vào bảng, ví dụ ở đây trả về các khoản bảo hiểm và thuế)
    SELECT v_bhxh AS BHXH, v_bhyt AS BHYT, v_bhtn AS BHTN, v_thue_tncn AS ThueTNCN;


END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_TinhCongLamViec` (IN `p_id_nhan_vien` INT, IN `p_thang` VARCHAR(7))   BEGIN
    DECLARE v_ngay_lam_viec INT;
    DECLARE v_ngay_nghi_le INT;
    DECLARE v_ngay_nghi_phep INT;
    DECLARE v_cong_chinh DECIMAL(5,2);
    DECLARE v_lam_them DECIMAL(5,2);
    DECLARE v_ngay_dau_thang DATE;
    DECLARE v_ngay_cuoi_thang DATE;
    
    SET v_ngay_dau_thang = STR_TO_DATE(CONCAT(p_thang, '-01'), '%Y-%m-%d');
    SET v_ngay_cuoi_thang = LAST_DAY(v_ngay_dau_thang);
    
    -- Tính số ngày làm việc (có chấm công)
    SELECT COUNT(*) INTO v_ngay_lam_viec
    FROM cham_cong
    WHERE id_nhan_vien = p_id_nhan_vien
    AND ngay_lam_viec BETWEEN v_ngay_dau_thang AND v_ngay_cuoi_thang
    AND trang_thai IN ('Đúng giờ', 'Đi trễ', 'Làm thêm');
    
    -- Tính số ngày nghỉ lễ
    SELECT COUNT(DISTINCT ngay_lam_viec) INTO v_ngay_nghi_le
    FROM cham_cong cc
    JOIN ngay_le nl ON cc.ngay_lam_viec BETWEEN nl.ngay_bat_dau AND nl.ngay_ket_thuc
    WHERE cc.id_nhan_vien = p_id_nhan_vien
    AND cc.ngay_lam_viec BETWEEN v_ngay_dau_thang AND v_ngay_cuoi_thang;
    
    -- Tính số ngày nghỉ phép được duyệt
    SELECT SUM(DATEDIFF(LEAST(np.ngay_ket_thuc, v_ngay_cuoi_thang), 
                       GREATEST(np.ngay_bat_dau, v_ngay_dau_thang)) + 1)
    INTO v_ngay_nghi_phep
    FROM nghi_phep np
    WHERE np.id_nhan_vien = p_id_nhan_vien
    AND np.trang_thai = 'Đã duyệt'
    AND np.loai_nghi = 'Nghỉ phép năm'
    AND ((np.ngay_bat_dau BETWEEN v_ngay_dau_thang AND v_ngay_cuoi_thang)
    OR (np.ngay_ket_thuc BETWEEN v_ngay_dau_thang AND v_ngay_cuoi_thang));
    
    -- Tính công chính (mỗi ngày làm việc đúng giờ là 1 công)
    SELECT COUNT(*) INTO v_cong_chinh
    FROM cham_cong
    WHERE id_nhan_vien = p_id_nhan_vien
    AND ngay_lam_viec BETWEEN v_ngay_dau_thang AND v_ngay_cuoi_thang
    AND trang_thai = 'Đúng giờ';
    
    -- Tính công làm thêm (mỗi giờ làm thêm là 0.125 công)
    SELECT SUM(TIME_TO_SEC(TIMEDIFF(gio_ra, gio_vao)) - 28800)/3600 * 0.125 INTO v_lam_them
    FROM cham_cong
    WHERE id_nhan_vien = p_id_nhan_vien
    AND ngay_lam_viec BETWEEN v_ngay_dau_thang AND v_ngay_cuoi_thang
    AND TIME_TO_SEC(TIMEDIFF(gio_ra, gio_vao)) > 28800; -- Làm hơn 8 tiếng
    
    -- Cập nhật hoặc chèn vào bảng tổng hợp công
    INSERT INTO tong_hop_cong_thang (id_nhan_vien, thang, tong_cong, cong_chinh, lam_them, ngay_lam_viec, ngay_nghi_le, ngay_nghi_phep)
    VALUES (p_id_nhan_vien, p_thang, v_cong_chinh + v_lam_them, v_cong_chinh, v_lam_them, v_ngay_lam_viec, v_ngay_nghi_le, v_ngay_nghi_phep)
    ON DUPLICATE KEY UPDATE
        tong_cong = v_cong_chinh + v_lam_them,
        cong_chinh = v_cong_chinh,
        lam_them = v_lam_them,
        ngay_lam_viec = v_ngay_lam_viec,
        ngay_nghi_le = v_ngay_nghi_le,
        ngay_nghi_phep = v_ngay_nghi_phep;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_TinhLuongThang` (IN `p_id_nhan_vien` INT, IN `p_thang` VARCHAR(7))   BEGIN
    DECLARE v_luong_co_ban DECIMAL(12,2);
    DECLARE v_so_ngay_cong INT;
    DECLARE v_tien_thuong DECIMAL(12,2);
    DECLARE v_luong_theo_cong DECIMAL(12,2);
    DECLARE v_luong_thuc_nhan DECIMAL(12,2);
    DECLARE v_tong_khoan_tru DECIMAL(12,2);
    DECLARE v_cong_chinh DECIMAL(5,2);
    DECLARE v_lam_them DECIMAL(5,2);
    DECLARE v_phu_cap_chuc_vu DECIMAL(12,2);
    DECLARE v_ngay_cong_chuan INT DEFAULT 22;
    
    -- Lấy lương cơ bản và phụ cấp chức vụ
    SELECT nv.luong_co_ban, IFNULL(cv.phu_cap, 0) INTO v_luong_co_ban, v_phu_cap_chuc_vu
    FROM nhan_vien nv
    LEFT JOIN chuc_vu cv ON nv.id_chuc_vu = cv.id_chuc_vu
    WHERE nv.id_nhan_vien = p_id_nhan_vien;
    
    -- Lấy số ngày công và công làm thêm
    SELECT cong_chinh, lam_them INTO v_cong_chinh, v_lam_them
    FROM tong_hop_cong_thang
    WHERE id_nhan_vien = p_id_nhan_vien AND thang = p_thang;
    
    -- Tính số ngày công
    SET v_so_ngay_cong = v_cong_chinh;
    
    -- Tính lương theo công (lương cơ bản / 22 * số ngày công thực tế)
    SET v_luong_theo_cong = v_luong_co_ban / v_ngay_cong_chuan * v_cong_chinh;
    
    -- Tính tiền thưởng (thưởng 10% lương nếu làm đủ công, 5% nếu làm từ 18-21 ngày)
    IF v_cong_chinh >= v_ngay_cong_chuan THEN
        SET v_tien_thuong = v_luong_co_ban * 0.1;
    ELSEIF v_cong_chinh >= 18 THEN
        SET v_tien_thuong = v_luong_co_ban * 0.05;
    ELSE
        SET v_tien_thuong = 0;
    END IF;
    
    -- Lấy tổng các khoản trừ (BH và thuế)
    SELECT tong_khoan_tru INTO v_tong_khoan_tru
    FROM bao_hiem_thue_tncn
    WHERE id_nhan_vien = p_id_nhan_vien AND thang = p_thang;
    
    -- Tính lương thực nhận
    SET v_luong_thuc_nhan = v_luong_theo_cong + v_phu_cap_chuc_vu + 
                           (v_lam_them * v_luong_co_ban / v_ngay_cong_chuan / 8) + 
                           v_tien_thuong - IFNULL(v_tong_khoan_tru, 0);
    
    -- Cập nhật hoặc chèn vào bảng lương
    INSERT INTO luong (id_nhan_vien, thang, so_ngay_cong, luong_co_ban, phu_cap_chuc_vu, 
                      luong_lam_them, tien_thuong, cac_khoan_tru, luong_thuc_nhan, ngay_cham_cong)
    VALUES (p_id_nhan_vien, p_thang, v_so_ngay_cong, v_luong_co_ban, v_phu_cap_chuc_vu,
            (v_lam_them * v_luong_co_ban / v_ngay_cong_chuan / 8), v_tien_thuong, 
            IFNULL(v_tong_khoan_tru, 0), v_luong_thuc_nhan, CURDATE())
    ON DUPLICATE KEY UPDATE
        so_ngay_cong = v_so_ngay_cong,
        luong_co_ban = v_luong_co_ban,
        phu_cap_chuc_vu = v_phu_cap_chuc_vu,
        luong_lam_them = (v_lam_them * v_luong_co_ban / v_ngay_cong_chuan / 8),
        tien_thuong = v_tien_thuong,
        cac_khoan_tru = IFNULL(v_tong_khoan_tru, 0),
        luong_thuc_nhan = v_luong_thuc_nhan,
        ngay_cham_cong = CURDATE();
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_TinhLuongToanCongTy` (IN `p_thang` VARCHAR(7))   BEGIN
    DECLARE v_done INT DEFAULT FALSE;
    DECLARE v_id_nhan_vien INT;
    DECLARE v_luong_co_ban DECIMAL(12,2);
    
    -- Khai báo cursor để lặp qua tất cả nhân viên đang làm việc
    DECLARE cur_nhan_vien CURSOR FOR 
        SELECT id_nhan_vien, luong_co_ban 
        FROM nhan_vien 
        WHERE trang_thai = 'Đang làm việc';
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;
    
    OPEN cur_nhan_vien;
    
    read_loop: LOOP
        FETCH cur_nhan_vien INTO v_id_nhan_vien, v_luong_co_ban;
        IF v_done THEN
            LEAVE read_loop;
        END IF;
        
        -- Tính tổng hợp công tháng
        CALL sp_TinhCongLamViec(v_id_nhan_vien, p_thang);
        
        -- Tính bảo hiểm và thuế
        CALL sp_TinhBaoHiemThueTNCN(v_id_nhan_vien, p_thang);
        
        -- Tính lương
        CALL sp_TinhLuongThang(v_id_nhan_vien, p_thang);
    END LOOP;
    
    CLOSE cur_nhan_vien;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bao_hiem_thue_tncn`
--

CREATE TABLE `bao_hiem_thue_tncn` (
  `id` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `thang` varchar(7) NOT NULL,
  `bhxh` decimal(12,2) NOT NULL DEFAULT 0.00,
  `bhyt` decimal(12,2) NOT NULL DEFAULT 0.00,
  `bhtn` decimal(12,2) NOT NULL DEFAULT 0.00,
  `thue_tncn` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tong_khoan_tru` decimal(12,2) GENERATED ALWAYS AS (`bhxh` + `bhyt` + `bhtn` + `thue_tncn`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `bao_hiem_thue_tncn`
--

INSERT INTO `bao_hiem_thue_tncn` (`id`, `id_nhan_vien`, `thang`, `bhxh`, `bhyt`, `bhtn`, `thue_tncn`) VALUES
(1, 1, '2024-04', 1500000.00, 750000.00, 150000.00, 2000000.00),
(2, 2, '2024-04', 1200000.00, 600000.00, 120000.00, 1500000.00),
(3, 3, '2024-04', 1000000.00, 500000.00, 100000.00, 1000000.00),
(4, 4, '2024-04', 500000.00, 250000.00, 50000.00, 0.00),
(5, 5, '2024-04', 1300000.00, 650000.00, 130000.00, 1800000.00),
(6, 6, '2024-04', 1400000.00, 700000.00, 140000.00, 1900000.00),
(7, 7, '2024-04', 1100000.00, 550000.00, 110000.00, 1300000.00),
(8, 8, '2024-04', 900000.00, 450000.00, 90000.00, 800000.00),
(9, 9, '2024-04', 950000.00, 475000.00, 95000.00, 850000.00),
(10, 10, '2024-04', 1250000.00, 625000.00, 125000.00, 1600000.00),
(11, 11, '2024-04', 1050000.00, 525000.00, 105000.00, 1200000.00),
(12, 12, '2024-04', 1150000.00, 575000.00, 115000.00, 1400000.00),
(13, 13, '2024-04', 1300000.00, 650000.00, 130000.00, 1750000.00),
(14, 14, '2024-04', 1400000.00, 700000.00, 140000.00, 1900000.00),
(15, 15, '2024-04', 1000000.00, 500000.00, 100000.00, 1000000.00),
(16, 16, '2024-04', 1100000.00, 550000.00, 110000.00, 1200000.00),
(17, 17, '2024-04', 1200000.00, 600000.00, 120000.00, 1400000.00),
(18, 18, '2024-04', 1250000.00, 625000.00, 125000.00, 1600000.00),
(19, 19, '2024-04', 1300000.00, 650000.00, 130000.00, 1700000.00),
(20, 20, '2024-04', 900000.00, 450000.00, 90000.00, 700000.00);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `ca_lam_viec`
--

CREATE TABLE `ca_lam_viec` (
  `id_ca` int(11) NOT NULL,
  `ten_ca` varchar(100) NOT NULL,
  `gio_bat_dau` time NOT NULL,
  `gio_ket_thuc` time NOT NULL,
  `mo_ta` varchar(255) DEFAULT NULL,
  `he_so` decimal(3,2) DEFAULT 1.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `ca_lam_viec`
--

INSERT INTO `ca_lam_viec` (`id_ca`, `ten_ca`, `gio_bat_dau`, `gio_ket_thuc`, `mo_ta`, `he_so`) VALUES
(1, 'Ca sáng', '08:00:00', '12:00:00', 'Làm việc buổi sáng', 1.00),
(2, 'Ca chiều', '13:00:00', '17:00:00', 'Làm việc buổi chiều', 1.00),
(3, 'Ca tối', '18:00:00', '22:00:00', 'Làm việc buổi tối', 1.50);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cham_cong`
--

CREATE TABLE `cham_cong` (
  `id_cham_cong` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `ngay_lam_viec` date NOT NULL,
  `gio_vao` time DEFAULT NULL,
  `gio_ra` time DEFAULT NULL,
  `trang_thai` enum('Đúng giờ','Đi trễ','Có phép','Không phép') DEFAULT NULL,
  `ghi_chu` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `cham_cong`
--

INSERT INTO `cham_cong` (`id_cham_cong`, `id_nhan_vien`, `ngay_lam_viec`, `gio_vao`, `gio_ra`, `trang_thai`, `ghi_chu`) VALUES
(3, 1, '2025-04-01', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(4, 1, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(5, 1, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(6, 1, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(7, 1, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(8, 1, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(9, 1, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(10, 1, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(11, 1, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(12, 1, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(13, 1, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(14, 1, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(15, 1, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(16, 1, '2025-04-14', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(17, 1, '2025-04-15', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(20, 1, '2025-04-27', '00:00:00', '00:00:00', 'Không phép', NULL),
(24, 2, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(25, 3, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(26, 3, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(27, 1, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(28, 3, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(29, 2, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(30, 2, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(31, 2, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(32, 3, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(33, 4, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(34, 4, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(35, 4, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(36, 4, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(37, 5, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(38, 5, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(39, 5, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(40, 6, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(42, 6, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(43, 6, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(44, 7, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(45, 7, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(46, 5, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(47, 7, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(48, 7, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(50, 8, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(52, 9, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(54, 10, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(55, 9, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(56, 10, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(57, 10, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(58, 8, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(59, 9, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(60, 11, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(61, 10, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(62, 11, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(63, 11, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(64, 11, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(65, 12, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(67, 12, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(68, 13, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(70, 13, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(71, 13, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(72, 12, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(73, 14, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(75, 14, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(76, 15, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(77, 14, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(80, 15, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(81, 16, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(82, 17, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(83, 16, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(84, 17, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(85, 16, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(86, 17, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(87, 17, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(88, 18, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(89, 18, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(90, 18, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(91, 19, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(92, 19, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(93, 19, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(94, 20, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(95, 16, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(96, 19, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(97, 18, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(98, 20, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(99, 20, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(100, 20, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(102, 6, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(103, 8, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(104, 12, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(105, 13, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(106, 8, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(107, 14, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(108, 15, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(109, 9, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(110, 15, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(111, 2, '2025-04-01', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(112, 3, '2025-04-01', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(113, 4, '2025-04-01', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(114, 5, '2025-04-01', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(115, 6, '2025-04-01', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(116, 7, '2025-04-01', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(117, 8, '2025-04-01', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(118, 9, '2025-04-01', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(119, 10, '2025-04-01', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(120, 11, '2025-04-01', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(121, 12, '2025-04-01', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(122, 13, '2025-04-01', '00:00:00', '00:00:00', 'Có phép', NULL),
(123, 14, '2025-04-01', '00:00:00', '00:00:00', 'Có phép', NULL),
(124, 15, '2025-04-01', '00:00:00', '00:00:00', 'Có phép', NULL),
(125, 16, '2025-04-01', '00:00:00', '00:00:00', 'Có phép', NULL),
(126, 17, '2025-04-01', '00:00:00', '00:00:00', 'Có phép', NULL),
(127, 18, '2025-04-01', '00:00:00', '00:00:00', 'Có phép', NULL),
(128, 19, '2025-04-01', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(129, 20, '2025-04-01', '00:00:00', '00:00:00', 'Không phép', NULL),
(130, 20, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(131, 20, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(132, 19, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(133, 19, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(134, 18, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(135, 18, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(136, 17, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(137, 17, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(138, 16, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(139, 16, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(140, 15, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(141, 15, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(142, 14, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(143, 14, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(144, 13, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(145, 13, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(146, 12, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(147, 12, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(148, 11, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(149, 11, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(150, 10, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(151, 10, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(152, 9, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(153, 9, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(154, 8, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(155, 2, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(156, 3, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(157, 4, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(158, 5, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(159, 6, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(160, 7, '2025-04-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(161, 2, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(162, 3, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(163, 4, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(164, 5, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(165, 6, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(166, 7, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(167, 8, '2025-04-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(168, 2, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(169, 3, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(170, 4, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(171, 5, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(172, 6, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(173, 7, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(174, 8, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(175, 9, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(176, 10, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(177, 11, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(178, 12, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(179, 13, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(180, 14, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(181, 15, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(182, 16, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(183, 17, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(184, 18, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(185, 19, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(186, 20, '2025-04-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(187, 20, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(188, 19, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(189, 18, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(190, 17, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(191, 16, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(192, 15, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(193, 14, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(194, 13, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(195, 12, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(196, 11, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(197, 2, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(198, 3, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(199, 4, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(200, 5, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(201, 6, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(202, 7, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(203, 8, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(204, 9, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(205, 10, '2025-04-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(206, 2, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(207, 3, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(208, 4, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(209, 5, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(210, 6, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(211, 7, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(212, 8, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(213, 9, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(214, 2, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(215, 3, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(216, 4, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(217, 5, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(218, 6, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(219, 7, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(220, 8, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(221, 9, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(222, 2, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(223, 3, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(224, 4, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(225, 5, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(226, 6, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(227, 7, '2025-04-09', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(228, 8, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(229, 9, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(230, 10, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(231, 10, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(232, 10, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(233, 11, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(234, 12, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(235, 12, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(236, 13, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(237, 14, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(238, 14, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(239, 14, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(240, 13, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(241, 13, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(242, 12, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(243, 11, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(244, 11, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(245, 15, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(246, 15, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(247, 15, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(248, 16, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(249, 16, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(250, 16, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(251, 17, '2025-04-07', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(252, 18, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(253, 19, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(254, 20, '2025-04-07', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(255, 20, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(256, 19, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(257, 18, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(258, 17, '2025-04-08', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(259, 17, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(260, 18, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(261, 19, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(262, 20, '2025-04-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(263, 2, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(264, 3, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(265, 4, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(266, 3, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(267, 2, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(268, 4, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(269, 5, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(270, 6, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(271, 7, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(272, 8, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(273, 7, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(274, 6, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(275, 2, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(276, 3, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(277, 4, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(278, 5, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(279, 6, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(280, 7, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(281, 8, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(282, 8, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(283, 9, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(284, 10, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(285, 11, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(286, 12, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(287, 13, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(288, 14, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(289, 15, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(290, 16, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(291, 17, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(292, 18, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(293, 19, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(294, 20, '2025-04-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(295, 9, '2025-04-11', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(296, 10, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(297, 11, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(298, 12, '2025-04-11', '00:00:00', '00:00:00', 'Không phép', NULL),
(299, 13, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(300, 14, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(301, 15, '2025-04-11', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(302, 16, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(303, 17, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(304, 18, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(305, 19, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(306, 20, '2025-04-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(307, 20, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(308, 19, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(309, 18, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(310, 17, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(311, 16, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(312, 15, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(313, 14, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(314, 13, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(315, 12, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(316, 9, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(317, 10, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(318, 11, '2025-04-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(319, 2, '2025-04-14', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(320, 3, '2025-04-14', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(321, 4, '2025-04-14', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(322, 5, '2025-04-14', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(323, 6, '2025-04-14', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(324, 7, '2025-04-14', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(325, 8, '2025-04-14', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(326, 9, '2025-04-14', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(327, 1, '2025-01-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(329, 1, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(330, 1, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(331, 2, '2025-01-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(333, 2, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(334, 3, '2025-01-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(335, 2, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(336, 3, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(337, 3, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(338, 3, '2025-01-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(339, 4, '2025-01-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(340, 4, '2025-01-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(341, 4, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(342, 5, '2025-01-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(343, 5, '2025-01-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(344, 5, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(345, 5, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(346, 4, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(347, 6, '2025-01-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(349, 6, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(350, 7, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(352, 8, '2025-01-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(353, 6, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(356, 8, '2025-01-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(357, 9, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(358, 8, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(359, 8, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(362, 10, '2025-01-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(363, 9, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(365, 11, '2025-01-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(368, 11, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(370, 12, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(371, 11, '2025-01-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(372, 11, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(374, 12, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(375, 13, '2025-01-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(377, 13, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(378, 14, '2025-01-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(381, 14, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(382, 15, '2025-01-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(383, 13, '2025-01-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(384, 16, '2025-01-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(385, 16, '2025-01-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(386, 15, '2025-01-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(387, 16, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(388, 16, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(389, 15, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(390, 15, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(391, 17, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(392, 18, '2025-01-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(395, 18, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(397, 19, '2025-01-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(398, 17, '2025-01-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(399, 18, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(400, 19, '2025-01-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(401, 17, '2025-01-12', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(402, 19, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(403, 20, '2025-01-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(406, 20, '2025-01-26', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(407, 1, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(408, 2, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(409, 3, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(410, 4, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(411, 5, '2025-04-19', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(412, 6, '2025-04-19', '00:00:00', '00:00:00', 'Có phép', NULL),
(413, 7, '2025-04-19', '00:00:00', '00:00:00', 'Không phép', NULL),
(414, 8, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(415, 9, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(416, 10, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(417, 11, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(418, 12, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(419, 13, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(420, 14, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(421, 15, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(422, 16, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(423, 17, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(424, 18, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(425, 19, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(426, 20, '2025-04-19', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(427, 20, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(428, 19, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(429, 18, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(430, 17, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(431, 20, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(432, 19, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(433, 18, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(434, 17, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(435, 16, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(436, 16, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(437, 15, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(438, 15, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(439, 14, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(440, 14, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(441, 13, '2025-04-18', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(442, 13, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(443, 12, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(444, 11, '2025-04-17', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(445, 11, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(446, 12, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(447, 1, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(448, 1, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(449, 2, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(450, 2, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(451, 3, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(452, 3, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(453, 4, '2025-04-17', '00:00:00', '00:00:00', 'Không phép', NULL),
(454, 4, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(455, 5, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(456, 5, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(457, 6, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(458, 6, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(459, 7, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(460, 8, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(461, 9, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(462, 10, '2025-04-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(463, 10, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(464, 9, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(465, 8, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(466, 7, '2025-04-17', '08:00:00', '17:00:00', 'Đúng giờ', NULL);

--
-- Bẫy `cham_cong`
--
DELIMITER $$
CREATE TRIGGER `trg_cham_cong_insert` AFTER INSERT ON `cham_cong` FOR EACH ROW BEGIN
    DECLARE v_gio_vao_chuan TIME;
    DECLARE v_gio_ra_chuan TIME;
    DECLARE v_trang_thai VARCHAR(20);
    
    -- Lấy thông tin ca làm việc của nhân viên trong ngày
    SELECT clv.gio_bat_dau, clv.gio_ket_thuc INTO v_gio_vao_chuan, v_gio_ra_chuan
    FROM phan_ca pc
    JOIN ca_lam_viec clv ON pc.id_ca = clv.id_ca
    WHERE pc.id_nhan_vien = NEW.id_nhan_vien
    AND pc.ngay = NEW.ngay_lam_viec;
    
    -- Nếu có phân ca thì kiểm tra trạng thái
    IF v_gio_vao_chuan IS NOT NULL THEN
        -- Kiểm tra đi trễ
        IF NEW.gio_vao > v_gio_vao_chuan THEN
            SET v_trang_thai = 'Đi trễ';
        -- Kiểm tra về sớm
        ELSEIF NEW.gio_ra < v_gio_ra_chuan THEN
            SET v_trang_thai = 'Về sớm';
        -- Kiểm tra làm thêm
        ELSEIF TIME_TO_SEC(TIMEDIFF(NEW.gio_ra, NEW.gio_vao)) > TIME_TO_SEC(TIMEDIFF(v_gio_ra_chuan, v_gio_vao_chuan)) THEN
            SET v_trang_thai = 'Làm thêm';
        ELSE
            SET v_trang_thai = 'Đúng giờ';
        END IF;
        
        -- Cập nhật trạng thái
        UPDATE cham_cong
        SET trang_thai = v_trang_thai
        WHERE id_cham_cong = NEW.id_cham_cong;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chuc_vu`
--

CREATE TABLE `chuc_vu` (
  `id_chuc_vu` int(11) NOT NULL,
  `ten_chuc_vu` varchar(100) NOT NULL,
  `mo_ta` text DEFAULT NULL,
  `phu_cap` decimal(12,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `chuc_vu`
--

INSERT INTO `chuc_vu` (`id_chuc_vu`, `ten_chuc_vu`, `mo_ta`, `phu_cap`) VALUES
(1, 'Trưởng Phòng', 'Lãnh đạo cao cấp', 5000000.00),
(2, 'Phó Trưởng phòng', 'Lãnh đạo các phòng ban', 3000000.00),
(3, 'Nhân viên', 'Nhân viên làm việc theo yêu cầu', 2000000.00),
(4, 'Thực tập sinh', 'Học hỏi và hỗ trợ công việc', 1000000.00);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `luong`
--

CREATE TABLE `luong` (
  `id_luong` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `thang` varchar(7) NOT NULL,
  `so_ngay_cong` int(11) NOT NULL,
  `luong_co_ban` decimal(12,2) NOT NULL,
  `phu_cap_chuc_vu` decimal(12,2) DEFAULT 0.00,
  `luong_lam_them` decimal(12,2) DEFAULT 0.00,
  `tien_thuong` decimal(12,2) DEFAULT 0.00,
  `cac_khoan_tru` decimal(12,2) DEFAULT 0.00,
  `luong_thuc_nhan` decimal(12,2) NOT NULL,
  `ngay_cham_cong` date NOT NULL,
  `trang_thai` enum('Tạm tính','Đã thanh toán') DEFAULT 'Tạm tính'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `luong`
--

INSERT INTO `luong` (`id_luong`, `id_nhan_vien`, `thang`, `so_ngay_cong`, `luong_co_ban`, `phu_cap_chuc_vu`, `luong_lam_them`, `tien_thuong`, `cac_khoan_tru`, `luong_thuc_nhan`, `ngay_cham_cong`, `trang_thai`) VALUES
(1, 1, '2024-04', 22, 10000000.00, 2000000.00, 500000.00, 1000000.00, 800000.00, 12420000.00, '2024-04-01', 'Đã thanh toán'),
(2, 2, '2024-04', 20, 9000000.00, 1800000.00, 400000.00, 800000.00, 700000.00, 11600000.00, '2024-04-02', 'Đã thanh toán'),
(3, 3, '2024-04', 18, 9500000.00, 1500000.00, 300000.00, 1200000.00, 600000.00, 11000000.00, '2024-04-03', 'Đã thanh toán'),
(4, 4, '2024-04', 22, 10000000.00, 2000000.00, 600000.00, 1100000.00, 900000.00, 12320000.00, '2024-04-04', 'Đã thanh toán'),
(5, 5, '2024-04', 21, 9500000.00, 1800000.00, 500000.00, 900000.00, 750000.00, 11375000.00, '2024-04-05', 'Đã thanh toán'),
(6, 6, '2024-04', 22, 10500000.00, 2200000.00, 700000.00, 1200000.00, 850000.00, 13015000.00, '2024-04-06', 'Đã thanh toán'),
(7, 7, '2024-04', 19, 9000000.00, 1600000.00, 450000.00, 1000000.00, 650000.00, 10955000.00, '2024-04-07', 'Đã thanh toán'),
(8, 8, '2024-04', 20, 9500000.00, 1700000.00, 300000.00, 800000.00, 700000.00, 10770000.00, '2024-04-08', 'Đã thanh toán'),
(9, 9, '2024-04', 22, 10000000.00, 1900000.00, 600000.00, 1100000.00, 850000.00, 12085000.00, '2024-04-09', 'Đã thanh toán'),
(10, 10, '2024-04', 20, 9500000.00, 1800000.00, 500000.00, 800000.00, 750000.00, 11475000.00, '2024-04-10', 'Đã thanh toán'),
(11, 11, '2024-04', 18, 9000000.00, 1600000.00, 400000.00, 750000.00, 600000.00, 10525000.00, '2024-04-11', 'Đã thanh toán'),
(12, 12, '2024-04', 19, 9200000.00, 1650000.00, 450000.00, 800000.00, 700000.00, 10655000.00, '2024-04-12', 'Đã thanh toán'),
(13, 13, '2024-04', 21, 9500000.00, 1750000.00, 550000.00, 900000.00, 700000.00, 11220000.00, '2024-04-13', 'Đã thanh toán'),
(14, 14, '2024-04', 20, 9400000.00, 1700000.00, 500000.00, 850000.00, 700000.00, 11235000.00, '2024-04-14', 'Đã thanh toán'),
(15, 15, '2024-04', 22, 10500000.00, 2300000.00, 600000.00, 1200000.00, 850000.00, 13145000.00, '2024-04-15', 'Đã thanh toán'),
(16, 16, '2024-04', 23, 11000000.00, 2500000.00, 700000.00, 1300000.00, 900000.00, 14120000.00, '2024-04-16', 'Đã thanh toán'),
(17, 17, '2024-04', 19, 9200000.00, 1800000.00, 400000.00, 800000.00, 700000.00, 10980000.00, '2024-04-17', 'Đã thanh toán'),
(18, 18, '2024-04', 22, 10000000.00, 1900000.00, 500000.00, 1100000.00, 850000.00, 12085000.00, '2024-04-18', 'Đã thanh toán'),
(19, 19, '2024-04', 20, 9500000.00, 1800000.00, 400000.00, 850000.00, 750000.00, 11125000.00, '2024-04-19', 'Đã thanh toán'),
(20, 20, '2024-04', 22, 10500000.00, 2100000.00, 600000.00, 1100000.00, 800000.00, 12120000.00, '2024-04-20', 'Tạm tính'),
(25, 1, '2025-4', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(26, 2, '2025-4', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(27, 1, '2025-04', 18, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(28, 2, '2025-04', 19, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(29, 3, '2025-04', 19, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(30, 4, '2025-04', 17, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(31, 5, '2025-04', 18, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(32, 6, '2025-04', 18, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(34, 7, '2025-04', 17, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(35, 8, '2025-04', 19, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(38, 9, '2025-04', 19, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(40, 10, '2025-04', 18, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(41, 11, '2025-04', 18, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(42, 12, '2025-04', 16, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(44, 13, '2025-04', 16, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(46, 14, '2025-04', 17, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(48, 15, '2025-04', 16, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(51, 16, '2025-04', 17, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(52, 17, '2025-04', 16, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(53, 18, '2025-04', 17, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(54, 19, '2025-04', 18, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(55, 20, '2025-04', 16, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(56, 1, '2025-01', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(58, 2, '2025-01', 3, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(60, 3, '2025-01', 3, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(61, 4, '2025-01', 4, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(62, 5, '2025-01', 3, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(63, 6, '2025-01', 3, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(65, 7, '2025-01', 1, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(66, 8, '2025-01', 3, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(70, 9, '2025-01', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(73, 10, '2025-01', 1, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(75, 11, '2025-01', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(78, 12, '2025-01', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(81, 13, '2025-01', 3, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(83, 14, '2025-01', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(86, 15, '2025-01', 3, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(87, 16, '2025-01', 3, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(88, 17, '2025-01', 3, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(89, 18, '2025-01', 3, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(92, 19, '2025-01', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', ''),
(94, 20, '2025-01', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-04-20', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `ngay_le`
--

CREATE TABLE `ngay_le` (
  `id_ngay_le` int(11) NOT NULL,
  `ten_ngay_le` varchar(100) NOT NULL,
  `ngay_bat_dau` date NOT NULL,
  `ngay_ket_thuc` date NOT NULL,
  `he_so_luong` decimal(3,2) DEFAULT 2.00,
  `mo_ta` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `ngay_le`
--

INSERT INTO `ngay_le` (`id_ngay_le`, `ten_ngay_le`, `ngay_bat_dau`, `ngay_ket_thuc`, `he_so_luong`, `mo_ta`) VALUES
(6, 'Tết Dương lịch', '2024-01-01', '2024-01-01', 3.00, 'Ngày đầu năm mới'),
(7, 'Tết Nguyên đán', '2024-02-08', '2024-02-14', 3.00, 'Tết cổ truyền'),
(8, 'Giỗ tổ Hùng Vương', '2024-04-18', '2024-04-18', 2.00, 'Ngày giỗ tổ'),
(9, 'Quốc tế Lao động', '2024-05-01', '2024-05-01', 2.00, 'Ngày Quốc tế Lao động');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nghi_phep`
--

CREATE TABLE `nghi_phep` (
  `id_nghi_phep` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `ngay_bat_dau` date NOT NULL,
  `ngay_ket_thuc` date NOT NULL,
  `loai_nghi` enum('Có phép','Không phép') DEFAULT NULL,
  `ly_do` text DEFAULT NULL,
  `trang_thai1` enum('Chờ duyệt','Đã duyệt','Từ chối') DEFAULT 'Chờ duyệt',
  `id_nguoi_duyet` int(11) DEFAULT NULL COMMENT 'ID người duyệt (không ràng buộc khóa ngoại)',
  `ngay_duyet` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `nghi_phep`
--

INSERT INTO `nghi_phep` (`id_nghi_phep`, `id_nhan_vien`, `ngay_bat_dau`, `ngay_ket_thuc`, `loai_nghi`, `ly_do`, `trang_thai1`, `id_nguoi_duyet`, `ngay_duyet`) VALUES
(1, 1, '2024-04-01', '2024-04-03', '', 'Đi du lịch', 'Đã duyệt', 5, '2024-04-02 00:00:00'),
(2, 2, '2024-04-05', '2024-04-07', '', 'Cảm cúm', 'Đã duyệt', 6, '2024-04-06 00:00:00'),
(3, 3, '2024-04-10', '2024-04-12', '', 'Đi công tác ngoài tỉnh', 'Chờ duyệt', NULL, NULL),
(4, 4, '2024-04-15', '2024-04-16', '', 'Nghỉ dưỡng', 'Đã duyệt', 7, '2024-04-14 00:00:00'),
(5, 5, '2024-04-20', '2024-04-21', '', 'Đi tham quan', 'Từ chối', 8, '2024-04-19 00:00:00'),
(6, 6, '2024-04-25', '2024-04-28', '', 'Viêm họng', 'Chờ duyệt', NULL, NULL),
(7, 7, '2024-04-30', '2024-05-02', '', 'Kết hôn', 'Đã duyệt', 9, '2024-04-29 00:00:00'),
(8, 8, '2024-04-01', '2024-04-02', '', 'Công việc gia đình', 'Từ chối', 10, '2024-03-31 00:00:00'),
(9, 9, '2024-04-07', '2024-04-09', '', 'Học thêm', 'Đã duyệt', 5, '2024-04-06 00:00:00'),
(10, 10, '2024-04-12', '2024-04-13', '', 'Đi du lịch', 'Chờ duyệt', NULL, NULL),
(11, 11, '2024-04-16', '2024-04-17', '', 'Nghỉ dưỡng', 'Đã duyệt', 6, '2024-04-15 00:00:00'),
(12, 12, '2024-04-21', '2024-04-22', '', 'Đau dạ dày', 'Đã duyệt', 7, '2024-04-20 00:00:00'),
(13, 13, '2024-04-23', '2024-04-24', '', 'Sự kiện quan trọng', 'Từ chối', 8, '2024-04-22 00:00:00'),
(14, 14, '2024-04-28', '2024-04-30', '', 'Đi thăm gia đình', 'Chờ duyệt', NULL, NULL),
(15, 15, '2024-04-03', '2024-04-05', '', 'Đi công tác', 'Đã duyệt', 9, '2024-04-02 00:00:00'),
(16, 16, '2024-04-07', '2024-04-08', '', 'Du lịch nghỉ dưỡng', 'Đã duyệt', 10, '2024-04-06 00:00:00'),
(17, 17, '2024-04-13', '2024-04-14', '', 'Cảm cúm', 'Từ chối', 5, '2024-04-12 00:00:00'),
(18, 18, '2024-04-17', '2024-04-18', '', 'Sự kiện đột xuất', 'Chờ duyệt', NULL, NULL),
(19, 19, '2024-04-22', '2024-04-23', '', 'Du lịch dài ngày', 'Đã duyệt', 6, '2024-04-21 00:00:00'),
(20, 20, '2024-04-28', '2024-04-29', '', 'Nghỉ gia đình', 'Chờ duyệt', NULL, NULL),
(21, 3, '2025-04-20', '2025-04-21', 'Có phép', NULL, 'Chờ duyệt', 1, '2025-04-20 23:52:23');

--
-- Bẫy `nghi_phep`
--
DELIMITER $$
CREATE TRIGGER `trg_nghi_phep_update` BEFORE UPDATE ON `nghi_phep` FOR EACH ROW BEGIN
    DECLARE v_vai_tro VARCHAR(20);
    
    -- Nếu cập nhật trạng thái và có người duyệt
    IF NEW.trang_thai IN ('Đã duyệt', 'Từ chối') AND NEW.id_nguoi_duyet IS NOT NULL THEN
        -- Lấy vai trò người duyệt (giả sử có view hoặc join)
        SELECT vai_tro INTO v_vai_tro
        FROM nguoi_dung
        WHERE id_nhan_vien = NEW.id_nguoi_duyet;
        
        -- Kiểm tra quyền
        IF v_vai_tro NOT IN ('Admin', 'Quản lý') THEN
            SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'Chỉ Admin hoặc Quản lý được phép duyệt đơn nghỉ phép';
        END IF;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nguoi_dung`
--

CREATE TABLE `nguoi_dung` (
  `id_nguoi_dung` int(11) NOT NULL,
  `ten_dang_nhap` varchar(50) NOT NULL,
  `mat_khau` varchar(255) NOT NULL,
  `vai_tro` enum('Admin','Quản lý','Nhân viên') NOT NULL DEFAULT 'Nhân viên'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `nguoi_dung`
--

INSERT INTO `nguoi_dung` (`id_nguoi_dung`, `ten_dang_nhap`, `mat_khau`, `vai_tro`) VALUES
(1, 'admin', '123', 'Admin'),
(2, 'quanly', '123456', 'Quản lý');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nhan_vien`
--

CREATE TABLE `nhan_vien` (
  `id_nhan_vien` int(11) NOT NULL,
  `ho_ten` varchar(100) NOT NULL,
  `gioi_tinh` enum('Nam','Nữ','Khác') DEFAULT NULL,
  `ngay_sinh` date DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `so_dien_thoai` varchar(20) DEFAULT NULL,
  `dia_chi` varchar(200) DEFAULT NULL,
  `can_cuoc_cong_dan` varchar(20) DEFAULT NULL,
  `ngay_cap` date DEFAULT NULL,
  `noi_cap` varchar(100) DEFAULT NULL,
  `que_quan` varchar(200) DEFAULT NULL,
  `hinh_anh` varchar(255) DEFAULT NULL,
  `id_phong_ban` int(11) DEFAULT NULL,
  `id_chuc_vu` int(11) DEFAULT NULL,
  `loai_hop_dong` enum('Toàn thời gian','Bán thời gian','Thực tập') NOT NULL,
  `luong_co_ban` decimal(12,2) NOT NULL,
  `ngay_vao_lam` date NOT NULL,
  `ngay_nghi_viec` date DEFAULT NULL,
  `trang_thai` enum('Đang làm việc','Nghỉ phép','Đã nghỉ việc') DEFAULT 'Đang làm việc'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `nhan_vien`
--

INSERT INTO `nhan_vien` (`id_nhan_vien`, `ho_ten`, `gioi_tinh`, `ngay_sinh`, `email`, `so_dien_thoai`, `dia_chi`, `can_cuoc_cong_dan`, `ngay_cap`, `noi_cap`, `que_quan`, `hinh_anh`, `id_phong_ban`, `id_chuc_vu`, `loai_hop_dong`, `luong_co_ban`, `ngay_vao_lam`, `ngay_nghi_viec`, `trang_thai`) VALUES
(1, 'Phan Văn T', 'Nữ', '1990-01-03', 'a@company.com', '0901234567', 'Hà Nội', '1234567832', '2010-01-01', 'Hà Nội', 'Hà Nội', 'image1.jpg', 1, 1, 'Toàn thời gian', 10000000.00, '2020-01-01', '0000-00-00', 'Đang làm việc'),
(2, 'Trần Thị B', 'Nữ', '1995-02-01', 'b@company.com', '0901234568', 'Hà Nội', '123456789', '2015-05-01', 'Hà Nội', 'Hà Nội', 'image2.jpg', 1, 2, 'Toàn thời gian', 8000000.00, '2020-01-01', NULL, 'Đang làm việc'),
(3, 'Lê Minh C', 'Nam', '1992-03-01', 'c@company.com', '0901234569', 'Hà Nội', '123456789', '2012-06-01', 'Hà Nội', 'Hà Nội', 'image3.jpg', 1, 3, 'Toàn thời gian', 6000000.00, '2020-01-01', NULL, 'Đang làm việc'),
(4, 'Phan Lan D', 'Nữ', '1997-04-01', 'd@company.com', '0901234570', 'Hà Nội', '123456789', '2018-09-01', 'Hà Nội', 'Hà Nội', 'image4.jpg', 1, 4, 'Thực tập', 4000000.00, '2020-01-01', NULL, 'Đang làm việc'),
(5, 'Nguyễn Thị E', 'Nữ', '1990-05-01', 'e@company.com', '0901234571', 'Hà Nội', '123456789', '2012-01-01', 'Hà Nội', 'Hà Nội', 'image5.jpg', 2, 1, 'Toàn thời gian', 12000000.00, '2020-01-01', NULL, 'Đang làm việc'),
(6, 'Trần Minh F', 'Nam', '1994-06-01', 'f@company.com', '0901234572', 'Hà Nội', '123456789', '2014-04-01', 'Hà Nội', 'Hà Nội', 'image6.jpg', 2, 2, 'Toàn thời gian', 10000000.00, '2020-01-01', NULL, 'Đang làm việc'),
(7, 'Lê Thị G', 'Nữ', '1993-07-01', 'g@company.com', '0901234573', 'Hà Nội', '123456789', '2015-03-01', 'Hà Nội', 'Hà Nội', 'image7.jpg', 2, 3, 'Bán thời gian', 7000000.00, '2020-01-01', NULL, 'Đang làm việc'),
(8, 'Phan Minh H', 'Nam', '1996-08-01', 'h@company.com', '0901234574', 'Hà Nội', '123456789', '2018-10-01', 'Hà Nội', 'Hà Nội', 'image8.jpg', 2, 4, 'Thực tập', 4000000.00, '2020-01-01', NULL, 'Đang làm việc'),
(9, 'Nguyễn Hoàng I', 'Nam', '1989-09-01', 'i@company.com', '0901234575', 'Hà Nội', '123456789', '2011-02-01', 'Hà Nội', 'Hà Nội', 'image9.jpg', 3, 1, 'Toàn thời gian', 11000000.00, '2020-01-01', NULL, 'Đang làm việc'),
(10, 'Trần Kim J', 'Nữ', '1992-10-01', 'j@company.com', '0901234576', 'Hà Nội', '123456789', '2014-05-01', 'Hà Nội', 'Hà Nội', 'image10.jpg', 3, 2, 'Bán thời gian', 7500000.00, '2020-01-01', NULL, 'Đang làm việc'),
(11, 'Lê Thảo K', 'Nam', '1991-11-01', 'k@company.com', '0901234577', 'Hà Nội', '123456789', '2013-07-01', 'Hà Nội', 'Hà Nội', 'image11.jpg', 3, 3, 'Toàn thời gian', 8000000.00, '2020-01-01', NULL, 'Đang làm việc'),
(12, 'Phan Thanh L', 'Nữ', '1995-12-01', 'l@company.com', '0901234578', 'Hà Nội', '123456789', '2017-08-01', 'Hà Nội', 'Hà Nội', 'image12.jpg', 3, 4, 'Thực tập', 5000000.00, '2020-01-01', NULL, 'Đang làm việc'),
(13, 'Nguyễn Thị M', 'Nữ', '1988-01-01', 'm@company.com', '0901234579', 'Hà Nội', '123456789', '2010-04-01', 'Hà Nội', 'Hà Nội', 'image13.jpg', 4, 1, 'Toàn thời gian', 13000000.00, '2020-01-01', NULL, 'Đang làm việc'),
(14, 'Trần Ngọc N', 'Nam', '1990-02-01', 'n@company.com', '0901234580', 'Hà Nội', '123456789', '2013-03-01', 'Hà Nội', 'Hà Nội', 'image14.jpg', 4, 2, 'Bán thời gian', 7800000.00, '2020-01-01', NULL, 'Đang làm việc'),
(15, 'Lê Minh O', 'Nữ', '1994-04-01', 'o@company.com', '0901234581', 'Hà Nội', '123456789', '2016-05-01', 'Hà Nội', 'Hà Nội', 'image15.jpg', 4, 3, 'Toàn thời gian', 8500000.00, '2020-01-01', NULL, 'Đang làm việc'),
(16, 'Phan Lan P', 'Nam', '1997-05-01', 'p@company.com', '0901234582', 'Hà Nội', '123456789', '2018-06-01', 'Hà Nội', 'Hà Nội', 'image16.jpg', 4, 4, 'Thực tập', 4000000.00, '2020-01-01', NULL, 'Đang làm việc'),
(17, 'Nguyễn Hoàng Q', 'Nam', '1987-06-01', 'q@company.com', '0901234583', 'Hà Nội', '123456789', '2009-07-01', 'Hà Nội', 'Hà Nội', 'image17.jpg', 5, 1, 'Toàn thời gian', 14000000.00, '2020-01-01', NULL, 'Đang làm việc'),
(18, 'Trần Ngọc R', 'Nữ', '1991-08-01', 'r@company.com', '0901234584', 'Hà Nội', '123456789', '2012-11-01', 'Hà Nội', 'Hà Nội', 'image18.jpg', 5, 2, 'Bán thời gian', 7700000.00, '2020-01-01', NULL, 'Đang làm việc'),
(19, 'Lê Minh S', 'Nam', '1993-09-01', 's@company.com', '0901234585', 'Hà Nội', '123456789', '2014-02-01', 'Hà Nội', 'Hà Nội', 'image19.jpg', 5, 3, 'Toàn thời gian', 9000000.00, '2020-01-01', NULL, 'Đang làm việc'),
(20, 'Phan Lan T', 'Nữ', '1998-10-01', 't@company.com', '0901234586', 'Hà Nội', '123456789', '2019-12-01', 'Hà Nội', 'Hà Nội', 'image20.jpg', 5, 4, 'Thực tập', 4500000.00, '2020-01-01', NULL, 'Đang làm việc'),
(22, 'that', 'Nữ', '1998-10-01', 't@company.com', '0901234586', 'Hà Nội', '123456789', '2019-12-01', 'Hà Nội', 'Hà Nội', 'image20.jpg', 5, 4, 'Thực tập', 4500000.00, '2020-01-01', NULL, 'Đang làm việc'),
(23, 'luo', 'Nữ', '1998-10-01', 't@company.com', '0901234586', 'Hà Nội', '123456789', '2019-12-01', 'Hà Nội', 'Hà Nội', 'image20.jpg', 5, 4, 'Thực tập', 4500000.00, '2020-01-01', NULL, 'Đang làm việc'),
(24, 'luogggg', 'Nữ', '1998-10-01', 't@company.com', '0901234586', 'Hà Nội', '123456789', '2019-12-01', 'Hà Nội', 'Hà Nội', 'image20.jpg', 5, 4, 'Thực tập', 4500000.00, '2020-01-01', NULL, 'Đang làm việc'),
(25, 'luoggggdđ', 'Nữ', '1998-10-01', 't@company.com', '0901234586', 'Hà Nội', '123456789', '2019-12-01', 'Hà Nội', 'Hà Nội', 'image20.jpg', 5, 4, 'Thực tập', 4500000.00, '2020-01-01', NULL, 'Đang làm việc'),
(26, 'luoggggdđ', 'Nữ', '1998-10-01', 't@company.com', '0901234586', 'Hà Nội', '123456789', '2019-12-01', 'Hà Nội', 'Hà Nội', 'image20.jpg', 5, 4, 'Thực tập', 4500000.00, '2025-04-21', NULL, 'Đang làm việc');

--
-- Bẫy `nhan_vien`
--
DELIMITER $$
CREATE TRIGGER `trg_nhan_vien_update` BEFORE UPDATE ON `nhan_vien` FOR EACH ROW BEGIN
    -- Nếu cập nhật trạng thái thành "Đã nghỉ việc"
    IF NEW.trang_thai = 'Đã nghỉ việc' AND OLD.trang_thai != 'Đã nghỉ việc' THEN
        SET NEW.ngay_nghi_viec = CURDATE();
        
        -- Vô hiệu hóa tài khoản người dùng nếu có
        UPDATE nguoi_dung 
        SET trang_thai = 'Inactive' 
        WHERE id_nhan_vien = NEW.id_nhan_vien;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `phan_ca`
--

CREATE TABLE `phan_ca` (
  `id_phan_ca` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `ngay` date NOT NULL,
  `id_ca` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `phan_ca`
--

INSERT INTO `phan_ca` (`id_phan_ca`, `id_nhan_vien`, `ngay`, `id_ca`) VALUES
(1, 1, '2024-04-15', 1),
(2, 2, '2024-04-15', 2),
(3, 3, '2024-04-15', 1),
(4, 4, '2024-04-15', 3),
(5, 5, '2024-04-15', 1),
(6, 6, '2024-04-15', 2),
(7, 7, '2024-04-15', 1),
(8, 8, '2024-04-15', 3),
(9, 9, '2024-04-15', 1),
(10, 10, '2024-04-15', 2),
(11, 11, '2024-04-15', 1),
(12, 12, '2024-04-15', 3),
(13, 13, '2024-04-15', 1),
(14, 14, '2024-04-15', 2),
(15, 15, '2024-04-15', 1),
(16, 16, '2024-04-15', 3),
(17, 17, '2024-04-15', 1),
(18, 18, '2024-04-15', 2),
(19, 19, '2024-04-15', 1),
(20, 20, '2024-04-15', 3);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `phong_ban`
--

CREATE TABLE `phong_ban` (
  `id_phong_ban` int(11) NOT NULL,
  `ten_phong_ban` varchar(100) NOT NULL,
  `mo_ta` text DEFAULT NULL,
  `truong_phong` int(11) DEFAULT NULL,
  `trang_thai` enum('Hoạt động','Ngừng hoạt động') DEFAULT 'Hoạt động'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `phong_ban`
--

INSERT INTO `phong_ban` (`id_phong_ban`, `ten_phong_ban`, `mo_ta`, `truong_phong`, `trang_thai`) VALUES
(1, 'Phòng Kế toán', 'Quản lý tài chính công ty', 1, 'Hoạt động'),
(2, 'Phòng Nhân sự', 'Quản lý tuyển dụng và chấm công', 2, 'Hoạt động'),
(3, 'Phòng Kinh doanh', 'Phát triển và duy trì khách hàng', 3, 'Hoạt động'),
(4, 'Phòng Marketing', 'Quảng bá và xây dựng thương hiệu', 4, 'Hoạt động'),
(5, 'Phòng IT', 'Phát triển phần mềm và hệ thống', 5, 'Hoạt động');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tong_hop_cong_thang`
--

CREATE TABLE `tong_hop_cong_thang` (
  `id_tong_hop` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `thang` varchar(7) NOT NULL,
  `tong_cong` decimal(5,2) DEFAULT 0.00,
  `cong_chinh` decimal(5,2) DEFAULT 0.00,
  `lam_them` decimal(5,2) DEFAULT 0.00,
  `ngay_lam_viec` int(11) DEFAULT 0,
  `ngay_nghi_le` int(11) DEFAULT 0,
  `ngay_nghi_phep` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `tong_hop_cong_thang`
--

INSERT INTO `tong_hop_cong_thang` (`id_tong_hop`, `id_nhan_vien`, `thang`, `tong_cong`, `cong_chinh`, `lam_them`, `ngay_lam_viec`, `ngay_nghi_le`, `ngay_nghi_phep`) VALUES
(4, 1, '2025-04', 17.50, 17.50, 0.00, 0, 0, 1),
(5, 2, '2025-04', 19.00, 19.00, 0.00, 0, 0, 0),
(6, 3, '2025-04', 19.00, 19.00, 0.00, 0, 0, 0),
(7, 4, '2025-04', 17.00, 17.00, 0.00, 0, 0, 0),
(8, 5, '2025-04', 17.50, 17.50, 0.00, 0, 0, 0),
(9, 6, '2025-04', 17.50, 17.50, 0.00, 0, 0, 0),
(10, 7, '2025-04', 16.50, 16.50, 0.00, 0, 0, 0),
(11, 8, '2025-04', 18.50, 18.50, 0.00, 0, 0, 0),
(12, 9, '2025-04', 18.50, 18.50, 0.00, 0, 0, 0),
(13, 10, '2025-04', 17.50, 17.50, 0.00, 0, 0, 0),
(14, 11, '2025-04', 17.50, 17.50, 0.00, 0, 0, 0),
(15, 12, '2025-04', 15.50, 15.50, 0.00, 0, 0, 0),
(16, 13, '2025-04', 16.00, 16.00, 0.00, 0, 0, 0),
(17, 14, '2025-04', 16.50, 16.50, 0.00, 0, 0, 0),
(18, 15, '2025-04', 16.00, 16.00, 0.00, 0, 0, 0),
(19, 17, '2025-04', 16.00, 16.00, 0.00, 0, 0, 0),
(20, 16, '2025-04', 16.50, 16.50, 0.00, 0, 0, 0),
(21, 18, '2025-04', 16.50, 16.50, 0.00, 0, 0, 0),
(22, 19, '2025-04', 17.50, 17.50, 0.00, 0, 0, 0),
(23, 20, '2025-04', 16.00, 16.00, 0.00, 0, 0, 0),
(24, 1, '2025-01', 2.00, 2.00, 0.00, 0, 0, 0),
(25, 2, '2025-01', 3.00, 3.00, 0.00, 0, 0, 0),
(26, 3, '2025-01', 3.00, 3.00, 0.00, 0, 0, 0),
(27, 4, '2025-01', 4.00, 4.00, 0.00, 0, 0, 0),
(28, 5, '2025-01', 3.00, 3.00, 0.00, 0, 0, 0),
(29, 6, '2025-01', 3.00, 3.00, 0.00, 0, 0, 0),
(30, 7, '2025-01', 1.00, 1.00, 0.00, 0, 0, 0),
(31, 8, '2025-01', 3.00, 3.00, 0.00, 0, 0, 0),
(32, 9, '2025-01', 2.00, 2.00, 0.00, 0, 0, 0),
(33, 10, '2025-01', 1.00, 1.00, 0.00, 0, 0, 0),
(34, 11, '2025-01', 2.00, 2.00, 0.00, 0, 0, 0),
(35, 12, '2025-01', 2.00, 2.00, 0.00, 0, 0, 0),
(36, 13, '2025-01', 3.00, 3.00, 0.00, 0, 0, 0),
(37, 14, '2025-01', 2.00, 2.00, 0.00, 0, 0, 0),
(38, 15, '2025-01', 3.00, 3.00, 0.00, 0, 0, 0),
(39, 16, '2025-01', 3.00, 3.00, 0.00, 0, 0, 0),
(40, 17, '2025-01', 3.00, 3.00, 0.00, 0, 0, 0),
(41, 18, '2025-01', 3.00, 3.00, 0.00, 0, 0, 0),
(42, 19, '2025-01', 2.00, 2.00, 0.00, 0, 0, 0),
(43, 20, '2025-01', 2.00, 2.00, 0.00, 0, 0, 0);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `bao_hiem_thue_tncn`
--
ALTER TABLE `bao_hiem_thue_tncn`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_nhan_vien` (`id_nhan_vien`,`thang`);

--
-- Chỉ mục cho bảng `ca_lam_viec`
--
ALTER TABLE `ca_lam_viec`
  ADD PRIMARY KEY (`id_ca`);

--
-- Chỉ mục cho bảng `cham_cong`
--
ALTER TABLE `cham_cong`
  ADD PRIMARY KEY (`id_cham_cong`),
  ADD UNIQUE KEY `id_nhan_vien` (`id_nhan_vien`,`ngay_lam_viec`);

--
-- Chỉ mục cho bảng `chuc_vu`
--
ALTER TABLE `chuc_vu`
  ADD PRIMARY KEY (`id_chuc_vu`);

--
-- Chỉ mục cho bảng `luong`
--
ALTER TABLE `luong`
  ADD PRIMARY KEY (`id_luong`),
  ADD UNIQUE KEY `id_nhan_vien` (`id_nhan_vien`,`thang`);

--
-- Chỉ mục cho bảng `ngay_le`
--
ALTER TABLE `ngay_le`
  ADD PRIMARY KEY (`id_ngay_le`);

--
-- Chỉ mục cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  ADD PRIMARY KEY (`id_nghi_phep`),
  ADD KEY `id_nhan_vien` (`id_nhan_vien`);

--
-- Chỉ mục cho bảng `nguoi_dung`
--
ALTER TABLE `nguoi_dung`
  ADD PRIMARY KEY (`id_nguoi_dung`),
  ADD UNIQUE KEY `ten_dang_nhap` (`ten_dang_nhap`);

--
-- Chỉ mục cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  ADD PRIMARY KEY (`id_nhan_vien`),
  ADD KEY `id_phong_ban` (`id_phong_ban`),
  ADD KEY `id_chuc_vu` (`id_chuc_vu`);

--
-- Chỉ mục cho bảng `phan_ca`
--
ALTER TABLE `phan_ca`
  ADD PRIMARY KEY (`id_phan_ca`),
  ADD UNIQUE KEY `id_nhan_vien` (`id_nhan_vien`,`ngay`),
  ADD KEY `id_ca` (`id_ca`);

--
-- Chỉ mục cho bảng `phong_ban`
--
ALTER TABLE `phong_ban`
  ADD PRIMARY KEY (`id_phong_ban`);

--
-- Chỉ mục cho bảng `tong_hop_cong_thang`
--
ALTER TABLE `tong_hop_cong_thang`
  ADD PRIMARY KEY (`id_tong_hop`),
  ADD UNIQUE KEY `id_nhan_vien` (`id_nhan_vien`,`thang`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `bao_hiem_thue_tncn`
--
ALTER TABLE `bao_hiem_thue_tncn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT cho bảng `ca_lam_viec`
--
ALTER TABLE `ca_lam_viec`
  MODIFY `id_ca` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `cham_cong`
--
ALTER TABLE `cham_cong`
  MODIFY `id_cham_cong` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=467;

--
-- AUTO_INCREMENT cho bảng `chuc_vu`
--
ALTER TABLE `chuc_vu`
  MODIFY `id_chuc_vu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `luong`
--
ALTER TABLE `luong`
  MODIFY `id_luong` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT cho bảng `ngay_le`
--
ALTER TABLE `ngay_le`
  MODIFY `id_ngay_le` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  MODIFY `id_nghi_phep` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT cho bảng `nguoi_dung`
--
ALTER TABLE `nguoi_dung`
  MODIFY `id_nguoi_dung` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  MODIFY `id_nhan_vien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT cho bảng `phan_ca`
--
ALTER TABLE `phan_ca`
  MODIFY `id_phan_ca` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT cho bảng `phong_ban`
--
ALTER TABLE `phong_ban`
  MODIFY `id_phong_ban` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `tong_hop_cong_thang`
--
ALTER TABLE `tong_hop_cong_thang`
  MODIFY `id_tong_hop` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `bao_hiem_thue_tncn`
--
ALTER TABLE `bao_hiem_thue_tncn`
  ADD CONSTRAINT `bao_hiem_thue_tncn_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `cham_cong`
--
ALTER TABLE `cham_cong`
  ADD CONSTRAINT `cham_cong_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `luong`
--
ALTER TABLE `luong`
  ADD CONSTRAINT `luong_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  ADD CONSTRAINT `nghi_phep_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  ADD CONSTRAINT `nhan_vien_ibfk_1` FOREIGN KEY (`id_phong_ban`) REFERENCES `phong_ban` (`id_phong_ban`),
  ADD CONSTRAINT `nhan_vien_ibfk_2` FOREIGN KEY (`id_chuc_vu`) REFERENCES `chuc_vu` (`id_chuc_vu`);

--
-- Các ràng buộc cho bảng `phan_ca`
--
ALTER TABLE `phan_ca`
  ADD CONSTRAINT `phan_ca_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE,
  ADD CONSTRAINT `phan_ca_ibfk_2` FOREIGN KEY (`id_ca`) REFERENCES `ca_lam_viec` (`id_ca`);

--
-- Các ràng buộc cho bảng `tong_hop_cong_thang`
--
ALTER TABLE `tong_hop_cong_thang`
  ADD CONSTRAINT `tong_hop_cong_thang_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
