
<?php
// Enable error reporting for debugging (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/check_login.php';
include(__DIR__ . '/../includes/header.php');
include(__DIR__ . '/../includes/sidebar.php');

require_once __DIR__ . '/../config/Database.php';

// Initialize database connection
try {
    $database = new Database();
    $conn = $database->getConnection();
    if (!$conn) {
        throw new Exception("Không thể kết nối đến cơ sở dữ liệu.");
    }
} catch (Exception $e) {
    error_log("Database connection error: " . $e->getMessage());
    die("<div class='error-container'><div class='error-message'>Lỗi: " . $e->getMessage() . "</div></div>");
}

// Get month and year from request, default to current month
$month = isset($_GET['month']) ? (int)$_GET['month'] : date('m');
$year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
$month_year = sprintf("%04d-%02d", $year, $month);

// 1. Insurance and Tax Data by Department (Grouped Bar Chart, Limit to 5 Departments)
try {
    $insuranceTaxStmt = $conn->prepare("
        SELECT p.ten_phong_ban,
               SUM(bh.bhxh) as bhxh,
               SUM(bh.bhyt) as bhyt,
               SUM(bh.bhtn) as bhtn,
               SUM(bh.thue_tncn) as thue_tncn
        FROM phong_ban p
        LEFT JOIN nhan_vien n ON p.id_phong_ban = n.id_phong_ban 
            AND n.trang_thai != 'Đã nghỉ việc'
        LEFT JOIN bao_hiem_thue_tncn bh ON n.id_nhan_vien = bh.id_nhan_vien 
            AND bh.thang = ?
        WHERE p.trang_thai = 'Hoạt động'
        GROUP BY p.id_phong_ban
        ORDER BY p.id_phong_ban
        LIMIT 5
    ");
    $insuranceTaxStmt->execute([$month_year]);
    $insuranceTaxData = $insuranceTaxStmt->fetchAll(PDO::FETCH_ASSOC);

    // Pad with placeholder departments if fewer than 5
    while (count($insuranceTaxData) < 5) {
        $insuranceTaxData[] = [
            'ten_phong_ban' => 'N/A ' . (count($insuranceTaxData) + 1),
            'bhxh' => 0,
            'bhyt' => 0,
            'bhtn' => 0,
            'thue_tncn' => 0
        ];
    }
} catch (PDOException $e) {
    error_log("Error in insuranceTax query: " . $e->getMessage());
    $insuranceTaxData = array_fill(0, 5, [
        'ten_phong_ban' => 'N/A',
        'bhxh' => 0,
        'bhyt' => 0,
        'bhtn' => 0,
        'thue_tncn' => 0
    ]);
}

// 2. Bonuses/Penalties and Payroll Data by Department (Combo Chart, Limit to 5 Departments)
try {
    $bonusPayrollStmt = $conn->prepare("
        SELECT p.ten_phong_ban,
               SUM(CASE WHEN t.tien_thuong > 0 THEN t.tien_thuong ELSE 0 END) as tong_thuong,
               SUM(CASE WHEN t.tien_thuong < 0 THEN ABS(t.tien_thuong) ELSE 0 END) as tong_phat,
               SUM(l.luong_thuc_nhan) as luong_thuc_nhan
        FROM phong_ban p
        LEFT JOIN nhan_vien n ON p.id_phong_ban = n.id_phong_ban 
            AND n.trang_thai != 'Đã nghỉ việc'
        LEFT JOIN thuong t ON n.id_nhan_vien = t.id_nhan_vien 
            AND DATE_FORMAT(t.ngay, '%Y-%m') = ?
        LEFT JOIN luong l ON n.id_nhan_vien = l.id_nhan_vien 
            AND l.thang = ?
        WHERE p.trang_thai = 'Hoạt động'
        GROUP BY p.id_phong_ban
        ORDER BY p.id_phong_ban
        LIMIT 5
    ");
    $bonusPayrollStmt->execute([$month_year, $month_year]);
    $bonusPayrollData = $bonusPayrollStmt->fetchAll(PDO::FETCH_ASSOC);

    // Pad with placeholder departments if fewer than 5
    while (count($bonusPayrollData) < 5) {
        $bonusPayrollData[] = [
            'ten_phong_ban' => 'N/A ' . (count($bonusPayrollData) + 1),
            'tong_thuong' => 0,
            'tong_phat' => 0,
            'luong_thuc_nhan' => 0
        ];
    }
} catch (PDOException $e) {
    error_log("Error in bonusPayroll query: " . $e->getMessage());
    $bonusPayrollData = array_fill(0, 5, [
        'ten_phong_ban' => 'N/A',
        'tong_thuong' => 0,
        'tong_phat' => 0,
        'luong_thuc_nhan' => 0
    ]);
}

// 3. KPI Data for Right Sidebar
try {
    // Total Employees
    $totalEmployeesStmt = $conn->prepare("
        SELECT COUNT(*) as total
        FROM nhan_vien
        WHERE trang_thai != 'Đã nghỉ việc'
    ");
    $totalEmployeesStmt->execute();
    $totalEmployees = $totalEmployeesStmt->fetch(PDO::FETCH_ASSOC)['total'];

    // Total Insurance
    $totalInsuranceStmt = $conn->prepare("
        SELECT SUM(bhxh + bhyt + bhtn) as total_insurance
        FROM bao_hiem_thue_tncn
        WHERE thang = ?
    ");
    $totalInsuranceStmt->execute([$month_year]);
    $totalInsurance = $totalInsuranceStmt->fetch(PDO::FETCH_ASSOC)['total_insurance'] ?? 0;

    // Total Personal Income Tax
    $totalTaxStmt = $conn->prepare("
        SELECT SUM(thue_tncn) as total_tax
        FROM bao_hiem_thue_tncn
        WHERE thang = ?
    ");
    $totalTaxStmt->execute([$month_year]);
    $totalTax = $totalTaxStmt->fetch(PDO::FETCH_ASSOC)['total_tax'] ?? 0;

    // Total Bonuses/Penalties
    $totalBonusPenaltyStmt = $conn->prepare("
        SELECT SUM(tien_thuong) as total_bonus_penalty
        FROM thuong
        WHERE DATE_FORMAT(ngay, '%Y-%m') = ?
    ");
    $totalBonusPenaltyStmt->execute([$month_year]);
    $totalBonusPenalty = $totalBonusPenaltyStmt->fetch(PDO::FETCH_ASSOC)['total_bonus_penalty'] ?? 0;

    // Total Net Salary
    $totalSalaryStmt = $conn->prepare("
        SELECT SUM(luong_thuc_nhan) as total_salary
        FROM luong
        WHERE thang = ?
    ");
    $totalSalaryStmt->execute([$month_year]);
    $totalSalary = $totalSalaryStmt->fetch(PDO::FETCH_ASSOC)['total_salary'] ?? 0;
} catch (PDOException $e) {
    error_log("Error in KPI queries: " . $e->getMessage());
    $totalEmployees = $totalInsurance = $totalTax = $totalBonusPenalty = $totalSalary = 0;
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Báo cáo tài chính | Hệ thống quản lý nhân sự</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0/dist/chartjs-plugin-datalabels.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        :root {
            --primary-color: #5a67d8;
            --secondary-color: #4c51bf;
            --success-color: #48bb78;
            --danger-color: #f56565;
            --warning-color: #ed8936;
            --info-color: #4299e1;
            --light-color: #f7fafc;
            --dark-color: #1a202c;
            --gray-color: #718096;
            --white-color: #ffffff;
            --border-radius: 10px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            --transition: all 0.3s ease-in-out;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f4f7fc;
            color: var(--dark-color);
            line-height: 1.6;
            margin: 0;
            overflow: auto;
        }

        .main-content {
            padding: 20px;
            margin-left: 250px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .page-header {
            background: linear-gradient(135deg, #ffffff, #f9fafb);
            padding: 12px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
        }

        .page-header:hover {
            transform: translateY(-2px);
        }

        .page-title {
            font-size: 26px;
            font-weight: 700;
            color: var(--dark-color);
            margin: 0;
        }

        .filter-form {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .filter-form label {
            font-weight: 600;
            color: var(--gray-color);
            font-size: 13px;
        }

        .filter-form select,
        .filter-form button,
        .export-button {
            padding: 8px 14px;
            border-radius: 6px;
            border: 1px solid #e2e8f0;
            font-size: 13px;
            background: #ffffff;
        }

        .filter-form select:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(90, 103, 216, 0.15);
        }

        .filter-form button,
        .export-button {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--white-color);
            border: none;
            cursor: pointer;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .filter-form button:hover,
        .export-button:hover {
            background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
            transform: translateY(-1px);
        }

        .charts-container {
            display: grid;
            grid-template-columns: 70% 30%; /* Left charts 70%, Right chart 30% */
            gap: 12px;
            height: calc(100vh - 120px); /* Adjust height to fit screen, accounting for header and padding */
            overflow: hidden;
        }

        .left-charts {
            display: grid;
            grid-template-rows: 1fr 1fr; /* Two charts with equal height */
            gap: 12px;
            height: 100%; /* Full height of charts-container */
            overflow: hidden;
        }

        .chart-card {
            background: #ffffff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 12px;
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            height: 100%; /* Each chart takes 50% of the left-charts height, increased to fit screen */
        }

        .chart-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
        }

        .chart-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary-color), var(--secondary-color));
        }

        .chart-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--dark-color);
            margin: 0 0 8px 0;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .chart-title i {
            color: var(--primary-color);
            font-size: 18px;
        }

        canvas {
            width: 100% !important;
            flex-grow: 1;
            max-height: 100%;
        }

        .kpi-container {
            display: grid;
            grid-template-rows: repeat(5, 1fr); /* Five KPI cards */
            gap: 8px;
            height: 100%; /* Match the combined height of the two left charts */
            overflow: hidden;
        }

        .kpi-card {
            text-align: center;
            padding: 8px;
            background: #ffffff;
            border-radius: 6px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .kpi-card:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.08);
        }

        .kpi-card i {
            font-size: 14px;
            color: var(--primary-color);
            margin-bottom: 4px;
        }

        .kpi-card .kpi-value {
            font-size: 14px;
            font-weight: 700;
            color: var(--dark-color);
        }

        .kpi-card .kpi-label {
            font-size: 9px;
            color: var(--gray-color);
        }

        .no-data {
            text-align: center;
            padding: 10px;
            color: var(--gray-color);
            font-size: 12px;
            background-color: #f9fafb;
            border-radius: var(--border-radius);
            flex-grow: 1;
        }

        .no-data i {
            font-size: 20px;
            margin-bottom: 6px;
            color: #dee2e6;
        }

        .error-container {
            background-color: #fff5f5;
            border-radius: var(--border-radius);
            margin-bottom: 12px;
            border-left: 4px solid var(--danger-color);
        }

        .error-message {
            padding: 10px;
            color: var(--danger-color);
            font-weight: 500;
        }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 12px;
            padding: 12px 0;
        }

        .pagination button {
            padding: 8px 16px;
            border-radius: 6px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--white-color);
            border: none;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            transition: var(--transition);
        }

        .pagination button:disabled {
            background: var(--gray-color);
            cursor: not-allowed;
        }

        .pagination button:hover:not(:disabled) {
            background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
            transform: translateY(-1px);
        }

        @media (max-width: 1200px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .charts-container {
                height: calc(100vh - 90px); /* Adjust for smaller screens */
            }
        }

        @media (max-width: 768px) {
            .charts-container {
                grid-template-columns: 1fr; /* Stack vertically on small screens */
                height: auto;
                max-height: 80vh; /* Limit height on mobile */
            }

            .left-charts {
                grid-template-rows: auto auto;
                height: auto;
            }

            .chart-card {
                height: auto;
                min-height: 200px; /* Ensure readability */
            }

            .kpi-container {
                grid-template-rows: auto;
                height: auto;
            }

            .kpi-card {
                min-height: 80px;
            }
        }
    </style>
</head>
<body>
    <div class="main-content">
        <div class="page-header">
            <h1 class="page-title">
                <i class="fas fa-chart-bar"></i>
                Báo cáo tài chính
            </h1>
            <form method="GET" action="baocao1.php" class="filter-form">
                <div>
                    <label for="month"><i class="far fa-calendar-alt"></i> Tháng:</label>
                    <select id="month" name="month">
                        <?php for ($m = 1; $m <= 12; $m++): ?>
                            <option value="<?= $m ?>" <?= $m == $month ? 'selected' : '' ?>>
                                Tháng <?= $m ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div>
                    <label for="year"><i class="far fa-calendar"></i> Năm:</label>
                    <select id="year" name="year">
                        <?php for ($y = date('Y') - 5; $y <= date('Y') + 1; $y++): ?>
                            <option value="<?= $y ?>" <?= $y == $year ? 'selected' : '' ?>>
                                <?= $y ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <button type="submit">
                    <i class="fas fa-filter"></i>
                    Lọc dữ liệu
                </button>
                <button type="button" class="export-button" onclick="exportToPDF()">
                    <i class="fas fa-file-pdf"></i>
                    Xuất PDF
                </button>
            </form>
        </div>

        <div class="charts-container">
            <!-- Left Side: Two Vertical Charts -->
            <div class="left-charts">
                <!-- Chart 1: Insurance and Tax by Department -->
                <div class="chart-card">
                    <h3 class="chart-title">
                        <i class="fas fa-file-invoice"></i>
                        Bảo hiểm và thuế theo phòng ban
                    </h3>
                    <canvas id="insuranceTaxChart"></canvas>
                    <?php if (empty($insuranceTaxData) || !array_filter($insuranceTaxData, fn($row) => $row['bhxh'] > 0 || $row['bhyt'] > 0 || $row['bhtn'] > 0 || $row['thue_tncn'] > 0)): ?>
                        <div class="no-data">
                            <i class="fas fa-file-invoice"></i>
                            <p>Không có dữ liệu bảo hiểm và thuế</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Chart 2: Bonuses/Penalties and Payroll -->
                <div class="chart-card">
                    <h3 class="chart-title">
                        <i class="fas fa-money-check-alt"></i>
                        Thưởng, phạt và lương theo phòng ban
                    </h3>
                    <canvas id="bonusPayrollChart"></canvas>
                    <?php if (empty($bonusPayrollData) || !array_filter($bonusPayrollData, fn($row) => $row['tong_thuong'] >= 0 || $row['tong_phat'] >= 0 || $row['luong_thuc_nhan'] >= 0)): ?>
                        <div class="no-data">
                            <i class="fas fa-money-check-alt"></i>
                            <p>Không có dữ liệu thưởng, phạt và lương</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Right Side: KPI Cards -->
            <div class="chart-card">
                <h3 class="chart-title">
                    <i class="fas fa-info-circle"></i>
                    Chỉ số tài chính
                </h3>
                <div class="kpi-container">
                    <div class="kpi-card">
                        <i class="fas fa-users"></i>
                        <div class="kpi-value"><?= number_format($totalEmployees, 0, ',', '.') ?></div>
                        <div class="kpi-label">Tổng số nhân viên</div>
                    </div>
                    <div class="kpi-card">
                        <i class="fas fa-shield-alt"></i>
                        <div class="kpi-value"><?= number_format($totalInsurance, 0, ',', '.') ?> VNĐ</div>
                        <div class="kpi-label">Tổng bảo hiểm</div>
                    </div>
                    <div class="kpi-card">
                        <i class="fas fa-calculator"></i>
                        <div class="kpi-value"><?= number_format($totalTax, 0, ',', '.') ?> VNĐ</div>
                        <div class="kpi-label">Tổng thuế TNCN</div>
                    </div>
                    <div class="kpi-card">
                        <i class="fas fa-money-bill-wave"></i>
                        <div class="kpi-value"><?= number_format($totalBonusPenalty, 0, ',', '.') ?> VNĐ</div>
                        <div class="kpi-label">Tổng thưởng/phạt</div>
                    </div>
                    <div class="kpi-card">
                        <i class="fas fa-wallet"></i>
                        <div class="kpi-value"><?= number_format($totalSalary, 0, ',', '.') ?> VNĐ</div>
                        <div class="kpi-label">Tổng lương thực nhận</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pagination Buttons -->
       <div class="pagination">
    <button id="prevPage"><i class="fas fa-chevron-left"></i> Trang trước</button>
    <button id="nextPage"><i class="fas fa-chevron-right"></i> Trang sau</button>
</div>
    </div>

    <script>
        // Register ChartDataLabels plugin
        Chart.register(ChartDataLabels);

        // Chart colors
        const chartColors = {
            primary: '#5a67d8',
            secondary: '#4c51bf',
            success: '#48bb78',
            danger: '#f56565',
            warning: '#ed8936',
            info: '#4299e1',
            light: '#f7fafc',
            dark: '#1a202c'
        };

        // Common chart options
        const chartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                tooltip: {
                    backgroundColor: 'rgba(26, 32, 44, 0.9)',
                    titleFont: { size: 14, family: 'Inter', weight: 'bold' },
                    bodyFont: { size: 12, family: 'Inter' },
                    padding: 8,
                    cornerRadius: 6,
                    displayColors: true,
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) label += ': ';
                            let value = context.parsed.y || context.parsed;
                            return `${label}${value.toLocaleString('vi-VN')} VNĐ`;
                        }
                    }
                },
                legend: {
                    labels: {
                        font: { size: 12, family: 'Inter' },
                        padding: 8,
                        color: '#1a202c',
                        usePointStyle: true,
                        pointStyle: 'circle'
                    },
                    position: 'top'
                },
                datalabels: {
                    font: { size: 10, family: 'Inter', weight: 'bold' },
                    color: '#1a202c',
                    anchor: 'end',
                    align: 'top',
                    offset: 5,
                    formatter: function(value, context) {
                        if (context.dataset.type === 'line') {
                            return value ? value.toLocaleString('vi-VN') + ' VNĐ' : '';
                        } else if (context.dataset.type === 'bar' && context.dataset.label === 'Lương thực nhận') {
                            return value ? value.toLocaleString('vi-VN') + ' VNĐ' : '';
                        }
                        return '';
                    }
                }
            },
            animation: {
                duration: 800,
                easing: 'easeOutQuart'
            },
            layout: {
                padding: {
                    bottom: 20
                }
            }
        };

        // 1. Insurance and Tax Chart (Grouped Bar Chart, 5 Departments with X-Axis Labels)
        const insuranceTaxData = {
            labels: [<?php foreach ($insuranceTaxData as $row) echo "'" . addslashes($row['ten_phong_ban']) . "',"; ?>],
            datasets: [
                {
                    label: 'Bảo hiểm xã hội',
                    data: [<?php foreach ($insuranceTaxData as $row) echo $row['bhxh'] . ","; ?>],
                    backgroundColor: chartColors.primary,
                    borderRadius: 4
                },
                {
                    label: 'Bảo hiểm y tế',
                    data: [<?php foreach ($insuranceTaxData as $row) echo $row['bhyt'] . ","; ?>],
                    backgroundColor: chartColors.success,
                    borderRadius: 4
                },
                {
                    label: 'Bảo hiểm thất nghiệp',
                    data: [<?php foreach ($insuranceTaxData as $row) echo $row['bhtn'] . ","; ?>],
                    backgroundColor: chartColors.info,
                    borderRadius: 4
                },
                {
                    label: 'Thuế TNCN',
                    data: [<?php foreach ($insuranceTaxData as $row) echo $row['thue_tncn'] . ","; ?>],
                    backgroundColor: chartColors.danger,
                    borderRadius: 4
                }
            ]
        };

        if (insuranceTaxData.datasets.some(dataset => dataset.data.some(value => value > 0))) {
            new Chart(document.getElementById('insuranceTaxChart'), {
                type: 'bar',
                data: insuranceTaxData,
                options: {
                    ...chartOptions,
                    plugins: {
                        ...chartOptions.plugins,
                        datalabels: {
                            display: false // Disable datalabels for monetary values
                        }
                    },
                    scales: {
                        x: {
                            grid: { display: false },
                            ticks: {
                                display: true,
                                font: { size: 10, family: 'Inter' },
                                color: '#718096',
                                maxRotation: 0,
                                minRotation: 0
                            }
                        },
                        y: {
                            beginAtZero: true,
                            grid: { color: '#e2e8f0' },
                            ticks: {
                                font: { size: 12, family: 'Inter' },
                                color: '#718096',
                                callback: function(value) {
                                    return value.toLocaleString('vi-VN');
                                }
                            },
                            title: {
                                display: true,
                                text: 'Số tiền (VNĐ)',
                                font: { size: 12, family: 'Inter' }
                            }
                        }
                    }
                }
            });
        }

        // 2. Bonuses/Penalties and Payroll Chart (Combo Bar/Line, 5 Departments, Net Salary as Bar with Values, Bonuses/Penalties as Lines)
       // 2. Bonuses/Penalties and Payroll Chart (Combo Bar/Line)
const bonusPayrollData = {
    labels: [<?php foreach ($bonusPayrollData as $row) echo "'" . addslashes($row['ten_phong_ban']) . "',"; ?>],
    datasets: [
        // Bar dataset (Net Salary) - vẽ đầu tiên (nằm dưới)
        {
            label: 'Lương thực nhận',
            data: [<?php foreach ($bonusPayrollData as $row) echo $row['luong_thuc_nhan'] . ","; ?>],
            backgroundColor: chartColors.primary + '80', // Thêm độ trong suốt
            borderColor: chartColors.primary,
            borderWidth: 1,
            type: 'bar',
            borderRadius: 4,
            yAxisID: 'y'
        },
        // Line datasets (Bonuses and Penalties) - vẽ sau (nằm trên)
        {
            label: 'Thưởng',
            data: [<?php foreach ($bonusPayrollData as $row) echo $row['tong_thuong'] . ","; ?>],
            borderColor: chartColors.success,
            backgroundColor: 'transparent',
            borderWidth: 2, // Tăng độ dày
            type: 'line',
            tension: 0.1, // Giảm độ cong
            fill: false,
            yAxisID: 'y2',
            pointBackgroundColor: '#fff',
            pointBorderColor: chartColors.success,
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 7
        },
        {
            label: 'Phạt',
            data: [<?php foreach ($bonusPayrollData as $row) echo $row['tong_phat'] . ","; ?>],
            borderColor: chartColors.danger,
            backgroundColor: 'transparent',
            borderWidth: 3, // Tăng độ dày
            type: 'line',
            tension: 0.1, // Giảm độ cong
            fill: false,
            yAxisID: 'y2',
            pointBackgroundColor: '#fff',
            pointBorderColor: chartColors.danger,
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 7
        }
    ]
};

        if (bonusPayrollData.datasets.some(dataset => dataset.data.some(value => value > 0))) {
            new Chart(document.getElementById('bonusPayrollChart'), {
                type: 'bar',
                data: bonusPayrollData,
                options: {
                    ...chartOptions,
                    scales: {
                        x: {
                            grid: { display: false },
                            ticks: {
                                display: true,
                                font: { size: 10, family: 'Inter' },
                                color: '#718096',
                                maxRotation: 0,
                                minRotation: 0
                            }
                        },
                        y: {
                            beginAtZero: true,
                            grid: { color: '#e2e8f0' },
                            ticks: {
                                font: { size: 12, family: 'Inter' },
                                color: '#718096',
                                callback: function(value) {
                                    return value.toLocaleString('vi-VN');
                                }
                            },
                            title: {
                                display: true,
                                text: 'Lương thực nhận (VNĐ)',
                                font: { size: 12, family: 'Inter' }
                            }
                        },
                        y2: {
                            position: 'right',
                            beginAtZero: true,
                            grid: { display: false },
                            ticks: {
                                font: { size: 12, family: 'Inter' },
                                color: '#718096',
                                callback: function(value) {
                                    return value.toLocaleString('vi-VN');
                                }
                            },
                            title: {
                                display: true,
                                text: 'Thưởng/Phạt (VNĐ)',
                                font: { size: 12, family: 'Inter' }
                            }
                        }
                    }
                }
            });
        }

        // Pagination event listeners
       // Pagination event listeners
document.getElementById('prevPage').addEventListener('click', () => {
    const month = document.getElementById('month').value;
    const year = document.getElementById('year').value;
    window.location.href = `baocao.php?month=${month}&year=${year}`;
});

document.getElementById('nextPage').addEventListener('click', () => {
    const month = document.getElementById('month').value;
    const year = document.getElementById('year').value;
    window.location.href = `baocao2.php?month=${month}&year=${year}`;
});

        // Export to PDF
        function exportToPDF() {
            const element = document.querySelector('.main-content');
            const opt = {
                margin: 5,
                filename: `bao_cao_tai_chinh_thang_${<?= $month ?>}_${<?= $year ?>}.pdf`,
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2, useCORS: true },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            html2pdf().set(opt).from(element).save();
        }
    </script>
</body>
</html>