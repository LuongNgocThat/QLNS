<?php
require_once __DIR__ . '/../includes/check_login.php';
include(__DIR__ . '/../includes/header.php');
include(__DIR__ . '/../includes/sidebar.php');

// Kiểm tra quyền cài đặt
if (!isset($_SESSION['user_id']) || !$_SESSION['quyen_them'] || !$_SESSION['quyen_sua'] || !$_SESSION['quyen_xoa']) {
    header("Location: /doanqlns/views/login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cài đặt Tài khoản Người Dùng</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">

    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f7f6;
            color: #333;
            line-height: 1.6;
        }

        .main-content {
            padding: 20px;
        }

        .settings-container {
            max-width: 750px;
            margin: 30px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
            animation: slideIn 0.5s ease-out;
        }

        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .settings-container h2 {
            color: #2c3e50;
            margin-bottom: 25px;
            font-weight: 500;
        }

        .settings-buttons {
            margin-bottom: 30px;
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        .settings-buttons button {
            padding: 10px 20px;
            margin: 0 10px;
            border: none;
            border-radius: 4px;
            background: #f0f0f0;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .settings-buttons button.active {
            background: #007bff;
            color: white;
        }

        .settings-buttons button:hover {
            background: #e0e0e0;
        }

        .settings-buttons button.active:hover {
            background: #0056b3;
        }
        
        .settings-buttons button.active-btn {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
        }

        .form-container {
            display: none;
            margin-top: 20px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            animation: fadeIn 0.3s ease-in-out;
        }

        .form-container.active {
            display: block;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .form-container h3 {
            color: #34495e;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 500;
        }

        .form-group {
            margin-bottom: 20px;
            position: relative;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.3s ease;
            background-color: white;
        }

        .form-group input:focus {
            border-color: #3498db;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
            outline: none;
        }

        .form-group input::placeholder {
            color: #95a5a6;
        }

        .role-buttons {
            margin: 20px 0;
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        .role-buttons button {
            padding: 10px 20px;
            font-size: 14px;
            cursor: pointer;
            border: none;
            border-radius: 20px;
            background-color: #ecf0f1;
            color: #7f8c8d;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .role-buttons button:hover {
            background-color: #bdc3c7;
            color: #2c3e50;
            transform: translateY(-1px);
        }

        .role-buttons button.selected {
            background: linear-gradient(135deg, #2ecc71, #27ae60);
            color: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .form-container button[type="submit"] {
            width: 100%;
            padding: 14px;
            font-size: 16px;
            background: linear-gradient(135deg, #2ecc71, #27ae60);
            color: white;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 20px;
            position: relative;
            overflow: hidden;
        }

        .form-container button[type="submit"]:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .form-container button[type="submit"]:before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: 0.5s;
        }

        .form-container button[type="submit"]:hover:before {
            left: 100%;
        }

        .message {
            padding: 12px;
            margin-top: 15px;
            border-radius: 8px;
            font-size: 14px;
            text-align: center;
            display: none;
            animation: fadeIn 0.3s ease-in-out;
        }

        .message.active {
            display: block;
        }

        .message.error {
            background-color: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        .message.success {
            background-color: #dcfce7;
            color: #166534;
            border: 1px solid #bbf7d0;
        }

        .message.info {
            background-color: #e7f3fe;
            color: #1e4976;
            border: 1px solid #b3d4fc;
        }

        .loading {
            position: relative;
            pointer-events: none;
        }

        .loading:after {
            content: '';
            position: absolute;
            width: 20px;
            height: 20px;
            top: 50%;
            left: 50%;
            margin: -10px 0 0 -10px;
            border: 2px solid #fff;
            border-radius: 50%;
            border-left-color: transparent;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
            }
            .settings-container {
                margin: 20px;
                padding: 20px;
            }
            .settings-buttons button {
                width: calc(48% - 10px);
                margin-bottom: 10px;
            }
        }
        @media (max-width: 480px) {
            .settings-buttons button {
                width: calc(100% - 20px);
            }
            .role-buttons button {
                width: calc(33% - 10px);
            }
        }

        .table-responsive {
            overflow-x: auto;
            margin-top: 20px;
        }

        .user-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .user-table th,
        .user-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
            max-width: 200px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .user-table th {
            background: #f8f9fa;
            font-weight: 500;
            color: #2c3e50;
        }

        .user-table tr:hover {
            background-color: #f5f6f7;
        }

        .user-table td:hover {
            overflow: visible;
            white-space: normal;
            word-break: break-all;
        }

        .action-btn {
            padding: 6px 12px;
            margin: 0 4px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .edit-btn {
            background: #3498db;
            color: white;
        }

        .delete-btn {
            background: #e74c3c;
            color: white;
        }

        .action-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .permission-toggle, .status-toggle {
            width: 46px;
            height: 24px;
            background-color: #e0e0e0;
            border-radius: 12px;
            position: relative;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0.0, 0.2, 1);
            box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
            margin: 0 auto;
        }

        .permission-toggle::after, .status-toggle::after {
            content: '';
            position: absolute;
            width: 20px;
            height: 20px;
            background-color: white;
            border-radius: 50%;
            top: 2px;
            left: 2px;
            transition: transform 0.3s cubic-bezier(0.4, 0.0, 0.2, 1), background-color 0.3s ease;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .permission-toggle.active {
            background-color: #4CAF50;
        }

        .status-toggle.active {
            background-color: #2196F3;
        }

        .permission-toggle.active::after, .status-toggle.active::after {
            transform: translateX(22px);
        }

        .permission-toggle:hover::after, .status-toggle:hover::after {
            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.3);
        }

        .permission-toggle.disabled, .status-toggle.disabled {
            opacity: 0.6;
            cursor: not-allowed;
            pointer-events: none;
        }

        .permission-toggle.processing, .status-toggle.processing {
            animation: pulse 1.5s infinite;
        }

        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.6; }
            100% { opacity: 1; }
        }

        .status-label {
            margin-left: 8px;
            font-size: 14px;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .status-label[data-status="Hoạt động"] {
            color: #2196F3;
        }

        .status-label[data-status="Không hoạt động"] {
            color: #757575;
        }

        .role-btn {
            position: relative;
            overflow: hidden;
            transform: translate3d(0, 0, 0);
            padding: 8px 16px;
            background: #f5f5f5;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .role-btn:hover {
            background: #e0e0e0;
        }

        .role-btn.selected {
            background: #2196F3;
            color: white;
        }

        .role-btn::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 5px;
            height: 5px;
            background: rgba(255, 255, 255, .5);
            opacity: 0;
            border-radius: 100%;
            transform: scale(1, 1) translate(-50%);
            transform-origin: 50% 50%;
        }

        .role-btn:focus:not(:active)::after {
            animation: ripple 1s ease-out;
        }

        @keyframes ripple {
            0% {
                transform: scale(0, 0);
                opacity: 0.5;
            }
            100% {
                transform: scale(100, 100);
                opacity: 0;
            }
        }

        .fingerprint-list {
            list-style: none;
            padding: 0;
            margin: 20px 0;
        }

        .fingerprint-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            margin-bottom: 10px;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }

        .fingerprint-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .fingerprint-icon {
            color: #3498db;
            font-size: 24px;
        }

        .fingerprint-details {
            flex-grow: 1;
        }

        .fingerprint-name {
            font-weight: 500;
            color: #2c3e50;
            margin-bottom: 4px;
        }

        .fingerprint-date {
            font-size: 12px;
            color: #6c757d;
        }

        .fingerprint-actions button {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .fingerprint-delete {
            background: #dc3545;
            color: white;
        }

        .fingerprint-delete:hover {
            background: #c82333;
        }

        .add-fingerprint-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 20px;
        }

        .add-fingerprint-btn:hover {
            background: #2980b9;
        }

        .fingerprint-scanner {
            display: none;
            flex-direction: column;
            align-items: center;
            margin: 20px 0;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 12px;
            border: 2px solid #e3f2fd;
        }

        .fingerprint-scanner.active {
            display: flex;
        }

        .scanner-animation {
            width: 150px;
            height: 150px;
            position: relative;
            margin: 20px 0;
        }

        .fingerprint-icon {
            font-size: 120px;
            color: #3498db;
            opacity: 0.7;
        }

        .scan-line {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, transparent, #4CAF50, transparent);
            animation: scanning 2s linear infinite;
            opacity: 0;
        }

        .scanning .scan-line {
            opacity: 1;
        }

        @keyframes scanning {
            0% {
                top: 0;
            }
            100% {
                top: 100%;
            }
        }

        .scanner-status {
            text-align: center;
            margin-top: 15px;
            font-size: 16px;
            color: #2c3e50;
        }

        .scanner-instructions {
            text-align: center;
            margin-top: 10px;
            color: #666;
            font-size: 14px;
        }

        .cancel-scan-btn {
            margin-top: 15px;
            padding: 8px 20px;
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .cancel-scan-btn:hover {
            background: #c82333;
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
                opacity: 0.7;
            }
            50% {
                transform: scale(1.05);
                opacity: 0.9;
            }
            100% {
                transform: scale(1);
                opacity: 0.7;
            }
        }

        .scanning .fingerprint-icon {
            animation: pulse 2s infinite;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        .form-control:focus {
            border-color: #3498db;
            outline: none;
            box-shadow: 0 0 5px rgba(52, 152, 219, 0.5);
        }

        select.form-control {
            background-color: white;
            cursor: pointer;
        }

        select.form-control option {
            padding: 10px;
        }
    </style>
</head>
<body>
<div class="main-content">
    <div class="settings-container">
        <h2><i class="fas fa-cog"></i> Cài đặt Hệ thống</h2>
        
        <div class="settings-buttons">
            <button id="registerBtn" onclick="showForm('register')">
                <i class="fas fa-user-plus"></i> Đăng ký tài khoản
            </button>
            <button id="manageBtn" onclick="showForm('manage')">
                <i class="fas fa-users-cog"></i> Quản lý người dùng
            </button>
            <button id="fingerprintBtn" onclick="showForm('fingerprint')">
                <i class="fas fa-fingerprint"></i> Vân tay
            </button>
            <button id="fingerprintManageBtn" onclick="showForm('fingerprintManage')">
                <i class="fas fa-list"></i> Quản lý vân tay
            </button>
        </div>

        

        <div id="registerForm" class="form-container">
            <h3><i class="fas fa-user"></i> Đăng ký tài khoản</h3>
            <form id="form-regular" method="POST">
                <div class="form-group">
                    <input type="text" name="ten_dang_nhap" placeholder="Tên đăng nhập" required>
                </div>
                <div class="form-group">
                    <input type="email" name="email" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <input type="password" name="mat_khau" placeholder="Mật khẩu" required>
                </div>
                <div class="form-group">
                    <input type="password" name="confirm_mat_khau" placeholder="Xác nhận mật khẩu" required>
                </div>
                <div class="role-buttons">
                    <button type="button" class="role-btn" onclick="selectRole('admin', this)">Admin</button>
                    <button type="button" class="role-btn" onclick="selectRole('manager', this)">Quản Lý</button>
                    <button type="button" class="role-btn" onclick="selectRole('employee', this)">Nhân Viên</button>
                </div>
                <input type="hidden" name="role">
                <button type="submit"><i class="fas fa-paper-plane"></i> Đăng ký</button>
            </form>
            <p id="register-regular-message" class="message"></p>
        </div>

        <div id="manageForm" class="form-container">
            <h3><i class="fas fa-users"></i> Danh sách người dùng</h3>
            <div class="table-responsive">
                <table class="user-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>ID Nhân viên</th>
                            <th>Tên đăng nhập</th>
                            <th>Email</th>
                            <th>Quyền thêm</th>
                            <th>Quyền sửa</th>
                            <th>Quyền xóa</th>
                            <th>Trạng thái</th>
                        </tr>
                    </thead>
                    <tbody id="user-list-body">
                        <!-- Dữ liệu sẽ được thêm vào đây bằng JavaScript -->
                    </tbody>
                </table>
            </div>
            <p id="user-list-message" class="message"></p>
        </div>

        <div id="fingerprintForm" class="form-container">
            <h3><i class="fas fa-fingerprint"></i> Quản lý Vân tay</h3>
            
            <div class="form-group">
                <select id="employeeSelect" class="form-control">
                    <option value="">-- Chọn nhân viên --</option>
                </select>
            </div>
            
            <button class="add-fingerprint-btn" onclick="startFingerprintEnrollment()">
                <i class="fas fa-plus"></i>
                Thêm vân tay mới
            </button>

            <div id="enrollment-status" class="message" style="display: none;"></div>

            <div id="fingerprintScanner" class="fingerprint-scanner">
                <div class="scanner-animation">
                    <i class="fas fa-fingerprint fingerprint-icon"></i>
                    <div class="scan-line"></div>
                </div>
                <div class="scanner-status">Đang chờ vân tay...</div>
                <div class="scanner-instructions">Vui lòng đặt ngón tay lên cảm biến</div>
                <button class="cancel-scan-btn" onclick="cancelScanning()">
                    <i class="fas fa-times"></i> Hủy
                </button>
            </div>

            <ul class="fingerprint-list" id="fingerprint-list">
                <!-- Danh sách vân tay sẽ được thêm vào đây bằng JavaScript -->
            </ul>
        </div>

        <div id="fingerprintManageForm" class="form-container">
            <h3><i class="fas fa-list"></i> Quản lý Thông tin Vân tay</h3>
            <div class="table-responsive">
                <table class="user-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>ID Nhân viên</th>
                            <th>Tên nhân viên</th>
                            <th>Mã vân tay</th>
                            <th>Ngày tạo</th>
                            <th>Trạng thái</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody id="fingerprint-manage-list">
                        <!-- Dữ liệu sẽ được thêm vào đây bằng JavaScript -->
                    </tbody>
                </table>
            </div>
            <p id="fingerprint-manage-message" class="message"></p>
        </div>
    </div>

    
</div>

<script>
    console.log('Settings script loaded');

    document.addEventListener('DOMContentLoaded', () => {
        showForm('register');

        const formRegular = document.getElementById('form-regular');
        if (formRegular) {
            formRegular.addEventListener('submit', async function(e) {
                e.preventDefault();
                const submitBtn = this.querySelector('button[type="submit"]');
                submitBtn.classList.add('loading');
                await handleFormSubmit(this, document.getElementById('register-regular-message'));
                submitBtn.classList.remove('loading');
            });
        }

        const buttons = document.querySelectorAll('button');
        buttons.forEach(button => {
            button.addEventListener('click', function(e) {
                const x = e.clientX - e.target.offsetLeft;
                const y = e.clientY - e.target.offsetTop;

                const ripples = document.createElement('span');
                ripples.style.left = x + 'px';
                ripples.style.top = y + 'px';
                this.appendChild(ripples);

                setTimeout(() => {
                    ripples.remove();
                }, 1000);
            });
        });

        document.getElementById('manageBtn').addEventListener('click', loadUserList);
        document.getElementById('fingerprintBtn').addEventListener('click', () => {
            showForm('fingerprint');
            loadEmployeeList();
            loadFingerprintList();
        });
        document.getElementById('fingerprintManageBtn').addEventListener('click', loadFingerprintManageList);
    });

    function showForm(formType) {
        document.querySelectorAll('.form-container').forEach(form => {
            form.classList.remove('active');
            form.style.opacity = '0';
        });
        
        document.querySelectorAll('.settings-buttons button').forEach(button => {
            button.classList.remove('active');
        });
        
        const targetForm = document.getElementById(formType + 'Form');
        const targetButton = document.getElementById(formType + 'Btn');
        
        targetForm.classList.add('active');
        targetButton.classList.add('active');

        requestAnimationFrame(() => {
            targetForm.style.transition = 'opacity 0.3s ease';
            targetForm.style.opacity = '1';
        });
    }

    function selectRole(role, clickedButton) {
        const formContainer = clickedButton.closest('.form-container');
        if (!formContainer) return;

        formContainer.querySelectorAll('.role-btn').forEach(btn => {
            btn.classList.remove('selected');
        });
        clickedButton.classList.add('selected');

        const roleInput = formContainer.querySelector('input[name="role"]');
        if (roleInput) {
            roleInput.value = role;
        }
    }

    async function handleFormSubmit(form, messageElement) {
        try {
            const submitBtn = form.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.classList.add('loading');

            const roleInput = form.querySelector('input[name="role"]');
            if (!roleInput || !roleInput.value) {
                showMessage(messageElement, 'Vui lòng chọn vai trò người dùng', 'error');
                return;
            }

            if (form.id === 'form-regular') {
                const password = form.querySelector('input[name="mat_khau"]').value;
                const confirmPassword = form.querySelector('input[name="confirm_mat_khau"]').value;
                if (password !== confirmPassword) {
                    showMessage(messageElement, 'Mật khẩu xác nhận không khớp', 'error');
                    return;
                }
            }

            const formData = new FormData(form);
            const data = {};
            formData.forEach((value, key) => {
                if (key !== 'confirm_mat_khau') {
                    data[key] = value;
                }
            });

            const endpoint = '/doanqlns/index.php/api/settings/register-regular';

            const response = await fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            
            if (result.success) {
                showMessage(messageElement, result.message, 'success');
                form.reset();
                form.querySelectorAll('.role-btn').forEach(btn => btn.classList.remove('selected'));
                if (roleInput) roleInput.value = '';
                
                if (document.getElementById('manageForm').classList.contains('active')) {
                    loadUserList();
                }
            } else {
                showMessage(messageElement, result.message || 'Lỗi khi đăng ký', 'error');
            }
        } catch (error) {
            console.error('Error:', error);
            showMessage(messageElement, 'Lỗi khi xử lý yêu cầu: ' + error.message, 'error');
        } finally {
            const submitBtn = form.querySelector('button[type="submit"]');
            submitBtn.disabled = false;
            submitBtn.classList.remove('loading');
        }
    }

    function showMessage(element, message, type) {
        element.textContent = message;
        element.className = `message ${type}`;
        
        element.style.opacity = '0';
        element.classList.add('active');
        
        requestAnimationFrame(() => {
            element.style.transition = 'opacity 0.3s ease';
            element.style.opacity = '1';
        });

        setTimeout(() => {
            element.style.opacity = '0';
            setTimeout(() => {
                element.classList.remove('active');
            }, 300);
        }, 3000);
    }

    async function loadUserList() {
        try {
            console.log('Loading user list...');
            const response = await fetch('/doanqlns/index.php/api/settings/users');

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            
            if (result.success) {
                const tbody = document.getElementById('user-list-body');
                tbody.innerHTML = '';

                result.data.forEach(user => {
                    // Bỏ qua user có ID = 1 (admin)
                    if (user.id === 1) return;
                    
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${user.id}</td>
                        <td>${user.id_nhan_vien || 'N/A'}</td>
                        <td>${user.ten_dang_nhap || 'N/A'}</td>
                        <td>${user.email || 'N/A'}</td>
                        <td>
                            <div class="permission-toggle ${user.quyen_them ? 'active' : ''}" 
                                 onclick="togglePermission(this, ${user.id}, 'quyen_them')"
                                 title="Quyền thêm"></div>
                        </td>
                        <td>
                            <div class="permission-toggle ${user.quyen_sua ? 'active' : ''}"
                                 onclick="togglePermission(this, ${user.id}, 'quyen_sua')"
                                 title="Quyền sửa"></div>
                        </td>
                        <td>
                            <div class="permission-toggle ${user.quyen_xoa ? 'active' : ''}"
                                 onclick="togglePermission(this, ${user.id}, 'quyen_xoa')"
                                 title="Quyền xóa"></div>
                        </td>
                        <td>
                            <div class="status-toggle ${user.trang_thai === 'Hoạt động' ? 'active' : ''}"
                                 onclick="toggleUserStatus(this, ${user.id})"
                                 data-user-id="${user.id}"
                                 title="Click để thay đổi trạng thái"></div>
                            <span class="status-label" data-status="${user.trang_thai}">${user.trang_thai}</span>
                        </td>
                    `;
                    tbody.appendChild(row);
                });
            } else {
                showMessage(document.getElementById('user-list-message'), result.message, 'error');
            }
        } catch (error) {
            console.error('Error:', error);
            showMessage(document.getElementById('user-list-message'), 'Lỗi khi tải danh sách người dùng: ' + error.message, 'error');
        }
    }

    async function togglePermission(element, userId, permission) {
        try {
            if (element.classList.contains('processing')) {
                return;
            }

            element.classList.add('processing', 'disabled');
            
            const isActive = !element.classList.contains('active');
            const data = {
                [permission]: isActive ? 1 : 0
            };

            const response = await fetch(`/doanqlns/index.php/api/settings/permissions/${userId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            
            if (result.success) {
                element.classList.toggle('active', isActive);
                showMessage(document.getElementById('user-list-message'), 
                    `${permission.replace('quyen_', 'Quyền ')} đã được ${isActive ? 'bật' : 'tắt'}`, 
                    'success'
                );
            } else {
                showMessage(document.getElementById('user-list-message'), 
                    result.message || 'Lỗi khi cập nhật quyền', 
                    'error'
                );
            }
        } catch (error) {
            console.error('Error:', error);
            showMessage(document.getElementById('user-list-message'), 
                'Lỗi khi cập nhật quyền: ' + error.message, 
                'error'
            );
        } finally {
            setTimeout(() => {
                element.classList.remove('processing', 'disabled');
            }, 300);
        }
    }

    async function toggleUserStatus(element, userId) {
        try {
            const toggleElement = element;
            const statusLabel = toggleElement.nextElementSibling;

            if (toggleElement.classList.contains('processing')) {
                return;
            }

            const isCurrentlyActive = toggleElement.classList.contains('active');
            const newStatus = isCurrentlyActive ? 'Không hoạt động' : 'Hoạt động';

            if (!confirm(`Bạn có muốn thay đổi trạng thái thành "${newStatus}" không?`)) {
                return;
            }

            toggleElement.classList.add('processing', 'disabled');
            
            const response = await fetch(`/doanqlns/index.php/api/settings/user-status/${userId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ trang_thai: newStatus })
            });

            let result;
            const contentType = response.headers.get("content-type");
            if (contentType && contentType.indexOf("application/json") !== -1) {
                result = await response.json();
            } else {
                throw new Error("Phản hồi không phải định dạng JSON");
            }
            
            if (result.success) {
                toggleElement.classList.toggle('active');
                statusLabel.textContent = newStatus;
                statusLabel.setAttribute('data-status', newStatus);
                showMessage(document.getElementById('user-list-message'), 
                    `Trạng thái đã được chuyển thành ${newStatus}`, 
                    'success'
                );
            } else {
                throw new Error(result.message || 'Lỗi khi cập nhật trạng thái');
            }
        } catch (error) {
            console.error('Error:', error);
            showMessage(document.getElementById('user-list-message'), 
                'Lỗi khi cập nhật trạng thái: ' + error.message, 
                'error'
            );
            // Khôi phục trạng thái UI
            element.classList.remove('active');
            const statusLabel = element.nextElementSibling;
            statusLabel.textContent = element.classList.contains('active') ? 'Hoạt động' : 'Không hoạt động';
            statusLabel.setAttribute('data-status', element.classList.contains('active') ? 'Hoạt động' : 'Không hoạt động');
        } finally {
            setTimeout(() => {
                element.classList.remove('processing', 'disabled');
            }, 300);
        }
    }

    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('vi-VN', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    async function loadEmployeeList() {
        try {
            const response = await fetch('/doanqlns/index.php/api/users');
            if (!response.ok) {
                throw new Error(`Lỗi khi tải danh sách nhân viên: ${response.status}`);
            }
            const result = await response.json();
            
            if (!Array.isArray(result)) {
                throw new Error('Dữ liệu nhân viên không hợp lệ');
            }

            const select = document.getElementById('employeeSelect');
            select.innerHTML = '<option value="">-- Chọn nhân viên --</option>';

            result.forEach(user => {
                if (user.id_nhan_vien && user.ho_ten) {
                    const option = document.createElement('option');
                    option.value = user.id_nhan_vien;
                    option.textContent = `${user.ho_ten} (ID: ${user.id_nhan_vien})`;
                    select.appendChild(option);
                }
            });
        } catch (error) {
            console.error('Error:', error);
            showMessage(document.getElementById('enrollment-status'), 
                'Lỗi khi tải danh sách nhân viên: ' + error.message, 'error');
        }
    }

    async function startFingerprintEnrollment() {
        try {
            const employeeSelect = document.getElementById('employeeSelect');
            const employeeId = employeeSelect.value;
            
            if (!employeeId) {
                showMessage(document.getElementById('enrollment-status'), 
                    'Vui lòng chọn nhân viên trước khi thêm vân tay', 'error');
                return;
            }

            const statusElement = document.getElementById('enrollment-status');
            const scannerElement = document.getElementById('fingerprintScanner');
            
            scannerElement.classList.add('active');
            scannerElement.querySelector('.scanner-animation').classList.add('scanning');
            
            statusElement.style.display = 'block';
            showMessage(statusElement, 'Đang khởi tạo cảm biến vân tay...', 'info');

            // Kiểm tra hỗ trợ Web Biometrics API
            if (!window.PublicKeyCredential || 
                !PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable) {
                showMessage(statusElement, 'Trình duyệt của bạn không hỗ trợ xác thực sinh trắc học', 'error');
                stopScanning();
                return;
            }

            // Kiểm tra xem thiết bị có hỗ trợ xác thực sinh trắc học không
            const available = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
            if (!available) {
                showMessage(statusElement, 'Thiết bị của bạn không có cảm biến vân tay hoặc không hỗ trợ xác thực sinh trắc học', 'error');
                stopScanning();
                return;
            }

            showMessage(statusElement, 'Vui lòng đặt ngón tay lên cảm biến...', 'info');

            // Tạo challenge ngẫu nhiên
            const challenge = new Uint8Array(32);
            window.crypto.getRandomValues(challenge);

            // Tạo options cho credential
            const publicKeyCredentialCreationOptions = {
                challenge: challenge,
                rp: {
                    name: "Hệ thống quản lý nhân sự",
                    id: window.location.hostname
                },
                user: {
                    id: Uint8Array.from(employeeId, c => c.charCodeAt(0)),
                    name: employeeSelect.options[employeeSelect.selectedIndex].text,
                    displayName: employeeSelect.options[employeeSelect.selectedIndex].text
                },
                pubKeyCredParams: [{
                    type: "public-key",
                    alg: -7 // ES256
                }],
                authenticatorSelection: {
                    authenticatorAttachment: "platform",
                    requireResidentKey: false,
                    userVerification: "required"
                },
                timeout: 60000,
                attestation: "direct"
            };

            try {
                // Yêu cầu người dùng xác thực bằng vân tay
                const credential = await navigator.credentials.create({
                    publicKey: publicKeyCredentialCreationOptions
                });

                if (credential) {
                    // Chuyển đổi dữ liệu vân tay thành định dạng có thể lưu trữ
                    const fingerprintData = {
                        id: credential.id,
                        rawId: Array.from(new Uint8Array(credential.rawId)),
                        type: credential.type,
                        response: {
                            attestationObject: Array.from(new Uint8Array(credential.response.attestationObject)),
                            clientDataJSON: Array.from(new Uint8Array(credential.response.clientDataJSON))
                        }
                    };

                    // Chuyển đổi dữ liệu thành chuỗi Base64
                    const fingerprintString = JSON.stringify(fingerprintData);
                    const fingerprintBase64 = btoa(fingerprintString);

                    // Gửi dữ liệu vân tay lên server
            const response = await fetch('/doanqlns/index.php/api/settings/fingerprint/enroll', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            id_nhan_vien: employeeId,
                            du_lieu_van_tay: fingerprintBase64,
                            trang_thai: 'completed'
                        })
            });

            const result = await response.json();
            
            if (result.success) {
                        showMessage(statusElement, 'Đã lưu vân tay thành công!', 'success');
                        setTimeout(() => {
                            stopScanning();
                            loadFingerprintList();
                        }, 1500);
            } else {
                        throw new Error(result.message || 'Không thể lưu vân tay');
                    }
                }
            } catch (error) {
                console.error('Error:', error);
                if (error.name === 'NotAllowedError') {
                    showMessage(statusElement, 'Người dùng từ chối truy cập cảm biến vân tay', 'error');
                } else if (error.name === 'SecurityError') {
                    showMessage(statusElement, 'Không thể truy cập cảm biến vân tay vì lý do bảo mật', 'error');
                } else {
                    showMessage(statusElement, 'Lỗi khi đọc vân tay: ' + error.message, 'error');
                }
                stopScanning();
            }
        } catch (error) {
            console.error('Error:', error);
            showMessage(document.getElementById('enrollment-status'), 
                'Lỗi khi khởi tạo quá trình lấy vân tay: ' + error.message, 'error');
            stopScanning();
        }
    }

    function stopScanning() {
        const scannerElement = document.getElementById('fingerprintScanner');
        scannerElement.classList.remove('active');
        scannerElement.querySelector('.scanner-animation').classList.remove('scanning');
    }

    function cancelScanning() {
        if (confirm('Bạn có chắc muốn hủy quá trình lấy vân tay?')) {
            stopScanning();
            showMessage(document.getElementById('enrollment-status'), 
                'Đã hủy quá trình lấy vân tay', 'info');
        }
    }

    async function loadFingerprintList() {
        try {
            const response = await fetch('/doanqlns/index.php/api/settings/fingerprints');
            const result = await response.json();
            
            if (result.success) {
                const fingerprintList = document.getElementById('fingerprint-list');
                fingerprintList.innerHTML = '';
                
                if (!result.data || result.data.length === 0) {
                    fingerprintList.innerHTML = '<p class="text-center text-muted">Chưa có vân tay nào được đăng ký</p>';
                    return;
                }

                result.data.forEach(fingerprint => {
                    const li = document.createElement('li');
                    li.className = 'fingerprint-item';
                    li.innerHTML = `
                        <div class="fingerprint-info">
                            <i class="fas fa-fingerprint fingerprint-icon"></i>
                            <div class="fingerprint-details">
                                <div class="fingerprint-name">
                                    ${fingerprint.ten_nhan_vien} 
                                    <span class="fingerprint-id">(ID: ${fingerprint.id_nhan_vien})</span>
                                </div>
                                <div class="fingerprint-date">Thêm ngày: ${fingerprint.ngay_tao}</div>
                                <div class="fingerprint-status">
                                    Trạng thái: <span class="status-${fingerprint.trang_thai.toLowerCase()}">${fingerprint.trang_thai}</span>
                                </div>
                            </div>
                        </div>
                        <div class="fingerprint-actions">
                            <button class="fingerprint-delete" onclick="deleteFingerprint(${fingerprint.id})">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    `;
                    fingerprintList.appendChild(li);
                });

                // Thêm styles cho trạng thái
                const style = document.createElement('style');
                style.textContent = `
                    .fingerprint-id {
                        font-size: 0.9em;
                        color: #666;
                    }
                    .fingerprint-status {
                        margin-top: 5px;
                        font-size: 0.9em;
                    }
                    .status-completed {
                        color: #28a745;
                        font-weight: 500;
                    }
                    .status-pending {
                        color: #ffc107;
                        font-weight: 500;
                    }
                    .status-failed {
                        color: #dc3545;
                        font-weight: 500;
                    }
                `;
                document.head.appendChild(style);
            } else {
                showMessage(document.getElementById('enrollment-status'), 
                    result.message || 'Không thể tải danh sách vân tay', 'error');
            }
        } catch (error) {
            console.error('Error:', error);
            showMessage(document.getElementById('enrollment-status'), 
                'Lỗi khi tải danh sách vân tay: ' + error.message, 'error');
        }
    }

    async function loadFingerprintManageList() {
            try {
            console.log('Loading fingerprint management list...');
            const response = await fetch('/doanqlns/index.php/api/settings/fingerprints/manage');
                const result = await response.json();
            console.log('Fingerprint data:', result);

                if (result.success) {
                const tbody = document.getElementById('fingerprint-manage-list');
                tbody.innerHTML = '';
                
                if (!result.data || result.data.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="7" class="text-center">Không có dữ liệu vân tay</td></tr>';
                        return;
                }

                result.data.forEach(fingerprint => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${fingerprint.id || ''}</td>
                        <td>${fingerprint.id_nhan_vien || 'Chưa gán'}</td>
                        <td>${fingerprint.ten_nhan_vien || 'Chưa gán'}</td>
                        <td>${fingerprint.du_lieu_van_tay || 'Chưa có'}</td>
                        <td>${fingerprint.ngay_tao || ''}</td>
                        <td>
                            <div class="status-toggle ${fingerprint.trang_thai === 'Hoàn thành' ? 'active' : ''}"
                                 onclick="toggleFingerprintStatus(${fingerprint.id})"
                                 title="Click để thay đổi trạng thái">
                            </div>
                            <span class="status-label" data-status="${fingerprint.trang_thai}">${fingerprint.trang_thai}</span>
                        </td>
                        <td>
                            <button class="action-btn delete-btn" onclick="deleteFingerprint(${fingerprint.id})">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </td>
                    `;
                    tbody.appendChild(row);
                });

                console.log('Fingerprint list loaded successfully');
            } else {
                showMessage(document.getElementById('fingerprint-manage-message'), 
                    result.message || 'Không thể tải danh sách thông tin vân tay', 'error');
            }
        } catch (error) {
            console.error('Error:', error);
            showMessage(document.getElementById('fingerprint-manage-message'), 
                'Lỗi khi tải danh sách thông tin vân tay: ' + error.message, 'error');
        }
    }

    async function toggleFingerprintStatus(fingerprintId) {
        try {
            const toggleElement = event.currentTarget;
            const statusLabel = toggleElement.nextElementSibling;

            if (toggleElement.classList.contains('processing')) {
                        return;
                    }

            const currentStatus = toggleElement.classList.contains('active') ? 'Hoàn thành' : 'Chờ xử lý';
            const newStatus = currentStatus === 'Hoàn thành' ? 'Chờ xử lý' : 'Hoàn thành';

            if (!confirm('Bạn có muốn thay đổi trạng thái vân tay này không?')) {
                return;
            }

            toggleElement.classList.add('processing', 'disabled');
            
            const response = await fetch(`/doanqlns/index.php/api/settings/fingerprint/status/${fingerprintId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ 
                    status: newStatus === 'Hoàn thành' ? 'completed' : 'pending' 
                })
            });

            const result = await response.json();
            
            if (result.success) {
                toggleElement.classList.toggle('active', newStatus === 'Hoàn thành');
                statusLabel.textContent = newStatus;
                statusLabel.setAttribute('data-status', newStatus);
                showMessage(document.getElementById('fingerprint-manage-message'), 
                    `Trạng thái vân tay đã được chuyển thành ${newStatus}`, 
                    'success'
                );
                } else {
                showMessage(document.getElementById('fingerprint-manage-message'), 
                    result.message || 'Lỗi khi cập nhật trạng thái vân tay', 
                    'error'
                );
                }
            } catch (error) {
                console.error('Error:', error);
            showMessage(document.getElementById('fingerprint-manage-message'), 
                'Lỗi khi cập nhật trạng thái vân tay: ' + error.message, 
                'error'
            );
        } finally {
            setTimeout(() => {
                event.currentTarget.classList.remove('processing', 'disabled');
            }, 300);
        }
    }

    async function deleteFingerprint(fingerprintId) {
        if (!confirm('Bạn có chắc chắn muốn xóa vân tay này không?')) {
            return;
        }

        try {
            const response = await fetch(`/doanqlns/index.php/api/settings/fingerprint/${fingerprintId}`, {
                method: 'DELETE'
            });

            const result = await response.json();
            
            if (result.success) {
                showMessage(document.getElementById('enrollment-status'), 
                    'Đã xóa vân tay thành công', 'success');
                loadFingerprintManageList();
            } else {
                showMessage(document.getElementById('enrollment-status'), 
                    result.message || 'Không thể xóa vân tay', 'error');
            }
        } catch (error) {
            console.error('Error:', error);
            showMessage(document.getElementById('enrollment-status'), 
                'Lỗi khi xóa vân tay: ' + error.message, 'error');
        }
    }
</script>
</body>
</html>