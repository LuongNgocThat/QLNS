<?php
require_once __DIR__ . '/../includes/check_login.php';
include(__DIR__ . '/../includes/header.php');
include(__DIR__ . '/../includes/sidebar.php');

if (!($_SESSION['quyen_them'] || $_SESSION['quyen_sua'])) {
    header("Location: /doanqlns/giaodien.php?error=access_denied");
    exit();
}

$editId = isset($_GET['edit_id']) ? intval($_GET['edit_id']) : 0;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Quản Lý Nhân Sự</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/styleuser.css">
    <style>
        .name-link,
        .name-link:hover {
            text-decoration: none;
            color: blue;
        }
        .action-btn.delete i {
            color: #ff0000;
        }
        .action-buttons {
            display: flex;
            gap: 8px;
            justify-content: center;
        }
        .action-btn {
            padding: 5px 5px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .action-btn.edit {
            color: #4CAF50;
        }
        .action-btn.delete {
            color: #f44336;
        }
        .action-btn:hover {
            opacity: 0.7;
        }
        .table-responsive table th:last-child,
        .table-responsive table td:last-child {
            width: 120px;
            text-align: center;
        }
        .action-btn i {
            font-size: 14px;
        }
        .table-container {
            width: 100%;
            max-width: 100%;
            overflow-x: auto;
            margin-bottom: 20px;
        }
        .table-responsive {
            width: 100%;
        }
        .table-responsive table {
            width: 100%;
            border-collapse: collapse;
            table-layout: auto;
        }
        .table-responsive th, .table-responsive td {
            padding: 10px;
            text-align: left;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 150px;
        }
        .avatar {
            width: 150px;
            height: 200px;
            object-fit: cover;
            border: 1px solid #ddd;
            border-radius: 0;
            margin-bottom: 10px;
        }
        .modal-section .avatar-container {
            text-align: center;
        }
        .modal-field input[type="file"] {
            padding: 5px;
        }
        .modal-field label {
            font-weight: 500;
            margin-bottom: 5px;
            display: block;
        }
        .modal-field select {
            width: 80%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        .search-container {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }
        .search-input, .filter-select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            font-family: 'Roboto', sans-serif;
            flex: 1;
            min-width: 150px;
        }
        .filter-select {
            max-width: 200px;
        }
        .search-input:focus, .filter-select:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 0 2px rgba(0,123,255,0.2);
        }
        #userDetailModal.user-detail-modal {
            z-index: 2000 !important;
            display: none;
        }
        #userDetailModal .user-detail-modal-content {
            max-width: 1000px !important;
            width: 100% !important;
            margin: 5% auto;
            padding: 30px;
            border-radius: 12px;
        }
        #userDetailModal .user-detail-avatar {
            width: 150px !important;
            height: 200px !important;
            border-radius: 0 !important;
            object-fit: cover;
        }
        #userDetailModal .user-detail-modal-section h3 {
            font-size: 1.4rem;
            color: #2c3e50;
            border-left: 4px solid #007bff;
            padding-left: 10px;
        }
        #userDetailModal .user-detail-modal-field label {
            width: 180px;
            font-weight: 600;
            color: #34495e;
        }
        #userDetailModal .user-detail-modal-field span {
            padding: 12px;
            background: #f8f9fa;
            border-radius: 6px;
            border: 1px solid #e0e0e0;
        }
        @media (max-width: 768px) {
            .search-container {
                flex-direction: column;
                align-items: stretch;
            }
            .search-input, .filter-select {
                min-width: 100%;
            }
            .filter-select {
                max-width: 100%;
            }
            .avatar {
                width: 120px;
                height: 160px;
            }
        }
        .custom-file-btn {
    display: inline-block;
    padding: 8px 12px;
    background-color: #007bff;
    color: white;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    text-align: center;
}
.custom-file-btn:hover {
    background-color: #0056b3;
}

.avatar-container {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    margin-bottom: 15px;
}

.avatar-input-wrapper {
    display: flex;
    align-items: center;
    gap: 15px; /* Space between file input and avatar preview */
}

.avatar-container input[type="file"] {
    padding: 5px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
    max-width: 200px; /* Limit width of file input for better alignment */
}




    </style>
</head>
<body>
    <?php include('../includes/sidebar.php'); ?>
    <div class="main-content">
        <?php 
        $page_title = "Danh Sách Nhân Viên";
        include('../includes/header.php'); 
        ?>

        <div class="page-header">
            <h1 class="page-title">Danh Sách Nhân Viên</h1>
            <div class="search-container">
                <select id="filterPhongBan" class="filter-select" aria-label="Lọc theo phòng ban">
                    <option value="">Tất cả phòng ban</option>
                </select>
                <input type="text" id="searchInput" class="search-input" placeholder="Nhập tên nhân viên...">
                <?php if ($_SESSION['quyen_them']): ?>
                    <button class="action-btn" onclick="showAddUserModal()">
                        <i class="fas fa-user-plus"></i> Thêm nhân viên
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <div class="table-container">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Mã Nhân Viên</th>
                            <th>Họ Tên</th>
                            <th>Giới Tính</th>
                            <th>Ngày Sinh</th>
                            <th>Email</th>
                            <th>Số Điện Thoại</th>
                            <th>Phòng Ban</th>
                            <th>Chức Vụ</th>
                            <th>Trạng Thái</th>
                            <th>Hành Động</th>
                        </tr>
                    </thead>
                    <tbody id="userTableBody">
                    </tbody>
                </table>
            </div>
        </div>

        <div id="editUserModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">Chỉnh Sửa Nhân Viên</h2>
                    <button class="modal-close">×</button>
                </div>
                <div class="modal-body" id="editModalBody">
                </div>
            </div>
        </div>

        <div id="addUserModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">Thêm Nhân Viên</h2>
                    <button class="modal-close">×</button>
                </div>
                <div class="modal-body" id="addModalBody">
                    <div class="modal-section">
                        <h3>Thông Tin Cá Nhân</h3>
                        <div class="avatar-input-wrapper">
                            <label for="add_hinh_anh" class="custom-file-btn">Choose File</label>
                            <input type="file" id="add_hinh_anh" accept="image/jpeg,image/png" style="display: none;">
                            <img id="add_hinh_anh_preview" class="avatar" src="https://via.placeholder.com/150x200" alt="Avatar Preview">
                        </div>
                        <div class="modal-field">
                            <label>Họ Tên <span style="color: red;">*</span></label>
                            <input type="text" id="add_ho_ten">
                        </div>
                        <div class="modal-field">
                            <label>Giới Tính</label>
                            <select id="add_gioi_tinh">
                                <option value="Nam">Nam</option>
                                <option value="Nữ">Nữ</option>
                            </select>
                        </div>
                        <div class="modal-field">
                            <label>Ngày Sinh <span style="color: red;">*</span></label>
                            <input type="date" id="add_ngay_sinh">
                        </div>
                        <div class="modal-field">
                            <label>Căn Cước Công Dân</label>
                            <input type="text" id="add_can_cuoc_cong_dan">
                        </div>
                        <div class="modal-field">
                            <label>Ngày Cấp</label>
                            <input type="date" id="add_ngay_cap">
                        </div>
                        <div class="modal-field">
                            <label>Nơi Cấp</label>
                            <input type="text" id="add_noi_cap">
                        </div>
                        <div class="modal-field">
                            <label>Quê Quán</label>
                            <input type="text" id="add_que_quan">
                        </div>
                    </div>
                    <div class="modal-section">
                        <h3>Liên Hệ</h3>
                        <div class="modal-field">
                            <label>Email <span style="color: red;">*</span></label>
                            <input type="email" id="add_email">
                        </div>
                        <div class="modal-field">
                            <label>Số Điện Thoại</label>
                            <input type="text" id="add_so_dien_thoai">
                        </div>
                        <div class="modal-field">
                            <label>Địa Chỉ</label>
                            <input type="text" id="add_dia_chi">
                        </div>
                    </div>
                    <div class="modal-section">
                        <h3>Công Việc</h3>
                        <div class="modal-field">
                            <label>Phòng Ban <span style="color: red;">*</span></label>
                            <select id="add_ten_phong_ban">
                                <option value="">Chọn phòng ban</option>
                            </select>
                        </div>
                        <div class="modal-field">
                            <label>Chức Vụ <span style="color: red;">*</span></label>
                            <select id="add_ten_chuc_vu">
                                <option value="">Chọn chức vụ</option>
                            </select>
                        </div>
                        <div class="modal-field">
                            <label>Loại Hợp Đồng <span style="color: red;">*</span></label>
                            <select id="add_loai_hop_dong">
                                <option value="">Chọn loại hợp đồng</option>
                                <option value="Thực tập">Thực tập</option>
                                <option value="Toàn thời gian">Toàn thời gian</option>
                            </select>
                        </div>
                        <div class="modal-field">
                            <label>Ngày Vào Làm <span style="color: red;">*</span></label>
                            <input type="date" id="add_ngay_vao_lam">
                        </div>
                        <div class="modal-field">
                            <label>Trạng Thái</label>
                            <select id="add_trang_thai">
                                <option value="Đang làm việc">Đang làm việc</option>
                                <option value="Nghỉ việc">Nghỉ việc</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-section">
                        <h3>Tài Chính</h3>
                        <div class="modal-field">
                            <label>Lương Cơ Bản <span style="color: red;">*</span></label>
                            <input type="number" id="add_luong_co_ban">
                        </div>
                    </div>
                    <div class="modal-actions">
                        <button class="modal-btn modal-btn-save" onclick="addUser()">
                            <i class="fas fa-save"></i> Lưu
                        </button>
                        <button class="modal-btn modal-btn-cancel" onclick="closeAddUserModal()">
                            <i class="fas fa-times"></i> Hủy
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div id="userDetailModalContainer"></div>
    </div>

    <script>
        let usersData = [];
        let phongBanList = [];
        let chucVuList = [];

        // Lấy danh sách phòng ban từ API
        fetch("http://localhost/doanqlns/index.php/api/phongban")
            .then(response => response.json())
            .then(data => {
                phongBanList = data;
                populatePhongBanSelect('add_ten_phong_ban');
                populatePhongBanSelect('edit_ten_phong_ban');
                populatePhongBanSelect('filterPhongBan');
            })
            .catch(error => {
                console.error("Lỗi khi tải danh sách phòng ban:", error);
            });

        // Lấy danh sách chức vụ từ API
        fetch("http://localhost/doanqlns/index.php/api/chucvu")
            .then(response => response.json())
            .then(data => {
                chucVuList = data;
                populateChucVuSelect('add_ten_chuc_vu');
                populateChucVuSelect('edit_ten_chuc_vu');
            })
            .catch(error => {
                console.error("Lỗi khi tải danh sách chức vụ:", error);
            });

        // Hàm điền danh sách phòng ban vào select
        function populatePhongBanSelect(selectId) {
            const select = document.getElementById(selectId);
            if (select) {
                select.innerHTML = selectId === 'filterPhongBan' ? '<option value="">Tất cả phòng ban</option>' : '<option value="">Chọn phòng ban</option>';
                phongBanList.forEach(pb => {
                    const option = document.createElement('option');
                    option.value = pb.ten_phong_ban;
                    option.textContent = pb.ten_phong_ban;
                    select.appendChild(option);
                });
            }
        }

        // Hàm điền danh sách chức vụ vào select
        function populateChucVuSelect(selectId) {
            const select = document.getElementById(selectId);
            if (select) {
                select.innerHTML = '<option value="">Chọn chức vụ</option>';
                chucVuList.forEach(cv => {
                    const option = document.createElement('option');
                    option.value = cv.ten_chuc_vu;
                    option.textContent = cv.ten_chuc_vu;
                    select.appendChild(option);
                });
            }
        }

        // Lấy danh sách nhân viên từ API
        fetch("http://localhost/doanqlns/index.php/api/users")
            .then(response => {
                console.log("Response status:", response.status);
                return response.json();
            })
            .then(data => {
                console.log("API data:", data);
                usersData = data;
                filterAndRenderTable();
                <?php if ($editId): ?>
                    fetchUserAndShowEditModal(<?php echo $editId; ?>);
                <?php endif; ?>
                // Kiểm tra và mở modal thêm nếu có tham số action=add
                const urlParams = new URLSearchParams(window.location.search);
                if (urlParams.get('action') === 'add' && <?php echo $_SESSION['quyen_them'] ? 'true' : 'false'; ?>) {
                    showAddUserModal();
                }
            })
            .catch(error => {
                console.error("Lỗi khi tải dữ liệu:", error);
                document.getElementById("userTableBody").innerHTML = '<tr><td colspan="10">Lỗi khi tải dữ liệu</td></tr>';
            });

        // Các hàm còn lại giữ nguyên...
        function filterAndRenderTable() {
            const keyword = document.getElementById("searchInput").value.toLowerCase();
            const selectedPhongBan = document.getElementById("filterPhongBan").value;

            let filteredData = usersData;
            if (selectedPhongBan) {
                filteredData = filteredData.filter(user => user.ten_phong_ban === selectedPhongBan);
            }
            if (keyword) {
                filteredData = filteredData.filter(user => user.ho_ten.toLowerCase().includes(keyword));
            }

            renderTable(filteredData);
        }

        function renderTable(data) {
            const tableBody = document.getElementById("userTableBody");
            tableBody.innerHTML = "";
            if (data && data.length) {
                data.forEach(user => {
                    const row = document.createElement("tr");
                    let statusClass = user.trang_thai === "Đang làm việc" ? "active" : "inactive";
                    row.innerHTML = `
                        <td>${user.id_nhan_vien}</td>
                        <td><a href="#" class="name-link" data-id="${user.id_nhan_vien}">${user.ho_ten}</a></td>
                        <td>${user.gioi_tinh || 'N/A'}</td>
                        <td>${user.ngay_sinh || 'N/A'}</td>
                        <td>${user.email || 'N/A'}</td>
                        <td>${user.so_dien_thoai || 'N/A'}</td>
                        <td>${user.ten_phong_ban || 'N/A'}</td>
                        <td>${user.ten_chuc_vu || 'N/A'}</td>
                        <td><span class="status ${statusClass}">${user.trang_thai || 'N/A'}</span></td>
                        <td>
                            <div class="action-buttons">
                                <?php if ($_SESSION['quyen_sua']): ?>
                                    <button class="action-btn edit" onclick="fetchUserAndShowEditModal(${user.id_nhan_vien})">
                                        <i class="fas fa-edit"></i> Sửa
                                    </button>
                                <?php endif; ?>
                                <?php if ($_SESSION['quyen_xoa']): ?>
                                    <button class="action-btn delete" onclick="confirmDelete(${user.id_nhan_vien})">
                                        <i class="fas fa-trash"></i> Xóa
                                    </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    `;
                    tableBody.appendChild(row);
                });

                document.querySelectorAll('.name-link').forEach(link => {
                    link.addEventListener('click', function(e) {
                        e.preventDefault();
                        const userId = this.getAttribute('data-id');
                        showUserDetails(userId);
                    });
                });
            } else {
                tableBody.innerHTML = '<tr><td colspan="10">Không có dữ liệu</td></tr>';
            }
        }

        function showUserDetails(userId) {
            fetch(`chitietnhansu.php?id=${userId}`)
                .then(response => response.text())
                .then(data => {
                    const container = document.getElementById('userDetailModalContainer');
                    container.innerHTML = data;
                    const scripts = container.querySelectorAll('script');
                    scripts.forEach(script => {
                        const newScript = document.createElement('script');
                        newScript.textContent = script.textContent;
                        document.body.appendChild(newScript);
                    });
                    if (typeof loadUserDetails === 'function') {
                        loadUserDetails(userId);
                    } else {
                        console.error("Hàm loadUserDetails không được định nghĩa");
                        alert("Lỗi khi tải thông tin chi tiết nhân viên");
                    }
                })
                .catch(error => {
                    console.error("Lỗi khi tải modal chi tiết:", error);
                    alert("Lỗi khi tải thông tin chi tiết nhân viên");
                });
        }

        function fetchUserAndShowEditModal(userId) {
            fetch(`http://localhost/doanqlns/index.php/api/user?id=${userId}`)
                .then(response => response.json())
                .then(user => {
                    if (user.message) {
                        alert(user.message);
                        return;
                    }
                    showEditUserModal(user);
                })
                .catch(error => {
                    console.error("Lỗi khi tải chi tiết nhân viên:", error);
                    alert("Lỗi khi tải thông tin nhân viên");
                });
        }

        function confirmDelete(userId) {
            if (confirm('Bạn có chắc chắn muốn xóa nhân viên này?')) {
                deleteUser(userId);
            }
        }

        function showEditUserModal(user) {
            const editModalBody = document.getElementById('editModalBody');
            editModalBody.innerHTML = `
                <div class="modal-section">
                    <h3>Thông Tin Cá Nhân</h3>
                    <div class="modal-field">
                        <label>Mã Nhân Viên</label>
                        <span>${user.id_nhan_vien}</span>
                    </div>
                    <div class="modal-field">
                        <label>Họ Tên <span style="color: red;">*</span></label>
                        <input type="text" id="edit_ho_ten" value="${user.ho_ten}">
                    </div>
                    <div class="modal-field">
                        <label>Giới Tính</label>
                        <select id="edit_gioi_tinh">
                            <option value="Nam" ${user.gioi_tinh === 'Nam' ? 'selected' : ''}>Nam</option>
                            <option value="Nữ" ${user.gioi_tinh === 'Nữ' ? 'selected' : ''}>Nữ</option>
                        </select>
                    </div>
                    <div class="modal-field">
                        <label>Ngày Sinh <span style="color: red;">*</span></label>
                        <input type="date" id="edit_ngay_sinh" value="${user.ngay_sinh || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Căn Cước Công Dân</label>
                        <input type="text" id="edit_can_cuoc_cong_dan" value="${user.can_cuoc_cong_dan || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Ngày Cấp</label>
                        <input type="date" id="edit_ngay_cap" value="${user.ngay_cap || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Nơi Cấp</label>
                        <input type="text" id="edit_noi_cap" value="${user.noi_cap || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Quê Quán</label>
                        <input type="text" id="edit_que_quan" value="${user.que_quan || ''}">
                    </div>
                </div>
                <div class="modal-section">
                    <h3>Liên Hệ</h3>
                    <div class="modal-field">
                        <label>Email <span style="color: red;">*</span></label>
                        <input type="email" id="edit_email" value="${user.email || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Số Điện Thoại</label>
                        <input type="text" id="edit_so_dien_thoai" value="${user.so_dien_thoai || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Địa Chỉ</label>
                        <input type="text" id="edit_dia_chi" value="${user.dia_chi || ''}">
                    </div>
                </div>
                <div class="modal-section">
                    <h3>Công Việc</h3>
                    <div class="modal-field">
                        <label>Phòng Ban <span style="color: red;">*</span></label>
                        <select id="edit_ten_phong_ban">
                            <option value="">Chọn phòng ban</option>
                        </select>
                    </div>
                    <div class="modal-field">
                        <label>Chức Vụ <span style="color: red;">*</span></label>
                        <select id="edit_ten_chuc_vu">
                            <option value="">Chọn chức vụ</option>
                        </select>
                    </div>
                    <div class="modal-field">
                        <label>Loại Hợp Đồng <span style="color: red;">*</span></label>
                        <select id="edit_loai_hop_dong">
                            <option value="">Chọn loại hợp đồng</option>
                            <option value="Thực tập" ${user.loai_hop_dong === 'Thực tập' ? 'selected' : ''}>Thực tập</option>
                            <option value="Toàn thời gian" ${user.loai_hop_dong === 'Toàn thời gian' ? 'selected' : ''}>Toàn thời gian</option>
                        </select>
                    </div>
                    <div class="modal-field">
                        <label>Ngày Vào Làm <span style="color: red;">*</span></label>
                        <input type="date" id="edit_ngay_vao_lam" value="${user.ngay_vao_lam || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Ngày Nghỉ Việc</label>
                        <input type="date" id="edit_ngay_nghi_viec" value="${user.ngay_nghi_viec || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Trạng Thái</label>
                        <select id="edit_trang_thai">
                            <option value="Đang làm việc" ${user.trang_thai === 'Đang làm việc' ? 'selected' : ''}>Đang làm việc</option>
                            <option value="Nghỉ việc" ${user.trang_thai === 'Nghỉ việc' ? 'selected' : ''}>Nghỉ việc</option>
                        </select>
                    </div>
                </div>
                <div class="modal-section">
                    <h3>Tài Chính</h3>
                    <div class="modal-field">
                        <label>Lương Cơ Bản <span style="color: red;">*</span></label>
                        <input type="number" id="edit_luong_co_ban" value="${user.luong_co_ban || ''}">
                    </div>
                </div>
                <div class="modal-actions">
                    <button class="modal-btn modal-btn-save" onclick="updateUser(${user.id_nhan_vien})">
                        <i class="fas fa-save"></i> Lưu
                    </button>
                    <button class="modal-btn modal-btn-cancel" onclick="closeEditUserModal()">
                        <i class="fas fa-times"></i> Hủy
                    </button>
                </div>
            `;

            populatePhongBanSelect('edit_ten_phong_ban');
            populateChucVuSelect('edit_ten_chuc_vu');

            document.getElementById('edit_ten_phong_ban').value = user.ten_phong_ban || '';
            document.getElementById('edit_ten_chuc_vu').value = user.ten_chuc_vu || '';

            document.getElementById('editUserModal').style.display = 'flex';
        }

        function addUser() {
            const formData = new FormData();
            formData.append('ho_ten', document.getElementById('add_ho_ten').value);
            formData.append('gioi_tinh', document.getElementById('add_gioi_tinh').value);
            formData.append('ngay_sinh', document.getElementById('add_ngay_sinh').value);
            formData.append('can_cuoc_cong_dan', document.getElementById('add_can_cuoc_cong_dan').value);
            formData.append('ngay_cap', document.getElementById('add_ngay_cap').value);
            formData.append('noi_cap', document.getElementById('add_noi_cap').value);
            formData.append('que_quan', document.getElementById('add_que_quan').value);
            formData.append('email', document.getElementById('add_email').value);
            formData.append('so_dien_thoai', document.getElementById('add_so_dien_thoai').value);
            formData.append('dia_chi', document.getElementById('add_dia_chi').value);
            formData.append('ten_phong_ban', document.getElementById('add_ten_phong_ban').value);
            formData.append('ten_chuc_vu', document.getElementById('add_ten_chuc_vu').value);
            formData.append('loai_hop_dong', document.getElementById('add_loai_hop_dong').value);
            formData.append('ngay_vao_lam', document.getElementById('add_ngay_vao_lam').value);
            formData.append('trang_thai', document.getElementById('add_trang_thai').value);
            formData.append('luong_co_ban', document.getElementById('add_luong_co_ban').value);
            const hinhAnhInput = document.getElementById('add_hinh_anh');
            if (hinhAnhInput.files.length > 0) {
                formData.append('hinh_anh', hinhAnhInput.files[0]);
            }

            const requiredFields = ['ho_ten', 'ngay_sinh', 'email', 'ten_phong_ban', 'ten_chuc_vu', 'loai_hop_dong', 'ngay_vao_lam', 'luong_co_ban'];
            for (let field of requiredFields) {
                if (!formData.get(field)) {
                    alert(`Vui lòng điền trường bắt buộc: ${field.replace('_', ' ')}`);
                    return;
                }
            }

            if (hinhAnhInput.files.length > 0) {
                const file = hinhAnhInput.files[0];
                const validTypes = ['image/jpeg', 'image/png'];
                if (!validTypes.includes(file.type)) {
                    alert('Vui lòng chọn file ảnh định dạng JPG hoặc PNG.');
                    return;
                }
                if (file.size > 2 * 1024 * 1024) {
                    alert('Kích thước file không được vượt quá 2MB.');
                    return;
                }
            }

            fetch(`http://localhost/doanqlns/index.php/api/user`, {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        document.getElementById('addUserModal').style.display = 'none';
                        fetch("http://localhost/doanqlns/index.php/api/users")
                            .then(response => response.json())
                            .then(data => {
                                usersData = data;
                                filterAndRenderTable();
                                alert('Thêm nhân viên thành công!');
                            });
                    } else {
                        alert('Lỗi khi thêm nhân viên: ' + (result.message || 'Không rõ nguyên nhân'));
                    }
                })
                .catch(error => {
                    console.error("Lỗi khi thêm nhân viên:", error);
                    alert("Lỗi khi thêm nhân viên");
                });
        }

        function updateUser(userId) {
            const updatedUser = {
                ho_ten: document.getElementById('edit_ho_ten').value,
                gioi_tinh: document.getElementById('edit_gioi_tinh').value,
                ngay_sinh: document.getElementById('edit_ngay_sinh').value,
                can_cuoc_cong_dan: document.getElementById('edit_can_cuoc_cong_dan').value,
                ngay_cap: document.getElementById('edit_ngay_cap').value,
                noi_cap: document.getElementById('edit_noi_cap').value,
                que_quan: document.getElementById('edit_que_quan').value,
                email: document.getElementById('edit_email').value,
                so_dien_thoai: document.getElementById('edit_so_dien_thoai').value,
                dia_chi: document.getElementById('edit_dia_chi').value,
                ten_phong_ban: document.getElementById('edit_ten_phong_ban').value,
                ten_chuc_vu: document.getElementById('edit_ten_chuc_vu').value,
                loai_hop_dong: document.getElementById('edit_loai_hop_dong').value,
                ngay_vao_lam: document.getElementById('edit_ngay_vao_lam').value,
                ngay_nghi_viec: document.getElementById('edit_ngay_nghi_viec').value,
                trang_thai: document.getElementById('edit_trang_thai').value,
                luong_co_ban: document.getElementById('edit_luong_co_ban').value
            };

            const requiredFields = ['ho_ten', 'ngay_sinh', 'email', 'ten_phong_ban', 'ten_chuc_vu', 'loai_hop_dong', 'ngay_vao_lam', 'luong_co_ban'];
            for (let field of requiredFields) {
                if (!updatedUser[field]) {
                    alert(`Vui lòng điền trường bắt buộc: ${field.replace('_', ' ')}`);
                    return;
                }
            }

            fetch(`http://localhost/doanqlns/index.php/api/user?id=${userId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(updatedUser)
            })
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        document.getElementById('editUserModal').style.display = 'none';
                        fetch("http://localhost/doanqlns/index.php/api/users")
                            .then(response => response.json())
                            .then(data => {
                                usersData = data;
                                filterAndRenderTable();
                                alert('Cập nhật nhân viên thành công!');
                            });
                    } else {
                        alert('Lỗi khi cập nhật nhân viên: ' + (result.message || 'Không rõ nguyên nhân'));
                    }
                })
                .catch(error => {
                    console.error("Lỗi khi cập nhật nhân viên:", error);
                    alert("Lỗi khi cập nhật nhân viên");
                });
        }

        function deleteUser(userId) {
            fetch(`http://localhost/doanqlns/index.php/api/user?id=${userId}`, {
                method: 'DELETE'
            })
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        usersData = usersData.filter(user => user.id_nhan_vien != userId);
                        filterAndRenderTable();
                        alert('Xóa nhân viên thành công!');
                    } else {
                        alert('Lỗi khi xóa nhân viên: ' + (result.message || 'Không rõ nguyên nhân'));
                    }
                })
                .catch(error => {
                    console.error("Lỗi khi xóa nhân viên:", error);
                    alert("Lỗi khi xóa nhân viên");
                });
        }

        function showAddUserModal() {
            document.getElementById('addUserModal').style.display = 'flex';
            document.getElementById('add_hinh_anh_preview').src = 'https://via.placeholder.com/150x200';
            document.getElementById('add_ho_ten').value = '';
            document.getElementById('add_gioi_tinh').value = 'Nam';
            document.getElementById('add_ngay_sinh').value = '';
            document.getElementById('add_can_cuoc_cong_dan').value = '';
            document.getElementById('add_ngay_cap').value = '';
            document.getElementById('add_noi_cap').value = '';
            document.getElementById('add_que_quan').value = '';
            document.getElementById('add_email').value = '';
            document.getElementById('add_so_dien_thoai').value = '';
            document.getElementById('add_dia_chi').value = '';
            document.getElementById('add_ten_phong_ban').value = '';
            document.getElementById('add_ten_chuc_vu').value = '';
            document.getElementById('add_loai_hop_dong').value = '';
            document.getElementById('add_ngay_vao_lam').value = '';
            document.getElementById('add_trang_thai').value = 'Đang làm việc';
            document.getElementById('add_luong_co_ban').value = '';
            document.getElementById('add_hinh_anh').value = '';
        }

        function closeAddUserModal() {
            document.getElementById('addUserModal').style.display = 'none';
        }

        function closeEditUserModal() {
            document.getElementById('editUserModal').style.display = 'none';
        }

        document.querySelector('#editUserModal .modal-close').addEventListener('click', () => {
            closeEditUserModal();
        });

        document.querySelector('#addUserModal .modal-close').addEventListener('click', () => {
            closeAddUserModal();
        });

        document.getElementById('editUserModal').addEventListener('click', (e) => {
            if (e.target === document.getElementById('editUserModal')) {
                closeEditUserModal();
            }
        });

        document.getElementById('addUserModal').addEventListener('click', (e) => {
            if (e.target === document.getElementById('addUserModal')) {
                closeAddUserModal();
            }
        });

        document.getElementById("searchInput").addEventListener("keyup", function() {
            filterAndRenderTable();
        });

        document.getElementById("filterPhongBan").addEventListener("change", function() {
            filterAndRenderTable();
        });

       document.getElementById('add_hinh_anh').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('add_hinh_anh_preview').src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
});
    </script>

    <?php include(__DIR__ . '/../includes/footer.php'); ?>
</body>
</html>