<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Quản Lý Nhân Sự</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/styleuser.css">
    
</head>
<body>
    <?php include('../includes/sidebar.php'); ?>
    <div class="main-content">
        <?php 
        $page_title = "Danh Sách Nhân Viên";
        include('../includes/header.php'); 
        ?>
   
        <div class="page-header">
            <h1 class="page-title">Danh Sách Nhân Viên</h1>
            <div class="search-container">
                <input type="text" id="searchInput" class="search-input" placeholder="Nhập tên nhân viên...">
                <button id="searchButton" class="search-button">
                    <i class="fas fa-search"></i> Tìm kiếm
                </button>
            </div>
        </div>

        <div class="table-container">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Mã Nhân Viên</th>
                            <th>Họ Tên</th>
                            <th>Giới Tính</th>
                            <th>Ngày Sinh</th>
                            <th>Email</th>
                            <th>Số Điện Thoại</th>
                            <th>Địa Chỉ</th>
                            <!-- <th>CCCD</th>
                            <th>Ngày Cấp</th>
                            <th>Nơi Cấp</th>
                            <th>Quê Quán</th>
                            <th>Hình Ảnh</th> -->
                            <th>Phòng Ban</th>
                            <th>Chức Vụ</th>
                            <!-- <th>Loại Hợp Đồng</th>
                            <th>Lương Cơ Bản</th>
                            <th>Ngày Vào Làm</th>
                            <th>Ngày Nghỉ Việc</th> -->
                            <th>Trạng Thái</th>
                        </tr>
                    </thead>
                    <tbody id="userTableBody">
                        <!-- Dữ liệu sẽ được thêm vào đây -->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Modal chi tiết nhân viên -->
        <div id="userModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">Thông Tin Chi Tiết Nhân Viên</h2>
                    <button class="modal-close">×</button>
                </div>
                <div class="modal-body" id="modalBody">
                    <!-- Thông tin sẽ được thêm vào đây -->
                </div>
            </div>
        </div>

        <!-- Modal chỉnh sửa nhân viên -->
        <div id="editUserModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">Chỉnh Sửa Nhân Viên</h2>
                    <button class="modal-close">×</button>
                </div>
                <div class="modal-body" id="editModalBody">
                    <!-- Form chỉnh sửa sẽ được thêm vào đây -->
                </div>
            </div>
        </div>
    </div>

    <script>
        let usersData = [];
        let currentUserId = null;

        // Lấy danh sách nhân viên từ API
        fetch("http://localhost/doanqlns/index.php/api/users")
            .then(response => response.json())
            .then(data => {
                usersData = data;
                renderTable(data);
            })
            .catch(error => {
                console.error("Lỗi khi tải dữ liệu:", error);
                document.getElementById("userTableBody").innerHTML = '<tr><td colspan="19">Lỗi khi tải dữ liệu</td></tr>';
            });

        // Hàm hiển thị bảng
        function renderTable(data) {
            const tableBody = document.getElementById("userTableBody");
            tableBody.innerHTML = "";
            if (data && data.length) {
                data.forEach(user => {
                    const row = document.createElement("tr");
                    let statusClass = user.trang_thai === "Đang làm việc" ? "active" : "inactive";
                    row.innerHTML = `
                        <td>${user.id_nhan_vien}</td>
                        <td><a href="#" class="name-link" data-id="${user.id_nhan_vien}">${user.ho_ten}</a></td>
                        <td>${user.gioi_tinh || 'N/A'}</td>
                        <td>${user.ngay_sinh || 'N/A'}</td>
                        <td>${user.email || 'N/A'}</td>
                        <td>${user.so_dien_thoai || 'N/A'}</td>
                        <td>${user.dia_chi || 'N/A'}</td>
                       
                        <td>${user.ten_phong_ban || 'N/A'}</td>
                        <td>${user.ten_chuc_vu || 'N/A'}</td>
                        
                        <td><span class="status ${statusClass}">${user.trang_thai || 'N/A'}</span></td>
                    `;
                    tableBody.appendChild(row);
                });

                // Thêm sự kiện click cho các link tên
                document.querySelectorAll('.name-link').forEach(link => {
                    link.addEventListener('click', function(e) {
                        e.preventDefault();
                        const userId = this.getAttribute('data-id');
                        showUserDetails(userId);
                    });
                });
            } else {
                tableBody.innerHTML = '<tr><td colspan="19">Không có dữ liệu</td></tr>';
            }
        }

        // Hàm hiển thị chi tiết nhân viên
        function showUserDetails(userId) {
            currentUserId = userId;
            fetch(`http://localhost/doanqlns/index.php/api/user?id=${userId}`)
                .then(response => response.json())
                .then(user => {
                    if (user.message) {
                        alert(user.message);
                        return;
                    }
                    const modalBody = document.getElementById('modalBody');
                    modalBody.innerHTML = `
                        <div class="modal-section">
                            <h3>Thông Tin Cá Nhân</h3>
                            <img src="${user.hinh_anh || 'https://via.placeholder.com/80'}" alt="Avatar">
                            <div class="modal-field">
                                <label>Mã Nhân Viên</label>
                                <span>${user.id_nhan_vien}</span>
                            </div>
                            <div class="modal-field">
                                <label>Họ Tên</label>
                                <span>${user.ho_ten}</span>
                            </div>
                            <div class="modal-field">
                                <label>Giới Tính</label>
                                <span>${user.gioi_tinh || 'N/A'}</span>
                            </div>
                            <div class="modal-field">
                                <label>Ngày Sinh</label>
                                <span>${user.ngay_sinh || 'N/A'}</span>
                            </div>
                            <div class="modal-field">
                                <label>Căn Cước Công Dân</label>
                                <span>${user.can_cuoc_cong_dan || 'N/A'}</span>
                            </div>
                            <div class="modal-field">
                                <label>Ngày Cấp</label>
                                <span>${user.ngay_cap || 'N/A'}</span>
                            </div>
                            <div class="modal-field">
                                <label>Nơi Cấp</label>
                                <span>${user.noi_cap || 'N/A'}</span>
                            </div>
                            <div class="modal-field">
                                <label>Quê Quán</label>
                                <span>${user.que_quan || 'N/A'}</span>
                            </div>
                        </div>
                        <div class="modal-section">
                            <h3>Liên Hệ</h3>
                            <div class="modal-field">
                                <label>Email</label>
                                <span>${user.email || 'N/A'}</span>
                            </div>
                            <div class="modal-field">
                                <label>Số Điện Thoại</label>
                                <span>${user.so_dien_thoai || 'N/A'}</span>
                            </div>
                            <div class="modal-field">
                                <label>Địa Chỉ</label>
                                <span>${user.dia_chi || 'N/A'}</span>
                            </div>
                        </div>
                        <div class="modal-section">
                            <h3>Công Việc</h3>
                            <div class="modal-field">
                                <label>Phòng Ban</label>
                                <span>${user.ten_phong_ban || 'N/A'}</span>
                            </div>
                            <div class="modal-field">
                                <label>Chức Vụ</label>
                                <span>${user.ten_chuc_vu || 'N/A'}</span>
                            </div>
                            <div class="modal-field">
                                <label>Loại Hợp Đồng</label>
                                <span>${user.loai_hop_dong || 'N/A'}</span>
                            </div>
                            <div class="modal-field">
                                <label>Ngày Vào Làm</label>
                                <span>${user.ngay_vao_lam || 'N/A'}</span>
                            </div>
                            <div class="modal-field">
                                <label>Ngày Nghỉ Việc</label>
                                <span>${user.ngay_nghi_viec || 'N/A'}</span>
                            </div>
                            <div class="modal-field">
                                <label>Trạng Thái</label>
                                <span>${user.trang_thai || 'N/A'}</span>
                            </div>
                        </div>
                        <div class="modal-section">
                            <h3>Tài Chính</h3>
                            <div class="modal-field">
                                <label>Lương Cơ Bản</label>
                                <span>${user.luong_co_ban ? new Intl.NumberFormat('vi-VN').format(user.luong_co_ban) + ' VNĐ' : 'N/A'}</span>
                            </div>
                        </div>
                        <div class="modal-actions">
                            <button class="modal-btn modal-btn-edit">
                                <i class="fas fa-edit"></i> Sửa
                            </button>
                            <button class="modal-btn modal-btn-delete">
                                <i class="fas fa-trash"></i> Xóa
                            </button>
                        </div>
                    `;
                    document.getElementById('userModal').style.display = 'flex';

                    // Xử lý nút Sửa
                    document.querySelector('.modal-btn-edit').addEventListener('click', () => {
                        showEditUserModal(user);
                    });

                    // Xử lý nút Xóa
                    document.querySelector('.modal-btn-delete').addEventListener('click', () => {
                        if (confirm('Bạn có chắc chắn muốn xóa nhân viên này?')) {
                            deleteUser(user.id_nhan_vien);
                        }
                    });
                })
                .catch(error => {
                    console.error("Lỗi khi tải chi tiết nhân viên:", error);
                    alert("Lỗi khi tải thông tin nhân viên");
                });
        }

        // Hàm hiển thị modal chỉnh sửa
        function showEditUserModal(user) {
            const editModalBody = document.getElementById('editModalBody');
            editModalBody.innerHTML = `
                <div class="modal-section">
                    <h3>Thông Tin Cá Nhân</h3>
                    <div class="modal-field">
                        <label>Mã Nhân Viên</label>
                        <span>${user.id_nhan_vien}</span>
                    </div>
                    <div class="modal-field">
                        <label>Họ Tên</label>
                        <input type="text" id="edit_ho_ten" value="${user.ho_ten}">
                    </div>
                    <div class="modal-field">
                        <label>Giới Tính</label>
                        <select id="edit_gioi_tinh">
                            <option value="Nam" ${user.gioi_tinh === 'Nam' ? 'selected' : ''}>Nam</option>
                            <option value="Nữ" ${user.gioi_tinh === 'Nữ' ? 'selected' : ''}>Nữ</option>
                        </select>
                    </div>
                    <div class="modal-field">
                        <label>Ngày Sinh</label>
                        <input type="date" id="edit_ngay_sinh" value="${user.ngay_sinh || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Căn Cước Công Dân</label>
                        <input type="text" id="edit_can_cuoc_cong_dan" value="${user.can_cuoc_cong_dan || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Ngày Cấp</label>
                        <input type="date" id="edit_ngay_cap" value="${user.ngay_cap || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Nơi Cấp</label>
                        <input type="text" id="edit_noi_cap" value="${user.noi_cap || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Quê Quán</label>
                        <input type="text" id="edit_que_quan" value="${user.que_quan || ''}">
                    </div>
                </div>
                <div class="modal-section">
                    <h3>Liên Hệ</h3>
                    <div class="modal-field">
                        <label>Email</label>
                        <input type="email" id="edit_email" value="${user.email || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Số Điện Thoại</label>
                        <input type="text" id="edit_so_dien_thoai" value="${user.so_dien_thoai || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Địa Chỉ</label>
                        <input type="text" id="edit_dia_chi" value="${user.dia_chi || ''}">
                    </div>
                </div>
                <div class="modal-section">
                    <h3>Công Việc</h3>
                    <div class="modal-field">
                        <label>Phòng Ban</label>
                        <input type="text" id="edit_ten_phong_ban" value="${user.ten_phong_ban || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Chức Vụ</label>
                        <input type="text" id="edit_ten_chuc_vu" value="${user.ten_chuc_vu || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Loại Hợp Đồng</label>
                        <input type="text" id="edit_loai_hop_dong" value="${user.loai_hop_dong || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Ngày Vào Làm</label>
                        <input type="date" id="edit_ngay_vao_lam" value="${user.ngay_vao_lam || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Ngày Nghỉ Việc</label>
                        <input type="date" id="edit_ngay_nghi_viec" value="${user.ngay_nghi_viec || ''}">
                    </div>
                    <div class="modal-field">
                        <label>Trạng Thái</label>
                        <select id="edit_trang_thai">
                            <option value="Đang làm việc" ${user.trang_thai === 'Đang làm việc' ? 'selected' : ''}>Đang làm việc</option>
                            <option value="Nghỉ việc" ${user.trang_thai === 'Nghỉ việc' ? 'selected' : ''}>Nghỉ việc</option>
                        </select>
                    </div>
                </div>
                <div class="modal-section">
                    <h3>Tài Chính</h3>
                    <div class="modal-field">
                        <label>Lương Cơ Bản</label>
                        <input type="number" id="edit_luong_co_ban" value="${user.luong_co_ban || ''}">
                    </div>
                </div>
                <div class="modal-actions">
                    <button class="modal-btn modal-btn-save">
                        <i class="fas fa-save"></i> Lưu
                    </button>
                    <button class="modal-btn modal-btn-cancel">
                        <i class="fas fa-times"></i> Hủy
                    </button>
                </div>
            `;
            document.getElementById('editUserModal').style.display = 'flex';

            // Xử lý nút Lưu
            document.querySelector('.modal-btn-save').addEventListener('click', () => {
                updateUser(user.id_nhan_vien);
            });

            // Xử lý nút Hủy
            document.querySelector('.modal-btn-cancel').addEventListener('click', () => {
                document.getElementById('editUserModal').style.display = 'none';
            });
        }

        // Hàm cập nhật nhân viên
        function updateUser(userId) {
            const updatedUser = {
                ho_ten: document.getElementById('edit_ho_ten').value,
                gioi_tinh: document.getElementById('edit_gioi_tinh').value,
                ngay_sinh: document.getElementById('edit_ngay_sinh').value,
                can_cuoc_cong_dan: document.getElementById('edit_can_cuoc_cong_dan').value,
                ngay_cap: document.getElementById('edit_ngay_cap').value,
                noi_cap: document.getElementById('edit_noi_cap').value,
                que_quan: document.getElementById('edit_que_quan').value,
                email: document.getElementById('edit_email').value,
                so_dien_thoai: document.getElementById('edit_so_dien_thoai').value,
                dia_chi: document.getElementById('edit_dia_chi').value,
                ten_phong_ban: document.getElementById('edit_ten_phong_ban').value,
                ten_chuc_vu: document.getElementById('edit_ten_chuc_vu').value,
                loai_hop_dong: document.getElementById('edit_loai_hop_dong').value,
                ngay_vao_lam: document.getElementById('edit_ngay_vao_lam').value,
                ngay_nghi_viec: document.getElementById('edit_ngay_nghi_viec').value,
                trang_thai: document.getElementById('edit_trang_thai').value,
                luong_co_ban: document.getElementById('edit_luong_co_ban').value
            };

            fetch(`http://localhost/doanqlns/index.php/api/user?id=${userId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(updatedUser)
            })
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        // Đóng modal chỉnh sửa và chi tiết
                        document.getElementById('editUserModal').style.display = 'none';
                        document.getElementById('userModal').style.display = 'none';
                        // Cập nhật danh sách
                        fetch("http://localhost/doanqlns/index.php/api/users")
                            .then(response => response.json())
                            .then(data => {
                                usersData = data;
                                renderTable(data);
                                alert('Cập nhật nhân viên thành công!');
                            });
                    } else {
                        alert('Lỗi khi cập nhật nhân viên: ' + (result.message || 'Không rõ nguyên nhân'));
                    }
                })
                .catch(error => {
                    console.error("Lỗi khi cập nhật nhân viên:", error);
                    alert("Lỗi khi cập nhật nhân viên");
                });
        }

        // Hàm xóa nhân viên
        function deleteUser(userId) {
            fetch(`http://localhost/doanqlns/index.php/api/user?id=${userId}`, {
                method: 'DELETE'
            })
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        // Đóng modal
                        document.getElementById('userModal').style.display = 'none';
                        // Làm mới danh sách
                        usersData = usersData.filter(user => user.id_nhan_vien != userId);
                        renderTable(usersData);
                        alert('Xóa nhân viên thành công!');
                    } else {
                        alert('Lỗi khi xóa nhân viên: ' + (result.message || 'Không rõ nguyên nhân'));
                    }
                })
                .catch(error => {
                    console.error("Lỗi khi xóa nhân viên:", error);
                    alert("Lỗi khi xóa nhân viên");
                });
        }

        // Đóng modal chi tiết
        document.querySelector('#userModal .modal-close').addEventListener('click', () => {
            document.getElementById('userModal').style.display = 'none';
        });

        // Đóng modal chỉnh sửa
        document.querySelector('#editUserModal .modal-close').addEventListener('click', () => {
            document.getElementById('editUserModal').style.display = 'none';
        });

        // Đóng modal chi tiết khi nhấp ra ngoài
        document.getElementById('userModal').addEventListener('click', (e) => {
            if (e.target === document.getElementById('userModal')) {
                document.getElementById('userModal').style.display = 'none';
            }
        });

        // Đóng modal chỉnh sửa khi nhấp ra ngoài
        document.getElementById('editUserModal').addEventListener('click', (e) => {
            if (e.target === document.getElementById('editUserModal')) {
                document.getElementById('editUserModal').style.display = 'none';
            }
        });

        // Xử lý tìm kiếm
        document.getElementById("searchButton").addEventListener("click", function() {
            const keyword = document.getElementById("searchInput").value.toLowerCase();
            const filteredData = usersData.filter(user => 
                user.ho_ten.toLowerCase().includes(keyword)
            );
            renderTable(filteredData);
        });

        document.getElementById("searchInput").addEventListener("keyup", function(event) {
            if (event.key === "Enter") {
                document.getElementById("searchButton").click();
            }
        });
    </script>
</body>
</html>