<?php include('../includes/header.php'); ?>

<div class="container mt-5">
    <div class="alert alert-danger">
        <h4 class="alert-heading">Không có quyền truy cập!</h4>
        <p>Bạn không có quyền thực hiện thao tác này. Vui lòng liên hệ quản trị viên.</p>
        <hr>
        <a href="/doanqlns/giaodien.php" class="btn btn-primary">Quay lại trang chủ</a>
    </div>
</div>

<?php include('../includes/footer.php'); ?>