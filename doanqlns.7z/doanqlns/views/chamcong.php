<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Bảng Chấm Công</title>

    <!-- Font Awesome & Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- CSS chính -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/stylechamcong.css">
    <style>
        .status-select {
            padding: 5px;
            font-size: 14px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        .status-select option[value="Đúng giờ"] {
            color: green;
        }
        .status-select option[value="Đi trễ"] {
            color: orange;
        }
        .status-select option[value="Chưa điểm danh"] {
            color: gray;
        }
        .status-select option[value="Có phép"] {
            color: blue;
        }
        .status-select option[value="Không phép"] {
            color: red;
        }
        .status-select:disabled {
            background-color: #f0f0f0;
            cursor: not-allowed;
        }
        .date-navigation {
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 10px 0;
        }
        .date-navigation button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 5px 10px;
            margin: 0 10px;
            cursor: pointer;
            border-radius: 4px;
        }
        .date-navigation button:hover {
            background-color: #0056b3;
        }
        .date-navigation span {
            font-size: 16px;
            font-weight: 500;
        }
    </style>
</head>

<body>
    <?php include('../includes/sidebar.php'); ?>

    <div class="main-content">
        <h3>Bảng Chấm Công</h3>
        
        <!-- Nút Điểm Danh -->
        <div class="action-container">
            <button class="btn-diemdanh" onclick="showDiemDanhModal()">
                <i class="fas fa-check-circle"></i> Điểm Danh
            </button>
        </div>

        <!-- Điều hướng ngày -->
        <div class="date-navigation">
            <button onclick="changeDate(-1)"><</button>
            <span id="selectedDate">20/04/2025</span>
            <button onclick="changeDate(1)">></button>
        </div>

        <table>
            <thead>
                <tr>
                    <th>ID Chấm Công</th>
                    <th>Nhân Viên</th>
                    <th>Ngày Công</th>
                    <th>Giờ Vào</th>
                    <th>Giờ Ra</th>
                    <th>Trạng Thái</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody id="chamCongTableBody">
                <tr><td colspan="7">Chưa có dữ liệu. Vui lòng điểm danh để hiển thị.</td></tr>
            </tbody>
        </table>

        <!-- Modal Điểm Danh -->
        <div id="diemDanhModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">Điểm Danh Nhân Viên</h2>
                    <button class="modal-close">×</button>
                </div>
                <div class="modal-body">
                    <div class="filter-container">
                        <select id="selectMonth" onchange="updateAttendanceTable()">
                            <option value="1">Tháng 1</option>
                            <option value="2">Tháng 2</option>
                            <option value="3">Tháng 3</option>
                            <option value="4">Tháng 4</option>
                            <option value="5">Tháng 5</option>
                            <option value="6">Tháng 6</option>
                            <option value="7">Tháng 7</option>
                            <option value="8">Tháng 8</option>
                            <option value="9">Tháng 9</option>
                            <option value="10">Tháng 10</option>
                            <option value="11">Tháng 11</option>
                            <option value="12">Tháng 12</option>
                        </select>
                        <select id="selectYear" onchange="updateAttendanceTable()">
                            <option value="2023">2023</option>
                            <option value="2024">2024</option>
                            <option value="2025" selected>2025</option>
                        </select>
                    </div>
                    <div class="attendance-table-container">
                        <table class="attendance-table" id="attendanceTable">
                            <thead id="attendanceTableHead"></thead>
                            <tbody id="attendanceTableBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let usersData = [];
        let attendanceData = [];
        let selectedDate = new Date('2025-04-20'); // Ngày mặc định là 20/04/2025

        // Lấy dữ liệu chấm công
        async function loadAttendanceData() {
            try {
                const response = await fetch("http://localhost/doanqlns/index.php/api/chamcong");
                if (!response.ok) throw new Error("Lỗi khi tải dữ liệu chấm công: " + response.status);
                const data = await response.json();
                if (!Array.isArray(data)) throw new Error("Dữ liệu chấm công không hợp lệ");
                attendanceData = data;
                console.log("Dữ liệu chấm công sau khi tải:", attendanceData);

                // Hiển thị dữ liệu ngay sau khi tải
                renderChamCongTable(data);
            } catch (error) {
                console.error("Lỗi khi tải dữ liệu:", error);
                document.getElementById("chamCongTableBody").innerHTML = '<tr><td colspan="7">Lỗi khi tải dữ liệu</td></tr>';
            }
        }

        // Lấy danh sách nhân viên
        async function loadUsersData() {
            try {
                const response = await fetch("http://localhost/doanqlns/index.php/api/users");
                if (!response.ok) throw new Error("Lỗi khi tải danh sách nhân viên: " + response.status);
                const data = await response.json();
                if (!Array.isArray(data)) throw new Error("Danh sách nhân viên không hợp lệ");
                usersData = data;
                console.log("Danh sách nhân viên:", usersData);
            } catch (error) {
                console.error("Lỗi khi tải danh sách nhân viên:", error);
            }
        }

        // Tải danh sách nhân viên ban đầu
        loadUsersData();

        // Hàm hiển thị bảng chấm công
        function renderChamCongTable(data) {
            const tableBody = document.getElementById("chamCongTableBody");
            tableBody.innerHTML = "";

            // Định dạng ngày được chọn thành chuỗi YYYY-MM-DD
            const selectedDateStr = `${selectedDate.getFullYear()}-${(selectedDate.getMonth() + 1).toString().padStart(2, '0')}-${selectedDate.getDate().toString().padStart(2, '0')}`;

            // Cập nhật ngày hiển thị
            document.getElementById('selectedDate').textContent = `${selectedDate.getDate().toString().padStart(2, '0')}/${(selectedDate.getMonth() + 1).toString().padStart(2, '0')}/${selectedDate.getFullYear()}`;

            // Lọc dữ liệu chỉ lấy các bản ghi của ngày được chọn
            const filteredData = data.filter(record => record.ngay_lam_viec === selectedDateStr);

            if (filteredData && Array.isArray(filteredData) && filteredData.length > 0) {
                filteredData.forEach(record => {
                    const row = document.createElement("tr");
                    let statusClass = "";
                    switch (record.trang_thai.toLowerCase()) {
                        case "đúng giờ":
                            statusClass = "dadiemdanh";
                            break;
                        case "đi trễ":
                            statusClass = "ditre";
                            break;
                        case "có phép":
                            statusClass = "cophep";
                            break;
                        case "không phép":
                            statusClass = "khongphep";
                            break;
                        case "nghỉ việc":
                            statusClass = "nghiviec";
                            break;
                        default:
                            statusClass = "chuadiemdanh";
                            break;
                    }
                    row.innerHTML = `
                        <td>${record.id_cham_cong}</td>
                        <td>${record.ho_ten}</td>
                        <td>${record.ngay_lam_viec}</td>
                        <td>${record.gio_vao || ''}</td>
                        <td>${record.gio_ra || ''}</td>
                        <td><span class="status ${statusClass}">${record.trang_thai}</span></td>
                        <td>
                            
                            <button class="btn-delete" onclick="deleteChamCong(${record.id_cham_cong})">Xóa chấm công<i class="fas fa-trash-alt"></i></button>
                        </td>
                    `;
                    tableBody.appendChild(row);
                });
            } else {
                tableBody.innerHTML = '<tr><td colspan="7">Chưa có dữ liệu cho ngày ' + document.getElementById('selectedDate').textContent + '. Vui lòng điểm danh để hiển thị.</td></tr>';
            }
        }

        // Hàm thay đổi ngày
        function changeDate(direction) {
            // Direction: -1 (ngày trước), +1 (ngày sau)
            selectedDate.setDate(selectedDate.getDate() + direction);
            renderChamCongTable(attendanceData);
        }

        // Hàm hiển thị modal điểm danh
        function showDiemDanhModal() {
            const currentDate = new Date();
            document.getElementById('selectMonth').value = currentDate.getMonth() + 1;
            document.getElementById('selectYear').value = currentDate.getFullYear();
            loadAttendanceData().then(() => {
                updateAttendanceTable();
            });
            document.getElementById('diemDanhModal').style.display = 'flex';
        }

        // Hàm tính tổng điểm danh, số ngày nghỉ và tổng công
        function calculateAttendanceStats(userId, month, year) {
            const startDate = new Date(year, month - 1, 1);
            const endDate = new Date(year, month, 0);
            const records = attendanceData.filter(record => {
                const recordDate = new Date(record.ngay_lam_viec);
                return record.id_nhan_vien == userId && 
                       recordDate >= startDate && 
                       recordDate <= endDate;
            });

            let diemDanhDays = 0; // Tổng ngày điểm danh (Đúng giờ + Đi trễ)
            let nghiDays = 0; // Tổng ngày nghỉ (Có phép + Không phép)

            // Duyệt qua từng ngày trong tháng để tính toán
            for (let day = 1; day <= endDate.getDate(); day++) {
                const date = new Date(year, month - 1, day);
                const dateStr = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
                const isSunday = date.getDay() === 0; // Chủ nhật là ngày 0 trong JavaScript

                // Tìm bản ghi chấm công cho ngày hiện tại
                const record = records.find(r => r.ngay_lam_viec === dateStr);

                if (isSunday) {
                    // Nếu là Chủ nhật, tự động tính là "Đúng giờ"
                    diemDanhDays += 1;
                } else if (record) {
                    // Nếu không phải Chủ nhật và có bản ghi, tính theo trạng thái thực tế
                    if (record.trang_thai === 'Đúng giờ') {
                        diemDanhDays += 1;
                    } else if (record.trang_thai === 'Đi trễ') {
                        diemDanhDays += 0.25;
                    } else if (record.trang_thai === 'Có phép') {
                        nghiDays += 0.5;
                    } else if (record.trang_thai === 'Không phép') {
                        nghiDays += 1;
                    }
                }
            }

            // Tổng công = Điểm danh - Số ngày nghỉ
            const totalWorkDays = diemDanhDays - nghiDays;

            console.log(`Nhân viên ${userId}, tháng ${month}/${year}: Điểm danh=${diemDanhDays}, Nghỉ=${nghiDays}, Tổng công=${totalWorkDays}`);
            return { diemDanhDays, nghiDays, totalWorkDays };
        }

        // Hàm cập nhật bảng điểm danh trong modal
        function updateAttendanceTable() {
            const month = parseInt(document.getElementById('selectMonth').value);
            const year = parseInt(document.getElementById('selectYear').value);
            const daysInMonth = new Date(year, month, 0).getDate();
            const tableHead = document.getElementById('attendanceTableHead');
            const tableBody = document.getElementById('attendanceTableBody');

            // Lấy ngày hiện tại
            const currentDate = new Date('2025-04-20'); // Ngày hiện tại là 20/04/2025
            const currentYear = currentDate.getFullYear();
            const currentMonth = currentDate.getMonth() + 1;
            const currentDay = currentDate.getDate();

            console.log("Dữ liệu chấm công trước khi cập nhật bảng:", attendanceData);

            let headerRow = `
                <tr>
                    <th>ID Chấm Công</th>
                    <th>ID Nhân Viên</th>
                    <th>Họ Tên</th>
            `;
            for (let day = 1; day <= daysInMonth; day++) {
                const date = new Date(year, month - 1, day);
                const weekday = date.toLocaleDateString('vi-VN', { weekday: 'short' });
                headerRow += `
                    <th>
                        <div class="day-header">${day}</div>
                        <div class="weekday-header">${weekday}</div>
                    </th>
                `;
            }
            headerRow += `
                <th>Điểm danh</th>
                <th>Số ngày nghỉ</th>
                <th>Tổng công</th>
            </tr>`;
            tableHead.innerHTML = headerRow;

            tableBody.innerHTML = '';
            if (usersData && usersData.length) {
                usersData.forEach(user => {
                    const row = document.createElement('tr');
                    let rowContent = `
                        <td>${user.id_nhan_vien * 1000 + 1}</td>
                        <td>${user.id_nhan_vien}</td>
                        <td>${user.ho_ten}</td>
                    `;
                    for (let day = 1; day <= daysInMonth; day++) {
                        const date = new Date(year, month - 1, day);
                        const dateStr = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
                        const isSunday = date.getDay() === 0; // Chủ nhật là ngày 0 trong JavaScript

                        // Kiểm tra xem ngày hiện tại có sau ngày hiện tại không
                        let isFutureDate = false;
                        if (year > currentYear || (year === currentYear && month > currentMonth) || 
                            (year === currentYear && month === currentMonth && day > currentDay)) {
                            isFutureDate = true; // Vô hiệu hóa nếu là ngày trong tương lai
                        }

                        // Tìm bản ghi chấm công
                        const attendanceRecord = attendanceData.find(record => 
                            record.id_nhan_vien == user.id_nhan_vien && 
                            record.ngay_lam_viec === dateStr
                        );

                        let currentStatus = attendanceRecord ? attendanceRecord.trang_thai : 'Chưa điểm danh';
                        let isDisabled = isFutureDate; // Vô hiệu hóa nếu là ngày trong tương lai

                        // Nếu là Chủ nhật, tự động đặt trạng thái là "Đúng giờ" và vô hiệu hóa
                        if (isSunday) {
                            currentStatus = 'Đúng giờ';
                            isDisabled = true;

                            // Nếu chưa có bản ghi cho Chủ nhật, tự động thêm vào cơ sở dữ liệu
                            if (!attendanceRecord) {
                                const data = {
                                    id_nhan_vien: user.id_nhan_vien,
                                    ngay_lam_viec: dateStr,
                                    gio_vao: '08:00:00',
                                    gio_ra: '17:00:00',
                                    trang_thai: 'Đúng giờ',
                                    month: month,
                                    year: year
                                };
                                fetch("http://localhost/doanqlns/index.php/api/chamcong", {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json'
                                    },
                                    body: JSON.stringify(data)
                                })
                                .then(response => response.json())
                                .then(result => {
                                    if (result.success) {
                                        console.log(`Tự động thêm điểm danh "Đúng giờ" cho Chủ nhật ${dateStr}, nhân viên ${user.id_nhan_vien}`);
                                        loadAttendanceData(); // Cập nhật lại dữ liệu
                                    }
                                })
                                .catch(error => console.error("Lỗi khi tự động thêm điểm danh:", error));
                            }
                        }

                        console.log(`Trạng thái cho nhân viên ${user.id_nhan_vien}, ngày ${dateStr}: ${currentStatus}`);
                        rowContent += `
                            <td>
                                <select class="status-select" 
                                        data-id="${user.id_nhan_vien}" 
                                        data-date="${dateStr}" 
                                        onchange="updateAttendance(this)"
                                        ${isDisabled ? 'disabled' : ''}>
                                    <option value="Chưa điểm danh" ${currentStatus === 'Chưa điểm danh' ? 'selected' : ''}>Chưa điểm danh</option>
                                    <option value="Đúng giờ" ${currentStatus === 'Đúng giờ' ? 'selected' : ''}>Đúng giờ</option>
                                    <option value="Đi trễ" ${currentStatus === 'Đi trễ' ? 'selected' : ''}>Đi trễ</option>
                                    <option value="Có phép" ${currentStatus === 'Có phép' ? 'selected' : ''}>Có phép</option>
                                    <option value="Không phép" ${currentStatus === 'Không phép' ? 'selected' : ''}>Không phép</option>
                                </select>
                            </td>
                        `;
                    }
                    const { diemDanhDays, nghiDays, totalWorkDays } = calculateAttendanceStats(user.id_nhan_vien, month, year);
                    rowContent += `
                        <td class="diem-danh-days" data-id="${user.id_nhan_vien}">${diemDanhDays}</td>
                        <td class="nghi-days" data-id="${user.id_nhan_vien}">${nghiDays}</td>
                        <td class="total-work-days" data-id="${user.id_nhan_vien}">${totalWorkDays}</td>
                    `;
                    row.innerHTML = rowContent;
                    tableBody.appendChild(row);
                });
            } else {
                tableBody.innerHTML = '<tr><td colspan="' + (daysInMonth + 5) + '">Không có dữ liệu nhân viên</td></tr>';
            }
        }

        // Hàm cập nhật trạng thái điểm danh
        async function updateAttendance(select) {
            const userId = select.getAttribute('data-id');
            const date = select.getAttribute('data-date');
            const status = select.value;
            const month = parseInt(document.getElementById('selectMonth').value);
            const year = parseInt(document.getElementById('selectYear').value);

            console.log(`Cập nhật điểm danh: Nhân viên ${userId}, Ngày ${date}, Trạng thái ${status}`);

            const data = {
                id_nhan_vien: userId,
                ngay_lam_viec: date,
                gio_vao: status === 'Đúng giờ' ? '08:00:00' : (status === 'Đi trễ' ? '09:00:00' : '00:00:00'),
                gio_ra: (status === 'Đúng giờ' || status === 'Đi trễ') ? '17:00:00' : '00:00:00',
                trang_thai: status,
                month: month,
                year: year
            };

            try {
                const response = await fetch("http://localhost/doanqlns/index.php/api/chamcong", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
                const result = await response.json();
                console.log("Kết quả từ API:", result);

                if (result.success) {
                    await loadAttendanceData();

                    // Kiểm tra xem bản ghi đã được lưu đúng chưa
                    const updatedRecord = attendanceData.find(record => 
                        record.id_nhan_vien == userId && 
                        record.ngay_lam_viec === date
                    );
                    if (updatedRecord && updatedRecord.trang_thai === status) {
                        console.log("Bản ghi đã được cập nhật thành công:", updatedRecord);
                    } else {
                        console.error("Bản ghi không được lưu đúng:", updatedRecord);
                        throw new Error("Trạng thái không được lưu vào cơ sở dữ liệu");
                    }

                    updateAttendanceTable();
                } else {
                    throw new Error('Lỗi từ API: ' + (result.message || 'Không rõ nguyên nhân'));
                }
            } catch (error) {
                console.error("Lỗi khi cập nhật điểm danh:", error);
                alert(error.message || "Lỗi khi cập nhật điểm danh");
                select.value = attendanceData.find(record => 
                    record.id_nhan_vien == userId && record.ngay_lam_viec === date
                )?.trang_thai || 'Chưa điểm danh';
            }
        }

        

        // Hàm Xóa
        async function deleteChamCong(id) {
            if (confirm("Bạn có chắc chắn muốn xóa chấm công ID " + id + " không?")) {
                try {
                    const response = await fetch(`http://localhost/doanqlns/index.php/api/chamcong?id=${id}`, {
                        method: 'DELETE'
                    });
                    const result = await response.json();

                    if (result.success) {
                        await loadAttendanceData();
                        updateAttendanceTable();
                        alert("Đã xóa chấm công với ID: " + id);
                    } else {
                        throw new Error("Lỗi khi xóa chấm công: " + (result.message || "Không rõ nguyên nhân"));
                    }
                } catch (error) {
                    console.error("Lỗi khi xóa chấm công:", error);
                    alert(error.message || "Lỗi khi xóa chấm công");
                }
            }
        }

        // Đóng modal
        document.querySelector('#diemDanhModal .modal-close').addEventListener('click', () => {
            document.getElementById('diemDanhModal').style.display = 'none';
        });

        // Đóng modal khi nhấp ra ngoài
        document.getElementById('diemDanhModal').addEventListener('click', (e) => {
            if (e.target === document.getElementById('diemDanhModal')) {
                document.getElementById('diemDanhModal').style.display = 'none';
            }
        });

        // Tải dữ liệu chấm công ngay khi trang được tải
        loadAttendanceData();
    </script>
</body>
</html>