<?php
require_once __DIR__ . '/../includes/check_login.php';
include(__DIR__ . '/../includes/header.php');
include(__DIR__ . '/../includes/sidebar.php');
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Bảng Chấm Công</title>

    <!-- Font Awesome & Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- CSS chính -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/stylechamcong.css">
   <style>
    /* Các kiểu hiện có (giữ nguyên, chỉ thêm hoặc chỉnh sửa phần cần thiết) */
    .status.nghile {
        background-color: rgb(66, 157, 227); /* Màu xanh dương cho Nghỉ Lễ */
    }
    .status.phepnam {
        background-color: #8e44ad; /* Màu tím nhạt cho Phép Năm */
    }

    .name-link,
    .name-link:hover {
        text-decoration: none;
        color: #007bff;
    }

    .btn-diemdanh, .btn-edit, .btn-delete, .btn-export {
        padding: 6px 12px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 14px;
        color: white;
        display: inline-flex;
        align-items: center;
        gap: 4px;
        transition: opacity 0.2s, transform 0.2s;
    }

    .btn-diemdanh {
        background-color: #4CAF50;
    }

    .btn-diemdanh.btn-holiday {
        margin-left: 10px; /* Tạo khoảng cách giữa nút Điểm Danh và Điểm Danh Nghỉ Lễ */
        background-color: #007bff; /* Màu xanh dương để phân biệt */
    }

    .btn-diemdanh:hover {
        opacity: 0.9;
        transform: translateY(-1px);
    }

    .btn-edit {
        background-color: #007bff;
        margin-right: 5px;
    }

    .btn-delete {
        background-color: #dc3545;
    }

    .btn-export {
        background: #007bff;
    }

    .btn-export:hover {
        opacity: 0.9;
    }

    .status {
        padding: 4px 8px;
        border-radius: 4px;
        color: white;
        font-size: 12px;
    }

    .status.dadiemdanh { background-color: #4CAF50; }
    .status.ditre { background-color: #FF9800; }
    .status.cophep { background-color: #2196F3; }
    .status.khongphep { background-color: #f44336; }
    .status.nghiviec { background-color: #9E9E9E; }
    .status.chuadiemdanh { background-color: #B0BEC5; }

    .modal-content {
        max-width: 40%;
        overflow-x: auto;
    }

    .attendance-table th, .attendance-table td {
        min-width: 60px;
    }

    .current-day-column, .current-day-cell {
        background-color: #e0f7fa;
    }

    .day-header {
        font-weight: bold;
    }

    .weekday-header {
        font-size: 12px;
        color: #555;
    }

    @media (max-width: 768px) {
        th, td {
            font-size: 12px;
            padding: 6px;
        }

        .btn-diemdanh, .btn-edit, .btn-delete, .btn-export {
            padding: 4px 8px;
            font-size: 12px;
        }
    }

    table {
        border-collapse: collapse;
        width: 100%;
        max-width: 1200px;
        margin: 0 auto 20px;
        background: #fff;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    /* Modal Container */
    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        overflow: auto;
        animation: fadeIn 0.3s;
    }

    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    /* Modal Content */
    .modal-content {
        background-color: #fefefe;
        margin: 5% auto;
        padding: 0;
        border: none;
        border-radius: 8px;
        width: 90%;
        max-width: 1300px; /* Giảm max-width để modal nhỏ gọn hơn */
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        overflow: hidden;
    }

    /* Modal Header */
    .modal-header {
        background: linear-gradient(90deg, #007bff, #0056b3);
        color: white;
        padding: 15px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .modal-title {
        margin: 0;
        font-size: 1.5rem;
        font-weight: 600;
    }

    .modal-close {
        color: white;
        font-size: 1.8rem;
        font-weight: bold;
        background: none;
        border: none;
        cursor: pointer;
        transition: transform 0.2s;
    }

    .modal-close:hover {
        transform: scale(1.2);
        color: #f1f1f1;
    }

    /* Modal Body */
    .modal-body {
        padding: 20px;
        max-height: 60vh;
        overflow-y: auto;
    }

    /* Holiday Form Styles */
    .holiday-form {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .holiday-form .form-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .holiday-form label {
        font-weight: 500;
        color: #333;
        font-size: 14px;
    }

    .holiday-form input[type="date"] {
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 1rem;
        transition: border-color 0.3s;
        background-color: #f9f9f9;
    }

    .holiday-form input[type="date"]:focus {
        border-color: #007bff;
        outline: none;
        box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.2);
    }

    /* Modal Footer */
    .modal-footer {
        padding: 15px 20px;
        border-top: 1px solid #e9ecef;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        background: #f8f9fa;
    }

    .btn-close {
        padding: 10px 20px;
        background-color: #dc3545;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 500;
        transition: background-color 0.2s;
    }

    .btn-close:hover {
        background-color: #c82333;
    }

    .holiday-form .btn-diemdanh {
        padding: 10px 20px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 500;
        transition: background-color 0.2s;
    }

    .holiday-form .btn-diemdanh:hover {
        background-color: #0056b3;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .modal-content {
            width: 95%;
            max-width: 400px;
        }

        .holiday-form .form-group {
            gap: 5px;
        }

        .holiday-form input[type="date"] {
            font-size: 14px;
            padding: 8px 10px;
        }

        .modal-footer {
            flex-direction: column;
            gap: 8px;
        }

        .btn-close, .holiday-form .btn-diemdanh {
            width: 100%;
            padding: 10px;
        }

        .action-container {
            flex-direction: column;
            gap: 10px;
        }

        .btn-diemdanh.btn-holiday {
            margin-left: 0; /* Bỏ margin-left trên mobile */
        }
    }

    /* Action Container */
    .action-container {
        display: flex;
        gap: 10px; /* Tạo khoảng cách giữa các nút */
        margin-bottom: 20px;
        align-items: center;
    }
</style>
</head>

<body>
    <?php include('../includes/sidebar.php'); ?>

    <div class="main-content">
        <h3>Bảng Chấm Công</h3>

        <!-- Nút Điểm Danh -->
 <!-- Trong action-container -->
<div class="action-container">
    <?php if (isset($_SESSION['quyen_them']) && $_SESSION['quyen_them']): ?>
        <button class="btn-diemdanh" onclick="showDiemDanhModal()">
            <i class="fas fa-check-circle"></i> Điểm Danh
        </button>
        <button class="btn-diemdanh btn-holiday" onclick="showHolidayModal()">
            <i class="fas fa-calendar-alt"></i> Điểm Danh Nghỉ Lễ
        </button>
    <?php endif; ?>
</div>

<!-- Modal Điểm Danh Nghỉ Lễ -->
<div id="holidayModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 class="modal-title">Điểm Danh Nghỉ Lễ</h2>
            <button class="modal-close" onclick="closeHolidayModal()" aria-label="Đóng modal">×</button>
        </div>
        <div class="modal-body">
            <form id="holidayForm" class="holiday-form">
                <div class="form-group">
                    <label for="holidayStartDate">Ngày Bắt Đầu</label>
                    <input type="date" id="holidayStartDate" required>
                </div>
                <div class="form-group">
                    <label for="holidayEndDate">Ngày Kết Thúc</label>
                    <input type="date" id="holidayEndDate" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-close" onclick="closeHolidayModal()">Hủy</button>
                    <button type="submit" class="btn-diemdanh">Lưu</button>
                </div>
            </form>
        </div>
    </div>
</div>
        <!-- Điều hướng ngày -->
        <div class="date-navigation">
            <button onclick="changeDate(-1)" aria-label="Ngày trước"><i class="fas fa-chevron-left"></i></button>
            <span id="selectedDate"></span>
            <button onclick="changeDate(1)" aria-label="Ngày sau"><i class="fas fa-chevron-right"></i></button>
        </div>

        <!-- Bảng chấm công chính -->
        <table>
            <thead>
                <tr>
                    <th>ID Chấm Công</th>
                    <th>Nhân Viên</th>
                    <th>Ngày Công</th>
                    <th>Giờ Vào</th>
                    <th>Giờ Ra</th>
                    <th>Trạng Thái</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody id="chamCongTableBody">
                <tr><td colspan="7">Chưa có dữ liệu. Vui lòng điểm danh để hiển thị.</td></tr>
            </tbody>
        </table>

        <!-- Modal Điểm Danh -->
        <div id="diemDanhModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">Điểm Danh Nhân Viên</h2>
                    <button class="modal-close" onclick="closeDiemDanhModal()" aria-label="Đóng modal">×</button>
                </div>
                <div class="modal-body">
                    <div class="filter-container">
                        <select id="selectMonth" onchange="updateAttendanceTable()" aria-label="Chọn tháng">
                            <option value="1">Tháng 1</option>
                            <option value="2">Tháng 2</option>
                            <option value="3">Tháng 3</option>
                            <option value="4">Tháng 4</option>
                            <option value="5" selected>Tháng 5</option>
                            <option value="6">Tháng 6</option>
                            <option value="7">Tháng 7</option>
                            <option value="8">Tháng 8</option>
                            <option value="9">Tháng 9</option>
                            <option value="10">Tháng 10</option>
                            <option value="11">Tháng 11</option>
                            <option value="12">Tháng 12</option>
                        </select>
                        <input type="number" id="selectYear" min="2000" max="2100" onchange="updateAttendanceTable()" aria-label="Nhập năm"/>
                        <select id="selectPhongBan" class="filter-select" onchange="updateAttendanceTable()" aria-label="Chọn phòng ban">
                            <option value="">Tất cả phòng ban</option>
                        </select>
                        <input type="text" id="searchName" class="search-input" placeholder="Tìm kiếm theo tên..." oninput="updateAttendanceTable()" aria-label="Tìm kiếm theo tên"/>
                        <button class="btn-export" id="exportExcelBtn">
                            <i class="fas fa-file-excel"></i> Xuất Excel
                        </button>
                    </div>
                    <div class="attendance-table-container">
                        <table class="attendance-table" id="attendanceTable">
                            <thead id="attendanceTableHead"></thead>
                            <tbody id="attendanceTableBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Chỉnh Sửa Chấm Công -->
        <div id="editChamCongModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">Chỉnh Sửa Chấm Công</h2>
                    <button class="modal-close" onclick="closeEditChamCongModal()" aria-label="Đóng modal">×</button>
                </div>
                <div class="modal-body">
                    <form id="editChamCongForm">
                        <input type="hidden" id="editIdChamCong">
                        <input type="hidden" id="editIdNhanVien">
                        <div class="form-group">
                            <label for="editHoTen">Nhân Viên</label>
                            <input type="text" id="editHoTen" readonly>
                        </div>
                        <div class="form-group">
                            <label for="editNgayLamViec">Ngày Làm Việc</label>
                            <input type="date" id="editNgayLamViec" required>
                        </div>
                        <div class="form-group">
                            <label for="editGioVao">Giờ Vào</label>
                            <input type="time" id="editGioVao">
                        </div>
                        <div class="form-group">
                            <label for="editGioRa">Giờ Ra</label>
                            <input type="time" id="editGioRa">
                        </div>
                        <div class="form-group">
                            <label for="editTrangThai">Trạng Thái</label>
                            <select id="editTrangThai" required>
                                <option value="Đúng giờ">Đúng giờ</option>
                                <option value="Đi trễ">Đi trễ</option>
                                <option value="Có phép">Có phép</option>
                                <option value="Không phép">Không phép</option>
                                <option value="Phép Năm">Phép Năm</option>
                            </select>
                        </div>
                        <button type="submit" class="btn-diemdanh">Lưu</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal Chi Tiết Chấm Công -->
        <div id="detailChamCongModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Chi Tiết Nhân Viên</h2>
                    <button class="modal-close" onclick="closeDetailChamCongModal()">×</button>
                </div>
                <div class="modal-body">
                    <div class="section-title">Thông Tin Nhân Viên</div>
                    <div class="info-group">
                        <label>Họ và Tên:</label>
                        <span id="detailHoTen" class="info-value"></span>
                    </div>
                    <div class="info-group">
                        <label>Giới Tính:</label>
                        <span id="detailGioiTinh" class="info-value"></span>
                    </div>
                    <div class="info-group">
                        <label>Ngày Sinh:</label>
                        <span id="detailNgaySinh" class="info-value"></span>
                    </div>
                    <div class="info-group">
                        <label>Email:</label>
                        <span id="detailEmail" class="info-value"></span>
                    </div>
                    <div class="info-group">
                        <label>Số Điện Thoại:</label>
                        <span id="detailSoDienThoai" class="info-value"></span>
                    </div>
                    <div class="info-group">
                        <label>Địa Chỉ:</label>
                        <span id="detailDiaChi" class="info-value"></span>
                    </div>
                    <div class="info-group">
                        <label>Phòng Ban:</label>
                        <span id="detailPhongBan" class="info-value"></span>
                    </div>
                    <div class="info-group">
                        <label>Chức Vụ:</label>
                        <span id="detailChucVu" class="info-value"></span>
                    </div>
                    <div class="info-group">
                        <label>Lương Cơ Bản:</label>
                        <span id="detailLuongCoBanNhanVien" class="info-value"></span>
                    </div>
                    <div class="section-title">Thông Tin Chấm Công</div>
                    <div class="info-group">
                        <label>Số Ngày Công:</label>
                        <span id="detailSoNgayCong" class="info-value"></span>
                    </div>
                    <div class="info-group">
                        <label>Nghỉ Phép:</label>
                        <span id="detailNghiPhep" class="info-value"></span>
                    </div>
                    <div class="info-group">
                        <label>Tổng Công:</label>
                        <span id="detailTongCong" class="info-value"></span>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn-close" onclick="closeDetailChamCongModal()">Đóng</button>
                </div>
            </div>
        </div>

        <!-- Loading indicator -->
        <div class="loading" id="loadingIndicator"></div>
    </div>

    <script>
        // Biến toàn cục
        let usersData = [];
        let attendanceData = [];
        let phongBanList = [];
        let selectedDate = new Date();
        const userPermissions = {
            quyen_them: <?php echo isset($_SESSION['quyen_them']) && $_SESSION['quyen_them'] ? 'true' : 'false'; ?>,
            quyen_sua: <?php echo isset($_SESSION['quyen_sua']) && $_SESSION['quyen_sua'] ? 'true' : 'false'; ?>,
            quyen_xoa: <?php echo isset($_SESSION['quyen_xoa']) && $_SESSION['quyen_xoa'] ? 'true' : 'false'; ?>
        };

        // Tham chiếu đến các phần tử DOM
        const chamCongTableBody = document.getElementById("chamCongTableBody");
        const selectedDateElement = document.getElementById("selectedDate");
        const diemDanhModal = document.getElementById("diemDanhModal");
        const editChamCongModal = document.getElementById("editChamCongModal");
        const loadingIndicator = document.getElementById("loadingIndicator");

        // Hàm hiển thị loading
        function showLoading() {
            loadingIndicator.style.display = "flex";
        }

        // Hàm ẩn loading
        function hideLoading() {
            loadingIndicator.style.display = "none";
        }

        // Hàm định dạng số
        function formatNumber(number) {
            if (Number.isInteger(number)) {
                return number.toString();
            }
            return number.toFixed(2);
        }

        // Hàm định dạng tiền tệ
        function formatCurrency(value) {
            if (value == null || value === undefined) return '0';
            return Number(value).toLocaleString('vi-VN', { style: 'currency', currency: 'VND' }).replace('₫', '');
        }

        // Hàm lấy danh sách phòng ban từ API
        async function loadPhongBanData() {
            try {
                const response = await fetch("http://localhost/doanqlns/index.php/api/phongban");
                if (!response.ok) throw new Error("Lỗi khi tải danh sách phòng ban");
                const data = await response.json();
                phongBanList = data;
                populatePhongBanSelect();
            } catch (error) {
                console.error("Lỗi khi tải danh sách phòng ban:", error);
            }
        }

        // Hàm điền danh sách phòng ban vào select
        function populatePhongBanSelect() {
            const select = document.getElementById('selectPhongBan');
            select.innerHTML = '<option value="">Tất cả phòng ban</option>';
            phongBanList.forEach(pb => {
                const option = document.createElement('option');
                option.value = pb.ten_phong_ban;
                option.textContent = pb.ten_phong_ban;
                select.appendChild(option);
            });
        }

        // Hàm lấy dữ liệu chấm công từ API
        async function loadAttendanceData() {
            showLoading();
            try {
                const response = await fetch("http://localhost/doanqlns/index.php/api/chamcong");
                if (!response.ok) throw new Error("Lỗi khi tải dữ liệu chấm công: " + response.status);
                const data = await response.json();
                if (!Array.isArray(data)) throw new Error("Dữ liệu chấm công không hợp lệ");
                attendanceData = data;
                console.log("Dữ liệu chấm công:", attendanceData);
                renderChamCongTable(attendanceData);
            } catch (error) {
                console.error("Lỗi khi tải dữ liệu:", error);
                chamCongTableBody.innerHTML = '<tr><td colspan="7">Lỗi khi tải dữ liệu</td></tr>';
            } finally {
                hideLoading();
            }
        }

        // Hàm lấy danh sách nhân viên từ API
        async function loadUsersData() {
            showLoading();
            try {
                const response = await fetch("http://localhost/doanqlns/index.php/api/users");
                if (!response.ok) throw new Error("Lỗi khi tải danh sách nhân viên: " + response.status);
                const data = await response.json();
                if (!Array.isArray(data)) throw new Error("Danh sách nhân viên không hợp lệ");
                usersData = data;
                console.log("Danh sách nhân viên:", usersData);
            } catch (error) {
                console.error("Lỗi khi tải danh sách nhân viên:", error);
            } finally {
                hideLoading();
            }
        }

        // Hàm hiển thị bảng chấm công chính
        function renderChamCongTable(data) {
            const selectedDateStr = `${selectedDate.getFullYear()}-${(selectedDate.getMonth() + 1).toString().padStart(2, '0')}-${selectedDate.getDate().toString().padStart(2, '0')}`;
            selectedDateElement.textContent = `${selectedDate.getDate().toString().padStart(2, '0')}/${(selectedDate.getMonth() + 1).toString().padStart(2, '0')}/${selectedDate.getFullYear()}`;

            const filteredData = data.filter(record => record.ngay_lam_viec === selectedDateStr);
            chamCongTableBody.innerHTML = "";

            if (filteredData.length > 0) {
                filteredData.forEach(record => {
                   const statusClass = {
    "đúng giờ": "dadiemdanh",
    "đi trễ": "ditre",
    "có phép": "cophep",
    "không phép": "khongphep",
    "nghỉ việc": "nghiviec",
    "phép năm": "phepnam",
    "nghỉ lễ": "nghile"
}[record.trang_thai.toLowerCase()] || "chuadiemdanh";

                    const row = document.createElement("tr");
                    row.innerHTML = `
                        <td>${record.id_cham_cong}</td>
                        <td><a href="#" class="name-link" data-id="${record.id_nhan_vien}">${record.ho_ten}</a></td>
                        <td>${record.ngay_lam_viec}</td>
                        <td>${record.gio_vao || '-'}</td>
                        <td>${record.gio_ra || '-'}</td>
                        <td><span class="status ${statusClass}">${record.trang_thai}</span></td>
                        <td>
                            ${userPermissions.quyen_sua ? `
                                <button class="btn-edit" onclick="editChamCong(${record.id_cham_cong}, ${record.id_nhan_vien}, '${record.ho_ten}', '${record.ngay_lam_viec}', '${record.gio_vao || ''}', '${record.gio_ra || ''}', '${record.trang_thai}')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            ` : ''}
                            ${userPermissions.quyen_xoa ? `
                                <button class="btn-delete" onclick="deleteChamCong(${record.id_cham_cong})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            ` : ''}
                        </td>
                    `;
                    chamCongTableBody.appendChild(row);
                });

                document.querySelectorAll('.name-link').forEach(link => {
                    link.addEventListener('click', function(e) {
                        e.preventDefault();
                        const userId = this.getAttribute('data-id');
                        showDetailChamCong(userId);
                    });
                });
            } else {
                chamCongTableBody.innerHTML = `
                    <tr>
                        <td colspan="7">Chưa có dữ liệu cho ngày ${selectedDateElement.textContent}. Vui lòng điểm danh để hiển thị.</td>
                    </tr>
                `;
            }
        }

        // Hàm hiển thị modal chi tiết chấm công
        async function showDetailChamCong(userId) {
            showLoading();
            try {
                let user = usersData.find(u => u.id_nhan_vien == userId);
                if (!user) {
                    const response = await fetch(`http://localhost/doanqlns/index.php/api/users?id=${userId}`);
                    if (!response.ok) throw new Error("Lỗi khi tải thông tin nhân viên: " + response.status);
                    const data = await response.json();
                    user = Array.isArray(data) ? data[0] : data;
                    if (!user) throw new Error("Không tìm thấy thông tin nhân viên");
                }

                const month = parseInt(document.getElementById('selectMonth').value);
                const year = parseInt(document.getElementById('selectYear').value) || new Date().getFullYear();
                const { diemDanhDays, nghiDays, totalWorkDays } = calculateAttendanceStats(userId, month, year);

                document.getElementById('detailHoTen').textContent = user.ho_ten || 'Không có dữ liệu';
                document.getElementById('detailGioiTinh').textContent = user.gioi_tinh || 'Không có dữ liệu';
                document.getElementById('detailNgaySinh').textContent = user.ngay_sinh || 'Không có dữ liệu';
                document.getElementById('detailEmail').textContent = user.email || 'Không có dữ liệu';
                document.getElementById('detailSoDienThoai').textContent = user.so_dien_thoai || 'Không có dữ liệu';
                document.getElementById('detailDiaChi').textContent = user.dia_chi || 'Không có dữ liệu';
                document.getElementById('detailPhongBan').textContent = user.ten_phong_ban || 'Không có dữ liệu';
                document.getElementById('detailChucVu').textContent = user.ten_chuc_vu || 'Không có dữ liệu';
                document.getElementById('detailLuongCoBanNhanVien').textContent = formatCurrency(user.luong_co_ban) || 'Không có dữ liệu';

                document.getElementById('detailSoNgayCong').textContent = formatNumber(diemDanhDays) || '0';
                document.getElementById('detailNghiPhep').textContent = formatNumber(nghiDays) || '0';
                document.getElementById('detailTongCong').textContent = formatNumber(totalWorkDays) || '0';

                document.getElementById('detailChamCongModal').style.display = 'flex';
            } catch (error) {
                console.error("Lỗi khi hiển thị chi tiết chấm công:", error);
                alert("Lỗi khi hiển thị chi tiết chấm công: " + error.message);
            } finally {
                hideLoading();
            }
        }

        // Hàm đóng modal chi tiết chấm công
        function closeDetailChamCongModal() {
            document.getElementById('detailChamCongModal').style.display = 'none';
        }

        // Hàm thay đổi ngày
        function changeDate(direction) {
            selectedDate.setDate(selectedDate.getDate() + direction);
            renderChamCongTable(attendanceData);
        }

        // Hàm hiển thị modal điểm danh
        async function showDiemDanhModal() {
            if (!userPermissions.quyen_them) {
                alert("Bạn không có quyền điểm danh!");
                return;
            }
            const currentDate = new Date();
            document.getElementById('selectMonth').value = currentDate.getMonth() + 1;
            document.getElementById('selectYear').value = currentDate.getFullYear();
            diemDanhModal.style.display = 'flex';
            await loadPhongBanData();
            await loadUsersData();
            await loadAttendanceData();
            updateAttendanceTable();
        }

        // Hàm đóng modal điểm danh
        function closeDiemDanhModal() {
            diemDanhModal.style.display = 'none';
        }

        // Hàm hiển thị modal chỉnh sửa chấm công
        function editChamCong(id, idNhanVien, hoTen, ngayLamViec, gioVao, gioRa, trangThai) {
            if (!userPermissions.quyen_sua) {
                alert("Bạn không có quyền chỉnh sửa chấm công!");
                return;
            }
            document.getElementById('editIdChamCong').value = id;
            document.getElementById('editIdNhanVien').value = idNhanVien;
            document.getElementById('editHoTen').value = hoTen;
            document.getElementById('editNgayLamViec').value = ngayLamViec;
            document.getElementById('editGioVao').value = gioVao;
            document.getElementById('editGioRa').value = gioRa;
            document.getElementById('editTrangThai').value = trangThai;
            editChamCongModal.style.display = 'flex';
        }

        // Hàm đóng modal chỉnh sửa chấm công
        function closeEditChamCongModal() {
            editChamCongModal.style.display = 'none';
        }

        // Hàm tính thống kê chấm công
       function calculateAttendanceStats(userId, month, year) {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);
    const records = attendanceData.filter(record => {
        const recordDate = new Date(record.ngay_lam_viec);
        return record.id_nhan_vien == userId &&
               recordDate >= startDate &&
               recordDate <= endDate;
    });

    let diemDanhDays = 0;
    let nghiDays = 0;
    let khongPhepCount = 0;

    for (let day = 1; day <= endDate.getDate(); day++) {
        const date = new Date(year, month - 1, day);
        const dateStr = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
        const isSunday = date.getDay() === 0;
        const record = records.find(r => r.ngay_lam_viec === dateStr);

        if (isSunday) {
            diemDanhDays += 1;
        } else if (record) {
            if (record.trang_thai === 'Đúng giờ' || record.trang_thai === 'Phép Năm' || record.trang_thai === 'Nghỉ Lễ') {
                diemDanhDays += 1;
            } else if (record.trang_thai === 'Đi trễ') {
                diemDanhDays += 0.75;
            } else if (record.trang_thai === 'Có phép') {
                diemDanhDays += 1;
                nghiDays -= 0.5;
                khongPhepCount += 0.5;
            } else if (record.trang_thai === 'Không phép') {
                diemDanhDays += 1;
                nghiDays -= 1;
                khongPhepCount += 1;
            }
        }
    }

    const totalWorkDays = diemDanhDays - khongPhepCount;
    return { diemDanhDays, nghiDays, totalWorkDays };
}

        // Hàm cập nhật bảng điểm danh trong modal
        async function updateAttendanceTable() {
            const month = parseInt(document.getElementById('selectMonth').value);
            const yearInput = document.getElementById('selectYear');
            const year = parseInt(yearInput.value) || new Date().getFullYear();
            const phongBan = document.getElementById('selectPhongBan').value;
            const searchName = document.getElementById('searchName').value.toLowerCase();
            const daysInMonth = new Date(year, month, 0).getDate();

            const tableHead = document.getElementById('attendanceTableHead');
            const tableBody = document.getElementById('attendanceTableBody');

            if (!yearInput.value) {
                yearInput.value = new Date().getFullYear();
            }

            const currentDate = new Date();
            const currentYear = currentDate.getFullYear();
            const currentMonth = currentDate.getMonth() + 1;
            const currentDay = currentDate.getDate();

            // Lọc dữ liệu nhân viên dựa trên phòng ban và tên
            let filteredUsers = usersData;
            if (phongBan) {
                filteredUsers = filteredUsers.filter(user => user.ten_phong_ban === phongBan);
            }
            if (searchName) {
                filteredUsers = filteredUsers.filter(user => user.ho_ten.toLowerCase().includes(searchName));
            }

            let headerRow = `
                <tr>
                    <th>ID Chấm Công</th>
                    <th>ID Nhân Viên</th>
                    <th>Họ Tên</th>
            `;
            for (let day = 1; day <= daysInMonth; day++) {
                const date = new Date(year, month - 1, day);
                const weekday = date.toLocaleDateString('vi-VN', { weekday: 'short' });
                const isCurrentDay = (year === currentYear && month === currentMonth && day === currentDay);
                headerRow += `
                    <th class="${isCurrentDay ? 'current-day-column' : ''}">
                        <div class="day-header">${day}</div>
                        <div class="weekday-header">${weekday}</div>
                    </th>
                `;
            }
            headerRow += `
                    <th>Điểm danh</th>
                    <th>Số ngày nghỉ</th>
                    <th>Tổng công</th>
                </tr>`;
            tableHead.innerHTML = headerRow;

            tableBody.innerHTML = '';

            if (!filteredUsers || filteredUsers.length === 0) {
                tableBody.innerHTML = `<tr><td colspan="${daysInMonth + 6}">Không có dữ liệu nhân viên</td></tr>`;
                return;
            }

            filteredUsers.forEach(user => {
                const row = document.createElement('tr');
                let rowContent = `
                    <td>${user.id_nhan_vien * 1000 + 1}</td>
                    <td>${user.id_nhan_vien}</td>
                    <td>${user.ho_ten}</td>
                `;

                for (let day = 1; day <= daysInMonth; day++) {
                    const date = new Date(year, month - 1, day);
                    const dateStr = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
                    const isSunday = date.getDay() === 0;
                    const isFutureDate = year > currentYear ||
                        (year === currentYear && month > currentMonth) ||
                        (year === currentYear && month === currentMonth && day > currentDay);

                    const attendanceRecord = attendanceData.find(record =>
                        record.id_nhan_vien == user.id_nhan_vien &&
                        record.ngay_lam_viec === dateStr
                    );

                    let currentStatus = attendanceRecord ? attendanceRecord.trang_thai : 'Chưa điểm danh';
                    let isDisabled = isFutureDate || !userPermissions.quyen_sua;

                    if (isSunday) {
                        currentStatus = 'Đúng giờ';
                        isDisabled = true;

                        if (!attendanceRecord) {
                            const data = {
                                id_nhan_vien: user.id_nhan_vien,
                                ngay_lam_viec: dateStr,
                                gio_vao: '08:00:00',
                                gio_ra: '17:00:00',
                                trang_thai: 'Đúng giờ',
                                month: month,
                                year: year
                            };

                            fetch("http://localhost/doanqlns/index.php/api/chamcong", {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify(data)
                            })
                            .then(response => response.json())
                            .then(result => {
                                if (result.success) {
                                    console.log(`Tự động thêm điểm danh "Đúng giờ" cho Chủ nhật ${dateStr}, nhân viên ${user.id_nhan_vien}`);
                                } else {
                                    console.error("Thêm điểm danh thất bại:", result.message);
                                }
                            })
                            .catch(error => console.error("Lỗi khi tự động thêm điểm danh:", error));
                        }
                    }

                    const isCurrentDay = (year === currentYear && month === currentMonth && day === currentDay);
                   rowContent += `
                        <td class="${isCurrentDay ? 'current-day-cell' : ''}">
                            <select class="status-select" 
                                    data-id="${user.id_nhan_vien}" 
                                    data-date="${dateStr}" 
                                    onchange="updateAttendance(this)"
                                    ${isDisabled ? 'disabled' : ''}>
                                <option value="Chưa điểm danh" ${currentStatus === 'Chưa điểm danh' ? 'selected' : ''}>Chưa điểm danh</option>
                                <option value="Đúng giờ" ${currentStatus === 'Đúng giờ' ? 'selected' : ''}>Đúng giờ</option>
                                <option value="Đi trễ" ${currentStatus === 'Đi trễ' ? 'selected' : ''}>Đi trễ</option>
                                <option value="Có phép" ${currentStatus === 'Có phép' ? 'selected' : ''}>Có phép</option>
                                <option value="Không phép" ${currentStatus === 'Không phép' ? 'selected' : ''}>Không phép</option>
                                <option value="Phép Năm" ${currentStatus === 'Phép Năm' ? 'selected' : ''}>Phép Năm</option>
                                <option value="Nghỉ Lễ" ${currentStatus === 'Nghỉ Lễ' ? 'selected' : ''}>Nghỉ Lễ</option>
                            </select>
                        </td>
                    `;
                }

                const { diemDanhDays, nghiDays, totalWorkDays } = calculateAttendanceStats(user.id_nhan_vien, month, year);
                rowContent += `
                    <td class="diem-danh-days" data-id="${user.id_nhan_vien}">${formatNumber(diemDanhDays)}</td>
                    <td class="nghi-days" data-id="${user.id_nhan_vien}">${formatNumber(nghiDays)}</td>
                    <td class="total-work-days" data-id="${user.id_nhan_vien}">${formatNumber(totalWorkDays)}</td>
                `;

                row.innerHTML = rowContent;
                tableBody.appendChild(row);
            });

            await loadAttendanceData();
        }

        // Hàm cập nhật trạng thái điểm danh
        async function updateAttendance(select) {
            if (!userPermissions.quyen_sua) {
                alert("Bạn không có quyền chỉnh sửa chấm công!");
                select.value = attendanceData.find(record => 
                    record.id_nhan_vien == select.getAttribute('data-id') && 
                    record.ngay_lam_viec === select.getAttribute('data-date')
                )?.trang_thai || 'Chưa điểm danh';
                return;
            }

            const userId = select.getAttribute('data-id');
            const date = select.getAttribute('data-date');
            const status = select.value;
            const month = parseInt(document.getElementById('selectMonth').value);
            const year = parseInt(document.getElementById('selectYear').value);

            showLoading();

            const data = {
                id_nhan_vien: userId,
                ngay_lam_viec: date,
                gio_vao: status === 'Đúng giờ' ? '08:00:00' : (status === 'Đi trễ' ? '09:00:00' : null),
                gio_ra: (status === 'Đúng giờ' || status === 'Đi trễ') ? '17:00:00' : null,
                trang_thai: status,
                month: month,
                year: year
            };

            try {
                // Kiểm tra xem bản ghi đã tồn tại chưa
                const checkResponse = await fetch(`http://localhost/doanqlns/index.php/api/chamcong?id_nhan_vien=${userId}&ngay_cham_cong=${date}`);
                const existingRecord = await checkResponse.json();

                let response;
                if (existingRecord && existingRecord.length > 0) {
                    // Cập nhật bản ghi hiện có
                    response = await fetch(`http://localhost/doanqlns/index.php/api/chamcong?id_nhan_vien=${userId}&ngay_cham_cong=${date}`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(data)
                    });
                } else {
                    // Thêm bản ghi mới
                    response = await fetch("http://localhost/doanqlns/index.php/api/chamcong", {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(data)
                    });
                }

                const result = await response.json();

                if (result.success) {
                    await loadAttendanceData();
                    updateAttendanceTable();
                } else {
                    throw new Error('Lỗi từ API: ' + (result.message || 'Không rõ nguyên nhân'));
                }
            } catch (error) {
                console.error("Lỗi khi cập nhật điểm danh:", error);
                alert(error.message || "Lỗi khi cập nhật điểm danh");
                select.value = attendanceData.find(record => 
                    record.id_nhan_vien == userId && 
                    record.ngay_lam_viec === date
                )?.trang_thai || 'Chưa điểm danh';
            } finally {
                hideLoading();
            }
        }

        // Hàm xử lý chỉnh sửa chấm công
        async function handleEditChamCong(event) {
            event.preventDefault();
            if (!userPermissions.quyen_sua) {
                alert("Bạn không có quyền chỉnh sửa chấm công!");
                return;
            }

            const id = document.getElementById('editIdChamCong').value;
            const idNhanVien = document.getElementById('editIdNhanVien').value;
            const ngayLamViec = document.getElementById('editNgayLamViec').value;
            const gioVao = document.getElementById('editGioVao').value || null;
            const gioRa = document.getElementById('editGioRa').value || null;
            const trangThai = document.getElementById('editTrangThai').value;

            const data = {
                id_nhan_vien: idNhanVien,
                ngay_lam_viec: ngayLamViec,
                gio_vao: gioVao,
                gio_ra: gioRa,
                trang_thai: trangThai
            };

            showLoading();
            try {
                const response = await fetch(`http://localhost/doanqlns/index.php/api/chamcong?id_nhan_vien=${idNhanVien}&ngay_cham_cong=${ngayLamViec}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const result = await response.json();

                if (result.success) {
                    closeEditChamCongModal();
                    await loadAttendanceData();
                    updateAttendanceTable();
                    renderChamCongTable(attendanceData);
                    alert("Chỉnh sửa chấm công thành công!");
                } else {
                    throw new Error(result.message || "Lỗi khi chỉnh sửa chấm công");
                }
            } catch (error) {
                console.error("Lỗi khi chỉnh sửa chấm công:", error);
                alert(error.message || "Lỗi khi chỉnh sửa chấm công");
            } finally {
                hideLoading();
            }
        }

        // Hàm xóa chấm công
        async function deleteChamCong(id) {
            if (!userPermissions.quyen_xoa) {
                alert("Bạn không có quyền xóa chấm công!");
                return;
            }
            if (!confirm(`Bạn có chắc chắn muốn xóa chấm công ID ${id} không?`)) return;

            showLoading();
            try {
                const response = await fetch(`http://localhost/doanqlns/index.php/api/chamcong?id=${id}`, {
                    method: 'DELETE'
                });
                const result = await response.json();

                if (result.success) {
                    await loadAttendanceData();
                    updateAttendanceTable();
                    renderChamCongTable(attendanceData);
                    alert(`Đã xóa chấm công với ID: ${id}`);
                } else {
                    throw new Error("Lỗi khi xóa chấm công: " + (result.message || "Không rõ nguyên nhân"));
                }
            } catch (error) {
                console.error("Lỗi khi xóa chấm công:", error);
                alert(error.message || "Lỗi khi xóa chấm công");
            } finally {
                hideLoading();
            }
        }

        // Hàm xuất Excel
        async function exportToExcel() {
            const month = parseInt(document.getElementById('selectMonth').value);
            const year = parseInt(document.getElementById('selectYear').value) || new Date().getFullYear();
            const phongBan = document.getElementById('selectPhongBan').value;
            const searchName = document.getElementById('searchName').value.toLowerCase();
            const daysInMonth = new Date(year, month, 0).getDate();

            showLoading();
            try {
                let filteredUsers = usersData;
                if (phongBan) {
                    filteredUsers = filteredUsers.filter(user => user.ten_phong_ban === phongBan);
                }
                if (searchName) {
                    filteredUsers = filteredUsers.filter(user => user.ho_ten.toLowerCase().includes(searchName));
                }

                if (!filteredUsers || filteredUsers.length === 0) {
                    throw new Error("Không có dữ liệu nhân viên để xuất.");
                }

                const headers = [
                    'ID Chấm Công',
                    'ID Nhân Viên',
                    'Họ Tên',
                    ...Array.from({ length: daysInMonth }, (_, i) => `Ngày ${i + 1}`),
                    'Điểm danh',
                    'Số ngày nghỉ',
                    'Tổng công'
                ];

                const csvRows = [headers.map(header => `"${header}"`).join(',')];

                filteredUsers.forEach(user => {
                    const row = [
                        user.id_nhan_vien * 1000 + 1,
                        user.id_nhan_vien,
                        user.ho_ten
                    ];

                    for (let day = 1; day <= daysInMonth; day++) {
                        const dateStr = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
                        const attendanceRecord = attendanceData.find(record =>
                            record.id_nhan_vien == user.id_nhan_vien &&
                            record.ngay_lam_viec === dateStr
                        );
                        const status = attendanceRecord ? attendanceRecord.trang_thai : 'Chưa điểm danh';
                        row.push(status);
                    }

                    const { diemDanhDays, nghiDays, totalWorkDays } = calculateAttendanceStats(user.id_nhan_vien, month, year);
                    row.push(formatNumber(diemDanhDays));
                    row.push(formatNumber(nghiDays));
                    row.push(formatNumber(totalWorkDays));

                    csvRows.push(row.map(value => `"${value.toString().replace(/"/g, '""')}"`).join(','));
                });

                const csvContent = '\uFEFF' + csvRows.join('\n');
                const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.setAttribute('href', url);
                link.setAttribute('download', `BangChamCong_Thang${month}_${year}.csv`);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);
            } catch (error) {
                console.error('Lỗi khi xuất CSV:', error);
                alert('Lỗi khi xuất file CSV: ' + error.message);
            } finally {
                hideLoading();
            }
        }

        // Hiển thị modal điểm danh nghỉ lễ
function showHolidayModal() {
    if (!userPermissions.quyen_them) {
        alert("Bạn không có quyền điểm danh!");
        return;
    }
    document.getElementById('holidayModal').style.display = 'flex';
}

// Đóng modal điểm danh nghỉ lễ
function closeHolidayModal() {
    document.getElementById('holidayModal').style.display = 'none';
}

// Xử lý submit form điểm danh nghỉ lễ
document.getElementById('holidayForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const startDate = document.getElementById('holidayStartDate').value;
    const endDate = document.getElementById('holidayEndDate').value;

    if (!startDate || !endDate) {
        alert("Vui lòng chọn cả ngày bắt đầu và ngày kết thúc!");
        return;
    }

    if (new Date(endDate) < new Date(startDate)) {
        alert("Ngày kết thúc phải lớn hơn hoặc bằng ngày bắt đầu!");
        return;
    }

    const data = {
        start_date: startDate,
        end_date: endDate
    };

    showLoading();
    try {
        const response = await fetch('http://localhost/doanqlns/index.php/api/chamcong?action=markHoliday', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        const result = await response.json();

        if (result.success) {
            closeHolidayModal();
            await loadAttendanceData();
            updateAttendanceTable();
            renderChamCongTable(attendanceData);
            alert("Điểm danh nghỉ lễ thành công!");
        } else {
            throw new Error(result.message || "Lỗi khi điểm danh nghỉ lễ");
        }
    } catch (error) {
        console.error("Lỗi khi điểm danh nghỉ lễ:", error);
        alert(error.message || "Lỗi khi điểm danh nghỉ lễ");
    } finally {
        hideLoading();
    }
});

// Cập nhật sự kiện đóng modal
document.getElementById('holidayModal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('holidayModal')) {
        closeHolidayModal();
    }
});

        // Sự kiện đóng modal
        diemDanhModal.addEventListener('click', (e) => {
            if (e.target === diemDanhModal) {
                closeDiemDanhModal();
            }
        });

        editChamCongModal.addEventListener('click', (e) => {
            if (e.target === editChamCongModal) {
                closeEditChamCongModal();
            }
        });

        document.getElementById('detailChamCongModal').addEventListener('click', (e) => {
            if (e.target === document.getElementById('detailChamCongModal')) {
                closeDetailChamCongModal();
            }
        });

        // Sự kiện submit form chỉnh sửa
        document.getElementById('editChamCongForm').addEventListener('submit', handleEditChamCong);

        // Sự kiện xuất Excel
        document.getElementById('exportExcelBtn').addEventListener('click', exportToExcel);

        // Khởi tạo khi trang được tải
        document.addEventListener('DOMContentLoaded', async () => {
            selectedDateElement.textContent = `${selectedDate.getDate().toString().padStart(2, '0')}/${(selectedDate.getMonth() + 1).toString().padStart(2, '0')}/${selectedDate.getFullYear()}`;
            await loadPhongBanData();
            await loadUsersData();
            await loadAttendanceData();
        });
    </script>
    <?php include(__DIR__ . '/../includes/footer.php'); ?>
</body>
</html>