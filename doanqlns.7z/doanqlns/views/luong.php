<?php
require_once __DIR__ . '/../includes/check_login.php';
include(__DIR__ . '/../includes/header.php');
include(__DIR__ . '/../includes/sidebar.php');
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Bảng Lương</title>

    <!-- Font Awesome & Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- CSS chính -->
    <link rel="stylesheet" href="../css/style.css">

    <!-- CSS riêng -->
    <style>
        .name-link,
        .name-link:hover {
            text-decoration: none;
        }
        body {
            font-family: 'Roboto', sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 0;
        }
        .main-content {
            margin-left: 240px;
            padding: 20px;
        }
        h3 {
            font-size: 26px;
            margin-bottom: 20px;
            color: #333;
            text-align: center;
        }
        .filter-container {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            justify-content: center;
            align-items: center;
        }
        .filter-container select,
        .filter-container input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        .filter-container select:focus,
        .filter-container input:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.2);
        }
        .btn-export {
            padding: 10px 20px;
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            transition: opacity 0.3s;
        }
        .btn-export:hover {
            opacity: 0.9;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            max-width: 1200px;
            margin: 0 auto 20px;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 14px 16px;
            border-bottom: 1px solid #ddd;
            text-align: left;
            word-wrap: break-word;
        }
        th {
            background: #007bff;
            color: #fff;
            font-weight: 500;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        tr:hover {
            background: #eef3f7;
        }
        .btn-edit, .btn-delete {
            border: none;
            background: none;
            cursor: pointer;
            margin: 0 5px;
            font-size: 1rem;
        }
        .btn-edit {
            color: #007bff;
        }
        .btn-delete {
            color: #dc3545;
        }
        .btn-edit:hover, .btn-delete:hover {
            opacity: 0.8;
        }
        .loading {
            display: none;
            text-align: center;
            padding: 20px;
        }
        .loading::after {
            content: '';
            border: 4px solid #f3f3f3;
            border-top: 4px solid #007bff;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            animation: spin 1s linear infinite;
            display: inline-block;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            .filter-container {
                flex-direction: column;
                align-items: center;
            }
            table {
                width: 100%;
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }
            th, td {
                padding: 10px;
            }
            h3 {
                font-size: 22px;
            }
        }
        .modal-section .avatar-container {
            text-align: center;
        }
        .modal-field input[type="file"] {
            padding: 5px;
        }
        .modal-field label {
            font-weight: 500;
            margin-bottom: 5px;
            display: block;
        }
        .modal-field select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1050;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            align-items: center;
            justify-content: center;
        }
        .modal-content {
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.2);
            width: 90%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            animation: slideIn 0.3s ease;
        }
        @keyframes slideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        .modal-header {
            background: linear-gradient(90deg, #007bff, #0056b3);
            color: #fff;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .modal-header h2 {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 500;
        }
        .modal-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #fff;
            transition: transform 0.2s, color 0.2s;
        }
        .modal-close:hover {
            transform: scale(1.2);
            color: #e0e0e0;
        }
        .modal-body {
            padding: 25px;
        }
        .section-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #333;
            margin: 0 0 15px 0;
            border-bottom: 2px solid #007bff;
            padding-bottom: 5px;
        }
        .info-group {
            display: flex;
            align-items: flex-start;
            margin-bottom: 15px;
            padding: 8px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .info-group label {
            font-weight: 500;
            color: #333;
            width: 150px;
            flex-shrink: 0;
            font-size: 14px;
        }
        .info-group .info-value {
            color: #555;
            flex-grow: 1;
            font-size: 14px;
            line-height: 1.5;
        }
        .modal-footer {
            padding: 15px 20px;
            border-top: 1px solid #e9ecef;
            display: flex;
            justify-content: flex-end;
            background: #f8f9fa;
        }
        .btn-close {
            padding: 10px 20px;
            background-color: #dc3545;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: background-color 0.2s;
        }
        .btn-close:hover {
            opacity: 0.85;
        }
        @media (max-width: 768px) {
            .modal-content {
                width: 95%;
                max-width: 400px;
            }
            .info-group {
                flex-direction: column;
                align-items: flex-start;
            }
            .info-group label {
                width: auto;
                margin-bottom: 5px;
            }
            .info-group .info-value {
                width: 100%;
            }
            .modal-body {
                padding: 15px;
            }
            .modal-header h2 {
                font-size: 1.2rem;
            }
        }
    </style>
</head>

<body>
<?php include('../includes/sidebar.php'); ?>

<div class="main-content">
    <h3>Bảng Lương</h3>

    <!-- Bộ lọc tháng và năm -->
    <div class="filter-container">
        <select id="selectMonth" aria-label="Chọn tháng">
            <option value="1">Tháng 1</option>
            <option value="2">Tháng 2</option>
            <option value="3">Tháng 3</option>
            <option value="4" selected>Tháng 4</option>
            <option value="5">Tháng 5</option>
            <option value="6">Tháng 6</option>
            <option value="7">Tháng 7</option>
            <option value="8">Tháng 8</option>
            <option value="9">Tháng 9</option>
            <option value="10">Tháng 10</option>
            <option value="11">Tháng 11</option>
            <option value="12">Tháng 12</option>
        </select>
        <input type="number" id="selectYear" min="2000" max="2100" aria-label="Nhập năm" placeholder="Năm"/>
        <button class="btn-export" id="exportExcelBtn">
            <i class="fas fa-file-excel"></i> Xuất Excel
        </button>
    </div>

    <!-- Bảng lương -->
    <table>
        <thead>
            <tr>
                <th>Mã Lương</th>
                <th>Tên Nhân Viên</th>
                <th>Tháng</th>
                <th>Số Ngày Công</th>
                <th>Lương Tháng</th>
                <th>Phụ Cấp</th>
                <th>Tiền Thưởng/Phạt</th>
                <th>Các Khoản Trừ</th>
                <th>Lương Thực Nhận</th>
            </tr>
        </thead>
        <tbody id="luongTableBody">
            <tr><td colspan="9">Đang tải dữ liệu...</td></tr>
        </tbody>
    </table>

    <!-- Loading indicator -->
    <div class="loading" id="loadingIndicator"></div>

    <!-- Modal chi tiết lương -->
    <div id="detailLuongModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Chi Tiết Bảng Lương</h2>
                <button class="modal-close" onclick="closeDetailModal()">×</button>
            </div>
            <div class="modal-body">
                <div class="section-title">Thông Tin Nhân Viên</div>
                <div class="info-group">
                    <label>Họ và Tên:</label>
                    <span id="detailHoTen" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Giới Tính:</label>
                    <span id="detailGioiTinh" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Ngày Sinh:</label>
                    <span id="detailNgaySinh" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Email:</label>
                    <span id="detailEmail" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Số Điện Thoại:</label>
                    <span id="detailSoDienThoai" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Địa Chỉ:</label>
                    <span id="detailDiaChi" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Phòng Ban:</label>
                    <span id="detailPhongBan" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Chức Vụ:</label>
                    <span id="detailChucVu" class="info-value"></span>
                </div>
                <div class="info-group">
                        <label>Lương Cơ Bản:</label>
                        <span id="detailLuongCoBanNhanVien" class="info-value"></span>
                    </div>
                <div class="section-title">Thông Tin Lương</div>
                <div class="info-group">
                    <label>Mã Lương:</label>
                    <span id="detailIdLuong" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Tháng/Năm:</label>
                    <span id="detailThangNam" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Số Ngày Công:</label>
                    <span id="detailSoNgayCong" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Lương Tháng:</label>
                    <span id="detailLuongCoBan" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Phụ Cấp:</label>
                    <span id="detailPhuCap" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Tiền Thưởng:</label>
                    <span id="detailTienThuong" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Các Khoản Trừ:</label>
                    <span id="detailCacKhoanTru" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Lương Thực Nhận:</label>
                    <span id="detailLuongThucNhan" class="info-value"></span>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn-close" onclick="closeDetailModal()">Đóng</button>
            </div>
        </div>
    </div>
</div>

<script>
// Biến toàn cục để lưu dữ liệu lương
let luongData = [];
let usersData = [];

// Hàm định dạng tiền tệ
function formatCurrency(value) {
    if (value == null || value == undefined) return '0';
    return Number(value).toLocaleString('vi-VN', { style: 'currency', currency: 'VND' });
}

// Hàm định dạng số: luôn giữ số thập phân nếu có
function formatNumber(number) {
    if (typeof number !== 'number') {
        number = parseFloat(number) || 0;
    }
    return number.toString().includes('.') ? number.toString() : number.toFixed(0);
}

// Hàm hiển thị loading
function showLoading() {
    document.getElementById('loadingIndicator').style.display = 'block';
}

// Hàm ẩn loading
function hideLoading() {
    document.getElementById('loadingIndicator').style.display = 'none';
}

// Hàm tải dữ liệu chấm công và tính tổng công
async function loadAttendanceData(month, year) {
    try {
        const response = await fetch('http://localhost/doanqlns/index.php/api/chamcong');
        if (!response.ok) throw new Error(`Lỗi khi tải dữ liệu chấm công: ${response.status}`);
        const data = await response.json();
        if (!Array.isArray(data)) throw new Error('Dữ liệu chấm công không hợp lệ');

        // Lọc dữ liệu theo tháng/năm
        const filteredData = data.filter(record => {
            const recordDate = new Date(record.ngay_lam_viec);
            return recordDate.getMonth() + 1 === month && recordDate.getFullYear() === year;
        });

        // Tính tổng công (totalWorkDays) cho từng nhân viên
        const attendanceByEmployee = {};
        const uniqueEmployeeIds = [...new Set(filteredData.map(record => record.id_nhan_vien))];
        
        uniqueEmployeeIds.forEach(userId => {
            const stats = calculateAttendanceStats(userId, month, year, filteredData);
            attendanceByEmployee[userId] = stats.totalWorkDays;
        });

        return attendanceByEmployee; // { id_nhan_vien: totalWorkDays }
    } catch (error) {
        console.error('Lỗi khi tải dữ liệu chấm công:', error);
        return {};
    }
}

// Hàm tính thống kê chấm công (từ chamcong.php)
function calculateAttendanceStats(userId, month, year, data) {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);
    const records = data.filter(record => {
        const recordDate = new Date(record.ngay_lam_viec);
        return record.id_nhan_vien == userId && 
               recordDate >= startDate && 
               recordDate <= endDate;
    });

    let diemDanhDays = 0;
    let nghiDays = 0;
    let khongPhepCount = 0;

    for (let day = 1; day <= endDate.getDate(); day++) {
        const date = new Date(year, month - 1, day);
        const dateStr = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
        const isSunday = date.getDay() === 0;
        const record = records.find(r => r.ngay_lam_viec === dateStr);

        if (isSunday) {
            diemDanhDays += 1; // Chủ nhật được tính là ngày điểm danh
        } else if (record) {
            if (record.trang_thai === 'Đúng giờ' || record.trang_thai === 'Phép Năm' || record.trang_thai === 'Nghỉ Lễ') {
                diemDanhDays += 1; // Đúng giờ, Phép Năm, Nghỉ Lễ đều tính 1 ngày điểm danh
            } else if (record.trang_thai === 'Đi trễ') {
                diemDanhDays += 0.75; // Đi trễ tính 0.75 ngày
            } else if (record.trang_thai === 'Có phép') {
                diemDanhDays += 1; // Có phép tính 1 ngày điểm danh
                nghiDays -= 0.5; // Trừ 0.5 ngày nghỉ
                khongPhepCount += 0.5; // Tăng đếm không phép
            } else if (record.trang_thai === 'Không phép') {
                diemDanhDays += 1; // Không phép tính 1 ngày điểm danh
                nghiDays -= 1; // Trừ 1 ngày nghỉ
                khongPhepCount += 1; // Tăng đếm không phép
            }
        }
    }

    const totalWorkDays = diemDanhDays - khongPhepCount;
    console.log(`Nhân viên ${userId}, tháng ${month}/${year}: Điểm danh=${diemDanhDays}, Nghỉ=${nghiDays}, Không phép=${khongPhepCount}, Tổng công=${totalWorkDays}`);
    return { diemDanhDays, nghiDays, totalWorkDays };
}

// Hàm tải dữ liệu thưởng
async function loadBonusData(month, year) {
    try {
        const response = await fetch('http://localhost/doanqlns/index.php/api/thuong');
        if (!response.ok) throw new Error(`Lỗi khi tải dữ liệu thưởng: ${response.status}`);
        const data = await response.json();
        if (!Array.isArray(data)) throw new Error('Dữ liệu thưởng không hợp lệ');
        return data.filter(record => {
            const recordDate = new Date(record.ngay);
            return recordDate.getMonth() + 1 === month && recordDate.getFullYear() === year;
        });
    } catch (error) {
        console.error('Lỗi khi tải dữ liệu thưởng:', error);
        return [];
    }
}

// Hàm tính tổng tiền thưởng cho một nhân viên trong tháng/năm
function calculateTotalBonus(bonusData, userId, month, year) {
    const records = bonusData.filter(record => {
        const recordDate = new Date(record.ngay);
        return record.id_nhan_vien == userId && 
               recordDate.getMonth() + 1 === month && 
               recordDate.getFullYear() === year;
    });

    const totalBonus = records.reduce((sum, record) => sum + (parseFloat(record.tien_thuong) || 0), 0);
    return totalBonus;
}

// Hàm tải dữ liệu nhân viên
async function loadUsersData() {
    try {
        const response = await fetch('http://localhost/doanqlns/index.php/api/users');
        if (!response.ok) throw new Error(`Lỗi khi tải dữ liệu nhân viên: ${response.status}`);
        const data = await response.json();
        if (!Array.isArray(data)) throw new Error('Dữ liệu nhân viên không hợp lệ');
        usersData = data;
    } catch (error) {
        console.error('Lỗi khi tải dữ liệu nhân viên:', error);
        return [];
    }
}

// Hàm tải và hiển thị bảng lương
async function loadPayrollData() {
    const month = parseInt(document.getElementById('selectMonth').value);
    const yearInput = document.getElementById('selectYear');
    const year = parseInt(yearInput.value) || new Date().getFullYear();

    if (!yearInput.value) {
        yearInput.value = new Date().getFullYear();
    }

    showLoading();
    try {
        const luongResponse = await fetch('http://localhost/doanqlns/index.php/api/luong');
        if (!luongResponse.ok) throw new Error(`Lỗi khi tải dữ liệu lương: ${luongResponse.status}`);
        let luongDataTemp = await luongResponse.json();
        if (!Array.isArray(luongDataTemp)) throw new Error('Dữ liệu lương không hợp lệ');

        luongData = luongDataTemp.filter(record => {
            const [recordYear, recordMonth] = record.thang.split('-').map(Number);
            return recordMonth === month && recordYear === year;
        });

        const attendanceByEmployee = await loadAttendanceData(month, year);
        const bonusData = await loadBonusData(month, year);

        const tableBody = document.getElementById('luongTableBody');
        tableBody.innerHTML = '';

        if (luongData.length > 0) {
            luongData.forEach(record => {
                const adjustedBasicSalary = parseFloat(record.luong_co_ban) || 0;
                const totalBonus = calculateTotalBonus(bonusData, record.id_nhan_vien, month, year);
                const phuCapChucVu = parseFloat(record.phu_cap_chuc_vu) || 0;
                const cacKhoanTru = parseFloat(record.cac_khoan_tru) || 0;
                const soNgayCong = attendanceByEmployee[record.id_nhan_vien] || 0;
                const luongThucNhan = adjustedBasicSalary + phuCapChucVu + totalBonus - cacKhoanTru;

                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${record.id_luong}</td>
                    <td><a href="#" class="name-link" data-id="${record.id_nhan_vien}" data-luong-id="${record.id_luong}">${record.ho_ten}</a></td>
                    <td>${record.thang}</td>
                    <td>${formatNumber(soNgayCong)}</td>
                    <td>${formatCurrency(adjustedBasicSalary)}</td>
                    <td>${formatCurrency(phuCapChucVu)}</td>
                    <td>${formatCurrency(totalBonus)}</td>
                    <td>${formatCurrency(cacKhoanTru)}</td>
                    <td>${formatCurrency(luongThucNhan)}</td>
                `;
                tableBody.appendChild(row);
            });

            document.querySelectorAll('.name-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const userId = this.getAttribute('data-id');
                    const luongId = this.getAttribute('data-luong-id');
                    showDetailLuong(userId, luongId);
                });
            });
        } else {
            tableBody.innerHTML = `<tr><td colspan="9">Không có dữ liệu lương cho tháng ${month}/${year}</td></tr>`;
        }
    } catch (error) {
        console.error('Lỗi khi tải dữ liệu:', error);
        document.getElementById('luongTableBody').innerHTML = '<tr><td colspan="9">Lỗi khi tải dữ liệu</td></tr>';
    } finally {
        hideLoading();
    }
}

// Hàm hiển thị chi tiết bảng lương
async function showDetailLuong(userId, luongId) {
    showLoading();
    try {
        // Tìm bản ghi lương
        const luongRecord = luongData.find(record => record.id_luong == luongId);
        if (!luongRecord) throw new Error('Không tìm thấy bản ghi lương');

        // Tìm thông tin nhân viên
        let user = usersData.find(u => u.id_nhan_vien == userId);
        if (!user) {
            const response = await fetch(`http://localhost/doanqlns/index.php/api/users?id=${userId}`);
            if (!response.ok) throw new Error(`Lỗi khi tải thông tin nhân viên: ${response.status}`);
            const data = await response.json();
            user = Array.isArray(data) ? data[0] : data;
            if (!user) throw new Error('Không tìm thấy thông tin nhân viên');
        }

        // Tính toán thông tin lương
        const month = parseInt(document.getElementById('selectMonth').value);
        const year = parseInt(document.getElementById('selectYear').value) || new Date().getFullYear();
        const attendanceByEmployee = await loadAttendanceData(month, year);
        const bonusData = await loadBonusData(month, year);
        const adjustedBasicSalary = parseFloat(luongRecord.luong_co_ban) || 0;
        const totalBonus = calculateTotalBonus(bonusData, luongRecord.id_nhan_vien, month, year);
        const phuCapChucVu = parseFloat(luongRecord.phu_cap_chuc_vu) || 0;
        const cacKhoanTru = parseFloat(luongRecord.cac_khoan_tru) || 0;
        const soNgayCong = attendanceByEmployee[luongRecord.id_nhan_vien] || 0;
        const luongThucNhan = adjustedBasicSalary + phuCapChucVu + totalBonus - cacKhoanTru;

        // Điền thông tin nhân viên
        document.getElementById('detailHoTen').textContent = user.ho_ten || 'Không có dữ liệu';
        document.getElementById('detailGioiTinh').textContent = user.gioi_tinh || 'Không có dữ liệu';
        document.getElementById('detailNgaySinh').textContent = user.ngay_sinh || 'Không có dữ liệu';
        document.getElementById('detailEmail').textContent = user.email || 'Không có dữ liệu';
        document.getElementById('detailSoDienThoai').textContent = user.so_dien_thoai || 'Không có dữ liệu';
        document.getElementById('detailDiaChi').textContent = user.dia_chi || 'Không có dữ liệu';
        document.getElementById('detailPhongBan').textContent = user.ten_phong_ban || 'Không có dữ liệu';
        document.getElementById('detailChucVu').textContent = user.ten_chuc_vu || 'Không có dữ liệu';
        document.getElementById('detailLuongCoBanNhanVien').textContent = formatCurrency(user.luong_co_ban) || 'Không có dữ liệu';


        // Điền thông tin lương
        document.getElementById('detailIdLuong').textContent = luongRecord.id_luong || 'Không có dữ liệu';
        document.getElementById('detailThangNam').textContent = luongRecord.thang || `${month}/${year}`;
        document.getElementById('detailSoNgayCong').textContent = formatNumber(soNgayCong);
        document.getElementById('detailLuongCoBan').textContent = formatCurrency(adjustedBasicSalary);
        document.getElementById('detailPhuCap').textContent = formatCurrency(phuCapChucVu);
        document.getElementById('detailTienThuong').textContent = formatCurrency(totalBonus);
        document.getElementById('detailCacKhoanTru').textContent = formatCurrency(cacKhoanTru);
        document.getElementById('detailLuongThucNhan').textContent = formatCurrency(luongThucNhan);

        // Hiển thị modal
        document.getElementById('detailLuongModal').style.display = 'flex';
    } catch (error) {
        console.error('Lỗi khi hiển thị chi tiết bảng lương:', error);
        alert('Lỗi khi hiển thị chi tiết bảng lương: ' + error.message);
    } finally {
        hideLoading();
    }
}

// Hàm đóng modal
function closeDetailModal() {
    document.getElementById('detailLuongModal').style.display = 'none';
}

// Hàm xuất Excel (CSV)
async function exportToExcel() {
    const month = parseInt(document.getElementById('selectMonth').value);
    const year = parseInt(document.getElementById('selectYear').value) || new Date().getFullYear();

    showLoading();
    try {
        const attendanceByEmployee = await loadAttendanceData(month, year);
        const bonusData = await loadBonusData(month, year);

        if (luongData.length === 0) {
            throw new Error(`Không có dữ liệu lương cho tháng ${month}/${year}`);
        }

        // Chuẩn bị dữ liệu CSV
        const headers = [
            'Mã Lương',
            'Tên Nhân Viên',
            'Tháng',
            'Số Ngày Công',
            'Lương Tháng',
            'Phụ Cấp',
            'Tiền Thưởng',
            'Các Khoản Trừ',
            'Lương Thực Nhận'
        ];

        const csvRows = [headers.map(header => `"${header}"`).join(',')];

        luongData.forEach(record => {
            const adjustedBasicSalary = parseFloat(record.luong_co_ban) || 0;
            const totalBonus = calculateTotalBonus(bonusData, record.id_nhan_vien, month, year);
            const phuCapChucVu = parseFloat(record.phu_cap_chuc_vu) || 0;
            const cacKhoanTru = parseFloat(record.cac_khoan_tru) || 0;
            const soNgayCong = attendanceByEmployee[record.id_nhan_vien] || 0;
            const luongThucNhan = adjustedBasicSalary + phuCapChucVu + totalBonus - cacKhoanTru;

            const row = [
                record.id_luong || '',
                record.ho_ten || '',
                record.thang || `${month}/${year}`,
                formatNumber(soNgayCong),
                adjustedBasicSalary.toLocaleString('vi-VN'),
                phuCapChucVu.toLocaleString('vi-VN'),
                totalBonus.toLocaleString('vi-VN'),
                cacKhoanTru.toLocaleString('vi-VN'),
                luongThucNhan.toLocaleString('vi-VN')
            ].map(value => `"${value.toString().replace(/"/g, '""')}"`);

            csvRows.push(row.join(','));
        });

        // Tạo nội dung CSV với BOM để hỗ trợ tiếng Việt
        const csvContent = '\uFEFF' + csvRows.join('\n');

        // Tạo Blob và tải xuống
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `BangLuong_Thang${month}_${year}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    } catch (error) {
        console.error('Lỗi khi xuất CSV:', error);
        alert('Lỗi khi xuất file CSV: ' + error.message);
    } finally {
        hideLoading();
    }
}

// Khởi tạo khi trang tải
document.addEventListener('DOMContentLoaded', () => {
    const currentDate = new Date();
    document.getElementById('selectMonth').value = currentDate.getMonth() + 1;
    document.getElementById('selectYear').value = currentDate.getFullYear();
    loadUsersData();
    loadPayrollData();

    // Sự kiện thay đổi tháng/năm
    document.getElementById('selectMonth').addEventListener('change', loadPayrollData);
    document.getElementById('selectYear').addEventListener('change', loadPayrollData);

    // Sự kiện xuất Excel
    document.getElementById('exportExcelBtn').addEventListener('click', exportToExcel);

    // Sự kiện đóng modal khi click bên ngoài
    document.getElementById('detailLuongModal').addEventListener('click', (e) => {
        if (e.target === document.getElementById('detailLuongModal')) {
            closeDetailModal();
        }
    });
});
</script>
<?php include(__DIR__ . '/../includes/footer.php'); ?>
</body>
</html>