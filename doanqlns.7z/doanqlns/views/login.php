<?php
session_start();
require_once __DIR__ . '/../controllers/AuthController.php';

$auth = new AuthController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['google_id_token'])) {
        $result = $auth->googleLogin($_POST['google_id_token']);
        header('Content-Type: application/json');
        echo json_encode($result);
        exit();
    } else {
        $ten_dang_nhap = $_POST['ten_dang_nhap'] ?? '';
        $mat_khau = $_POST['mat_khau'] ?? '';
        
        $result = $auth->login($ten_dang_nhap, $mat_khau);
        
        if ($result['success']) {
            $redirect_url = isset($_SESSION['redirect_url']) ? $_SESSION['redirect_url'] : '/doanqlns/giaodien.php';
            unset($_SESSION['redirect_url']);
            header("Location: $redirect_url");
            exit();
        } else {
            $error = $result['message'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập hệ thống</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://accounts.google.com/gsi/client" async defer></script>
</head>
<body>
    <div class="login-container">
        <h2>Đăng nhập hệ thống</h2>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" id="login-form">
            <div class="form-group">
                <label for="ten_dang_nhap">Tên đăng nhập:</label>
                <input type="text" id="ten_dang_nhap" name="ten_dang_nhap" required>
            </div>
            <div class="form-group">
                <label for="mat_khau">Mật khẩu:</label>
                <input type="password" id="mat_khau" name="mat_khau" required>
            </div>
            <button type="submit" class="btn-login">Đăng nhập</button>
        </form>
        
        <div style="margin-top: 20px; text-align: center;">
            <div id="g_id_onload"
                 data-client_id="725719363319-vtnuuo1goitapagommctgbf91g8f5741.apps.googleusercontent.com"
                 data-callback="handleCredentialResponse"
                 data-auto_prompt="false">
            </div>
            <div class="g_id_signin" data-type="standard" data-size="large"></div>
        </div>
    </div>

    <script>
        function handleCredentialResponse(response) {
            const idToken = response.credential;
            fetch('/doanqlns/views/login.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'google_id_token=' + encodeURIComponent(idToken)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = '<?php echo isset($_SESSION['redirect_url']) ? $_SESSION['redirect_url'] : '/doanqlns/giaodien.php'; ?>';
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Đã có lỗi xảy ra khi đăng nhập bằng Google');
            });
        }
    </script>
</body>
</html>

<style>
.badge {
    padding: 3px 8px;
    border-radius: 10px;
    font-size: 12px;
    margin-right: 10px;
}

.badge-danger {
    background-color: #dc3545;
    color: white;
}

.badge-primary {
    background-color: #007bff;
    color: white;
}

.user-info {
    margin-right: 15px;
    font-weight: 500;
}

.login-container {
    max-width: 400px;
    margin: 100px auto;
    padding: 20px;
    background: #fff;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.login-container h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #333;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

.form-group input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    box-sizing: border-box;
}

.btn-login {
    width: 100%;
    padding: 10px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
}

.btn-login:hover {
    background-color: #45a049;
}

.alert {
    padding: 10px;
    margin-bottom: 15px;
    border-radius: 4px;
}

.alert-danger {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}
</style>