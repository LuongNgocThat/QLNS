<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Bảng Bảo Hiểm và Thuế TNCN</title>

    <!-- Font Awesome & Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- CSS chính -->
    <link rel="stylesheet" href="../css/style.css">

    <!-- CSS riêng cho bảng -->
    <style>
    body {
        font-family: 'Roboto', sans-serif;
        background: #f4f6f9;
        margin: 0;
        padding: 0;
    }
    .main-content {
        margin-left: 240px;
        padding: 20px;
    }
    h3 {
        font-size: 26px;
        margin-bottom: 20px;
        color: #333;
        text-align: center; /* Căn giữa tiêu đề */
    }
    table {
        border-collapse: collapse;
        width: 100%;
        max-width: 1200px; /* Giới hạn chiều rộng bảng */
        margin: 0 auto 20px; /* Căn giữa bảng */
        background: #fff;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    th, td {
        padding: 8px 10px; /* Giảm padding để thu nhỏ kích thước */
        border-bottom: 1px solid #ddd;
        text-align: left;
        font-size: 0.9rem; /* Giảm kích thước font để bảng trông nhỏ gọn hơn */
    }
    th {
        background: #007bff;
        color: #fff;
        font-weight: 500;
    }
    tr:nth-child(even) {
        background: #f9f9f9;
    }
    tr:hover {
        background: #eef3f7;
    }
    .status {
        padding: 3px 6px; /* Giảm padding cho trạng thái */
        border-radius: 5px;
        font-size: 0.8rem; /* Giảm kích thước font cho trạng thái */
        font-weight: 500;
        display: inline-block;
    }
    .status.danglam {
        background: #28a745;
        color: #fff;
    }
    .status.nghiviec {
        background: #dc3545;
        color: #fff;
    }
    .status.chuadien {
        background: #ffc107;
        color: #333;
    }
    .btn-edit, .btn-delete {
        border: none;
        background: none;
        cursor: pointer;
        margin: 0 3px;
        font-size: 0.9rem; /* Giảm kích thước font của các nút hành động */
    }
    .btn-edit {
        color: #007bff;
    }
    .btn-delete {
        color: #dc3545;
    }
    .btn-edit:hover, .btn-delete:hover {
        opacity: 0.8;
    }
    @media (max-width: 768px) {
        table {
            display: block;
            overflow-x: auto;
            max-width: 100%;
        }
    }
</style>

</head>

<body>

<?php include('../includes/sidebar.php'); ?>

<div class="main-content">
    <h3>Bảng Bảo Hiểm và Thuế TNCN</h3>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nhân Viên</th>
                <th>Tháng</th>
                <th>BHXH</th>
                <th>BHYT</th>
                <th>BHTN</th>
                <th>Thuế TNCN</th>
                <th>Tổng Khoản Trừ</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody id="baoHiemThueTableBody">
            <tr><td colspan="9">Đang tải dữ liệu...</td></tr>
        </tbody>
    </table>
</div>

<script>
fetch("http://localhost/doanqlns/index.php/api/baohiem")
    .then(response => response.json())
    .then(data => {
        const tableBody = document.getElementById("baoHiemThueTableBody");
        tableBody.innerHTML = ""; // Xóa dòng đang tải
        if (data && Array.isArray(data)) {
            data.forEach(record => {
                const row = document.createElement("tr");
                row.innerHTML = `
                    <td>${record.id}</td>
                    <td>${record.ho_ten}</td>
                    <td>${record.thang}</td>
                    <td>${record.bhxh}</td>
                    <td>${record.bhyt}</td>
                    <td>${record.bhtn}</td>
                    <td>${record.thue_tncn}</td>
                    <td>${record.tong_khoan_tru}</td>
                    <td>
                        <button class="btn-edit" onclick="editBaoHiemThuetncn(${record.id})"><i class="fas fa-edit"></i></button>
                        <button class="btn-delete" onclick="deleteBaoHiemThuetncn(${record.id})"><i class="fas fa-trash-alt"></i></button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        } else {
            tableBody.innerHTML = '<tr><td colspan="9">Không có dữ liệu</td></tr>';
        }
    })
    .catch(error => {
        console.error("Lỗi khi tải dữ liệu:", error);
        document.getElementById("baoHiemThueTableBody").innerHTML = '<tr><td colspan="9">Lỗi khi tải dữ liệu</td></tr>';
    });

// Hàm Sửa
function editBaoHiemThuetncn(id) {
    alert("Sửa bảo hiểm và thuế TNCN với ID: " + id);
    // Redirect hoặc hiện popup sửa tại đây
}

// Hàm Xóa
function deleteBaoHiemThuetncn(id) {
    if (confirm("Bạn có chắc chắn muốn xóa bảo hiểm và thuế TNCN ID " + id + " không?")) {
        alert("Đã xóa bảo hiểm và thuế TNCN với ID: " + id);
        // Gọi API xóa tại đây
    }
}
</script>

</body>
</html>
