<?php
require_once __DIR__ . '/../includes/check_login.php';
include(__DIR__ . '/../includes/header.php');
include(__DIR__ . '/../includes/sidebar.php');
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Bảng Bảo Hiểm và Thuế TNCN</title>

    <!-- Font Awesome & Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- CSS chính -->
    <link rel="stylesheet" href="../css/style.css">

    <!-- CSS riêng cho bảng -->
    <style>
        .name-link,
        .name-link:hover {
            text-decoration: none;
            color: blue;
        }
        body {
            font-family: 'Roboto', sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 0;
        }
        .main-content {
            margin-left: 240px;
            padding: 20px;
        }
        h3 {
            font-size: 26px;
            margin-bottom: 20px;
            color: #333;
            text-align: center;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            max-width: 1200px;
            margin: 0 auto 20px;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 8px 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
            font-size: 0.9rem;
        }
        th {
            background: #007bff;
            color: #fff;
            font-weight: 500;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        tr:hover {
            background: #eef3f7;
        }
        .status {
            padding: 3px 6px;
            border-radius: 5px;
            font-size: 0.8rem;
            font-weight: 500;
            display: inline-block;
        }
        .status.danglam {
            background: #28a745;
            color: #fff;
        }
        .status.nghiviec {
            background: #dc3545;
            color: #fff;
        }
        .status.chuadien {
            background: #ffc107;
            color: #333;
        }
        .btn-edit, .btn-delete {
            border: none;
            background: none;
            cursor: pointer;
            margin: 0 3px;
            font-size: 0.9rem;
        }
        .btn-edit {
            color: #007bff;
        }
        .btn-delete {
            color: #dc3545;
        }
        .btn-edit:hover, .btn-delete:hover {
            opacity: 0.8;
        }
        @media (max-width: 768px) {
            table {
                display: block;
                overflow-x: auto;
                max-width: 100%;
            }
        }

        /* Nút thêm mới và bộ lọc */
        .action-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }
        .btn-add {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: background-color 0.3s;
            margin-left: 90px;
        }
        .btn-add:hover {
            background-color: #218838;
        }
        .filter-container {
            display: flex;
            gap: 15px;
            align-items: center;
            margin-right: 90px;
        }
        .filter-container label {
            font-size: 14px;
            color: #333;
            font-weight: 500;
        }
        .filter-container select, .filter-container input {
            padding: 8px;
            font-size: 14px;
            border: 1px solid #ddd;
            border-radius: 4px;
            outline: none;
            width: 120px;
            transition: border-color 0.2s;
        }
        .filter-container select:focus, .filter-container input:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.2);
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
            animation: fadeIn 0.3s;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .modal-content {
            background-color: white;
            width: 90%;
            max-width: 700px;
            border-radius: 8px;
            overflow: hidden;
            position: relative;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }
        .modal-content::-webkit-scrollbar {
            width: 8px;
        }
        .modal-content::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }
        .modal-content::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
        }
        .modal-content::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        .modal-header {
            background: linear-gradient(90deg, #007bff, #0056b3);
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .modal-title {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 600;
        }
        .modal-close {
            color: white;
            font-size: 1.8rem;
            font-weight: bold;
            background: none;
            border: none;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .modal-close:hover {
            transform: scale(1.2);
            color: #f1f1f1;
        }
        .modal-body {
            padding: 20px;
            max-height: 60vh;
            overflow-y: auto;
        }
        .section-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #333;
            margin: 0 0 15px 0;
            border-bottom: 2px solid #007bff;
            padding-bottom: 5px;
        }
        .info-group {
            display: flex;
            align-items: flex-start;
            margin-bottom: 15px;
            padding: 8px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .info-group label {
            font-weight: 500;
            color: #333;
            width: 150px;
            flex-shrink: 0;
            font-size: 14px;
        }
        .info-group .info-value {
            color: #555;
            flex-grow: 1;
            font-size: 14px;
            line-height: 1.5;
        }
        .modal-footer {
            padding: 15px 20px;
            border-top: 1px solid #e9ecef;
            display: flex;
            justify-content: flex-end;
            background: #f8f9fa;
        }
        .btn-save, .btn-cancel, .btn-close {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        .btn-save {
            background-color: #007bff;
            color: white;
        }
        .btn-save:hover {
            background-color: #0056b3;
        }
        .btn-cancel {
            background-color: #6c757d;
            color: white;
        }
        .btn-cancel:hover {
            background-color: #5a6268;
        }
        .btn-close {
            background-color: #dc3545;
            color: white;
        }
        .btn-close:hover {
            background-color: #c82333;
        }
        /* Modal thêm mới và chỉnh sửa */
        #addModal .modal-content, #editModal .modal-content {
            max-width: 500px;
        }
        #addModal .modal-body, #editModal .modal-body {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        #addModal .modal-body label, #editModal .modal-body label {
            font-size: 14px;
            color: #333;
            font-weight: 500;
        }
        #addModal .modal-body input, #addModal .modal-body select,
        #editModal .modal-body input, #editModal .modal-body select {
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ddd;
            border-radius: 4px;
            outline: none;
            width: 100%;
            transition: border-color 0.2s;
        }
        #addModal .modal-body input:focus, #addModal .modal-body select:focus,
        #editModal .modal-body input:focus, #editModal .modal-body select:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.2);
        }
        #addModal .modal-body input[readonly], #editModal .modal-body input[readonly] {
            background-color: #f5f5f5;
            cursor: not-allowed;
        }
        /* Responsive Design */
        @media (max-width: 768px) {
            .modal-content {
                width: 95%;
                max-width: 400px;
            }
            .modal-body {
                max-height: 70vh;
            }
            .info-group {
                flex-direction: column;
                align-items: flex-start;
            }
            .info-group label {
                width: auto;
                margin-bottom: 5px;
            }
            .info-group .info-value {
                width: 100%;
            }
            .main-content {
                margin-left: 0;
                padding: 10px;
            }
            .btn-add {
                margin-left: 10px;
            }
            .filter-container {
                margin-right: 10px;
            }
        }
    </style>
</head>

<body>
<div class="main-content">
    <h3>Bảng Bảo Hiểm và Thuế TNCN</h3>

    <!-- Khu vực nút thêm và bộ lọc -->
    <div class="action-container">
        <button class="btn-add" onclick="showAddModal()">
            <i class="fas fa-plus"></i> Thêm mới
        </button>
        <div class="filter-container">
            <label for="filterMonth">Tháng:</label>
            <select id="filterMonth" onchange="loadData(); loadNhanVien();">
                <option value="01">Tháng 1</option>
                <option value="02">Tháng 2</option>
                <option value="03">Tháng 3</option>
                <option value="04">Tháng 4</option>
                <option value="05">Tháng 5</option>
                <option value="06">Tháng 6</option>
                <option value="07">Tháng 7</option>
                <option value="08">Tháng 8</option>
                <option value="09">Tháng 9</option>
                <option value="10">Tháng 10</option>
                <option value="11">Tháng 11</option>
                <option value="12">Tháng 12</option>
            </select>
            <label for="filterYear">Năm:</label>
            <input type="number" id="filterYear" min="2000" max="2100" onchange="loadData(); loadNhanVien();">
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nhân Viên</th>
                <th>Tháng</th>
                <th>BHXH</th>
                <th>BHYT</th>
                <th>BHTN</th>
                <th>Thuế TNCN</th>
                <th>Tổng Khoản Trừ</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody id="baoHiemThueTableBody">
            <tr><td colspan="9">Đang tải dữ liệu...</td></tr>
        </tbody>
    </table>

    <!-- Modal chỉnh sửa -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Chỉnh sửa Bảo Hiểm và Thuế TNCN</h2>
                <button class="modal-close" onclick="closeEditModal()" aria-label="Đóng modal">×</button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="editId">
                <input type="hidden" id="editIdNhanVien">
                <label for="editHoTen">Tên Nhân Viên:</label>
                <input type="text" id="editHoTen" readonly>
                <label for="editThang">Tháng (YYYY-MM):</label>
                <input type="text" id="editThang" placeholder="VD: 2023-10" readonly>
                <label for="editBhxh">BHXH:</label>
                <input type="text" id="editBhxh" placeholder="Nhập BHXH">
                <label for="editBhyt">BHYT:</label>
                <input type="text" id="editBhyt" placeholder="Nhập BHYT">
                <label for="editBhtn">BHTN:</label>
                <input type="text" id="editBhtn" placeholder="Nhập BHTN">
                <label for="editThueTncn">Thuế TNCN:</label>
                <input type="text" id="editThueTncn" placeholder="Thuế TNCN" readonly>
                <label for="editTongKhoanTru">Tổng Khoản Trừ:</label>
                <input type="text" id="editTongKhoanTru" placeholder="Tổng Khoản Trừ" readonly>
            </div>
            <div class="modal-footer">
                <button class="btn-cancel" onclick="closeEditModal()">Hủy</button>
                <button class="btn-save" onclick="saveBaoHiemThue()">Lưu</button>
            </div>
        </div>
    </div>

    <!-- Modal chi tiết bảo hiểm và thuế TNCN -->
    <div id="detailBaoHiemModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Chi Tiết Nhân Viên</h2>
                <button class="modal-close" onclick="closeDetailBaoHiemModal()" aria-label="Đóng modal">×</button>
            </div>
            <div class="modal-body">
                <div class="section-title">Thông Tin Nhân Viên</div>
                <div class="info-group">
                    <label>Họ và Tên:</label>
                    <span id="detailHoTen" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Giới Tính:</label>
                    <span id="detailGioiTinh" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Ngày Sinh:</label>
                    <span id="detailNgaySinh" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Email:</label>
                    <span id="detailEmail" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Số Điện Thoại:</label>
                    <span id="detailSoDienThoai" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Địa Chỉ:</label>
                    <span id="detailDiaChi" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Phòng Ban:</label>
                    <span id="detailPhongBan" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Chức Vụ:</label>
                    <span id="detailChucVu" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Lương Cơ Bản:</label>
                    <span id="detailLuongCoBan" class="info-value"></span>
                </div>
                <div class="section-title">Thông Tin Bảo Hiểm và Thuế TNCN</div>
                <div class="info-group">
                    <label>BHXH:</label>
                    <span id="detailBhxh" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>BHYT:</label>
                    <span id="detailBhyt" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>BHTN:</label>
                    <span id="detailBhtn" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Thuế TNCN:</label>
                    <span id="detailThueTncn" class="info-value"></span>
                </div>
                <div class="info-group">
                    <label>Tổng Khoản Trừ:</label>
                    <span id="detailTongKhoanTru" class="info-value"></span>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn-close" onclick="closeDetailBaoHiemModal()">Đóng</button>
            </div>
        </div>
    </div>

    <!-- Modal thêm mới -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Thêm mới Bảo Hiểm và Thuế TNCN</h2>
                <button class="modal-close" onclick="closeAddModal()" aria-label="Đóng modal">×</button>
            </div>
            <div class="modal-body">
                <label for="addIdNhanVien">Nhân Viên:</label>
                <select id="addIdNhanVien" onchange="calculateTaxForAdd()">
                    <option value="">Chọn nhân viên</option>
                    <!-- Danh sách nhân viên sẽ được tải động -->
                </select>
                <label for="addThang">Tháng (YYYY-MM):</label>
                <input type="text" id="addThang" placeholder="VD: 2023-10">
                <label for="addBhxh">BHXH:</label>
                <input type="text" id="addBhxh" placeholder="Nhập BHXH" oninput="updateTongKhoanTru('add')">
                <label for="addBhyt">BHYT:</label>
                <input type="text" id="addBhyt" placeholder="Nhập BHYT" oninput="updateTongKhoanTru('add')">
                <label for="addBhtn">BHTN:</label>
                <input type="text" id="addBhtn" placeholder="Nhập BHTN" oninput="updateTongKhoanTru('add')">
                <label for="addThueTncn">Thuế TNCN:</label>
                <input type="text" id="addThueTncn" placeholder="Thuế TNCN" readonly>
            </div>
            <div class="modal-footer">
                <button class="btn-cancel" onclick="closeAddModal()">Hủy</button>
                <button class="btn-save" onclick="addBaoHiemThue()">Thêm</button>
            </div>
        </div>
    </div>
</div>

<script>
// Hàm định dạng số có dấu phẩy
function formatNumber(number) {
    return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// Hàm bỏ định dạng số (loại bỏ dấu phẩy)
function unformatNumber(formattedNumber) {
    return parseFloat(formattedNumber.replace(/,/g, '')) || 0;
}

// Hàm định dạng tiền tệ
function formatCurrency(value) {
    if (value == null || value === undefined) return '0';
    return Number(value).toLocaleString('vi-VN', { style: 'currency', currency: 'VND' }).replace('₫', '');
}

// Hàm tính thuế TNCN dựa trên lương cơ bản
function calculateTax(luongCoBan) {
    if (luongCoBan < 10000000) {
        return 0; // Dưới 10 triệu: 0%
    } else if (luongCoBan >= 10000000 && luongCoBan < 15000000) {
        return luongCoBan * 0.05; // Từ 10 triệu đến dưới 15 triệu: 5%
    } else {
        return luongCoBan * 0.10; // Từ 15 triệu trở lên: 10%
    }
}

// Hàm tính tổng khoản trừ
function updateTongKhoanTru(mode) {
    const bhxh = unformatNumber(document.getElementById(`${mode}Bhxh`).value);
    const bhyt = unformatNumber(document.getElementById(`${mode}Bhyt`).value);
    const bhtn = unformatNumber(document.getElementById(`${mode}Bhtn`).value);
    const thueTncn = unformatNumber(document.getElementById(`${mode}ThueTncn`).value);
    const tongKhoanTru = bhxh + bhyt + bhtn + thueTncn;
    if (mode === 'edit') {
        document.getElementById('editTongKhoanTru').value = formatNumber(tongKhoanTru.toFixed(0));
    }
}

// Hàm tính thuế TNCN khi chọn nhân viên trong modal thêm mới
function calculateTaxForAdd() {
    const idNhanVien = document.getElementById('addIdNhanVien').value;
    if (!idNhanVien) {
        document.getElementById('addThueTncn').value = '';
        updateTongKhoanTru('add');
        return;
    }

    fetch(`http://localhost/doanqlns/index.php/api/user?id=${idNhanVien}`)
        .then(response => response.json())
        .then(user => {
            if (user && user.luong_co_ban) {
                const luongCoBan = parseFloat(user.luong_co_ban);
                const thueTncn = calculateTax(luongCoBan);
                document.getElementById('addThueTncn').value = formatNumber(thueTncn.toFixed(0));
                updateTongKhoanTru('add');
            } else {
                alert("Không tìm thấy thông tin lương cơ bản của nhân viên!");
                document.getElementById('addThueTncn').value = '';
                updateTongKhoanTru('add');
            }
        })
        .catch(error => {
            console.error("Lỗi khi lấy thông tin nhân viên:", error);
            alert("Lỗi khi lấy thông tin nhân viên");
        });
}

// Định dạng ngày tháng
function formatDateToYYYYMM(date) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    return `${year}-${month}`;
}

// Kiểm tra định dạng YYYY-MM
function isValidDateFormat(dateStr) {
    const regex = /^\d{4}-\d{2}$/;
    if (!regex.test(dateStr)) return false;

    const [year, month] = dateStr.split('-').map(Number);
    return year >= 2000 && year <= 2100 && month >= 1 && month <= 12;
}

// Đặt giá trị mặc định cho bộ lọc
function setDefaultFilter() {
    const currentDate = new Date();
    const currentMonth = (currentDate.getMonth() + 1).toString().padStart(2, '0');
    const currentYear = currentDate.getFullYear();

    document.getElementById('filterMonth').value = currentMonth;
    document.getElementById('filterYear').value = currentYear;
}

// Tải danh sách nhân viên để hiển thị trong dropdown
function loadNhanVien() {
    const month = document.getElementById('filterMonth').value;
    const year = document.getElementById('filterYear').value;

    if (!year) {
        alert("Vui lòng nhập năm!");
        return;
    }

    const filterDate = `${year}-${month}`;

    // Lấy danh sách nhân viên đã có bảo hiểm trong tháng/năm được chọn
    fetch("http://localhost/doanqlns/index.php/api/baohiem")
        .then(response => response.json())
        .then(baoHiemData => {
            const usedEmployeeIds = baoHiemData
                .filter(record => record.thang === filterDate)
                .map(record => record.id_nhan_vien);

            // Lấy toàn bộ danh sách nhân viên
            fetch("http://localhost/doanqlns/index.php/api/users")
                .then(response => response.json())
                .then(data => {
                    const select = document.getElementById("addIdNhanVien");
                    select.innerHTML = '<option value="">Chọn nhân viên</option>';
                    if (data && Array.isArray(data)) {
                        // Lọc nhân viên chưa có bảo hiểm trong tháng/năm được chọn
                        const availableEmployees = data.filter(user => !usedEmployeeIds.includes(user.id_nhan_vien));
                        availableEmployees.forEach(user => {
                            const option = document.createElement("option");
                            option.value = user.id_nhan_vien;
                            option.textContent = user.ho_ten;
                            select.appendChild(option);
                        });
                    }
                })
                .catch(error => {
                    console.error("Lỗi khi tải danh sách nhân viên:", error);
                });
        })
        .catch(error => {
            console.error("Lỗi khi tải dữ liệu bảo hiểm:", error);
        });
}

// Tải dữ liệu bảng với bộ lọc
function loadData() {
    const month = document.getElementById('filterMonth').value;
    const year = document.getElementById('filterYear').value;

    if (!year) {
        alert("Vui lòng nhập năm!");
        return;
    }

    const filterDate = `${year}-${month}`;

    fetch("http://localhost/doanqlns/index.php/api/baohiem")
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById("baoHiemThueTableBody");
            tableBody.innerHTML = "";
            if (data && Array.isArray(data)) {
                const filteredData = data.filter(record => record.thang === filterDate);
                if (filteredData.length > 0) {
                    filteredData.forEach(record => {
                        const row = document.createElement("tr");
                        row.innerHTML = `
                            <td>${record.id}</td>
                            <td><a href="#" class="name-link" data-id="${record.id_nhan_vien}">${record.ho_ten}</a></td>
                            <td>${record.thang}</td>
                            <td>${formatNumber(record.bhxh)}</td>
                            <td>${formatNumber(record.bhyt)}</td>
                            <td>${formatNumber(record.bhtn)}</td>
                            <td>${formatNumber(record.thue_tncn)}</td>
                            <td>${formatNumber(record.tong_khoan_tru)}</td>
                            <td>
                                <button class="btn-edit" onclick="editBaoHiemThuetncn(${record.id}, '${record.thang}', '${record.bhxh}', '${record.bhyt}', '${record.bhtn}', '${record.thue_tncn}', '${record.tong_khoan_tru}', '${record.ho_ten}', '${record.id_nhan_vien}')"><i class="fas fa-edit"></i></button>
                                <button class="btn-delete" onclick="deleteBaoHiemThuetncn(${record.id})"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        `;
                        tableBody.appendChild(row);
                    });
                    document.querySelectorAll('.name-link').forEach(link => {
                        link.addEventListener('click', function(e) {
                            e.preventDefault();
                            const userId = this.getAttribute('data-id');
                            showUserDetails(userId);
                        });
                    });
                } else {
                    tableBody.innerHTML = `<tr><td colspan="9">Không có dữ liệu cho ${month}/${year}</td></tr>`;
                }
            } else {
                tableBody.innerHTML = '<tr><td colspan="9">Không có dữ liệu</td></tr>';
            }
        })
        .catch(error => {
            console.error("Lỗi khi tải dữ liệu:", error);
            document.getElementById("baoHiemThueTableBody").innerHTML = '<tr><td colspan="9">Lỗi khi tải dữ liệu</td></tr>';
        });
}

// Hiển thị modal chi tiết nhân viên
async function showUserDetails(userId) {
    const month = document.getElementById('filterMonth').value;
    const year = document.getElementById('filterYear').value;
    const filterDate = `${year}-${month}`;

    try {
        // Lấy thông tin nhân viên
        const userResponse = await fetch(`http://localhost/doanqlns/index.php/api/user?id=${userId}`);
        if (!userResponse.ok) throw new Error("Lỗi khi tải thông tin nhân viên: " + userResponse.status);
        const user = await userResponse.json();

        // Lấy thông tin bảo hiểm
        const baoHiemResponse = await fetch("http://localhost/doanqlns/index.php/api/baohiem");
        if (!baoHiemResponse.ok) throw new Error("Lỗi khi tải dữ liệu bảo hiểm: " + baoHiemResponse.status);
        const baoHiemData = await baoHiemResponse.json();
        const baoHiemRecord = baoHiemData.find(record => record.id_nhan_vien == userId && record.thang === filterDate);

        // Điền thông tin nhân viên
        document.getElementById('detailHoTen').textContent = user.ho_ten || 'Không có dữ liệu';
        document.getElementById('detailGioiTinh').textContent = user.gioi_tinh || 'Không có dữ liệu';
        document.getElementById('detailNgaySinh').textContent = user.ngay_sinh || 'Không có dữ liệu';
        document.getElementById('detailEmail').textContent = user.email || 'Không có dữ liệu';
        document.getElementById('detailSoDienThoai').textContent = user.so_dien_thoai || 'Không có dữ liệu';
        document.getElementById('detailDiaChi').textContent = user.dia_chi || 'Không có dữ liệu';
        document.getElementById('detailPhongBan').textContent = user.ten_phong_ban || 'Không có dữ liệu';
        document.getElementById('detailChucVu').textContent = user.ten_chuc_vu || 'Không có dữ liệu';
        document.getElementById('detailLuongCoBan').textContent = formatCurrency(user.luong_co_ban) || 'Không có dữ liệu';

        // Điền thông tin bảo hiểm và thuế TNCN
        if (baoHiemRecord) {
            document.getElementById('detailBhxh').textContent = formatNumber(baoHiemRecord.bhxh) || '0';
            document.getElementById('detailBhyt').textContent = formatNumber(baoHiemRecord.bhyt) || '0';
            document.getElementById('detailBhtn').textContent = formatNumber(baoHiemRecord.bhtn) || '0';
            document.getElementById('detailThueTncn').textContent = formatNumber(baoHiemRecord.thue_tncn) || '0';
            document.getElementById('detailTongKhoanTru').textContent = formatNumber(baoHiemRecord.tong_khoan_tru) || '0';
        } else {
            document.getElementById('detailBhxh').textContent = 'Không có dữ liệu';
            document.getElementById('detailBhyt').textContent = 'Không có dữ liệu';
            document.getElementById('detailBhtn').textContent = 'Không có dữ liệu';
            document.getElementById('detailThueTncn').textContent = 'Không có dữ liệu';
            document.getElementById('detailTongKhoanTru').textContent = 'Không có dữ liệu';
        }

        document.getElementById('detailBaoHiemModal').style.display = 'flex';
    } catch (error) {
        console.error("Lỗi khi hiển thị chi tiết nhân viên:", error);
        alert("Lỗi khi hiển thị chi tiết nhân viên: " + error.message);
    }
}

// Đóng modal chi tiết
function closeDetailBaoHiemModal() {
    document.getElementById('detailBaoHiemModal').style.display = 'none';
}

// Hiển thị modal thêm mới
function showAddModal() {
    document.getElementById('addModal').style.display = 'flex';
    const currentDate = new Date();
    document.getElementById('addThang').value = formatDateToYYYYMM(currentDate);
    document.getElementById('addIdNhanVien').value = '';
    document.getElementById('addThueTncn').value = '';
    updateTongKhoanTru('add');
}

// Đóng modal thêm mới
function closeAddModal() {
    document.getElementById('addModal').style.display = 'none';
    // Reset form
    document.getElementById('addIdNhanVien').value = '';
    document.getElementById('addThang').value = '';
    document.getElementById('addBhxh').value = '';
    document.getElementById('addBhyt').value = '';
    document.getElementById('addBhtn').value = '';
    document.getElementById('addThueTncn').value = '';
}

// Thêm mới bảo hiểm và thuế TNCN
function addBaoHiemThue() {
    const id_nhan_vien = document.getElementById('addIdNhanVien').value;
    const thang = document.getElementById('addThang').value;
    const bhxh = unformatNumber(document.getElementById('addBhxh').value);
    const bhyt = unformatNumber(document.getElementById('addBhyt').value);
    const bhtn = unformatNumber(document.getElementById('addBhtn').value);
    const thue_tncn = unformatNumber(document.getElementById('addThueTncn').value);

    if (!id_nhan_vien || !thang || !bhxh || !bhyt || !bhtn) {
        alert("Vui lòng điền đầy đủ thông tin (trừ Thuế TNCN, sẽ được tính tự động)!");
        return;
    }

    if (!isValidDateFormat(thang)) {
        alert("Định dạng tháng không hợp lệ! Vui lòng nhập theo dạng YYYY-MM (VD: 2023-10)");
        return;
    }

    const data = { id_nhan_vien, thang, bhxh, bhyt, bhtn, thue_tncn };

    fetch("http://localhost/doanqlns/index.php/api/baohiem", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            alert("Thêm mới thành công!");
            closeAddModal();
            loadData();
            loadNhanVien();
        } else {
            alert("Thêm mới thất bại: " + (result.message || "Lỗi không xác định"));
        }
    })
    .catch(error => {
        console.error("Lỗi khi thêm mới:", error);
        alert("Lỗi khi thêm mới dữ liệu");
    });
}

// Hiển thị modal chỉnh sửa
function editBaoHiemThuetncn(id, thang, bhxh, bhyt, bhtn, thue_tncn, tong_khoan_tru, ho_ten, id_nhan_vien) {
    document.getElementById('editId').value = id;
    document.getElementById('editIdNhanVien').value = id_nhan_vien;
    document.getElementById('editHoTen').value = ho_ten;
    document.getElementById('editThang').value = thang;
    document.getElementById('editBhxh').value = formatNumber(bhxh);
    document.getElementById('editBhyt').value = formatNumber(bhyt);
    document.getElementById('editBhtn').value = formatNumber(bhtn);
    document.getElementById('editTongKhoanTru').value = formatNumber(tong_khoan_tru);

    // Lấy lương cơ bản để tính thuế TNCN
    fetch(`http://localhost/doanqlns/index.php/api/user?id=${id_nhan_vien}`)
        .then(response => response.json())
        .then(user => {
            if (user && user.luong_co_ban) {
                const luongCoBan = parseFloat(user.luong_co_ban);
                const thueTncn = calculateTax(luongCoBan);
                document.getElementById('editThueTncn').value = formatNumber(thueTncn.toFixed(0));
                updateTongKhoanTru('edit');
            } else {
                alert("Không tìm thấy thông tin lương cơ bản của nhân viên!");
                document.getElementById('editThueTncn').value = '';
                updateTongKhoanTru('edit');
            }
        })
        .catch(error => {
            console.error("Lỗi khi lấy thông tin nhân viên:", error);
            alert("Lỗi khi lấy thông tin nhân viên");
        });

    document.getElementById('editModal').style.display = 'flex';

    // Thêm sự kiện oninput để cập nhật tổng khoản trừ khi chỉnh sửa
    document.getElementById('editBhxh').oninput = () => updateTongKhoanTru('edit');
    document.getElementById('editBhyt').oninput = () => updateTongKhoanTru('edit');
    document.getElementById('editBhtn').oninput = () => updateTongKhoanTru('edit');
}

// Đóng modal chỉnh sửa
function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

// Lưu thay đổi
function saveBaoHiemThue() {
    const id = document.getElementById('editId').value;
    const thang = document.getElementById('editThang').value;
    const bhxh = unformatNumber(document.getElementById('editBhxh').value);
    const bhyt = unformatNumber(document.getElementById('editBhyt').value);
    const bhtn = unformatNumber(document.getElementById('editBhtn').value);
    const thue_tncn = unformatNumber(document.getElementById('editThueTncn').value);
    const tong_khoan_tru = unformatNumber(document.getElementById('editTongKhoanTru').value);

    if (!thang || !bhxh || !bhyt || !bhtn) {
        alert("Vui lòng điền đầy đủ thông tin (trừ Thuế TNCN và Tổng Khoản Trừ, sẽ được tính tự động)!");
        return;
    }

    if (!isValidDateFormat(thang)) {
        alert("Định dạng tháng không hợp lệ! Vui lòng nhập theo dạng YYYY-MM (VD: 2023-10)");
        return;
    }

    const data = { id, thang, bhxh, bhyt, bhtn, thue_tncn, tong_khoan_tru };

    fetch(`http://localhost/doanqlns/index.php/api/baohiem?id=${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            alert("Cập nhật thành công!");
            closeEditModal();
            loadData();
        } else {
            alert("Cập nhật thất bại: " + (result.message || "Lỗi không xác định"));
        }
    })
    .catch(error => {
        console.error("Lỗi khi cập nhật:", error);
        alert("Lỗi khi cập nhật dữ liệu");
    });
}

// Xóa
function deleteBaoHiemThuetncn(id) {
    if (confirm("Bạn có chắc chắn muốn xóa bảo hiểm và thuế TNCN ID " + id + " không?")) {
        fetch(`http://localhost/doanqlns/index.php/api/baohiem?id=${id}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                alert("Xóa thành công!");
                loadData();
                loadNhanVien();
            } else {
                alert("Xóa thất bại: " + (result.message || "Lỗi không xác định"));
            }
        })
        .catch(error => {
            console.error("Lỗi khi xóa:", error);
            alert("Lỗi khi xóa dữ liệu");
        });
    }
}

// Sự kiện đóng modal
document.getElementById('editModal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('editModal')) {
        closeEditModal();
    }
});

document.getElementById('addModal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('addModal')) {
        closeAddModal();
    }
});

document.getElementById('detailBaoHiemModal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('detailBaoHiemModal')) {
        closeDetailBaoHiemModal();
    }
});

// Tải dữ liệu khi trang được tải
document.addEventListener('DOMContentLoaded', () => {
    setDefaultFilter();
    loadData();
    loadNhanVien();
});
</script>
<?php include(__DIR__ . '/../includes/footer.php'); ?>
</body>
</html>