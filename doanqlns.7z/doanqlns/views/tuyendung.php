<?php
require_once __DIR__ . '/../includes/check_login.php';
include(__DIR__ . '/../includes/header.php');
include(__DIR__ . '/../includes/sidebar.php');
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Quản lý Tuyển dụng</title>

    <!-- Font Awesome & Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- CSS chính -->
    <link rel="stylesheet" href="../css/style.css">

    <style>

        
.name-link, .name-link:hover {
    text-decoration: none;
    color: blue;
}
body {
    font-family: 'Roboto', sans-serif;
    background: #f4f6f9;
    margin: 0;
    padding: 0;
}
.main-content {
    margin-left: 240px;
    padding: 20px;
}
h3 {
    font-size: 26px;
    margin-bottom: 20px;
    color: #333;
    text-align: center;
}
table {
    border-collapse: collapse;
    width: 100%;
    max-width: 1200px;
    margin: 0 auto 20px;
    background: #fff;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
th, td {
    padding: 8px 10px;
    border-bottom: 1px solid #ddd;
    text-align: left;
    font-size: 0.9rem;
}
th {
    background: #007bff;
    color: #fff;
    font-weight: 500;
}
tr:nth-child(even) {
    background: #f9f9f9;
}
tr:hover {
    background: #eef3f7;
}
.btn-edit, .btn-delete {
    border: none;
    background: none;
    cursor: pointer;
    margin: 0 3px;
    font-size: 0.9rem;
}
.btn-edit {
    color: #007bff;
}
.btn-delete {
    color: #dc3545;
}
.btn-edit:hover, .btn-delete:hover {
    opacity: 0.8;
}
.action-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    flex-wrap: wrap;
    gap: 15px;
}
.action-container > div {
display: flex;
gap: 10px; /* Khoảng cách giữa các nút con */
flex-wrap: wrap; /* Cho phép xuống dòng nếu không đủ chỗ */
}
.btn-add {
    background-color: #28a745;
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: background-color 0.3s;
    margin-left: 40px;
    white-space: nowrap;    
}
.btn-add:hover {
    background-color: #218838;
}
.btn-add.disabled {
    background-color: #6c757d;
    cursor: not-allowed;
}
.filter-container {
    display: flex;
    gap: 15px;
    align-items: center;
    margin-left: 60px;
}
.filter-container label {
    font-size: 14px;
    color: #333;
    font-weight: 500;
}
.filter-container select, .filter-container input {
    padding: 8px;
    font-size: 14px;
    border: 1px solid #ddd;
    border-radius: 4px;
    outline: none;
    width: 120px;
    transition: border-color 0.2s;
}
.filter-container select:focus, .filter-container input:focus {
    border-color: #007bff;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.2);
}
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    justify-content: center;
    align-items: center;
    z-index: 1000;
    animation: fadeIn 0.3s;
}
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}
.modal-content {
    background-color: white;
    width: 90%;
    max-width: 700px;
    border-radius: 8px;
    overflow: hidden;
    position: relative;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
}
.modal-header {
    background: linear-gradient(90deg, #007bff, #0056b3);
    color: white;
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.modal-title {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 600;
}
.modal-close {
    color: white;
    font-size: 1.8rem;
    font-weight: bold;
    background: none;
    border: none;
    cursor: pointer;
    transition: transform 0.2s;
}
.modal-close:hover {
    transform: scale(1.2);
    color: #f1f1f1;
}
.modal-body {
    padding: 20px;
    max-height: 60vh;
    overflow-y: auto;
}
.modal-body label {
    font-size: 14px;
    color: #333;
    font-weight: 500;
    display: block;
    margin-bottom: 5px;
}
.modal-body input, .modal-body select, .modal-body textarea {
    padding: 10px;
    font-size: 14px;
    border: 1px solid #ddd;
    border-radius: 4px;
    outline: none;
    width: 100%;
    margin-bottom: 15px;
    transition: border-color 0.2s;
}
.modal-body input:focus, .modal-body select:focus, .modal-body textarea:focus {
    border-color: #007bff;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.2);
}
.modal-footer {
    padding: 15px 20px;
    border-top: 1px solid #e9ecef;
    display: flex;
    justify-content: flex-end;
    background: #f8f9fa;
}
.btn-save, .btn-cancel {
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    font-size: 14px;
    cursor: pointer;
    transition: background-color 0.2s;
}
.btn-save {
    background-color: #007bff;
    color: white;
}
.btn-save:hover {
    background-color: #0056b3;
}
.btn-cancel {
    background-color: #6c757d;
    color: white;
    margin-right: 10px;
}
.btn-cancel:hover {
    background-color: #5a6268;
}
#tabs {
    margin-bottom: 20px;
    display: flex;
    justify-content: center;
    gap: 10px;
}
.tab-button {
    padding: 10px 20px;
    border: none;
    background: #e9ecef;
    cursor: pointer;
    border-radius: 4px;
    font-size: 14px;
    transition: background-color 0.2s;
}
.tab-button:hover {
    background: #d3d7db;
}
.tab-button.active {
    background: #007bff;
    color: white;
}
@media (max-width: 768px) {
    .main-content {
        margin-left: 0;
        padding: 10px;
    }
    .btn-add {
        margin-left: 10px;
    }
    .filter-container {
        margin-right: 10px;
    }
    .modal-content {
        width: 95%;
        max-width: 400px;
    }
    table {
        display: block;
        overflow-x: auto;
        max-width: 100%;
    }
}
.btn-approve {
    border: none;
    background: none;
    cursor: pointer;
    margin: 0 3px;
    font-size: 0.9rem;
    color: #28a745; /* Màu xanh lá cho nút duyệt */
}
.btn-approve:hover {
    opacity: 0.8;
}
</style>
</head>

<body>
<div class="main-content">
    <h3>Quản lý Tuyển dụng</h3>

    <!-- Action Container -->
    <div class="action-container">
        <div>
            <button class="btn-add" id="addPlanBtn" onclick="showAddModal('plan')">
    <i class="fas fa-plus"></i> Thêm Kế hoạch Tuyển dụng
</button>
            <button class="btn-add" id="addCampaignBtn" onclick="showAddModal('campaign')">
                <i class="fas fa-plus"></i> Thêm Đợt Tuyển dụng
            </button>
            <button class="btn-add" id="addCandidateBtn" onclick="showAddModal('candidate')">
                <i class="fas fa-plus"></i> Thêm Ứng viên
            </button>
            <button class="btn-add" id="addInterviewBtn" onclick="showAddModal('interview')">
                <i class="fas fa-plus"></i> Thêm Lịch Hẹn
            </button>
            <button class="btn-add" id="addEvaluationBtn" onclick="showAddModal('evaluation')">
                <i class="fas fa-plus"></i> Thêm Đánh giá
            </button>
            <button class="btn-add" id="addCostBtn" onclick="showAddModal('cost')">
                <i class="fas fa-plus"></i> Thêm Chi phí
            </button>
            <!-- <button class="btn-add" id="addAllocationBtn" onclick="showAddModal('allocation')">
                <i class="fas fa-plus"></i> Thêm Phân bổ
            </button> -->
        </div>
        <div class="filter-container">
            <label for="filterMonth">Tháng:</label>
            <select id="filterMonth" onchange="loadData()">
                <option value="01">Tháng 1</option>
                <option value="02">Tháng 2</option>
                <option value="03">Tháng 3</option>
                <option value="04">Tháng 4</option>
                <option value="05">Tháng 5</option>
                <option value="06">Tháng 6</option>
                <option value="07">Tháng 7</option>
                <option value="08">Tháng 8</option>
                <option value="09">Tháng 9</option>
                <option value="10">Tháng 10</option>
                <option value="11">Tháng 11</option>
                <option value="12">Tháng 12</option>
            </select>
            <label for="filterYear">Năm:</label>
            <input type="number" id="filterYear" min="2000" max="2100" onchange="loadData()">
        </div>
    </div>

    <!-- Tabs for different sections -->
   <div id="tabs">
    <button class="tab-button active" onclick="openTab('plans')">Kế hoạch</button>
    <button class="tab-button" onclick="openTab('campaigns')">Đợt tuyển</button>
    <button class="tab-button" onclick="openTab('candidates')">Ứng viên</button>
    <button class="tab-button" onclick="openTab('interviews')">Lịch hẹn</button>
    <button class="tab-button" onclick="openTab('evaluations')">Đánh giá</button>
    <button class="tab-button" onclick="openTab('allocations')">Phân bổ</button>
    <button class="tab-button" onclick="openTab('costs')">Chi phí</button>
</div>


    <!-- Tables -->

    <div id="plans" class="tab-content" style="display:none;">
    <table>
        <thead>
            <tr>
                <th>Chức vụ</th>
                <th>Số vòng thi</th>
                <th>Tên vòng thi</th>
                <th>Nội dung thi</th>
                <th>Điểm chuẩn</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody id="plansTableBody">
            <tr><td colspan="6">Đang tải dữ liệu...</td></tr>
        </tbody>
    </table>
</div>
    <div id="campaigns" class="tab-content">
        <table>
            <thead>
                <tr>
                    <th>Mã Đợt</th><th>Tên Đợt</th><th>Vị trí</th><th>Số lượng</th><th>Cán bộ</th><th>Ngày Bắt đầu</th><th>Ngày Kết thúc</th><th>Yêu cầu</th><th>Trạng thái</th><th>Hành động</th>
                </tr>
            </thead>
            <tbody id="campaignsTableBody">
                <tr><td colspan="10">Đang tải dữ liệu...</td></tr>
            </tbody>
        </table>
    </div>

    <div id="candidates" class="tab-content" style="display:none;">
        <table>
            <thead>
                <tr>
                    <th>Họ tên</th><th>Email</th><th>Số điện thoại</th><th>Đợt tuyển</th><th>Vị trí</th><th>Nguồn</th><th>Hồ sơ</th><th>Trạng thái</th><th>Hành động</th>
                </tr>
            </thead>
            <tbody id="candidatesTableBody">
                <tr><td colspan="9">Đang tải dữ liệu...</td></tr>
            </tbody>
        </table>
    </div>

    <div id="interviews" class="tab-content" style="display:none;">
        <table>
            <thead>
                <tr>
                    <th>Ứng viên</th><th>Ngày hẹn</th><th>Giờ hẹn</th><th>Địa điểm</th><th>Ghi chú</th><th>Trạng thái</th><th>Hành động</th>
                </tr>
            </thead>
            <tbody id="interviewsTableBody">
                <tr><td colspan="6">Đang tải dữ liệu...</td></tr>
            </tbody>
        </table>
    </div>

    <div id="evaluations" class="tab-content" style="display:none;">
        <table>
            <thead>
                <tr>
                    <th>Ứng viên</th><th>Vòng thi</th><th>Điểm</th><th>Nhận xét</th><th>Ngày đánh giá</th><th>Hành động</th>
                </tr>
            </thead>
            <tbody id="evaluationsTableBody">
                <tr><td colspan="6">Đang tải dữ liệu...</td></tr>
            </tbody>
        </table>
    </div>

    <div id="costs" class="tab-content" style="display:none;">
        <table>
            <thead>
                <tr>
                    <th>Đợt tuyển</th><th>Nội dung chi phí</th><th>Số tiền</th><th>Ngày chi</th><th>Hành động</th>
                </tr>
            </thead>
            <tbody id="costsTableBody">
                <tr><td colspan="5">Đang tải dữ liệu...</td></tr>
            </tbody>
        </table>
    </div>

    <div id="allocations" class="tab-content" style="display:none;">
        <table>
            <thead>
                <tr>
                    <th>Ứng viên</th><th>Phòng ban</th><th>Chức Vụ</th><th>Trạng thái</th><th>Ngày phân bổ</th><th>Hợp đồng</th><th>Hành động</th>
                </tr>
            </thead>
            <tbody id="allocationsTableBody">
                <tr><td colspan="6">Đang tải dữ liệu...</td></tr>
            </tbody>
        </table>
    </div>

    <!-- Add Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="modalTitle">Thêm Mới</h2>
                <button class="modal-close" onclick="closeAddModal()" aria-label="Đóng modal">×</button>
            </div>
            <div class="modal-body" id="addModalBody">
                <!-- Dynamic content will be loaded here -->
            </div>
            <div class="modal-footer">
                <button class="btn-cancel" onclick="closeAddModal()">Hủy</button>
                <button class="btn-save" id="saveButton">Lưu</button>
            </div>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Chỉnh sửa</h2>
                <button class="modal-close" onclick="closeEditModal()" aria-label="Đóng modal">×</button>
            </div>
            <div class="modal-body" id="editModalBody">
                <!-- Dynamic content will be loaded here -->
            </div>
            <div class="modal-footer">
                <button class="btn-cancel" onclick="closeEditModal()">Hủy</button>
                <button class="btn-save" onclick="saveEditData()">Lưu</button>
            </div>
        </div>
    </div>

    <!-- Detail Modal -->
    <div id="detailModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Chi Tiết</h2>
                <button class="modal-close" onclick="closeDetailModal()" aria-label="Đóng modal">×</button>
            </div>
            <div class="modal-body" id="detailModalBody">
                <!-- Dynamic content will be loaded here -->
            </div>
            <div class="modal-footer">
                <button class="btn-cancel" onclick="closeDetailModal()">Đóng</button>
            </div>
        </div>
    </div>
</div>

<script>
    // User permissions (set from PHP session)
  // User permissions (set from PHP session)
    const permissions = {
        quyen_them: <?php echo isset($_SESSION['quyen_them']) && $_SESSION['quyen_them'] ? 'true' : 'false'; ?>,
        quyen_sua: <?php echo isset($_SESSION['quyen_sua']) && $_SESSION['quyen_sua'] ? 'true' : 'false'; ?>,
        quyen_xoa: <?php echo isset($_SESSION['quyen_xoa']) && $_SESSION['quyen_xoa'] ? 'true' : 'false'; ?>
    };

    // Disable buttons based on permissions
    function initializePermissions() {
        if (!permissions.quyen_them) {
            const buttons = ['addPlanBtn','addCampaignBtn', 'addCandidateBtn', 'addInterviewBtn', 'addEvaluationBtn', 'addCostBtn', 'addAllocationBtn'];
            buttons.forEach(id => {
                const btn = document.getElementById(id);
                btn.classList.add('disabled');
                btn.disabled = true;
                btn.title = 'Bạn không có quyền thêm dữ liệu';
            });
        }
    }

    // Format number with commas
    function formatNumber(number) {
        return number ? Number(number).toLocaleString('vi-VN') : "0";
    }

    // Unformat number
    function unformatNumber(formattedNumber) {
        return parseFloat(formattedNumber.replace(/\./g, '').replace(',', '.')) || 0;
    }

    // Set default filter
    function setDefaultFilter() {
        const currentDate = new Date();
        const currentMonth = (currentDate.getMonth() + 1).toString().padStart(2, '0');
        const currentYear = currentDate.getFullYear();
        document.getElementById('filterMonth').value = currentMonth;
        document.getElementById('filterYear').value = currentYear;
    }

    // Load data based on filter
    async function loadData() {
        const month = document.getElementById('filterMonth').value;
        const year = document.getElementById('filterYear').value;
        if (!year) {
            alert("Vui lòng nhập năm hợp lệ!");
            return;
        }

        const url = `http://localhost/doanqlns/index.php/api/tuyendung?month=${month}&year=${year}`;
        try {
            const response = await fetch(url);
            if (!response.ok) {
                if (response.status === 401) {
                    alert('Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.');
                    window.location.href = 'login.php';
                    return;
                }
                throw new Error(`Lỗi HTTP: ${response.status} - ${response.statusText}`);
            }
            const data = await response.json();

            if (!data.success) {
                throw new Error(data.message || 'Không thể tải dữ liệu từ server');
            }

            // Clear tables
            const tableBodies = ['campaignsTableBody', 'candidatesTableBody', 'interviewsTableBody', 'evaluationsTableBody', 'costsTableBody', 'allocationsTableBody','plansTableBody'];
            tableBodies.forEach(id => {
                document.getElementById(id).innerHTML = '';
            });

            // Populate Plans Table
        const plansTable = document.getElementById('plansTableBody');
        if (data.data.plans && data.data.plans.length > 0) {
            data.data.plans.forEach(plan => {
                const row = `
                    <tr>
                        <td><a href="#" class="name-link" onclick="showDetailModal('plan', ${plan.id_ke_hoach})">${plan.ten_chuc_vu || ''}</a></td>
                        <td>${plan.so_vong_thi || ''}</td>
                        <td>${plan.ten_vong_thi || ''}</td>
                        <td>${plan.noi_dung_thi || ''}</td>
                        <td>${plan.diem_chuan || ''}</td>
                        <td>
                            ${permissions.quyen_sua ? `<button class="btn-edit" onclick="editData('plan', ${plan.id_ke_hoach})"><i class="fas fa-edit"></i></button>` : ''}
                            ${permissions.quyen_xoa ? `<button class="btn-delete" onclick="deleteData('plan', ${plan.id_ke_hoach})"><i class="fas fa-trash"></i></button>` : ''}
                        </td>
                    </tr>`;
                plansTable.insertAdjacentHTML('beforeend', row);
            });
        } else {
            plansTable.innerHTML = '<tr><td colspan="10">Không có dữ liệu</td></tr>';
        }

            // Populate Campaigns Table
            const campaignsTable = document.getElementById('campaignsTableBody');
            if (data.data.campaigns && data.data.campaigns.length > 0) {
                data.data.campaigns.forEach(campaign => {
                    const row = `
                        <tr>
                            <td>${campaign.ma_dot || ''}</td>
                            <td><a href="#" class="name-link" onclick="showDetailModal('campaign', ${campaign.id_dot_tuyen_dung})">${campaign.ten_dot || ''}</a></td>
                            <td>${campaign.ten_phong_ban || ''}</td>
                            <td>${formatNumber(campaign.so_luong_tuyen)}</td>
                            <td>${campaign.ten_can_bo || ''}</td>
                            <td>${campaign.ngay_bat_dau || ''}</td>
                            <td>${campaign.ngay_ket_thuc || ''}</td>
                            <td>${campaign.yeu_cau_vi_tri || ''}</td>
                            <td>${campaign.trang_thai || ''}</td>
                            <td>
                                ${permissions.quyen_sua ? `<button class="btn-edit" onclick="editData('campaign', ${campaign.id_dot_tuyen_dung})"><i class="fas fa-edit"></i></button>` : ''}
                                ${permissions.quyen_xoa ? `<button class="btn-delete" onclick="deleteData('campaign', ${campaign.id_dot_tuyen_dung})"><i class="fas fa-trash"></i></button>` : ''}
                            </td>
                        </tr>`;
                    campaignsTable.insertAdjacentHTML('beforeend', row);
                });
            } else {
                campaignsTable.innerHTML = '<tr><td colspan="10">Không có dữ liệu</td></tr>';
            }

            // Populate Candidates Table
            const candidatesTable = document.getElementById('candidatesTableBody');
            if (data.data.candidates && data.data.candidates.length > 0) {
                data.data.candidates.forEach(candidate => {
                    const row = `
                        <tr>
                            <td><a href="#" class="name-link" onclick="showDetailModal('candidate', ${candidate.id_ung_vien})">${candidate.ho_ten || ''}</a></td>
                            <td>${candidate.email || ''}</td>
                            <td>${candidate.so_dien_thoai || ''}</td>
                            <td>${candidate.ten_dot || ''}</td>
                            <td>${candidate.ten_chuc_vu || ''}</td>
                            <td>${candidate.nguon_ung_tuyen || ''}</td>
                            <td>${candidate.ho_so ? `<a href="${candidate.ho_so}" target="_blank">Xem</a>` : ''}</td>
                            <td>${candidate.trang_thai || ''}</td>
                            <td>
                                ${permissions.quyen_sua ? `<button class="btn-edit" onclick="editData('candidate', ${candidate.id_ung_vien})"><i class="fas fa-edit"></i></button>` : ''}
                                ${permissions.quyen_xoa ? `<button class="btn-delete" onclick="deleteData('candidate', ${candidate.id_ung_vien})"><i class="fas fa-trash"></i></button>` : ''}
                            </td>
                        </tr>`;
                    candidatesTable.insertAdjacentHTML('beforeend', row);
                });
            } else {
                candidatesTable.innerHTML = '<tr><td colspan="9">Không có dữ liệu</td></tr>';
            }

            // Populate Interviews Table
            const interviewsTable = document.getElementById('interviewsTableBody');
            if (data.data.interviews && data.data.interviews.length > 0) {
                data.data.interviews.forEach(interview => {
                    const row = `
                        <tr>
                            <td>${interview.ho_ten || ''}</td>
                            <td>${interview.ngay_hen || ''}</td>
                            <td>${interview.gio_hen || ''}</td>
                            <td>${interview.dia_diem || ''}</td>
                            <td>${interview.ghi_chu || ''}</td>
                            <td>${interview.trang_thai || 'ChỜ lên lịch'}</td>
                            <td>
                                ${permissions.quyen_sua && interview.trang_thai === 'Chờ lên lịch' ? `<button class="btn-approve" onclick="approveInterview(${interview.id_lich_hen})" title="Duyệt lịch hẹn"><i class="fas fa-check"></i></button>` : ''}
                                ${permissions.quyen_sua ? `<button class="btn-edit" onclick="editData('interview', ${interview.id_lich_hen})"><i class="fas fa-edit"></i></button>` : ''}
                                ${permissions.quyen_xoa ? `<button class="btn-delete" onclick="deleteData('interview', ${interview.id_lich_hen})"><i class="fas fa-trash"></i></button>` : ''}
                            </td>
                        </tr>`;
                    interviewsTable.insertAdjacentHTML('beforeend', row);
                });
            } else {
                interviewsTable.innerHTML = '<tr><td colspan="6">Không có dữ liệu</td></tr>';
            }

            // Populate Evaluations Table
            const evaluationsTable = document.getElementById('evaluationsTableBody');
            if (data.data.evaluations && data.data.evaluations.length > 0) {
                data.data.evaluations.forEach(evaluation => {
                    const row = `
                        <tr>
                            <td>${evaluation.ho_ten || ''}</td>
                            <td>${evaluation.vong_thi || ''}</td>
                            <td>${evaluation.diem || ''}</td>
                            <td>${evaluation.nhan_xet || ''}</td>
                            <td>${evaluation.ngay_danh_gia || ''}</td>
                            <td>
                                ${permissions.quyen_sua ? `<button class="btn-edit" onclick="editData('evaluation', ${evaluation.id_danh_gia})"><i class="fas fa-edit"></i></button>` : ''}
                                ${permissions.quyen_xoa ? `<button class="btn-delete" onclick="deleteData('evaluation', ${evaluation.id_danh_gia})"><i class="fas fa-trash"></i></button>` : ''}
                            </td>
                        </tr>`;
                    evaluationsTable.insertAdjacentHTML('beforeend', row);
                });
            } else {
                evaluationsTable.innerHTML = '<tr><td colspan="6">Không có dữ liệu</td></tr>';
            }

            // Populate Costs Table
            const costsTable = document.getElementById('costsTableBody');
            if (data.data.costs && data.data.costs.length > 0) {
                data.data.costs.forEach(cost => {
                    const row = `
                        <tr>
                            <td>${cost.ten_dot || ''}</td>
                            <td>${cost.noi_dung_chi_phi || ''}</td>
                            <td>${formatNumber(cost.so_tien)}</td>
                            <td>${cost.ngay_chi || ''}</td>
                            <td>
                                ${permissions.quyen_sua ? `<button class="btn-edit" onclick="editData('cost', ${cost.id_chi_phi})"><i class="fas fa-edit"></i></button>` : ''}
                                ${permissions.quyen_xoa ? `<button class="btn-delete" onclick="deleteData('cost', ${cost.id_chi_phi})"><i class="fas fa-trash"></i></button>` : ''}
                            </td>
                        </tr>`;
                    costsTable.insertAdjacentHTML('beforeend', row);
                });
            } else {
                costsTable.innerHTML = '<tr><td colspan="5">Không có dữ liệu</td></tr>';
            }

            // Populate Allocations Table
            const allocationsTable = document.getElementById('allocationsTableBody');
            if (data.data.allocations && data.data.allocations.length > 0) {
                data.data.allocations.forEach(allocation => {
                    const row = `
                        <tr>
                            <td>${allocation.ho_ten || ''}</td>
                            <td>${allocation.ten_phong_ban || ''}</td>
                            <td>${allocation.ten_chuc_vu || ''}</td>
                            <td>${allocation.trang_thai || ''}</td>
                            <td>${allocation.ngay_phan_bo || ''}</td>
                            <td>${allocation.hop_dong_thu_viec ? `<a href="${allocation.hop_dong_thu_viec}" target="_blank">Xem</a>` : ''}</td>
                            <td>
                                ${permissions.quyen_sua ? `<button class="btn-approve" onclick="approveAllocation(${allocation.id_phan_bo})" title="Duyệt phân bổ"><i class="fas fa-check"></i></button>` : ''}
                                ${permissions.quyen_sua ? `<button class="btn-edit" onclick="editData('allocation', ${allocation.id_phan_bo})"><i class="fas fa-edit"></i></button>` : ''}
                                ${permissions.quyen_xoa ? `<button class="btn-delete" onclick="deleteData('allocation', ${allocation.id_phan_bo})"><i class="fas fa-trash"></i></button>` : ''}
                            </td>
                        </tr>`;
                    allocationsTable.insertAdjacentHTML('beforeend', row);
                });
            } else {
                allocationsTable.innerHTML = '<tr><td colspan="7">Không có dữ liệu</td></tr>';
            }
        } catch (error) {
            console.error('Lỗi khi tải dữ liệu:', error);
            alert(`Lỗi khi tải dữ liệu: ${error.message}. Vui lòng kiểm tra kết nối hoặc đăng nhập lại.`);
            const tableBodies = ['campaignsTableBody', 'candidatesTableBody', 'interviewsTableBody', 'evaluationsTableBody', 'costsTableBody', 'allocationsTableBody'];
            tableBodies.forEach(id => {
                document.getElementById(id).innerHTML = '<tr><td colspan="10">Lỗi tải dữ liệu</td></tr>';
            });
        }
    }
// Approve Allocation
async function approveAllocation(id_phan_bo) {
    const confirmApprove = confirm('Bạn muốn duyệt phân bổ này? Nhấn OK để duyệt hoặc Cancel để từ chối.');
    
    const status = confirmApprove ? 'Đã duyệt' : 'Từ chối';

    try {
        // Gửi yêu cầu cập nhật trạng thái phân bổ
        const response = await fetch('http://localhost/doanqlns/index.php/api/tuyendung', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'update_allocation_status',
                id_phan_bo: id_phan_bo,
                trang_thai: status,
            }),
        });

        if (!response.ok) {
            throw new Error(`Lỗi HTTP: ${response.status} - ${response.statusText}`);
        }

        const result = await response.json();
        if (!result.success) {
            throw new Error(result.message || 'Không thể cập nhật trạng thái');
        }

        alert(`Phân bổ đã được ${status.toLowerCase()} thành công!`);
        loadData(); // Tải lại dữ liệu để cập nhật bảng
    } catch (error) {
        console.error('Lỗi khi xử lý phân bổ:', error);
        alert(`Lỗi: ${error.message}`);
    }
} 
async function approveInterview(id_lich_hen) {
    const confirmApprove = confirm('Bạn muốn duyệt lịch hẹn này? Nhấn OK để duyệt hoặc Cancel để từ chối.');
    const status = confirmApprove ? 'Đã duyệt' : 'Từ chối';
    try {
        const response = await fetch('http://localhost/doanqlns/index.php/api/tuyendung', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'update_interview_status',
                id_lich_hen: id_lich_hen,
                trang_thai: status,
            }),
        });
        if (!response.ok) throw new Error(`Lỗi HTTP: ${response.status}`);
        const result = await response.json();
        if (!result.success) throw new Error(result.message || 'Cập nhật thất bại');
        alert(`Lịch hẹn đã được ${status.toLowerCase()} thành công!`);
        loadData();
    } catch (error) {
        console.error('Lỗi:', error);
        alert(`Lỗi: ${error.message}`);
    }
}


// Open specific tab
    function openTab(tabName) {
        document.querySelectorAll('.tab-content').forEach(tab => tab.style.display = 'none');
        document.querySelectorAll('.tab-button').forEach(button => button.classList.remove('active'));
        document.getElementById(tabName).style.display = 'block';
        document.querySelector(`button[onclick="openTab('${tabName}')"]`).classList.add('active');
    }

    // Fetch options for dropdowns
    async function fetchOptions() {
        try {
            const response = await fetch('http://localhost/doanqlns/index.php/api/tuyendung/options');
            if (!response.ok) {
                throw new Error(`Lỗi HTTP: ${response.status}`);
            }
            return await response.json();
        } catch (error) {
            console.error('Lỗi khi tải options:', error);
            alert('Lỗi khi tải dữ liệu tùy chọn. Vui lòng thử lại.');
            return {};
        }
    }

    // Validate form inputs
    function validateForm(type) {
        const errors = [];
        switch (type) {
            case 'plan':
            if (!document.getElementById('id_chuc_vu').value) errors.push('Vui lòng chọn chức vụ');
            if (!document.getElementById('so_vong_thi').value || document.getElementById('so_vong_thi').value < 1) errors.push('Số vòng thi phải lớn hơn 0');
            if (!document.getElementById('ten_vong_thi').value.trim()) errors.push('Tên vòng thi không được để trống');
            if (!document.getElementById('noi_dung_thi').value.trim()) errors.push('Nội dung thi không được để trống');
            const diem_chuan = document.getElementById('diem_chuan').value;
            if (!diem_chuan || diem_chuan < 0 || diem_chuan > 100) errors.push('Điểm chuẩn phải từ 0 đến 100');
            break;
            case 'campaign':
                if (!document.getElementById('ma_dot').value.trim()) errors.push('Mã đợt không được để trống');
                if (!document.getElementById('ten_dot').value.trim()) errors.push('Tên đợt không được để trống');
                if (!document.getElementById('id_phong_ban').value) errors.push('Vui lòng chọn phòng ban');
                if (!document.getElementById('so_luong_tuyen').value || document.getElementById('so_luong_tuyen').value < 1) errors.push('Số lượng tuyển phải lớn hơn 0');
                if (!document.getElementById('id_can_bo_tuyen_dung').value) errors.push('Vui lòng chọn cán bộ tuyển dụng');
                if (!document.getElementById('ngay_bat_dau').value) errors.push('Ngày bắt đầu không được để trống');
                if (!document.getElementById('ngay_ket_thuc').value) errors.push('Ngày kết thúc không được để trống');
                if (!document.getElementById('trang_thai').value) errors.push('Vui lòng chọn trạng thái');
                break;
            case 'candidate':
                if (!document.getElementById('ho_ten').value.trim()) errors.push('Họ tên không được để trống');
                const email = document.getElementById('email').value.trim();
                if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('Email không hợp lệ');
                const phone = document.getElementById('so_dien_thoai').value.trim();
                if (!phone || !/^\d{10}$/.test(phone)) errors.push('Số điện thoại phải là 10 chữ số');
                if (!document.getElementById('id_dot_tuyen_dung').value) errors.push('Vui lòng chọn đợt tuyển dụng');
                if (!document.getElementById('id_chuc_vu').value) errors.push('Vui lòng chọn vị trí ứng tuyển');
                if (!document.getElementById('trang_thai').value) errors.push('Vui lòng chọn trạng thái');
                break;
            case 'interview':
                if (!document.getElementById('id_ung_vien').value) errors.push('Vui lòng chọn ứng viên');
                if (!document.getElementById('ngay_hen').value) errors.push('Ngày hẹn không được để trống');
                if (!document.getElementById('gio_hen').value) errors.push('Giờ hẹn không được để trống');
                if (!document.getElementById('dia_diem').value.trim()) errors.push('Địa điểm không được để trống');
                break;
            case 'evaluation':
                if (!document.getElementById('id_ung_vien').value) errors.push('Vui lòng chọn ứng viên');
                if (!document.getElementById('id_ke_hoach').value) errors.push('Vui lòng chọn kế hoạch tuyển dụng');
                if (!document.getElementById('vong_thi').value.trim()) errors.push('Vòng thi không được để trống');
                const diem = document.getElementById('diem').value;
                if (!diem || diem < 0 || diem > 100) errors.push('Điểm phải từ 0 đến 100');
                if (!document.getElementById('ngay_danh_gia').value) errors.push('Ngày đánh giá không được để trống');
                break;
            case 'cost':
                if (!document.getElementById('id_dot_tuyen_dung').value) errors.push('Vui lòng chọn đợt tuyển dụng');
                if (!document.getElementById('noi_dung_chi_phi').value.trim()) errors.push('Nội dung chi phí không được để trống');
                if (!document.getElementById('so_tien').value || document.getElementById('so_tien').value < 0) errors.push('Số tiền phải lớn hơn hoặc bằng 0');
                if (!document.getElementById('ngay_chi').value) errors.push('Ngày chi không được để trống');
                break;
            case 'allocation':
                if (!document.getElementById('id_ung_vien').value) errors.push('Vui lòng chọn ứng viên');
                if (!document.getElementById('id_phong_ban').value) errors.push('Vui lòng chọn phòng ban');
                if (!document.getElementById('id_chuc_vu').value) errors.push('Vui lòng chọn chức vụ');
                if (!document.getElementById('trang_thai').value) errors.push('Vui lòng chọn trạng thái');
                if (!document.getElementById('ngay_phan_bo').value) errors.push('Ngày phân bổ không được để trống');
                break;
        }
        if (errors.length > 0) {
            alert('Vui lòng sửa các lỗi sau:\n- ' + errors.join('\n- '));
            return false;
        }
        return true;
    }

    // Show Add Modal
   // Show Add Modal
    async function showAddModal(type) {
        if (!permissions.quyen_them) {
            alert('Bạn không có quyền thêm dữ liệu.');
            return;
        }

        const options = await fetchOptions();
        let html = '';
        let title = '';

        switch (type) {
            case 'plan':
            title = 'Thêm Kế hoạch Tuyển dụng';
            html = `
                <label for="id_chuc_vu">Chức vụ</label>
                <select id="id_chuc_vu" required>
                    <option value="">Chọn chức vụ</option>
                    ${options.positions?.map(pos => `<option value="${pos.id_chuc_vu}">${pos.ten_chuc_vu}</option>`).join('') || ''}
                </select>
                <p class="error-message" id="id_chuc_vu_error"></p>
                <label for="so_vong_thi">Số vòng thi</label>
                <input type="number" id="so_vong_thi" min="1" required>
                <p class="error-message" id="so_vong_thi_error"></p>
                <label for="ten_vong_thi">Tên vòng thi</label>
                <input type="text" id="ten_vong_thi" required>
                <p class="error-message" id="ten_vong_thi_error"></p>
                <label for="noi_dung_thi">Nội dung thi</label>
                <textarea id="noi_dung_thi" required></textarea>
                <p class="error-message" id="noi_dung_thi_error"></p>
                <label for="diem_chuan">Điểm chuẩn</label>
                <input type="number" id="diem_chuan" min="0" max="100" required>
                <p class="error-message" id="diem_chuan_error"></p>`;
            break;
            case 'campaign':
                title = 'Thêm Đợt Tuyển dụng';
                html = `
                    <label for="ma_dot">Mã Đợt</label>
                    <input type="text" id="ma_dot" required>
                    <p class="error-message" id="ma_dot_error"></p>
                    <label for="ten_dot">Tên Đợt</label>
                    <input type="text" id="ten_dot" required>
                    <p class="error-message" id="ten_dot_error"></p>
                    <label for="id_phong_ban">Phòng ban</label>
                    <select id="id_phong_ban" required>
                        <option value="">Chọn phòng ban</option>
                        ${options.departments?.map(dep => `<option value="${dep.id_phong_ban}">${dep.ten_phong_ban}</option>`).join('') || ''}
                    </select>
                    <p class="error-message" id="id_phong_ban_error"></p>
                    <label for="so_luong_tuyen">Số lượng tuyển</label>
                    <input type="number" id="so_luong_tuyen" min="1" required>
                    <p class="error-message" id="so_luong_tuyen_error"></p>
                    <label for="id_can_bo_tuyen_dung">Cán bộ tuyển dụng</label>
                    <select id="id_can_bo_tuyen_dung" required>
                        <option value="">Chọn cán bộ</option>
                        ${options.recruiters?.map(rec => `<option value="${rec.id_nhan_vien}">${rec.ho_ten}</option>`).join('') || ''}
                    </select>
                    <p class="error-message" id="id_can_bo_tuyen_dung_error"></p>
                    <label for="ngay_bat_dau">Ngày bắt đầu</label>
                    <input type="date" id="ngay_bat_dau" required>
                    <p class="error-message" id="ngay_bat_dau_error"></p>
                    <label for="ngay_ket_thuc">Ngày kết thúc</label>
                    <input type="date" id="ngay_ket_thuc" required>
                    <p class="error-message" id="ngay_ket_thuc_error"></p>
                    <label for="yeu_cau_vi_tri">Yêu cầu vị trí</label>
                    <textarea id="yeu_cau_vi_tri"></textarea>
                    <label for="trang_thai">Trạng thái</label>
                    <select id="trang_thai" required>
                        <option value="Đang tiến hành">Đang tiến hành</option>
                        <option value="Hoàn thành">Hoàn thành</option>
                        <option value="Hủy bỏ">Hủy bỏ</option>
                    </select>
                    <p class="error-message" id="trang_thai_error"></p>`;
                break;
            case 'candidate':
                title = 'Thêm Ứng viên';
                html = `
                    <label for="ho_ten">Họ tên</label>
                    <input type="text" id="ho_ten" required>
                    <p class="error-message" id="ho_ten_error"></p>
                    <label for="email">Email</label>
                    <input type="email" id="email" required>
                    <p class="error-message" id="email_error"></p>
                    <label for="so_dien_thoai">Số điện thoại</label>
                    <input type="text" id="so_dien_thoai" pattern="\d{10}" required>
                    <p class="error-message" id="so_dien_thoai_error"></p>
                    <label for="id_dot_tuyen_dung">Đợt tuyển dụng</label>
                    <select id="id_dot_tuyen_dung" required>
                        <option value="">Chọn đợt</option>
                        ${options.campaigns?.map(camp => `<option value="${camp.id_dot_tuyen_dung}">${camp.ten_dot}</option>`).join('') || ''}
                    </select>
                    <p class="error-message" id="id_dot_tuyen_dung_error"></p>
                    <label for="id_chuc_vu">Vị trí ứng tuyển</label>
                    <select id="id_chuc_vu" required>
                        <option value="">Chọn vị trí</option>
                        ${options.positions?.map(pos => `<option value="${pos.id_chuc_vu}">${pos.ten_chuc_vu}</option>`).join('') || ''}
                    </select>
                    <p class="error-message" id="id_chuc_vu_error"></p>
                    <label for="nguon_ung_tuyen">Nguồn ứng tuyển</label>
                    <input type="text" id="nguon_ung_tuyen">
                    <label for="ho_so">Hồ sơ (URL)</label>
                    <input type="url" id="ho_so">
                    <label for="trang_thai">Trạng thái</label>
                    <select id="trang_thai" required>
                        <option value="Mới nộp">Mới nộp</option>
                        <option value="Đang xử lý">Đang xử lý</option>
                        <option value="Đạt">Đạt</option>
                        <option value="Không đạt">Không đạt</option>
                    </select>
                    <p class="error-message" id="trang_thai_error"></p>`;
                break;
            case 'interview':
                title = 'Thêm Lịch Hẹn';
                html = `
                    <label for="id_ung_vien">Ứng viên</label>
                    <select id="id_ung_vien" required>
                        <option value="">Chọn ứng viên</option>
                        ${options.candidates?.map(cand => `<option value="${cand.id_ung_vien}">${cand.ho_ten}</option>`).join('') || ''}
                    </select>
                    <p class="error-message" id="id_ung_vien_error"></p>
                    <label for="ngay_hen">Ngày hẹn</label>
                    <input type="date" id="ngay_hen" required>
                    <p class="error-message" id="ngay_hen_error"></p>
                    <label for="gio_hen">Giờ hẹn</label>
                    <input type="time" id="gio_hen" required>
                    <p class="error-message" id="gio_hen_error"></p>
                    <label for="dia_diem">Địa điểm</label>
                    <input type="text" id="dia_diem" required>
                    <p class="error-message" id="dia_diem_error"></p>
                    <label for="ghi_chu">Ghi chú</label>
                    <textarea id="ghi_chu"></textarea>`;
                break;
            case 'evaluation':
                title = 'Thêm Đánh giá';
                html = `
                    <label for="id_ung_vien">Ứng viên</label>
                    <select id="id_ung_vien" required>
                        <option value="">Chọn ứng viên</option>
                        ${options.candidates?.map(cand => `<option value="${cand.id_ung_vien}">${cand.ho_ten}</option>`).join('') || ''}
                    </select>
                    <p class="error-message" id="id_ung_vien_error"></p>
                    <label for="id_ke_hoach">Kế hoạch tuyển dụng</label>
                    <select id="id_ke_hoach" required>
                        <option value="">Chọn kế hoạch</option>
                        ${options.plans?.map(plan => `<option value="${plan.id_ke_hoach}">${plan.ten_chuc_vu}</option>`).join('') || ''}
                    </select>
                    <p class="error-message" id="id_ke_hoach_error"></p>
                    <label for="vong_thi">Vòng thi</label>
                    <input type="text" id="vong_thi" required>
                    <p class="error-message" id="vong_thi_error"></p>
                    <label for="diem">Điểm</label>
                    <input type="number" id="diem" min="0" max="100" required>
                    <p class="error-message" id="diem_error"></p>
                    <label for="nhan_xet">Nhận xét</label>
                    <textarea id="nhan_xet"></textarea>
                    <label for="ngay_danh_gia">Ngày đánh giá</label>
                    <input type="date" id="ngay_danh_gia" required>
                    <p class="error-message" id="ngay_danh_gia_error"></p>`;
                break;
            case 'cost':
                title = 'Thêm Chi phí';
                html = `
                    <label for="id_dot_tuyen_dung">Đợt tuyển dụng</label>
                    <select id="id_dot_tuyen_dung" required>
                        <option value="">Chọn đợt</option>
                        ${options.campaigns?.map(camp => `<option value="${camp.id_dot_tuyen_dung}">${camp.ten_dot}</option>`).join('') || ''}
                    </select>
                    <p class="error-message" id="id_dot_tuyen_dung_error"></p>
                    <label for="noi_dung_chi_phi">Nội dung chi phí</label>
                    <input type="text" id="noi_dung_chi_phi" required>
                    <p class="error-message" id="noi_dung_chi_phi_error"></p>
                    <label for="so_tien">Số tiền</label>
                    <input type="number" id="so_tien" min="0" required>
                    <p class="error-message" id="so_tien_error"></p>
                    <label for="ngay_chi">Ngày chi</label>
                    <input type="date" id="ngay_chi" required>
                    <p class="error-message" id="ngay_chi_error"></p>`;
                break;
            case 'allocation':
                title = 'Thêm Phân bổ';
                html = `
                    <label for="id_ung_vien">Ứng viên</label>
                    <select id="id_ung_vien" required onchange="updateCandidateInfo()">
                        <option value="">Chọn ứng viên</option>
                        ${options.candidates?.map(cand => `<option value="${cand.id_ung_vien}" data-id-chuc-vu="${cand.id_chuc_vu}" data-id-dot-tuyen-dung="${cand.id_dot_tuyen_dung}">${cand.ho_ten}</option>`).join('') || ''}
                    </select>
                    <p class="error-message" id="id_ung_vien_error"></p>
                    <label for="id_phong_ban">Phòng ban</label>
                    <select id="id_phong_ban" required>
                        <option value="">Chọn phòng ban</option>
                        ${options.departments?.map(dep => `<option value="${dep.id_phong_ban}">${dep.ten_phong_ban}</option>`).join('') || ''}
                    </select>
                    <p class="error-message" id="id_phong_ban_error"></p>
                    <label for="id_chuc_vu">Chức vụ</label>
                    <select id="id_chuc_vu" required>
                        <option value="">Chọn chức vụ</option>
                        ${options.positions?.map(pos => `<option value="${pos.id_chuc_vu}">${pos.ten_chuc_vu}</option>`).join('') || ''}
                    </select>
                    <p class="error-message" id="id_chuc_vu_error"></p>
                    <label for="trang_thai">Trạng thái</label>
                    <select id="trang_thai" required>
                        <option value="Chờ phân bổ">Chờ phân bổ</option>
                        <option value="Từ chối">Từ chối</option>
                        <option value="Đã duyệt">Đã duyệt</option>
                    </select>
                    <p class="error-message" id="trang_thai_error"></p>
                    <label for="ngay_phan_bo">Ngày phân bổ</label>
                    <input type="date" id="ngay_phan_bo" required>
                    <p class="error-message" id="ngay_phan_bo_error"></p>
                    <label for="hop_dong_thu_viec">Hợp đồng thử việc (URL)</label>
                    <input type="url" id="hop_dong_thu_viec">`;
                break;
        }

        document.getElementById('modalTitle').textContent = title;
        document.getElementById('addModalBody').innerHTML = html;
        document.getElementById('addModal').style.display = 'flex';

        // Attach save event
        const saveButton = document.getElementById('saveButton');
        saveButton.onclick = () => saveAddData(type);
    }

    // Update candidate info (chức vụ và phòng ban) when candidate is selected
    async function updateCandidateInfo() {
        const candidateSelect = document.getElementById('id_ung_vien');
        const selectedOption = candidateSelect.options[candidateSelect.selectedIndex];
        const idChucVu = selectedOption ? selectedOption.getAttribute('data-id-chuc-vu') : '';
        const idDotTuyenDung = selectedOption ? selectedOption.getAttribute('data-id-dot-tuyen-dung') : '';

        // Cập nhật chức vụ
        if (idChucVu) {
            document.getElementById('id_chuc_vu').value = idChucVu;
        } else {
            document.getElementById('id_chuc_vu').value = '';
        }

        // Cập nhật phòng ban dựa trên đợt tuyển dụng
        if (idDotTuyenDung) {
            try {
                const response = await fetch(`http://localhost/doanqlns/index.php/api/tuyendung/campaign/${idDotTuyenDung}`);
                if (!response.ok) {
                    throw new Error(`Lỗi HTTP: ${response.status}`);
                }
                const campaignData = await response.json();
                if (campaignData.id_phong_ban) {
                    document.getElementById('id_phong_ban').value = campaignData.id_phong_ban;
                } else {
                    document.getElementById('id_phong_ban').value = '';
                }
            } catch (error) {
                console.error('Lỗi khi lấy thông tin phòng ban:', error);
                document.getElementById('id_phong_ban').value = '';
            }
        } else {
            document.getElementById('id_phong_ban').value = '';
        }
    }

    // Save Add Data
   // Save Add Data
    async function saveAddData(type) {
        if (!permissions.quyen_them) {
            alert('Bạn không có quyền thêm dữ liệu.');
            return;
        }

        if (!validateForm(type)) {
            return;
        }

        const data = { action: `add_${type}` };
        let url = 'http://localhost/doanqlns/index.php/api/tuyendung';

        switch (type) {
            case 'plan':
            data.id_chuc_vu = document.getElementById('id_chuc_vu').value;
            data.so_vong_thi = document.getElementById('so_vong_thi').value;
            data.ten_vong_thi = document.getElementById('ten_vong_thi').value.trim();
            data.noi_dung_thi = document.getElementById('noi_dung_thi').value.trim();
            data.diem_chuan = document.getElementById('diem_chuan').value;
            break;
            case 'campaign':
                data.ma_dot = document.getElementById('ma_dot').value.trim();
                data.ten_dot = document.getElementById('ten_dot').value.trim();
                data.id_phong_ban = document.getElementById('id_phong_ban').value;
                data.so_luong_tuyen = document.getElementById('so_luong_tuyen').value;
                data.id_can_bo_tuyen_dung = document.getElementById('id_can_bo_tuyen_dung').value;
                data.ngay_bat_dau = document.getElementById('ngay_bat_dau').value;
                data.ngay_ket_thuc = document.getElementById('ngay_ket_thuc').value;
                data.yeu_cau_vi_tri = document.getElementById('yeu_cau_vi_tri').value.trim();
                data.trang_thai = document.getElementById('trang_thai').value;
                break;
            case 'candidate':
                data.ho_ten = document.getElementById('ho_ten').value.trim();
                data.email = document.getElementById('email').value.trim();
                data.so_dien_thoai = document.getElementById('so_dien_thoai').value.trim();
                data.id_dot_tuyen_dung = document.getElementById('id_dot_tuyen_dung').value;
                data.id_chuc_vu = document.getElementById('id_chuc_vu').value;
                data.nguon_ung_tuyen = document.getElementById('nguon_ung_tuyen').value.trim();
                data.ho_so = document.getElementById('ho_so').value.trim();
                data.trang_thai = document.getElementById('trang_thai').value;
                break;
            case 'interview':
                data.id_ung_vien = document.getElementById('id_ung_vien').value;
                data.ngay_hen = document.getElementById('ngay_hen').value;
                data.gio_hen = document.getElementById('gio_hen').value;
                data.dia_diem = document.getElementById('dia_diem').value.trim();
                data.ghi_chu = document.getElementById('ghi_chu').value.trim();
                break;
            case 'evaluation':
                data.id_ung_vien = document.getElementById('id_ung_vien').value;
                data.id_ke_hoach = document.getElementById('id_ke_hoach').value;
                data.vong_thi = document.getElementById('vong_thi').value.trim();
                data.diem = document.getElementById('diem').value;
                data.nhan_xet = document.getElementById('nhan_xet').value.trim();
                data.ngay_danh_gia = document.getElementById('ngay_danh_gia').value;
                break;
            case 'cost':
                data.id_dot_tuyen_dung = document.getElementById('id_dot_tuyen_dung').value;
                data.noi_dung_chi_phi = document.getElementById('noi_dung_chi_phi').value.trim();
                data.so_tien = document.getElementById('so_tien').value;
                data.ngay_chi = document.getElementById('ngay_chi').value;
                break;
            case 'allocation':
                data.id_ung_vien = document.getElementById('id_ung_vien').value;
                data.id_phong_ban = document.getElementById('id_phong_ban').value;
                data.id_chuc_vu = document.getElementById('id_chuc_vu').value;
                data.trang_thai = document.getElementById('trang_thai').value;
                data.ngay_phan_bo = document.getElementById('ngay_phan_bo').value;
                data.hop_dong_thu_viec = document.getElementById('hop_dong_thu_viec').value.trim() || null;
                break;
        }

        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                throw new Error(`Lỗi HTTP: ${response.status}`);
            }

            const result = await response.json();
            if (result.success) {
                alert('Thêm dữ liệu thành công!');
                document.getElementById('addModal').style.display = 'none';
                loadData();
            } else {
                alert(`Lỗi: ${result.message || 'Không thể thêm dữ liệu'}`);
            }
        } catch (error) {
            console.error('Lỗi khi thêm dữ liệu:', error);
            alert('Lỗi khi thêm dữ liệu. Vui lòng thử lại.');
        }
    }

    // Edit Data
    async function editData(type, id) {
        if (!permissions.quyen_sua) {
            alert('Bạn không có quyền sửa dữ liệu.');
            return;
        }

        try {
            const options = await fetchOptions();
            const response = await fetch(`http://localhost/doanqlns/index.php/api/tuyendung/${type}/${id}`);
            if (!response.ok) {
                throw new Error(`Lỗi HTTP: ${response.status}`);
            }
            const data = await response.json();
            let html = '';
            let title = '';

            switch (type) {
                case 'plan':
                title = 'Sửa Kế hoạch Tuyển dụng';
                html = `
                    <input type="hidden" id="id_ke_hoach" value="${data.id_ke_hoach}">
                    <label for="id_chuc_vu">Chức vụ</label>
                    <select id="id_chuc_vu" required>
                        <option value="">Chọn chức vụ</option>
                        ${options.positions?.map(pos => `<option value="${pos.id_chuc_vu}" ${pos.id_chuc_vu == data.id_chuc_vu ? 'selected' : ''}>${pos.ten_chuc_vu}</option>`).join('') || ''}
                    </select>
                    <p class="error-message" id="id_chuc_vu_error"></p>
                    <label for="so_vong_thi">Số vòng thi</label>
                    <input type="number" id="so_vong_thi" value="${data.so_vong_thi || ''}" min="1" required>
                    <p class="error-message" id="so_vong_thi_error"></p>
                    <label for="ten_vong_thi">Tên vòng thi</label>
                    <input type="text" id="ten_vong_thi" value="${data.ten_vong_thi || ''}" required>
                    <p class="error-message" id="ten_vong_thi_error"></p>
                    <label for="noi_dung_thi">Nội dung thi</label>
                    <textarea id="noi_dung_thi" required>${data.noi_dung_thi || ''}</textarea>
                    <p class="error-message" id="noi_dung_thi_error"></p>
                    <label for="diem_chuan">Điểm chuẩn</label>
                    <input type="number" id="diem_chuan" value="${data.diem_chuan || ''}" min="0" max="100" required>
                    <p class="error-message" id="diem_chuan_error"></p>`;
                break;
                case 'campaign':
                    title = 'Sửa Đợt Tuyển dụng';
                    html = `
                        <input type="hidden" id="id_dot_tuyen_dung" value="${data.id_dot_tuyen_dung}">
                        <label for="ma_dot">Mã Đợt</label>
                        <input type="text" id="ma_dot" value="${data.ma_dot || ''}" required>
                        <p class="error-message" id="ma_dot_error"></p>
                        <label for="ten_dot">Tên Đợt</label>
                        <input type="text" id="ten_dot" value="${data.ten_dot || ''}" required>
                        <p class="error-message" id="ten_dot_error"></p>
                        <label for="id_phong_ban">Phòng ban</label>
                        <select id="id_phong_ban" required>
                            <option value="">Chọn phòng ban</option>
                            ${options.departments?.map(dep => `<option value="${dep.id_phong_ban}" ${dep.id_phong_ban == data.id_phong_ban ? 'selected' : ''}>${dep.ten_phong_ban}</option>`).join('') || ''}
                        </select>
                        <p class="error-message" id="id_phong_ban_error"></p>
                        <label for="so_luong_tuyen">Số lượng tuyển</label>
                        <input type="number" id="so_luong_tuyen" value="${data.so_luong_tuyen || ''}" min="1" required>
                        <p class="error-message" id="so_luong_tuyen_error"></p>
                        <label for="id_can_bo_tuyen_dung">Cán bộ tuyển dụng</label>
                        <select id="id_can_bo_tuyen_dung" required>
                            <option value="">Chọn cán bộ</option>
                            ${options.recruiters?.map(rec => `<option value="${rec.id_nhan_vien}" ${rec.id_nhan_vien == data.id_can_bo_tuyen_dung ? 'selected' : ''}>${rec.ho_ten}</option>`).join('') || ''}
                        </select>
                        <p class="error-message" id="id_can_bo_tuyen_dung_error"></p>
                        <label for="ngay_bat_dau">Ngày bắt đầu</label>
                        <input type="date" id="ngay_bat_dau" value="${data.ngay_bat_dau || ''}" required>
                        <p class="error-message" id="ngay_bat_dau_error"></p>
                        <label for="ngay_ket_thuc">Ngày kết thúc</label>
                        <input type="date" id="ngay_ket_thuc" value="${data.ngay_ket_thuc || ''}" required>
                        <p class="error-message" id="ngay_ket_thuc_error"></p>
                        <label for="yeu_cau_vi_tri">Yêu cầu vị trí</label>
                        <textarea id="yeu_cau_vi_tri">${data.yeu_cau_vi_tri || ''}</textarea>
                        <label for="trang_thai">Trạng thái</label>
                        <select id="trang_thai" required>
                            <option value="Đang tiến hành" ${data.trang_thai === 'Đang tiến hành' ? 'selected' : ''}>Đang tiến hành</option>
                            <option value="Hoàn thành" ${data.trang_thai === 'Hoàn thành' ? 'selected' : ''}>Hoàn thành</option>
                            <option value="Hủy bỏ" ${data.trang_thai === 'Hủy bỏ' ? 'selected' : ''}>Hủy bỏ</option>
                        </select>
                        <p class="error-message" id="trang_thai_error"></p>`;
                    break;
                case 'candidate':
                    title = 'Sửa Ứng viên';
                    html = `
                        <input type="hidden" id="id_ung_vien" value="${data.id_ung_vien}">
                        <label for="ho_ten">Họ tên</label>
                        <input type="text" id="ho_ten" value="${data.ho_ten || ''}" required>
                        <p class="error-message" id="ho_ten_error"></p>
                        <label for="email">Email</label>
                        <input type="email" id="email" value="${data.email || ''}" required>
                        <p class="error-message" id="email_error"></p>
                        <label for="so_dien_thoai">Số điện thoại</label>
                        <input type="text" id="so_dien_thoai" value="${data.so_dien_thoai || ''}" pattern="\d{10}" required>
                        <p class="error-message" id="so_dien_thoai_error"></p>
                        <label for="id_dot_tuyen_dung">Đợt tuyển dụng</label>
                        <select id="id_dot_tuyen_dung" required>
                            <option value="">Chọn đợt</option>
                            ${options.campaigns?.map(camp => `<option value="${camp.id_dot_tuyen_dung}" ${camp.id_dot_tuyen_dung == data.id_dot_tuyen_dung ? 'selected' : ''}>${camp.ten_dot}</option>`).join('') || ''}
                        </select>
                        <p class="error-message" id="id_dot_tuyen_dung_error"></p>
                        <label for="id_chuc_vu">Vị trí ứng tuyển</label>
                        <select id="id_chuc_vu" required>
                            <option value="">Chọn vị trí</option>
                            ${options.positions?.map(pos => `<option value="${pos.id_chuc_vu}" ${pos.id_chuc_vu == data.id_chuc_vu ? 'selected' : ''}>${pos.ten_chuc_vu}</option>`).join('') || ''}
                        </select>
                        <p class="error-message" id="id_chuc_vu_error"></p>
                        <label for="nguon_ung_tuyen">Nguồn ứng tuyển</label>
                        <input type="text" id="nguon_ung_tuyen" value="${data.nguon_ung_tuyen || ''}">
                        <label for="ho_so">Hồ sơ (URL)</label>
                        <input type="url" id="ho_so" value="${data.ho_so || ''}">
                        <label for="trang_thai">Trạng thái</label>
                        <select id="trang_thai" required>
                            <option value="Mới nộp" ${data.trang_thai === 'Mới nộp' ? 'selected' : ''}>Mới nộp</option>
                            <option value="Đang xử lý" ${data.trang_thai === 'Đang xử lý' ? 'selected' : ''}>Đang xử lý</option>
                            <option value="Đạt" ${data.trang_thai === 'Đạt' ? 'selected' : ''}>Đạt</option>
                            <option value="Không đạt" ${data.trang_thai === 'Không đạt' ? 'selected' : ''}>Không đạt</option>
                        </select>
                        <p class="error-message" id="trang_thai_error"></p>`;
                    break;
                case 'interview':
                    title = 'Sửa Lịch Hẹn';
                    html = `
                        <input type="hidden" id="id_lich_hen" value="${data.id_lich_hen}">
                        <label for="id_ung_vien">Ứng viên</label>
                        <select id="id_ung_vien" required>
                            <option value="">Chọn ứng viên</option>
                            ${options.candidates?.map(cand => `<option value="${cand.id_ung_vien}" ${cand.id_ung_vien == data.id_ung_vien ? 'selected' : ''}>${cand.ho_ten}</option>`).join('') || ''}
                        </select>
                        <p class="error-message" id="id_ung_vien_error"></p>
                        <label for="ngay_hen">Ngày hẹn</label>
                        <input type="date" id="ngay_hen" value="${data.ngay_hen || ''}" required>
                        <p class="error-message" id="ngay_hen_error"></p>
                        <label for="gio_hen">Giờ hẹn</label>
                        <input type="time" id="gio_hen" value="${data.gio_hen || ''}" required>
                        <p class="error-message" id="gio_hen_error"></p>
                        <label for="dia_diem">Địa điểm</label>
                        <input type="text" id="dia_diem" value="${data.dia_diem || ''}" required>
                        <p class="error-message" id="dia_diem_error"></p>
                        <label for="ghi_chu">Ghi chú</label>
                        <textarea id="ghi_chu">${data.ghi_chu || ''}</textarea>`;
                    break;
                case 'evaluation':
                    title = 'Sửa Đánh giá';
                    html = `
                        <input type="hidden" id="id_danh_gia" value="${data.id_danh_gia}">
                        <label for="id_ung_vien">Ứng viên</label>
                        <select id="id_ung_vien" required>
                            <option value="">Chọn ứng viên</option>
                            ${options.candidates?.map(cand => `<option value="${cand.id_ung_vien}" ${cand.id_ung_vien == data.id_ung_vien ? 'selected' : ''}>${cand.ho_ten}</option>`).join('') || ''}
                        </select>
                        <p class="error-message" id="id_ung_vien_error"></p>
                        <label for="id_ke_hoach">Kế hoạch tuyển dụng</label>
                        <select id="id_ke_hoach" required>
                            <option value="">Chọn kế hoạch</option>
                            ${options.plans?.map(plan => `<option value="${plan.id_ke_hoach}" ${plan.id_ke_hoach == data.id_ke_hoach ? 'selected' : ''}>${plan.ten_chuc_vu}</option>`).join('') || ''}
                        </select>
                        <p class="error-message" id="id_ke_hoach_error"></p>
                        <label for="vong_thi">Vòng thi</label>
                        <input type="text" id="vong_thi" value="${data.vong_thi || ''}" required>
                        <p class="error-message" id="vong_thi_error"></p>
                        <label for="diem">Điểm</label>
                        <input type="number" id="diem" value="${data.diem || ''}" min="0" max="100" required>
                        <p class="error-message" id="diem_error"></p>
                        <label for="nhan_xet">Nhận xét</label>
                        <textarea id="nhan_xet">${data.nhan_xet || ''}</textarea>
                        <label for="ngay_danh_gia">Ngày đánh giá</label>
                        <input type="date" id="ngay_danh_gia" value="${data.ngay_danh_gia || ''}" required>
                        <p class="error-message" id="ngay_danh_gia_error"></p>`;
                    break;
                case 'cost':
                    title = 'Sửa Chi phí';
                    html = `
                        <input type="hidden" id="id_chi_phi" value="${data.id_chi_phi}">
                        <label for="id_dot_tuyen_dung">Đợt tuyển dụng</label>
                        <select id="id_dot_tuyen_dung" required>
                            <option value="">Chọn đợt</option>
                            ${options.campaigns?.map(camp => `<option value="${camp.id_dot_tuyen_dung}" ${camp.id_dot_tuyen_dung == data.id_dot_tuyen_dung ? 'selected' : ''}>${camp.ten_dot}</option>`).join('') || ''}
                        </select>
                        <p class="error-message" id="id_dot_tuyen_dung_error"></p>
                        <label for="noi_dung_chi_phi">Nội dung chi phí</label>
                        <input type="text" id="noi_dung_chi_phi" value="${data.noi_dung_chi_phi || ''}" required>
                        <p class="error-message" id="noi_dung_chi_phi_error"></p>
                        <label for="so_tien">Số tiền</label>
                        <input type="number" id="so_tien" value="${data.so_tien || ''}" min="0" required>
                        <p class="error-message" id="so_tien_error"></p>
                        <label for="ngay_chi">Ngày chi</label>
                        <input type="date" id="ngay_chi" value="${data.ngay_chi || ''}" required>
                        <p class="error-message" id="ngay_chi_error"></p>`;
                    break;
                case 'allocation':
                    title = 'Sửa Phân bổ';
                    html = `
                        <input type="hidden" id="id_phan_bo" value="${data.id_phan_bo}">
                        <label for="id_ung_vien">Ứng viên</label>
                        <select id="id_ung_vien" required onchange="updateCandidateInfo()">
                            <option value="">Chọn ứng viên</option>
                            ${options.candidates?.map(cand => `<option value="${cand.id_ung_vien}" data-id-chuc-vu="${cand.id_chuc_vu}" ${cand.id_ung_vien == data.id_ung_vien ? 'selected' : ''}>${cand.ho_ten}</option>`).join('') || ''}
                        </select>
                        <p class="error-message" id="id_ung_vien_error"></p>
                        <label for="id_phong_ban">Phòng ban</label>
                        <select id="id_phong_ban" required>
                            <option value="">Chọn phòng ban</option>
                            ${options.departments?.map(dep => `<option value="${dep.id_phong_ban}" ${dep.id_phong_ban == data.id_phong_ban ? 'selected' : ''}>${dep.ten_phong_ban}</option>`).join('') || ''}
                        </select>
                        <p class="error-message" id="id_phong_ban_error"></p>
                        <label for="id_chuc_vu">Chức vụ</label>
                        <select id="id_chuc_vu" required>
                            <option value="">Chọn chức vụ</option>
                            ${options.positions?.map(pos => `<option value="${pos.id_chuc_vu}" ${pos.id_chuc_vu == data.id_chuc_vu ? 'selected' : ''}>${pos.ten_chuc_vu}</option>`).join('') || ''}
                        </select>
                        <p class="error-message" id="id_chuc_vu_error"></p>
                        <label for="trang_thai">Trạng thái</label>
                        <select id="trang_thai" required>
                            <option value="Chờ phân bổ" ${data.trang_thai === 'Chờ phân bổ' ? 'selected' : ''}>Chờ phân bổ</option>
                            <option value="Từ chối" ${data.trang_thai === 'Từ chối' ? 'selected' : ''}>Từ chối</option>
                            <option value="Đã duyệt" ${data.trang_thai === 'Đã duyệt' ? 'selected' : ''}>Đã duyệt</option>
                        </select>
                        <p class="error-message" id="trang_thai_error"></p>
                        <label for="ngay_phan_bo">Ngày phân bổ</label>
                        <input type="date" id="ngay_phan_bo" value="${data.ngay_phan_bo || ''}" required>
                        <p class="error-message" id="ngay_phan_bo_error"></p>
                        <label for="hop_dong_thu_viec">Hợp đồng thử việc (URL)</label>
                        <input type="url" id="hop_dong_thu_viec" value="${data.hop_dong_thu_viec || ''}">`;
                    break;
            }

            document.getElementById('modalTitle').textContent = title;
            document.getElementById('addModalBody').innerHTML = html;
            document.getElementById('addModal').style.display = 'flex';

            // Attach save event
            const saveButton = document.getElementById('saveButton');
            saveButton.onclick = () => saveEditData(type, id);
        } catch (error) {
            console.error('Lỗi khi tải dữ liệu chỉnh sửa:', error);
            alert('Lỗi khi tải dữ liệu chỉnh sửa. Vui lòng thử lại.');
        }
    }

    // Save Edit Data
   async function saveEditData(type, id) {
    if (!permissions.quyen_sua) {
        alert('Bạn không có quyền sửa dữ liệu.');
        return;
    }

    if (!validateForm(type)) {
        return;
    }

    const data = { action: `edit_${type}` }; // Use 'edit_' instead of 'update_'
    let url = `http://localhost/doanqlns/index.php/api/tuyendung/${type}/${id}`;

    switch (type) {
        case 'plan':
            data.id_chuc_vu = document.getElementById('id_chuc_vu').value;
            data.so_vong_thi = document.getElementById('so_vong_thi').value;
            data.ten_vong_thi = document.getElementById('ten_vong_thi').value.trim();
            data.noi_dung_thi = document.getElementById('noi_dung_thi').value.trim();
            data.diem_chuan = document.getElementById('diem_chuan').value;
            break;
        case 'campaign':
            data.ma_dot = document.getElementById('ma_dot').value.trim();
            data.ten_dot = document.getElementById('ten_dot').value.trim();
            data.id_phong_ban = document.getElementById('id_phong_ban').value;
            data.so_luong_tuyen = document.getElementById('so_luong_tuyen').value;
            data.id_can_bo_tuyen_dung = document.getElementById('id_can_bo_tuyen_dung').value;
            data.ngay_bat_dau = document.getElementById('ngay_bat_dau').value;
            data.ngay_ket_thuc = document.getElementById('ngay_ket_thuc').value;
            data.yeu_cau_vi_tri = document.getElementById('yeu_cau_vi_tri').value.trim();
            data.trang_thai = document.getElementById('trang_thai').value;
            break;
        case 'candidate':
            data.ho_ten = document.getElementById('ho_ten').value.trim();
            data.email = document.getElementById('email').value.trim();
            data.so_dien_thoai = document.getElementById('so_dien_thoai').value.trim();
            data.id_dot_tuyen_dung = document.getElementById('id_dot_tuyen_dung').value;
            data.id_chuc_vu = document.getElementById('id_chuc_vu').value;
            data.nguon_ung_tuyen = document.getElementById('nguon_ung_tuyen').value.trim();
            data.ho_so = document.getElementById('ho_so').value.trim();
            data.trang_thai = document.getElementById('trang_thai').value;
            break;
        case 'interview':
            data.id_ung_vien = document.getElementById('id_ung_vien').value;
            data.ngay_hen = document.getElementById('ngay_hen').value;
            data.gio_hen = document.getElementById('gio_hen').value;
            data.dia_diem = document.getElementById('dia_diem').value.trim();
            data.ghi_chu = document.getElementById('ghi_chu').value.trim();
            break;
        case 'evaluation':
            data.id_ung_vien = document.getElementById('id_ung_vien').value;
            data.id_ke_hoach = document.getElementById('id_ke_hoach').value;
            data.vong_thi = document.getElementById('vong_thi').value.trim();
            data.diem = document.getElementById('diem').value;
            data.nhan_xet = document.getElementById('nhan_xet').value.trim();
            data.ngay_danh_gia = document.getElementById('ngay_danh_gia').value;
            break;
        case 'cost':
            data.id_dot_tuyen_dung = document.getElementById('id_dot_tuyen_dung').value;
            data.noi_dung_chi_phi = document.getElementById('noi_dung_chi_phi').value.trim();
            data.so_tien = document.getElementById('so_tien').value;
            data.ngay_chi = document.getElementById('ngay_chi').value;
            break;
        case 'allocation':
            data.id_ung_vien = document.getElementById('id_ung_vien').value;
            data.id_phong_ban = document.getElementById('id_phong_ban').value;
            data.id_chuc_vu = document.getElementById('id_chuc_vu').value;
            data.trang_thai = document.getElementById('trang_thai').value;
            data.ngay_phan_bo = document.getElementById('ngay_phan_bo').value;
            data.hop_dong_thu_viec = document.getElementById('hop_dong_thu_viec').value.trim() || null;
            break;
    }

    try {
        const response = await fetch(url, {
            method: 'PUT', // Change to PUT
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        if (!response.ok) {
            throw new Error(`Lỗi HTTP: ${response.status}`);
        }

        const result = await response.json();
        if (result.success) {
            alert('Cập nhật dữ liệu thành công!');
            document.getElementById('addModal').style.display = 'none';
            loadData();
        } else {
            alert(`Lỗi: ${result.message || 'Không thể cập nhật dữ liệu'}`);
        }
    } catch (error) {
        console.error('Lỗi khi cập nhật dữ liệu:', error);
        alert('Lỗi khi cập nhật dữ liệu. Vui lòng thử lại.');
    }
}

    // Delete Data
    async function deleteData(type, id) {
        if (!permissions.quyen_xoa) {
            alert('Bạn không có quyền xóa dữ liệu.');
            return;
        }

        if (!confirm('Bạn có chắc chắn muốn xóa bản ghi này?')) {
            return;
        }

        try {
            const response = await fetch('http://localhost/doanqlns/index.php/api/tuyendung', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: `delete_${type}`, id })
            });

            if (!response.ok) {
                throw new Error(`Lỗi HTTP: ${response.status}`);
            }

            const result = await response.json();
            if (result.success) {
                alert('Xóa dữ liệu thành công!');
                loadData();
            } else {
                alert(`Lỗi: ${result.message || 'Không thể xóa dữ liệu'}`);
            }
        } catch (error) {
            console.error('Lỗi khi xóa dữ liệu:', error);
            alert('Lỗi khi xóa dữ liệu. Vui lòng thử lại.');
        }
    }

    // Show Detail Modal
   // Show Detail Modal
    async function showDetailModal(type, id) {
        try {
            const response = await fetch(`http://localhost/doanqlns/index.php/api/tuyendung/${type}/${id}`);
            if (!response.ok) {
                throw new Error(`Lỗi HTTP: ${response.status}`);
            }
            const data = await response.json();
            let html = '';

            switch (type) {
                case 'plan':
                title = 'Chi tiết Kế hoạch Tuyển dụng';
                html = `
                    <p><strong>Chức vụ:</strong> ${data.ten_chuc_vu || ''}</p>
                    <p><strong>Số vòng thi:</strong> ${data.so_vong_thi || ''}</p>
                    <p><strong>Tên vòng thi:</strong> ${data.ten_vong_thi || ''}</p>
                    <p><strong>Nội dung thi:</strong> ${data.noi_dung_thi || ''}</p>
                    <p><strong>Điểm chuẩn:</strong> ${data.diem_chuan || ''}</p>`;
                break;
                case 'campaign':
                    html = `
                        <p><strong>Mã Đợt:</strong> ${data.ma_dot || ''}</p>
                        <p><strong>Tên Đợt:</strong> ${data.ten_dot || ''}</p>
                        <p><strong>Phòng ban:</strong> ${data.ten_phong_ban || ''}</p>
                        <p><strong>Số lượng tuyển:</strong> ${formatNumber(data.so_luong_tuyen)}</p>
                        <p><strong>Cán bộ tuyển dụng:</strong> ${data.ten_can_bo || ''}</p>
                        <p><strong>Ngày bắt đầu:</strong> ${data.ngay_bat_dau || ''}</p>
                        <p><strong>Ngày kết thúc:</strong> ${data.ngay_ket_thuc || ''}</p>
                        <p><strong>Yêu cầu vị trí:</strong> ${data.yeu_cau_vi_tri || ''}</p>
                        <p><strong>Trạng thái:</strong> ${data.trang_thai || ''}</p>`;
                    break;
                case 'candidate':
                    html = `
                        <p><strong>Họ tên:</strong> ${data.ho_ten || ''}</p>
                        <p><strong>Email:</strong> ${data.email || ''}</p>
                        <p><strong>Số điện thoại:</strong> ${data.so_dien_thoai || ''}</p>
                        <p><strong>Đợt tuyển dụng:</strong> ${data.ten_dot || ''}</p>
                        <p><strong>Vị trí ứng tuyển:</strong> ${data.ten_chuc_vu || ''}</p>
                        <p><strong>Phòng ban:</strong> ${data.ten_phong_ban || 'Chưa phân bổ'}</p>
                        <p><strong>Nguồn ứng tuyển:</strong> ${data.nguon_ung_tuyen || ''}</p>
                        <p><strong>Hồ sơ:</strong> ${data.ho_so ? `<a href="${data.ho_so}" target="_blank">Xem</a>` : ''}</p>
                        <p><strong>Trạng thái:</strong> ${data.trang_thai || ''}</p>`;
                    break;
                case 'interview':
                    html = `
                        <p><strong>Ứng viên:</strong> ${data.ho_ten || ''}</p>
                        <p><strong>Ngày hẹn:</strong> ${data.ngay_hen || ''}</p>
                        <p><strong>Giờ hẹn:</strong> ${data.gio_hen || ''}</p>
                        <p><strong>Địa điểm:</strong> ${data.dia_diem || ''}</p>
                        <p><strong>Ghi chú:</strong> ${data.ghi_chu || ''}</p>`;
                    break;
                case 'evaluation':
                    html = `
                        <p><strong>Ứng viên:</strong> ${data.ho_ten || ''}</p>
                        <p><strong>Vòng thi:</strong> ${data.vong_thi || ''}</p>
                        <p><strong>Điểm:</strong> ${data.diem || ''}</p>
                        <p><strong>Nhận xét:</strong> ${data.nhan_xet || ''}</p>
                        <p><strong>Ngày đánh giá:</strong> ${data.ngay_danh_gia || ''}</p>`;
                    break;
                case 'cost':
                    html = `
                        <p><strong>Đợt tuyển dụng:</strong> ${data.ten_dot || ''}</p>
                        <p><strong>Nội dung chi phí:</strong> ${data.noi_dung_chi_phi || ''}</p>
                        <p><strong>Số tiền:</strong> ${formatNumber(data.so_tien)}</p>
                        <p><strong>Ngày chi:</strong> ${data.ngay_chi || ''}</p>`;
                    break;
                case 'allocation':
                    html = `
                        <p><strong>Ứng viên:</strong> ${data.ho_ten || ''}</p>
                        <p><strong>Phòng ban:</strong> ${data.ten_phong_ban || ''}</p>
                        <p><strong>Chức vụ:</strong> ${data.ten_chuc_vu || ''}</p>
                        <p><strong>Trạng thái:</strong> ${data.trang_thai || ''}</p>
                        <p><strong>Ngày phân bổ:</strong> ${data.ngay_phan_bo || ''}</p>
                        <p><strong>Hợp đồng thử việc:</strong> ${data.hop_dong_thu_viec ? `<a href="${data.hop_dong_thu_viec}" target="_blank">Xem</a>` : ''}</p>`;
                    break;
            }

            document.getElementById('detailModalBody').innerHTML = html;
            document.getElementById('detailModal').style.display = 'flex';
        } catch (error) {
            console.error('Lỗi khi tải chi tiết:', error);
            alert('Lỗi khi tải chi tiết. Vui lòng thử lại.');
        }
    }
    // Close Modals
    function closeAddModal() {
        document.getElementById('addModal').style.display = 'none';
        document.getElementById('addModalBody').innerHTML = '';
    }

    function closeEditModal() {
        document.getElementById('editModal').style.display = 'none';
        document.getElementById('editModalBody').innerHTML = '';
        window.currentEditType = null;
    }

    function closeDetailModal() {
        document.getElementById('detailModal').style.display = 'none';
        document.getElementById('detailModalBody').innerHTML = '';
    }

    // Initialize
    window.onload = function () {
        initializePermissions();
        setDefaultFilter();
        loadData();
        openTab('campaigns');
    };
</script>

</body>
</html>