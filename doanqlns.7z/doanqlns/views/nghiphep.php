<?php
require_once __DIR__ . '/../includes/check_login.php';
include(__DIR__ . '/../includes/header.php');
include(__DIR__ . '/../includes/sidebar.php');
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Bảng Nghỉ Phép</title>

    <!-- Font Awesome & Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- CSS chính -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/stylenghiphep.css">

    <!-- CSS riêng -->
    <style>
        .name-link,
        .name-link:hover {
            text-decoration: none;
            color: #007bff;
        }
        .btn-edit, .btn-delete, .btn-add {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            color: white;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .btn-edit {
            background-color: #007bff;
            margin-right: 5px;
        }
        .btn-delete {
            background-color: #f44336;
        }
        .btn-add {
            background-color: #4CAF50;
        }
        .btn-add:hover, .btn-edit:hover, .btn-delete:hover {
            opacity: 0.9;
        }
        .status {
            padding: 4px 8px;
            border-radius: 4px;
            color: white;
            font-size: 12px;
        }
        .status.daduyet { background-color: #4CAF50; }
        .status.tuchoi { background-color: #f44336; }
        .status.choxetduyet { background-color: #FF9800; }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        .modal-content {
            background: #fff;
            border-radius: 12px;
            max-width: 600px;
            width: 90%;
            box-shadow: 0 8px 24px rgba(0,0,0,0.2);
            overflow: hidden;
            animation: slideIn 0.3s ease;
        }
        @keyframes slideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
 Демодал-header {
            background: linear-gradient(90deg, #007bff, #0056b3);
            color: #fff;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .modal-header h2 {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 500;
        }
        .modal-close {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.5rem;
            cursor: pointer;
            transition: transform 0.2s, color 0.2s;
        }
        .modal-close:hover {
            transform: scale(1.2);
            color: #e0e0e0;
        }
        .modal-body {
            padding: 25px;
            max-height: 60vh;
            overflow-y: auto;
        }
        .modal-body .section-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #333;
            margin: 0 0 15px 0;
            border-bottom: 2px solid #007bff;
            padding-bottom: 5px;
        }
        .info-group {
            display: flex;
            align-items: flex-start;
            margin-bottom: 15px;
            padding: 8px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .info-group label {
            font-weight: 500;
            color: #333;
            width: 150px;
            flex-shrink: 0;
            font-size: 14px;
        }
        .info-group .info-value {
            color: #555;
            flex-grow: 1;
            font-size: 14px;
            line-height: 1.5;
        }
        .modal-field {
            margin-bottom: 15px;
        }
        .modal-field label {
            display: block;
            font-weight: 500;
            color: #333;
            margin-bottom: 5px;
        }
        .modal-body select, .modal-body input[type="date"], .modal-body input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.2s;
        }
        .modal-body select:focus, .modal-body input:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 5px rgba(0,123,255,0.3);
        }
        .reason-input {
            display: none;
            margin-top: 10px;
        }
        .reason-input.active {
            display: block;
        }
        .reason-input label {
            font-weight: 500;
            color: #333;
            display: block;
            margin-bottom: 5px;
        }
        .reason-input input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
        }
        .modal-footer {
            padding: 15px 20px;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            background: #f8f9fa;
            border-top: 1px solid #ddd;
        }
        .modal-footer .btn-save, .modal-footer .btn-close {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: background-color 0.2s;
        }
        .modal-footer .btn-save {
            background-color: #4CAF50;
            color: white;
        }
        .modal-footer .btn-close {
            background-color: #dc3545;
            color: white;
        }
        .modal-footer .btn-save:hover, .modal-footer .btn-close:hover {
            opacity: 0.85;
        }
        .loading {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 15px 30px;
            border-radius: 8px;
            z-index: 2000;
            font-size: 14px;
        }
        .filter-container {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            justify-content: center;
            align-items: center;
        }
        .filter-container select,
        .filter-container input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        .filter-container select:focus,
        .filter-container input:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.2);
        }
        /* Điều chỉnh chiều rộng cột */
        table th, table td {
            padding: 8px;
            text-align: left;
        }
        table th:nth-child(5), table td:nth-child(5) { /* Lý Do */
            min-width: 150px;
        }
        table th:nth-child(6), table td:nth-child(6) { /* Loại Nghỉ */
            min-width: 100px;
        }
        table th:nth-child(7), table td:nth-child(7) { /* Lý Do Từ Chối */
            min-width: 150px;
        }
        .red-star {
            color: #f44336;
            margin-right: 5px;
        }
        @media (max-width: 768px) {
            .modal-content {
                width: 95%;
                max-width: 400px;
            }
            .info-group {
                flex-direction: column;
                align-items: flex-start;
            }
            .info-group label {
                width: auto;
                margin-bottom: 5px;
            }
            .info-group .info-value {
                width: 100%;
            }
            th, td {
                font-size: 12px;
                padding: 6px;
            }
            .btn-edit, .btn-delete, .btn-add {
                padding: 4px 8px;
                font-size: 12px;
            }
            .modal-body {
                padding: 15px;
            }
            .modal-header h2 {
                font-size: 1.2rem;
            }
            .filter-container {
                flex-direction: column;
                align-items: center;
            }
        }
    </style>
</head>

<body>
    <?php include('../includes/sidebar.php'); ?>

    <div class="main-content">
        <h3>Bảng Nghỉ Phép</h3>
        <div class="filter-container">
            <select id="selectMonth" aria-label="Chọn tháng">
                <option value="1">Tháng 1</option>
                <option value="2">Tháng 2</option>
                <option value="3">Tháng 3</option>
                <option value="4">Tháng 4</option>
                <option value="5" selected>Tháng 5</option>
                <option value="6">Tháng 6</option>
                <option value="7">Tháng 7</option>
                <option value="8">Tháng 8</option>
                <option value="9">Tháng 9</option>
                <option value="10">Tháng 10</option>
                <option value="11">Tháng 11</option>
                <option value="12">Tháng 12</option>
            </select>
            <input type="number" id="selectYear" min="2000" max="2100" aria-label="Nhập năm" placeholder="Năm"/>
            <button class="btn-add" onclick="showAddNghiPhepModal()">
                <i class="fas fa-plus"></i> Thêm Nghỉ Phép
            </button>
        </div>
        <table>
            <thead>
                <tr>
                    <th>ID Nghỉ Phép</th>
                    <th>Nhân Viên</th>
                    <th>Ngày Bắt Đầu</th>
                    <th>Ngày Kết Thúc</th>
                    <th>Lý Do</th>
                    <th>Loại Nghỉ</th>
                    <th>Lý Do Từ Chối</th>
                    <th>Trạng Thái</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody id="nghiPhepTableBody">
                <tr><td colspan="9">Đang tải dữ liệu...</td></tr>
            </tbody>
        </table>

        <!-- Modal chi tiết đơn nghỉ phép -->
        <div id="detailNghiPhepModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Chi Tiết Đơn Nghỉ Phép</h2>
            <button class="modal-close" onclick="closeDetailModal()">×</button>
        </div>
        <div class="modal-body">
            <div class="section-title">Thông Tin Nhân Viên</div>
            <div class="info-group">
                <label>Họ và Tên:</label>
                <span id="detailHoTen" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Giới Tính:</label>
                <span id="detailGioiTinh" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Ngày Sinh:</label>
                <span id="detailNgaySinh" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Email:</label>
                <span id="detailEmail" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Số Điện Thoại:</label>
                <span id="detailSoDienThoai" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Địa Chỉ:</label>
                <span id="detailDiaChi" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Phòng Ban:</label>
                <span id="detailPhongBan" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Chức Vụ:</label>
                <span id="detailChucVu" class="info-value"></span>
            </div>
            <div class="section-title">Thông Tin Đơn Nghỉ Phép</div>
            <div class="info-group">
                <label>Ngày Bắt Đầu:</label>
                <span id="detailNgayBatDau" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Ngày Kết Thúc:</label>
                <span id="detailNgayKetThuc" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Lý Do:</label>
                <span id="detailLyDo" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Loại Nghỉ:</label>
                <span id="detailLoaiNghi" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Lý Do Từ Chối:</label>
                <span id="detailLyDoTuChoi" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Trạng Thái:</label>
                <span id="detailTrangThai" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Tổng Ngày Nghỉ Trong Tháng:</label>
                <span id="detailTongNgayNghi" class="info-value"></span>
            </div>
            <div class="info-group">
                <label>Số Ngày Phép Năm Còn Lại:</label>
                <span id="detailSoNgayPhepNamConLai" class="info-value"></span>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-close" onclick="closeDetailModal()">Đóng</button>
        </div>
    </div>
</div>

        <!-- Modal Sửa Trạng Thái -->
        <div id="editNghiPhepModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Sửa Trạng Thái Đơn Nghỉ Phép</h2>
                    <button class="modal-close" onclick="closeEditModal()">×</button>
                </div>
                <div class="modal-body">
                    <div class="modal-field">
                        <label for="editStatus">Trạng Thái:</label>
                        <select id="editStatus" onchange="toggleReasonInput()">
                            <option value="Chờ duyệt">Chờ duyệt</option>
                            <option value="Từ chối">Từ chối</option>
                            <option value="Duyệt">Duyệt</option>
                        </select>
                    </div>
                    <input type="hidden" id="editIdNghiPhep">
                    <input type="hidden" id="editIdNhanVien">
                    <input type="hidden" id="editNgayBatDau">
                    <input type="hidden" id="editNgayKetThuc">
                    <div class="reason-input" id="reasonInput">
                        <label for="reason">Lý do từ chối:</label>
                        <input type="text" id="reason" name="reason" placeholder="Nhập lý do từ chối">
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn-save" onclick="saveNghiPhepStatus()">Lưu</button>
                    <button class="btn-close" onclick="closeEditModal()">Hủy</button>
                </div>
            </div>
        </div>

        <!-- Modal Thêm Nghỉ Phép -->
        <div id="addNghiPhepModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Thêm Đơn Nghỉ Phép</h2>
                    <button class="modal-close" onclick="closeAddNghiPhepModal()">×</button>
                </div>
                <div class="modal-body">
                    <div class="modal-field">
                        <label for="addIdNhanVien">Nhân Viên:</label>
                        <select id="addIdNhanVien" required>
                            <option value="">Chọn nhân viên</option>
                        </select>
                    </div>
                    <div class="modal-field">
                        <label for="addNgayBatDau">Ngày Bắt Đầu:</label>
                        <input type="date" id="addNgayBatDau" required>
                    </div>
                    <div class="modal-field">
                        <label for="addNgayKetThuc">Ngày Kết Thúc:</label>
                        <input type="date" id="addNgayKetThuc" required>
                    </div>
                    <div class="modal-field">
                        <label for="addLyDo">Lý Do:</label>
                        <input type="text" id="addLyDo" placeholder="Nhập lý do nghỉ" required>
                    </div>
                    <div class="modal-field">
                        <label for="addLoaiNghi">Loại Nghỉ:</label>
                        <select id="addLoaiNghi" required>
                            <option value="Có phép">Có phép</option>
                            <option value="Không phép">Không phép</option>
                            <option value="Phép Năm">Phép Năm</option> <!-- Đã sửa đúng giá trị -->
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn-save" onclick="saveNewNghiPhep()">Lưu</button>
                    <button class="btn-close" onclick="closeAddNghiPhepModal()">Hủy</button>
                </div>
            </div>
        </div>

        <!-- Loading indicator -->
        <div class="loading" id="loadingIndicator">Đang xử lý...</div>
    </div>

    <script>
        // Biến toàn cục
        let nghiPhepData = [];
        let usersData = [];
        const userPermissions = {
            quyen_sua: <?php echo isset($_SESSION['quyen_sua']) && $_SESSION['quyen_sua'] ? 'true' : 'false'; ?>,
            quyen_xoa: <?php echo isset($_SESSION['quyen_xoa']) && $_SESSION['quyen_xoa'] ? 'true' : 'false'; ?>
        };
        const userId = <?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'null'; ?>;

        // Tham chiếu đến các phần tử DOM
        const nghiPhepTableBody = document.getElementById("nghiPhepTableBody");
        const detailNghiPhepModal = document.getElementById("detailNghiPhepModal");
        const editNghiPhepModal = document.getElementById("editNghiPhepModal");
        const addNghiPhepModal = document.getElementById("addNghiPhepModal");
        const loadingIndicator = document.getElementById("loadingIndicator");
        const reasonInput = document.getElementById("reasonInput");
        const editStatus = document.getElementById("editStatus");

        // Hàm hiển thị loading
        function showLoading() {
            loadingIndicator.style.display = "block";
        }

        // Hàm ẩn loading
        function hideLoading() {
            loadingIndicator.style.display = "none";
        }

        // Tải danh sách nhân viên
        async function loadUsersData() {
            showLoading();
            try {
                const response = await fetch("http://localhost/doanqlns/index.php/api/users");
                if (!response.ok) throw new Error("Lỗi khi tải danh sách nhân viên: " + response.status);
                const data = await response.json();
                if (!Array.isArray(data)) throw new Error("Danh sách nhân viên không hợp lệ");
                usersData = data;

                // Cập nhật danh sách nhân viên cho modal thêm nghỉ phép
                const select = document.getElementById("addIdNhanVien");
                select.innerHTML = '<option value="">Chọn nhân viên</option>';
                data.forEach(nv => {
                    const option = document.createElement("option");
                    option.value = nv.id_nhan_vien;
                    option.textContent = `${nv.ho_ten} (ID: ${nv.id_nhan_vien})`;
                    select.appendChild(option);
                });
            } catch (error) {
                console.error("Lỗi khi tải danh sách nhân viên:", error);
                alert("Lỗi khi tải danh sách nhân viên: " + error.message);
            } finally {
                hideLoading();
            }
        }

        // Hàm tính số ngày nghỉ trong tháng, trừ Chủ Nhật
        function calculateLeaveDays(records, month, year) {
            const leaveDaysByEmployee = {};

            records.forEach(record => {
                const startDate = new Date(record.ngay_bat_dau.split('-').reverse().join('-'));
                const endDate = new Date(record.ngay_ket_thuc.split('-').reverse().join('-'));
                const employeeId = record.id_nhan_vien;

                // Chỉ tính các ngày trong tháng và năm được chọn
                const monthStart = new Date(year, month - 1, 1);
                const monthEnd = new Date(year, month, 0);

                let currentDate = new Date(Math.max(startDate, monthStart));
                const end = new Date(Math.min(endDate, monthEnd));

                let days = 0;
                while (currentDate <= end) {
                    // Bỏ qua Chủ Nhật
                    if (currentDate.getDay() !== 0) {
                        days++;
                    }
                    currentDate.setDate(currentDate.getDate() + 1);
                }

                if (!leaveDaysByEmployee[employeeId]) {
                    leaveDaysByEmployee[employeeId] = {
                        totalDays: 0,
                        details: []
                    };
                }
                leaveDaysByEmployee[employeeId].totalDays += days;
                if (days > 0) {
                    leaveDaysByEmployee[employeeId].details.push({
                        startDate: startDate,
                        endDate: endDate,
                        days: days,
                        reason: record.ly_do,
                        type: record.loai_nghi
                    });
                }
            });

            return leaveDaysByEmployee;
        }

        async function loadNghiPhepData() {
            showLoading();
            try {
                const response = await fetch('http://localhost/doanqlns/index.php/api/nghiphep');
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const responseText = await response.text();
                
                let result;
                try {
                    result = JSON.parse(responseText);
                } catch (e) {
                    console.error("Invalid JSON response:", responseText);
                    throw new Error("Phản hồi từ server không hợp lệ");
                }

                if (!result.success) {
                    throw new Error(result.message || "Không thể tải dữ liệu");
                }

                nghiPhepData = result.data;
                
                // Lọc và hiển thị dữ liệu
                const filteredData = filterData();
                displayNghiPhepData(filteredData);
                
            } catch (error) {
                console.error("Lỗi khi tải dữ liệu:", error);
                document.getElementById('nghiPhepTableBody').innerHTML = `
                    <tr>
                        <td colspan="10" class="text-center text-danger">
                            <i class="fas fa-exclamation-triangle"></i> 
                            Lỗi khi tải dữ liệu: ${error.message}
                        </td>
                    </tr>`;
            } finally {
                hideLoading();
            }
        }

        // Hàm khởi tạo giá trị ban đầu và kiểm tra thay đổi ngày
        function initializeDateFilter() {
            const currentDate = new Date();
            const yearInput = document.getElementById('selectYear');
            const monthInput = document.getElementById('selectMonth');

            // Đặt giá trị mặc định cho năm và tháng
            yearInput.value = currentDate.getFullYear();
            monthInput.value = currentDate.getMonth() + 1;

            // Thêm sự kiện lắng nghe cho việc thay đổi tháng/năm
            yearInput.addEventListener('change', loadNghiPhepData);
            monthInput.addEventListener('change', loadNghiPhepData);

            // Tải dữ liệu ban đầu
            loadNghiPhepData();
        }

        // Hiển thị bảng nghỉ phép
        function renderNghiPhepTable(data, month, year) {
            nghiPhepTableBody.innerHTML = "";
            if (data && Array.isArray(data) && data.length > 0) {
                // Tính số ngày nghỉ của từng nhân viên trong tháng
                const leaveDaysByEmployee = calculateLeaveDays(data, month, year);

                data.forEach(record => {
                    const row = document.createElement("tr");
                    let statusClass = "";
                    let displayStatus = record.trang_thai1;
                    switch (record.trang_thai1.toLowerCase()) {
                        case "đã duyệt":
                            statusClass = "daduyet";
                            displayStatus = "Duyệt";
                            break;
                        case "từ chối":
                            statusClass = "tuchoi";
                            break;
                        case "chờ xét duyệt":
                            statusClass = "choxetduyet";
                            displayStatus = "Chờ duyệt";
                            break;
                        default:
                            statusClass = "choxetduyet";
                            displayStatus = "Chờ duyệt";
                            break;
                    }

                    // Kiểm tra số ngày nghỉ của nhân viên
                    const totalLeaveDays = leaveDaysByEmployee[record.id_nhan_vien] || 0;
                    const redStar = totalLeaveDays > 2 ? '<span class="red-star">★</span>' : '';

                   // Trong hàm renderNghiPhepTable
row.innerHTML = `
    <td>${record.id_nghi_phep}</td>
    <td>${redStar}<a href="#" class="name-link" data-id="${record.id_nhan_vien}" data-nghiphep-id="${record.id_nghi_phep}">${record.ho_ten}</a></td>
    <td>${record.ngay_bat_dau}</td>
    <td>${record.ngay_ket_thuc}</td>
    <td>${record.ly_do}</td>
    <td>${record.loai_nghi || 'Không có'}</td>
    <td>${record.ly_do_tu_choi || '-'}</td>
    <td><span class="status ${statusClass}">${displayStatus}</span></td>
    <td>
        ${userPermissions.quyen_sua && record.trang_thai1.toLowerCase() !== 'từ chối' ? `
            <button class="btn-edit" onclick="editNghiPhep(${record.id_nghi_phep}, ${record.id_nhan_vien}, '${record.ngay_bat_dau}', '${record.ngay_ket_thuc}', '${record.trang_thai1}')" title="Chỉnh sửa trạng thái">
                <i class="fas fa-edit"></i>
            </button>
        ` : ''}
        ${userPermissions.quyen_xoa ? `
            <button class="btn-delete" onclick="deleteNghiPhep(${record.id_nghi_phep})" title="Xóa đơn nghỉ phép">
                <i class="fas fa-trash-alt"></i>
            </button>
        ` : ''}
    </td>
`;
                    nghiPhepTableBody.appendChild(row);
                });
                document.querySelectorAll('.name-link').forEach(link => {
                    link.addEventListener('click', function(e) {
                        e.preventDefault();
                        const userId = this.getAttribute('data-id');
                        const nghiPhepId = this.getAttribute('data-nghiphep-id');
                        showDetailNghiPhep(userId, nghiPhepId);
                    });
                });
            } else {
                nghiPhepTableBody.innerHTML = '<tr><td colspan="9">Không có nhân viên nào nghỉ!</td></tr>';
            }
        }   

        // Hiển thị modal chi tiết đơn nghỉ phép
      // Hàm tính số ngày phép năm đã sử dụng trong năm
async function calculateUsedAnnualLeaveDays(userId, year) {
    try {
        const response = await fetch("http://localhost/doanqlns/index.php/api/nghiphep");
        if (!response.ok) throw new Error("Lỗi khi tải dữ liệu nghỉ phép: " + response.status);
        const data = await response.json();
        if (!Array.isArray(data)) throw new Error("Dữ liệu không hợp lệ");

        // Lọc các đơn nghỉ phép loại "Phép Năm" và trạng thái "Đã duyệt" trong năm
        const annualLeaveRecords = data.filter(record => 
            record.id_nhan_vien == userId &&
            record.loai_nghi === 'Phép Năm' &&
            record.trang_thai1.toLowerCase() === 'đã duyệt' &&
            new Date(record.ngay_bat_dau).getFullYear() === year
        );

        let totalDays = 0;
        annualLeaveRecords.forEach(record => {
            const startDate = new Date(record.ngay_bat_dau);
            const endDate = new Date(record.ngay_ket_thuc);
            let currentDate = new Date(startDate);
            while (currentDate <= endDate) {
                if (currentDate.getDay() !== 0) { // Bỏ qua Chủ Nhật
                    totalDays++;
                }
                currentDate.setDate(currentDate.getDate() + 1);
            }
        });

        // Mỗi nhân viên có tối đa 12 ngày phép năm
        const maxAnnualLeaveDays = 12;
        return maxAnnualLeaveDays - totalDays;
    } catch (error) {
        console.error("Lỗi khi tính số ngày phép năm:", error);
        return 12; // Giá trị mặc định nếu có lỗi
    }
}

// Hiển thị modal chi tiết đơn nghỉ phép
async function showDetailNghiPhep(userId, nghiPhepId) {
    showLoading();
    try {
        // Tìm bản ghi nghỉ phép
        const nghiPhepRecord = nghiPhepData.find(record => record.id_nghi_phep == nghiPhepId);
        if (!nghiPhepRecord) {
            throw new Error("Không tìm thấy đơn nghỉ phép");
        }

        // Tìm thông tin nhân viên
        let user = usersData.find(u => u.id_nhan_vien == userId);
        if (!user) {
            const response = await fetch(`http://localhost/doanqlns/index.php/api/users?id=${userId}`);
            if (!response.ok) throw new Error("Lỗi khi tải thông tin nhân viên: " + response.status);
            const data = await response.json();
            user = Array.isArray(data) ? data[0] : data;
            if (!user) throw new Error("Không tìm thấy thông tin nhân viên");
        }

        // Lấy năm hiện tại để tính số ngày phép năm
        const year = parseInt(document.getElementById('selectYear').value) || new Date().getFullYear();

        // Tính tổng số ngày nghỉ trong tháng
        const month = parseInt(document.getElementById('selectMonth').value);
        const leaveDaysByEmployee = calculateLeaveDays(nghiPhepData, month, year);
        const employeeLeaveInfo = leaveDaysByEmployee[userId] || { totalDays: 0, details: [] };

        // Tạo chi tiết ngày nghỉ
        let leaveDetailsHtml = '';
        if (employeeLeaveInfo.details.length > 0) {
            leaveDetailsHtml = '<ul style="margin: 5px 0; padding-left: 20px;">';
            employeeLeaveInfo.details.forEach(detail => {
                const startDateStr = detail.startDate.toLocaleDateString('vi-VN');
                const endDateStr = detail.endDate.toLocaleDateString('vi-VN');
                leaveDetailsHtml += `
                    <li style="margin-bottom: 5px;">
                        ${startDateStr} đến ${endDateStr} (${detail.days} ngày)
                        <br>
                        <small>Loại nghỉ: ${detail.type} - Lý do: ${detail.reason}</small>
                    </li>`;
            });
            leaveDetailsHtml += '</ul>';
        }

        // Hiển thị cảnh báo nếu vượt quá 2 ngày
        const warningStyle = employeeLeaveInfo.totalDays > 2 ? 
            'color: red; font-weight: bold;' : '';
        const warningIcon = employeeLeaveInfo.totalDays > 2 ? 
            '<span style="color: red; margin-left: 5px;">⚠️ Vượt quá 2 ngày cho phép</span>' : '';

        // Tính số ngày phép năm còn lại
        const remainingAnnualLeaveDays = await calculateUsedAnnualLeaveDays(userId, year);

        // Điền thông tin nhân viên
        document.getElementById('detailHoTen').textContent = user.ho_ten || 'Không có dữ liệu';
        document.getElementById('detailGioiTinh').textContent = user.gioi_tinh || 'Không có dữ liệu';
        document.getElementById('detailNgaySinh').textContent = user.ngay_sinh || 'Không có dữ liệu';
        document.getElementById('detailEmail').textContent = user.email || 'Không có dữ liệu';
        document.getElementById('detailSoDienThoai').textContent = user.so_dien_thoai || 'Không có dữ liệu';
        document.getElementById('detailDiaChi').textContent = user.dia_chi || 'Không có dữ liệu';
        document.getElementById('detailPhongBan').textContent = user.ten_phong_ban || 'Không có dữ liệu';
        document.getElementById('detailChucVu').textContent = user.ten_chuc_vu || 'Không có dữ liệu';

        // Điền thông tin đơn nghỉ phép
        document.getElementById('detailNgayBatDau').textContent = nghiPhepRecord.ngay_bat_dau || 'Không có dữ liệu';
        document.getElementById('detailNgayKetThuc').textContent = nghiPhepRecord.ngay_ket_thuc || 'Không có dữ liệu';
        document.getElementById('detailLyDo').textContent = nghiPhepRecord.ly_do || 'Không có dữ liệu';
        document.getElementById('detailLoaiNghi').textContent = nghiPhepRecord.loai_nghi || 'Không có dữ liệu';
        document.getElementById('detailLyDoTuChoi').textContent = nghiPhepRecord.ly_do_tu_choi || 'Không có';
        document.getElementById('detailTrangThai').textContent = 
            nghiPhepRecord.trang_thai1.toLowerCase() === 'đã duyệt' ? 'Duyệt' :
            nghiPhepRecord.trang_thai1.toLowerCase() === 'chờ xét duyệt' ? 'Chờ duyệt' :
            nghiPhepRecord.trang_thai1;

        // Điền tổng số ngày nghỉ trong tháng với chi tiết và cảnh báo
        document.getElementById('detailTongNgayNghi').innerHTML = `
            <span style="${warningStyle}">${employeeLeaveInfo.totalDays} ngày</span>
            ${warningIcon}
            ${leaveDetailsHtml}`;

        // Điền số ngày phép năm còn lại
        document.getElementById('detailSoNgayPhepNamConLai').textContent = `${remainingAnnualLeaveDays} ngày`;

        detailNghiPhepModal.style.display = 'flex';
    } catch (error) {
        console.error("Lỗi khi hiển thị chi tiết đơn nghỉ phép:", error);
        alert("Lỗi khi hiển thị chi tiết đơn nghỉ phép: " + error.message);
    } finally {
        hideLoading();
    }
}

        // Đóng modal chi tiết
        function closeDetailModal() {
            detailNghiPhepModal.style.display = 'none';
        }

        // Hiển thị modal sửa trạng thái
       // Hiển thị modal chỉnh trạng thái
function editNghiPhep(id, idNhanVien, ngayBatDau, ngayKetThuc, trangThai) {
    if (!userPermissions.quyen_sua) {
        alert("Bạn không có quyền chỉnh sửa trạng thái đơn nghỉ phép!");
        return;
    }
    // Kiểm tra nếu trạng thái là "Từ chối"
    if (trangThai.toLowerCase() === 'từ chối') {
        alert("Không thể chỉnh sửa đơn nghỉ phép đã bị từ chối!");
        return;
    }
    document.getElementById('editIdNghiPhep').value = id;
    document.getElementById('editIdNhanVien').value = idNhanVien;
    document.getElementById('editNgayBatDau').value = ngayBatDau;
    document.getElementById('editNgayKetThuc').value = ngayKetThuc;
    const displayStatus = trangThai.toLowerCase() === 'đã duyệt' ? 'Duyệt' : 
                         (trangThai.toLowerCase() === 'chờ xét duyệt' ? 'Chờ duyệt' : trangThai);
    document.getElementById('editStatus').value = displayStatus;
    toggleReasonInput();
    editNghiPhepModal.style.display = 'flex';
}

        // Đóng modal sửa trạng thái
        function closeEditModal() {
            editNghiPhepModal.style.display = 'none';
        }

        // Hiển thị modal thêm nghỉ phép
        function showAddNghiPhepModal() {
            if (!userPermissions.quyen_sua) {
                alert("Bạn không có quyền thêm đơn nghỉ phép!");
                return;
            }
            document.getElementById('addIdNhanVien').value = '';
            document.getElementById('addNgayBatDau').value = '';
            document.getElementById('addNgayKetThuc').value = '';
            document.getElementById('addLyDo').value = '';
            document.getElementById('addLoaiNghi').value = 'Có phép';
            addNghiPhepModal.style.display = 'flex';
        }

        // Đóng modal thêm nghỉ phép
        function closeAddNghiPhepModal() {
            addNghiPhepModal.style.display = 'none';
        }

        // Lưu đơn nghỉ phép mới
       // Lưu đơn nghỉ phép mới
async function saveNewNghiPhep() {
    if (!userPermissions.quyen_sua) {
        alert("Bạn không có quyền thêm đơn nghỉ phép!");
        return;
    }

    const idNhanVien = document.getElementById('addIdNhanVien').value;
    const ngayBatDau = document.getElementById('addNgayBatDau').value;
    const ngayKetThuc = document.getElementById('addNgayKetThuc').value;
    const lyDo = document.getElementById('addLyDo').value.trim();
    const loaiNghi = document.getElementById('addLoaiNghi').value;

    // Validate
    if (!idNhanVien || !ngayBatDau || !ngayKetThuc || !lyDo) {
        alert("Vui lòng điền đầy đủ thông tin!");
        return;
    }
    if (new Date(ngayKetThuc) < new Date(ngayBatDau)) {
        alert("Ngày kết thúc phải lớn hơn hoặc bằng ngày bắt đầu!");
        return;
    }

    // Kiểm tra số ngày phép năm còn lại nếu loại nghỉ là "Phép Năm"
    if (loaiNghi === 'Phép Năm') {
        const year = new Date(ngayBatDau).getFullYear();
        const remainingDays = await calculateUsedAnnualLeaveDays(idNhanVien, year);
        
        // Tính số ngày nghỉ của đơn hiện tại (loại bỏ Chủ Nhật)
        let leaveDays = 0;
        let currentDate = new Date(ngayBatDau);
        const endDate = new Date(ngayKetThuc);
        while (currentDate <= endDate) {
            if (currentDate.getDay() !== 0) {
                leaveDays++;
            }
            currentDate.setDate(currentDate.getDate() + 1);
        }

        if (remainingDays < leaveDays) {
            const user = usersData.find(u => u.id_nhan_vien == idNhanVien);
            const hoTen = user ? user.ho_ten : 'Nhân viên';
            alert(`${hoTen} đã nghỉ hết phép năm!`);
            return;
        }
    }

    const payload = {
        id_nhan_vien: parseInt(idNhanVien),
        ngay_bat_dau: ngayBatDau,
        ngay_ket_thuc: ngayKetThuc,
        ly_do: lyDo,
        loai_nghi: loaiNghi,
        trang_thai1: "Chờ xét duyệt",
        ly_do_tu_choi: null
    };

    showLoading();
    try {
        const response = await fetch("http://localhost/doanqlns/index.php/api/nghiphep", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        const responseText = await response.text();
        console.log('POST Response:', responseText);

        if (!response.ok) {
            throw new Error(`Lỗi HTTP: ${response.status} ${response.statusText}`);
        }

        let result;
        try {
            result = JSON.parse(responseText);
        } catch (e) {
            throw new Error("Phản hồi không phải JSON hợp lệ: " + responseText);
        }

        if (result.success) {
            await loadNghiPhepData();
            closeAddNghiPhepModal();
            alert("Thêm đơn nghỉ phép thành công!");
        } else {
            throw new Error(result.message || "Lỗi khi thêm đơn nghỉ phép");
        }
    } catch (error) {
        console.error("Lỗi khi thêm đơn nghỉ phép:", error);
        alert("Lỗi khi thêm đơn nghỉ phép: " + error.message);
    } finally {
        hideLoading();
    }
}

        // Toggle hiển thị ô lý do từ chối
        function toggleReasonInput() {
            const status = editStatus.value;
            const reasonInputDiv = document.getElementById('reasonInput');
            if (status === 'Từ chối') {
                reasonInputDiv.classList.add('active');
            } else {
                reasonInputDiv.classList.remove('active');
            }
        }

        // Lưu trạng thái đơn nghỉ phép
        async function saveNghiPhepStatus() {
            if (!userPermissions.quyen_sua) {
                alert("Bạn không có quyền chỉnh sửa trạng thái đơn nghỉ phép!");
                return;
            }

            const idNghiPhep = document.getElementById('editIdNghiPhep').value;
            const idNhanVien = document.getElementById('editIdNhanVien').value;
            const ngayBatDau = document.getElementById('editNgayBatDau').value;
            const ngayKetThuc = document.getElementById('editNgayKetThuc').value;
            let trangThai = document.getElementById('editStatus').value;
            const reason = document.getElementById('reason').value;

            if (trangThai === 'Từ chối' && !reason.trim()) {
                alert("Vui lòng nhập lý do từ chối!");
                return;
            }

            const trangThaiForBackend = trangThai === 'Duyệt' ? 'Đã duyệt' : 
                                       (trangThai === 'Chờ duyệt' ? 'Chờ xét duyệt' : trangThai);

            showLoading();
            try {
                if (!userId) {
                    throw new Error("Không tìm thấy ID người dùng trong session");
                }

                const payload = {
                    trang_thai1: trangThaiForBackend,
                    id_nguoi_duyet: (trangThai === 'Duyệt' || trangThai === 'Từ chối') ? userId : null,
                    ly_do_tu_choi: trangThai === 'Từ chối' ? reason : null
                };
                console.log('PUT Payload:', payload);

                const response = await fetch(`http://localhost/doanqlns/index.php/api/nghiphep?id=${idNghiPhep}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(payload)
                });

                const responseText = await response.text();
                console.log('Response Text:', responseText);

                if (!response.ok) {
                    throw new Error(`Lỗi HTTP: ${response.status} ${response.statusText}`);
                }

                let result;
                try {
                    result = JSON.parse(responseText);
                } catch (e) {
                    throw new Error("Phản hồi không phải JSON hợp lệ: " + responseText);
                }

                if (result.success) {
                    await updateChamCong(idNhanVien, ngayBatDau, ngayKetThuc, trangThai);
                    await loadNghiPhepData();
                    closeEditModal();
                    alert(trangThai === 'Duyệt' ? 
                        "Cập nhật trạng thái thành công! Email thông báo đã được gửi." : 
                        "Cập nhật trạng thái thành công!");
                } else {
                    throw new Error(result.message || "Lỗi khi cập nhật trạng thái");
                }
            } catch (error) {
                console.error("Lỗi khi cập nhật trạng thái:", error);
                alert("Lỗi khi cập nhật trạng thái: " + error.message);
            } finally {
                hideLoading();
            }
        }

        // Cập nhật bảng chấm công
        async function updateChamCong(idNhanVien, ngayBatDau, ngayKetThuc, trangThai) {
    const startDate = new Date(ngayBatDau);
    const endDate = new Date(ngayKetThuc);
    const dates = [];

    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
        const dateStr = `${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, '0')}-${d.getDate().toString().padStart(2, '0')}`;
        const isSunday = d.getDay() === 0;
        if (!isSunday) {
            dates.push(dateStr);
        }
    }

    let chamCongStatus;
    switch (trangThai.toLowerCase()) {
        case "duyệt":
            chamCongStatus = "Có phép";
            break;
        case "từ chối":
            chamCongStatus = "Không phép";
            break;
        case "chờ duyệt":
            chamCongStatus = "Chưa điểm danh";
            break;
        default:
            chamCongStatus = "Chưa điểm danh";
            break;
    }

    // Thêm logic để xử lý loai_nghi
    const nghiPhepRecord = nghiPhepData.find(record => record.id_nhan_vien == idNhanVien && record.ngay_bat_dau == ngayBatDau && record.ngay_ket_thuc == ngayKetThuc);
    if (nghiPhepRecord && trangThai.toLowerCase() === "duyệt") {
        chamCongStatus = nghiPhepRecord.loai_nghi; // Lấy trạng thái từ loai_nghi (Có phép, Không phép, Phép Năm)
    }

    for (const date of dates) {
        const data = {
            id_nhan_vien: idNhanVien,
            ngay_lam_viec: date,
            gio_vao: chamCongStatus === 'Có phép' || chamCongStatus === 'Không phép' || chamCongStatus === 'Phép Năm' ? null : '00:00:00',
            gio_ra: chamCongStatus === 'Có phép' || chamCongStatus === 'Không phép' || chamCongStatus === 'Phép Năm' ? null : '00:00:00',
            trang_thai: chamCongStatus,
            ghi_chu: '',
            month: parseInt(date.split('-')[1]),
            year: parseInt(date.split('-')[0])
        };

        try {
            const response = await fetch("http://localhost/doanqlns/index.php/api/chamcong", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            console.log(`POST ChamCong Response for ${date}:`, result);
            if (!result.success) {
                throw new Error(result.message || `Lỗi khi cập nhật chấm công cho ngày ${date}`);
            }
        } catch (error) {
            console.error(`Lỗi khi cập nhật chấm công cho ngày ${date}:`, error);
            alert(`Lỗi khi cập nhật chấm công cho ngày ${date}: ${error.message}`);
        }
    }
}

        // Xóa đơn nghỉ phép
        async function deleteNghiPhep(id) {
            if (!userPermissions.quyen_xoa) {
                alert("Bạn không có quyền xóa đơn nghỉ phép!");
                return;
            }
            if (!confirm(`Bạn có chắc chắn muốn xóa đơn nghỉ phép ID ${id} không?`)) return;

            showLoading();
            try {
                const response = await fetch(`http://localhost/doanqlns/index.php/api/nghiphep?id=${id}`, {
                    method: 'DELETE'
                });
                const result = await response.json();

                if (result.success) {
                    await loadNghiPhepData();
                    alert(`Đã xóa đơn nghỉ phép với ID: ${id}`);
                } else {
                    throw new Error(result.message || "Lỗi khi xóa đơn nghỉ phép");
                }
            } catch (error) {
                console.error("Lỗi khi xóa đơn nghỉ phép:", error);
                alert("Lỗi khi xóa đơn nghỉ phép: " + error.message);
            } finally {
                hideLoading();
            }
        }

        // Sự kiện đóng modal
        detailNghiPhepModal.addEventListener('click', (e) => {
            if (e.target === detailNghiPhepModal) {
                closeDetailModal();
            }
        });

        editNghiPhepModal.addEventListener('click', (e) => {
            if (e.target === editNghiPhepModal) {
                closeEditModal();
            }
        });

        addNghiPhepModal.addEventListener('click', (e) => {
            if (e.target === addNghiPhepModal) {
                closeAddNghiPhepModal();
            }
        });

        function startInitialization() {
            if (document.readyState === 'complete' || document.readyState === 'interactive') {
                initializeDateFilter();
            } else {
                document.addEventListener('DOMContentLoaded', initializeDateFilter);
                // Fallback: nếu sau 2 giây mà không chạy, buộc chạy
                setTimeout(() => {
                    if (!document.getElementById('selectDay').value) {
                        console.log("Fallback: Forcing initialization...");
                        initializeDateFilter();
                    }
                }, 2000);
            }
        }

        startInitialization();

        // Khởi tạo khi trang được tải
        document.addEventListener('DOMContentLoaded', () => {
            const currentDate = new Date();
            document.getElementById('selectMonth').value = currentDate.getMonth() + 1;
            document.getElementById('selectYear').value = currentDate.getFullYear();
            loadUsersData();
            loadNghiPhepData();

            // Sự kiện thay đổi tháng/năm
            document.getElementById('selectMonth').addEventListener('change', loadNghiPhepData);
            document.getElementById('selectYear').addEventListener('input', loadNghiPhepData);
        });

        function filterData() {
            const month = parseInt(document.getElementById('selectMonth').value);
            const year = parseInt(document.getElementById('selectYear').value) || new Date().getFullYear();
            
            return nghiPhepData.filter(record => {
                // Chuyển đổi chuỗi ngày thành đối tượng Date
                const startParts = record.ngay_bat_dau.split('-');
                const endParts = record.ngay_ket_thuc.split('-');
                
                // Tạo đối tượng Date (đảm bảo đúng định dạng DD-MM-YYYY)
                const startDate = new Date(startParts[2], startParts[1] - 1, startParts[0]);
                const endDate = new Date(endParts[2], endParts[1] - 1, endParts[0]);
                
                // Tạo ngày đầu và cuối của tháng được chọn
                const firstDayOfMonth = new Date(year, month - 1, 1);
                const lastDayOfMonth = new Date(year, month, 0);

                // Kiểm tra xem khoảng thời gian nghỉ có giao với tháng được chọn không
                const hasOverlap = (
                    // Trường hợp 1: Ngày bắt đầu nằm trong tháng
                    (startDate >= firstDayOfMonth && startDate <= lastDayOfMonth) ||
                    // Trường hợp 2: Ngày kết thúc nằm trong tháng
                    (endDate >= firstDayOfMonth && endDate <= lastDayOfMonth) ||
                    // Trường hợp 3: Khoảng thời gian bao trùm cả tháng
                    (startDate <= firstDayOfMonth && endDate >= lastDayOfMonth)
                );

                return hasOverlap;
            });
        }

        function displayNghiPhepData(data) {
            const tbody = document.getElementById('nghiPhepTableBody');
            if (!Array.isArray(data) || data.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="9" class="text-center">
                            <i class="fas fa-info-circle"></i> 
                            Không có dữ liệu nghỉ phép trong thời gian này
                        </td>
                    </tr>`;
                return;
            }

            // Tính số ngày nghỉ cho mỗi nhân viên
            const month = parseInt(document.getElementById('selectMonth').value);
            const year = parseInt(document.getElementById('selectYear').value);
            const leaveDaysByEmployee = calculateLeaveDays(data, month, year);

            tbody.innerHTML = data.map((record) => {
                const trangThai = record.trang_thai1 || 'Chờ xét duyệt';
                const statusClass = {
                    'Đã duyệt': 'status daduyet',
                    'Từ chối': 'status tuchoi',
                    'Chờ xét duyệt': 'status choxetduyet'
                }[trangThai] || 'status choxetduyet';

                const displayStatus = trangThai === 'Đã duyệt' ? 'Duyệt' : 
                                    trangThai === 'Chờ xét duyệt' ? 'Chờ duyệt' : 
                                    trangThai;

                // Thêm ngôi sao đỏ nếu nhân viên nghỉ quá 2 ngày
                const employeeLeaveInfo = leaveDaysByEmployee[record.id_nhan_vien] || { totalDays: 0 };
                const redStar = employeeLeaveInfo.totalDays > 2 ? '<span style="color: red; margin-right: 5px;">★</span>' : '';

                return `
                    <tr>
                        <td>${record.id_nghi_phep}</td>
                        <td>
                            ${redStar}<a href="#" class="name-link" onclick="showDetailNghiPhep('${record.id_nhan_vien}', '${record.id_nghi_phep}')">
                                ${record.ho_ten}
                            </a>
                        </td>
                        <td>${record.ngay_bat_dau}</td>
                        <td>${record.ngay_ket_thuc}</td>
                        <td>${record.ly_do || 'N/A'}</td>
                        <td>${record.loai_nghi || 'N/A'}</td>
                        <td>${record.ly_do_tu_choi || '-'}</td>
                        <td>
                            <span class="${statusClass}">${displayStatus}</span>
                        </td>
                        <td>
                            ${userPermissions.quyen_sua && trangThai !== 'Từ chối' ? `
                                <button class="btn-edit" onclick="editNghiPhep('${record.id_nghi_phep}', '${record.id_nhan_vien}', '${record.ngay_bat_dau}', '${record.ngay_ket_thuc}', '${trangThai}')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            ` : ''}
                            ${userPermissions.quyen_xoa ? `
                                <button class="btn-delete" onclick="deleteNghiPhep('${record.id_nghi_phep}')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            ` : ''}
                        </td>
                    </tr>`;
            }).join('');
        }
    </script>
    <?php include(__DIR__ . '/../includes/footer.php'); ?>
</body>
</html>