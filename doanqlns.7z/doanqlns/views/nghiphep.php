<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Bảng Nghỉ Phép</title>

    <!-- Font Awesome & Google Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- CSS chính -->
    <link rel="stylesheet" href="../css/style.css">

    <!-- CSS riêng -->
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 0;
        }
        .main-content {
            margin-left: 240px;
            padding: 20px;
            overflow-x: auto;
        }
        h3 {
            font-size: 26px;
            margin-bottom: 20px;
            color: #333;
            text-align: center;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            max-width: 1200px;
            margin: 0 auto 20px;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 14px 16px;
            border-bottom: 1px solid #ddd;
            text-align: left;
            word-wrap: break-word;
        }
        th {
            background: #007bff;
            color: #fff;
            font-weight: 500;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        tr:hover {
            background: #eef3f7;
        }
        .status {
            padding: 4px 8px;
            border-radius: 5px;
            font-size: 0.85rem;
            font-weight: 500;
            display: inline-block;
        }
        .status.daduyet {
            background: #28a745;
            color: #fff;
        }
        .status.tuchoi {
            background: #dc3545;
            color: #fff;
        }
        .status.choxetduyet {
            background: #ffc107;
            color: #333;
        }
        .btn-edit, .btn-delete {
            border: none;
            background: none;
            cursor: pointer;
            margin: 0 5px;
            font-size: 1rem;
        }
        .btn-edit {
            color: #007bff;
        }
        .btn-delete {
            color: #dc3545;
        }
        .btn-edit:hover, .btn-delete:hover {
            opacity: 0.8;
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            width: 400px;
            max-width: 90%;
            position: relative;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .modal-title {
            font-size: 1.25rem;
            font-weight: 500;
            color: #333;
        }
        .modal-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #666;
        }
        .modal-body {
            margin-bottom: 20px;
        }
        .modal-body label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
        }
        .modal-body select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }
        .modal-footer {
            text-align: right;
        }
        .btn-save {
            background: #007bff;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-save:hover {
            background: #0056b3;
        }
        @media (max-width: 768px) {
            table {
                width: 100%;
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }
            th, td {
                padding: 10px;
            }
            h3 {
                font-size: 22px;
            }
        }
    </style>
</head>

<body>

<?php include('../includes/sidebar.php'); ?>

<div class="main-content">
    <h3>Bảng Nghỉ Phép</h3>
    <table>
        <thead>
            <tr>
                <th>ID Nghỉ Phép</th>
                <th>Nhân Viên</th>
                <th>Ngày Bắt Đầu</th>
                <th>Ngày Kết Thúc</th>
                <th>Loại Nghỉ</th>
                <th>Lý Do</th>
                <th>Trạng Thái</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody id="nghiPhepTableBody">
            <tr><td colspan="8">Đang tải dữ liệu...</td></tr>
        </tbody>
    </table>

    <!-- Modal Sửa Trạng Thái -->
    <div id="editNghiPhepModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Sửa Trạng Thái Đơn Nghỉ Phép</h2>
                <button class="modal-close" onclick="closeEditModal()">×</button>
            </div>
            <div class="modal-body">
                <label for="editStatus">Trạng Thái:</label>
                <select id="editStatus">
                    <option value="Chờ xét duyệt">Chờ xét duyệt</option>
                    <option value="Từ chối">Từ chối</option>
                    <option value="Đã duyệt">Đã duyệt</option>
                </select>
                <input type="hidden" id="editIdNghiPhep">
                <input type="hidden" id="editIdNhanVien">
                <input type="hidden" id="editNgayBatDau">
                <input type="hidden" id="editNgayKetThuc">
            </div>
            <div class="modal-footer">
                <button class="btn-save" onclick="saveNghiPhepStatus()">Lưu</button>
            </div>
        </div>
    </div>
</div>

<script>
// Dữ liệu nghỉ phép
let nghiPhepData = [];

// Tải dữ liệu nghỉ phép
async function loadNghiPhepData() {
    try {
        const response = await fetch("http://localhost/doanqlns/index.php/api/nghiphep");
        if (!response.ok) throw new Error("Lỗi khi tải dữ liệu: " + response.status);
        const data = await response.json();
        if (!Array.isArray(data)) throw new Error("Dữ liệu không hợp lệ");
        
        nghiPhepData = data;
        renderNghiPhepTable(data);
    } catch (error) {
        console.error("Lỗi khi tải dữ liệu:", error);
        document.getElementById("nghiPhepTableBody").innerHTML = '<tr><td colspan="8">Lỗi khi tải dữ liệu</td></tr>';
    }
}

// Hiển thị bảng nghỉ phép
function renderNghiPhepTable(data) {
    const tableBody = document.getElementById("nghiPhepTableBody");
    tableBody.innerHTML = "";

    if (data && Array.isArray(data) && data.length > 0) {
        data.forEach(record => {
            const row = document.createElement("tr");
            let statusClass = "";
            switch (record.trang_thai.toLowerCase()) {
                case "đã duyệt":
                    statusClass = "daduyet";
                    break;
                case "từ chối":
                    statusClass = "tuchoi";
                    break;
                default:
                    statusClass = "choxetduyet";
                    break;
            }
            row.innerHTML = `
                <td>${record.id_nghi_phep}</td>
                <td>${record.ho_ten}</td>
                <td>${record.ngay_bat_dau}</td>
                <td>${record.ngay_ket_thuc}</td>
                <td>${record.loai_nghi}</td>
                <td>${record.ly_do}</td>
                <td><span class="status ${statusClass}">${record.trang_thai1}</span></td>
                <td>
                    <button class="btn-edit" onclick="editNghiPhep(${record.id_nghi_phep}, ${record.id_nhan_vien}, '${record.ngay_bat_dau}', '${record.ngay_ket_thuc}', '${record.trang_thai}')"><i class="fas fa-edit"></i></button>
                    <button class="btn-delete" onclick="deleteNghiPhep(${record.id_nghi_phep})"><i class="fas fa-trash-alt"></i></button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    } else {
        tableBody.innerHTML = '<tr><td colspan="8">Không có dữ liệu</td></tr>';
    }
}

// Hiển thị modal sửa trạng thái
function editNghiPhep(id, idNhanVien, ngayBatDau, ngayKetThuc, trangThai) {
    document.getElementById('editIdNghiPhep').value = id;
    document.getElementById('editIdNhanVien').value = idNhanVien;
    document.getElementById('editNgayBatDau').value = ngayBatDau;
    document.getElementById('editNgayKetThuc').value = ngayKetThuc;
    document.getElementById('editStatus').value = trangThai;
    document.getElementById('editNghiPhepModal').style.display = 'flex';
}

// Đóng modal
function closeEditModal() {
    document.getElementById('editNghiPhepModal').style.display = 'none';
}

// Lưu trạng thái mới
async function saveNghiPhepStatus() {
    const idNghiPhep = document.getElementById('editIdNghiPhep').value;
    const idNhanVien = document.getElementById('editIdNhanVien').value;
    const ngayBatDau = document.getElementById('editNgayBatDau').value;
    const ngayKetThuc = document.getElementById('editNgayKetThuc').value;
    const trangThai = document.getElementById('editStatus').value;

    try {
        // Cập nhật trạng thái đơn nghỉ phép bằng phương thức PUT
        const response = await fetch(`http://localhost/doanqlns/index.php/api/nghiphep?id=${idNghiPhep}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                trang_thai: trangThai
            })
        });
        const result = await response.json();

        if (result.success) {
            // Cập nhật bảng chấm công
            await updateChamCong(idNhanVien, ngayBatDau, ngayKetThuc, trangThai);
            
            // Tải lại dữ liệu nghỉ phép
            await loadNghiPhepData();
            closeEditModal();
            alert("Cập nhật trạng thái thành công!");
        } else {
            throw new Error(result.message || "Lỗi khi cập nhật trạng thái");
        }
    } catch (error) {
        console.error("Lỗi khi cập nhật trạng thái:", error);
        alert("Lỗi khi cập nhật trạng thái: " + error.message);
    }
}

// Cập nhật bảng chấm công dựa trên trạng thái đơn nghỉ phép
async function updateChamCong(idNhanVien, ngayBatDau, ngayKetThuc, trangThai) {
    const startDate = new Date(ngayBatDau);
    const endDate = new Date(ngayKetThuc);
    const dates = [];

    // Tạo danh sách các ngày trong khoảng thời gian nghỉ phép
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
        const dateStr = `${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, '0')}-${d.getDate().toString().padStart(2, '0')}`;
        const isSunday = d.getDay() === 0;

        // Bỏ qua ngày Chủ nhật vì đã được tự động đặt là "Đúng giờ"
        if (!isSunday) {
            dates.push(dateStr);
        }
    }

    // Xác định trạng thái chấm công dựa trên trạng thái đơn nghỉ phép
    let chamCongStatus;
    switch (trangThai) {
        case "Đã duyệt":
            chamCongStatus = "Có phép";
            break;
        case "Từ chối":
            chamCongStatus = "Không phép";
            break;
        case "Chờ xét duyệt":
        default:
            chamCongStatus = "Chưa điểm danh";
            break;
    }

    // Cập nhật trạng thái chấm công cho từng ngày
    for (const date of dates) {
        const data = {
            id_nhan_vien: idNhanVien,
            ngay_lam_viec: date,
            gio_vao: '00:00:00',
            gio_ra: '00:00:00',
            trang_thai: chamCongStatus,
            month: parseInt(date.split('-')[1]),
            year: parseInt(date.split('-')[0])
        };

        try {
            await fetch("http://localhost/doanqlns/index.php/api/chamcong", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
        } catch (error) {
            console.error(`Lỗi khi cập nhật chấm công cho ngày ${date}:`, error);
        }
    }
}

// Hàm Xóa
async function deleteNghiPhep(id) {
    if (confirm("Bạn có chắc chắn muốn xóa đơn nghỉ phép ID " + id + " không?")) {
        try {
            const response = await fetch(`http://localhost/doanqlns/index.php/api/nghiphep?id=${id}`, {
                method: 'DELETE'
            });
            const result = await response.json();

            if (result.success) {
                await loadNghiPhepData();
                alert("Đã xóa đơn nghỉ phép với ID: " + id);
            } else {
                throw new Error(result.message || "Lỗi khi xóa đơn nghỉ phép");
            }
        } catch (error) {
            console.error("Lỗi khi xóa đơn nghỉ phép:", error);
            alert("Lỗi khi xóa đơn nghỉ phép: " + error.message);
        }
    }
}

// Đóng modal khi nhấp ra ngoài
document.getElementById('editNghiPhepModal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('editNghiPhepModal')) {
        closeEditModal();
    }
});

// Tải dữ liệu khi trang được tải
loadNghiPhepData();
</script>

</body>
</html>