<?php
// Enable error reporting for debugging (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/check_login.php';
include(__DIR__ . '/../includes/header.php');
include(__DIR__ . '/../includes/sidebar.php');

require_once __DIR__ . '/../config/Database.php';

// Initialize database connection
try {
    $database = new Database();
    $conn = $database->getConnection();
    if (!$conn) {
        throw new Exception("Không thể kết nối đến cơ sở dữ liệu.");
    }
} catch (Exception $e) {
    error_log("Database connection error: " . $e->getMessage());
    die("<div class='error-container'><div class='error-message'>Lỗi: " . $e->getMessage() . "</div></div>");
}

// Get month and year from request, default to current month
$month = isset($_GET['month']) ? (int)$_GET['month'] : date('m');
$year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
$month_year = sprintf("%04d-%02d", $year, $month);

// 1. KPI Data
try {
    // Total Employees
    $totalEmployeesStmt = $conn->prepare("SELECT COUNT(*) as total FROM nhan_vien WHERE trang_thai != 'Đã nghỉ việc'");
    $totalEmployeesStmt->execute();
    $totalEmployees = $totalEmployeesStmt->fetch(PDO::FETCH_ASSOC)['total'];

    // Employees Attended
    $attendedStmt = $conn->prepare("
        SELECT COUNT(DISTINCT id_nhan_vien) as attended
        FROM cham_cong
        WHERE DATE_FORMAT(ngay_lam_viec, '%Y-%m') = ? AND trang_thai IN ('Đúng giờ', 'Đi trễ')
    ");
    $attendedStmt->execute([$month_year]);
    $employeesAttended = $attendedStmt->fetch(PDO::FETCH_ASSOC)['attended'];

    // Employees Resigned
    $resignedStmt = $conn->prepare("
        SELECT COUNT(*) as resigned
        FROM nhan_vien
        WHERE DATE_FORMAT(ngay_nghi_viec, '%Y-%m') = ? AND ngay_nghi_viec IS NOT NULL
    ");
    $resignedStmt->execute([$month_year]);
    $employeesResigned = $resignedStmt->fetch(PDO::FETCH_ASSOC)['resigned'];
} catch (PDOException $e) {
    error_log("Error in KPI queries: " . $e->getMessage());
    $totalEmployees = $employeesAttended = $employeesResigned = 0;
}

// 2. Gender Distribution by Department (Multiple Pie Charts)
try {
    $genderByDeptStmt = $conn->prepare("
        SELECT p.id_phong_ban, p.ten_phong_ban, n.gioi_tinh, COUNT(n.id_nhan_vien) as so_nhan_vien
        FROM phong_ban p
        LEFT JOIN nhan_vien n ON p.id_phong_ban = n.id_phong_ban AND n.trang_thai != 'Đã nghỉ việc'
        WHERE p.trang_thai = 'Hoạt động'
        GROUP BY p.id_phong_ban, n.gioi_tinh
        ORDER BY p.id_phong_ban, n.gioi_tinh
    ");
    $genderByDeptStmt->execute();
    $genderByDept = $genderByDeptStmt->fetchAll(PDO::FETCH_ASSOC);

    // Organize data by department
    $deptData = [];
    foreach ($genderByDept as $row) {
        $deptId = $row['id_phong_ban'];
        if (!isset($deptData[$deptId])) {
            $deptData[$deptId] = [
                'ten_phong_ban' => $row['ten_phong_ban'],
                'labels' => [],
                'data' => [],
                'total' => 0
            ];
        }
        if ($row['gioi_tinh']) {
            $deptData[$deptId]['labels'][] = $row['gioi_tinh'];
            $deptData[$deptId]['data'][] = $row['so_nhan_vien'];
            $deptData[$deptId]['total'] += $row['so_nhan_vien'];
        }
    }
} catch (PDOException $e) {
    error_log("Error in genderByDept query: " . $e->getMessage());
    $deptData = [];
}

// 3. Absence Trend (Gauge Chart for Absence Rate)
try {
    $absenceStmt = $conn->prepare("
        SELECT DATE(n.ngay_bat_dau) as ngay, 
            COUNT(*) as so_ngay_nghi,
            COUNT(*) / (? * 22) * 100 as ti_le_vang_mat
        FROM nghi_phep n
        JOIN nhan_vien nv ON n.id_nhan_vien = nv.id_nhan_vien
        WHERE n.trang_thai1 = 'Đã duyệt'
            AND DATE_FORMAT(n.ngay_bat_dau, '%Y-%m') = ?
            AND nv.trang_thai != 'Đã nghỉ việc'
        GROUP BY DATE(n.ngay_bat_dau)
        ORDER BY ngay
    ");
    $absenceStmt->execute([$totalEmployees, $month_year]);
    $absenceData = $absenceStmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate average absence days and rate
    $totalAbsenceDays = array_sum(array_column($absenceData, 'so_ngay_nghi'));
    $avgAbsenceDays = $totalAbsenceDays / (count($absenceData) ?: 1);
    $avgAbsenceRate = array_sum(array_column($absenceData, 'ti_le_vang_mat')) / (count($absenceData) ?: 1);
    $targetRate = 3.8;
} catch (PDOException $e) {
    error_log("Error in absence query: " . $e->getMessage());
    $absenceData = [];
    $avgAbsenceDays = 0;
    $avgAbsenceRate = 0;
    $targetRate = 3.8;
}

// 4. Time Compliance by Department (Vertical Grouped Bar Chart)
try {
    $timeComplianceStmt = $conn->prepare("
        SELECT p.ten_phong_ban,
            SUM(CASE WHEN c.trang_thai = 'Đúng giờ' THEN 1 ELSE 0 END) as dung_gio,
            SUM(CASE WHEN c.trang_thai = 'Đi trễ' THEN 1 ELSE 0 END) as di_tre,
            SUM(CASE WHEN c.trang_thai = 'Có phép' THEN 1 ELSE 0 END) as co_phep,
            SUM(CASE WHEN c.trang_thai = 'Không phép' THEN 1 ELSE 0 END) as khong_phep
        FROM phong_ban p
        LEFT JOIN nhan_vien n ON p.id_phong_ban = n.id_phong_ban
        LEFT JOIN cham_cong c ON n.id_nhan_vien = c.id_nhan_vien
        WHERE DATE_FORMAT(c.ngay_lam_viec, '%Y-%m') = ?
        GROUP BY p.id_phong_ban
    ");
    $timeComplianceStmt->execute([$month_year]);
    $timeCompliance = $timeComplianceStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error in timeCompliance query: " . $e->getMessage());
    $timeCompliance = [];
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Báo cáo thống kê | Hệ thống quản lý nhân sự</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0/dist/chartjs-plugin-datalabels.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        :root {
            --primary-color: #5a67d8;
            --secondary-color: #4c51bf;
            --success-color: #48bb78;
            --danger-color: #f56565;
            --warning-color: #ed8936;
            --info-color: #4299e1;
            --light-color: #f7fafc;
            --dark-color: #1a202c;
            --gray-color: #718096;
            --white-color: #ffffff;
            --border-radius: 10px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            --transition: all 0.3s ease-in-out;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #f4f7fc;
            color: var(--dark-color);
            line-height: 1.6;
            margin: 0;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .main-content {
            padding: 40px;
            margin-left: 250px;
            height: 100vh;
            display: grid;
            grid-template-rows: auto 1fr auto;
            gap: 12px;
        }

        .page-header {
            background: linear-gradient(135deg, #ffffff, #f9fafb);
            padding: 12px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            transition: var(--transition);
        }

        .page-header:hover {
            transform: translateY(-2px);
        }

        .page-title {
            font-size: 26px;
            font-weight: 700;
            color: var(--dark-color);
            margin: 0;
            letter-spacing: 0.01em;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            line-height: 1.3;
        }

        .filter-form {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .filter-form label {
            font-weight: 600;
            color: var(--gray-color);
            font-size: 13px;
        }

        .filter-form select,
        .filter-form button,
        .export-button {
            padding: 8px 14px;
            border-radius: 6px;
            border: 1px solid #e2e8f0;
            font-size: 13px;
            background: #ffffff;
            transition: var(--transition);
        }

        .filter-form select {
            min-width: 90px;
            box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.05);
        }

        .filter-form select:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(90, 103, 216, 0.15);
        }

        .filter-form button,
        .export-button {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--white-color);
            border: none;
            cursor: pointer;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .filter-form button:hover,
        .export-button:hover {
            background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
            transform: translateY(-1px);
        }

        .charts-container {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr;
            gap: 12px;
        }

        .chart-card {
            background: #ffffff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 12px;
            position: relative;
            overflow: hidden;
            transition: var(--transition);
        }

        .chart-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
        }

        .chart-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary-color), var(--secondary-color));
        }

        .chart-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--dark-color);
            margin: 0 0 8px 0;
            display: flex;
            align-items: center;
            gap: 6px;
            letter-spacing: 0.01em;
        }

        .chart-title i {
            color: var(--primary-color);
            font-size: 20px;
        }

        canvas {
            width: 100% !important;
            image-rendering: -webkit-optimize-contrast;
            image-rendering: crisp-edges;
            transition: opacity 0.5s ease;
        }

        canvas:not([style*="opacity"]) {
            opacity: 0;
            animation: fadeIn 0.5s forwards;
        }

        @keyframes fadeIn {
            to { opacity: 1; }
        }

        #timeComplianceChart {
            height: 250px !important;
        }

        #gaugeChart {
            height: 200px !important;
            max-width: 250px;
            margin: 0 auto;
        }

        .pie-charts-container {
            display: grid;
            grid-template-rows: auto auto;
            gap: 8px;
        }

        .pie-chart-row {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
        }

        .pie-charts-container .pie-chart-row:last-child {
            grid-template-columns: repeat(2, 1fr);
            justify-content: start;
        }

        .pie-chart-card {
            text-align: center;
        }

        .pie-chart-card canvas {
            height: 110px !important;
        }

        .pie-chart-card .total-employees {
            font-size: 13px;
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 6px;
        }

        .no-data {
            text-align: center;
            padding: 14px;
            color: var(--gray-color);
            font-size: 13px;
            background-color: #f9fafb;
            border-radius: var(--border-radius);
        }

        .no-data i {
            font-size: 22px;
            margin-bottom: 8px;
            color: #dee2e6;
        }

        .error-container {
            background-color: #fff5f5;
            border-radius: var(--border-radius);
            margin-bottom: 12px;
            border-left: 4px solid var(--danger-color);
        }

        .error-message {
            padding: 10px;
            color: var(--danger-color);
            font-weight: 500;
        }

        .kpi-container {
            display: grid;
            grid-template-columns: 1fr;
            gap: 4px;
            padding: 4px 0;
        }

        .kpi-icon {
            font-size: 2rem;
            margin-bottom: 0.125rem;
            color: var(--primary-color);
        }

        .absence-container {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .absence-kpi {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
        }

        .kpi-card {
            text-align: center;
            padding: 8px;
            background: #ffffff;
            border-radius: 6px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            transition: var(--transition);
        }

        .kpi-card:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.08);
        }

        .kpi-card i {
            font-size: 16px;
            color: var(--primary-color);
            margin-bottom: 4px;
        }

        .kpi-card .kpi-value {
            font-size: 15px;
            font-weight: 700;
            color: var(--dark-color);
            letter-spacing: 0.01em;
        }

        .kpi-card .kpi-label {
            font-size: 10px;
            color: var(--gray-color);
        }

        .kpi-gauge-card {
            text-align: center;
        }

        .value {
            font-size: 24px;
            font-weight: bold;
            color: var(--dark-color);
            margin-top: 10px;
        }

        .target {
            margin-top: -10px;
            color: var(--gray-color);
            font-size: 14px;
        }

        .time-compliance-card {
            grid-column: 1 / -1;
            max-width: 1400px;
            width: 100%;
            height: 290px;
            margin: 0 auto;
            padding: 6px;
        }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 12px;
            padding: 12px 0;
        }

        .pagination button {
            padding: 8px 16px;
            border-radius: 6px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--white-color);
            border: none;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            transition: var(--transition);
        }

        .pagination button:disabled {
            background: var(--gray-color);
            cursor: not-allowed;
        }

        .pagination button:hover:not(:disabled) {
            background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
            transform: translateY(-1px);
        }

        @media (max-width: 1200px) {
            .main-content {
                margin-left: 0;
            }

            .time-compliance-card {
                max-width: 100%;
            }
        }

        @media (max-width: 768px) {
            .charts-container {
                grid-template-columns: 1fr;
            }

            .kpi-container {
                grid-template-columns: 1fr;
            }

            .absence-kpi {
                grid-template-columns: 1fr;
            }

            .page-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .filter-form {
                width: 100%;
            }

            .filter-form select {
                flex: 1;
            }

            .pie-charts-container {
                grid-template-rows: auto;
            }

            .pie-chart-row {
                grid-template-columns: 1fr;
            }

            .time-compliance-card {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="main-content">
        <div class="page-header">
            <h1 class="page-title">
                <i class="fas fa-chart-line"></i>
                Báo cáo thống kê
            </h1>
            <form method="GET" action="baocao.php" class="filter-form">
                <div>
                    <label for="month"><i class="far fa-calendar-alt"></i> Tháng:</label>
                    <select id="month" name="month">
                        <?php for ($m = 1; $m <= 12; $m++): ?>
                            <option value="<?= $m ?>" <?= $m == $month ? 'selected' : '' ?>>
                                Tháng <?= $m ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div>
                    <label for="year"><i class="far fa-calendar"></i> Năm:</label>
                    <select id="year" name="year">
                        <?php for ($y = date('Y') - 5; $y <= date('Y') + 1; $y++): ?>
                            <option value="<?= $y ?>" <?= $y == $year ? 'selected' : '' ?>>
                                <?= $y ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <button type="submit">
                    <i class="fas fa-filter"></i>
                    Lọc dữ liệu
                </button>
                <button type="button" class="export-button" onclick="exportToPDF()">
                    <i class="fas fa-file-pdf"></i>
                    Xuất PDF
                </button>
            </form>
        </div>

        <div class="charts-container">
            <!-- Chart 1: Gender Distribution by Department (Multiple Pie Charts) -->
            <div class="chart-card">
                <h3 class="chart-title">
                    <i class="fas fa-users"></i>
                    Phòng ban theo giới tính
                </h3>
                <div class="pie-charts-container" id="pieChartsContainer">
                    <!-- Pie charts will be rendered here via JavaScript -->
                </div>
                <?php if (empty($deptData)): ?>
                    <div class="no-data">
                        <i class="fas fa-user-slash"></i>
                        <p>Không có dữ liệu giới tính theo phòng ban</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Chart 2: Absence Trend (Gauge Chart + Absence KPIs) -->
            <div class="chart-card">
                <h3 class="chart-title">
                    <i class="fas fa-calendar-times"></i>
                    Tỉ lệ vắng mặt tháng <?= $month ?>/<?= $year ?>
                </h3>
                <div class="absence-container">
                    <div class="absence-kpi">
                        <div class="kpi-card">
                            <i class="fas fa-calendar-times"></i>
                            <div class="kpi-value"><?= number_format($avgAbsenceDays, 1) ?> ngày</div>
                            <div class="kpi-label">Số ngày vắng mặt TB</div>
                        </div>
                        <div class="kpi-card">
                            <i class="fas fa-chart-line"></i>
                            <div class="kpi-value"><?= number_format($avgAbsenceRate, 1) ?>%</div>
                            <div class="kpi-label">Tỉ lệ vắng mặt TB</div>
                        </div>
                    </div>
                    <div class="kpi-gauge-card">
                        <canvas id="gaugeChart"></canvas>
                        <div class="value" id="absenceRate"><?= number_format($avgAbsenceRate, 1) ?>%</div>
                        <div class="target">Mục tiêu < 3.8%</div>
                    </div>
                </div>
                <?php if (empty($absenceData)): ?>
                    <div class="no-data">
                        <i class="fas fa-calendar-times"></i>
                        <p>Không có dữ liệu nghỉ phép</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- KPI Cards -->
            <div class="chart-card">
                <h3 class="chart-title">
                    <i class="fas fa-info-circle"></i>
                    Chỉ số KPI
                </h3>
                <div class="kpi-icon">
                    <div class="kpi-container">
                        <div class="kpi-card">
                            <i class="fas fa-users"></i>
                            <div class="kpi-value"><?= number_format($totalEmployees) ?></div>
                            <div class="kpi-label">Tổng số nhân viên</div>
                        </div>
                        <div class="kpi-card">
                            <i class="fas fa-calendar-check"></i>
                            <div class="kpi-value"><?= number_format($employeesAttended) ?></div>
                            <div class="kpi-label">Nhân viên đi làm</div>
                        </div>
                        <div class="kpi-card">
                            <i class="fas fa-user-times"></i>
                            <div class="kpi-value"><?= number_format($employeesResigned) ?></div>
                            <div class="kpi-label">Nhân viên nghỉ việc</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Chart 3: Time Compliance by Department (Vertical Grouped Bar Chart) -->
        <div class="chart-card time-compliance-card">
            <h3 class="chart-title">
                <i class="fas fa-clock"></i>
                Tổng quan chấp hành giờ giấc tại công ty theo phòng ban
            </h3>
            <canvas id="timeComplianceChart"></canvas>
            <?php if (empty($timeCompliance)): ?>
                <div class="no-data">
                    <i class="fas fa-clock"></i>
                    <p>Không có dữ liệu chấp hành giờ giấc</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Pagination Buttons -->
        <div class="pagination">
            <button id="prevPage" disabled><i class="fas fa-chevron-left"></i> Trang trước</button>
            <button id="nextPage"><i class="fas fa-chevron-right"></i> Trang sau</button>
        </div>
    </div>

    <script>
        // Register ChartDataLabels plugin
        Chart.register(ChartDataLabels);

        // Chart colors
        const chartColors = {
            primary: '#5a67d8',
            secondary: '#4c51bf',
            success: '#48bb78',
            danger: '#f56565',
            warning: '#ed8936',
            info: '#4299e1',
            light: '#f7fafc',
            dark: '#1a202c',
            gray: '#e0e0e0'
        };

        // Common chart options
        const chartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            devicePixelRatio: window.devicePixelRatio * 2,
            plugins: {
                tooltip: {
                    backgroundColor: 'rgba(26, 32, 44, 0.9)',
                    titleFont: { size: 14, family: 'Inter', weight: 'bold' },
                    bodyFont: { size: 12, family: 'Inter' },
                    padding: 8,
                    cornerRadius: 6,
                    displayColors: true,
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) label += ': ';
                            let value = context.parsed.y !== undefined ? context.parsed.y : context.parsed;
                            if (context.chart.canvas.id.includes('genderChart')) {
                                const sum = context.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / sum) * 100);
                                return `${label}${value} (${percentage}%)`;
                            }
                            return `${label}${Math.round(value)} lần`;
                        }
                    }
                },
                legend: {
                    labels: {
                        font: { size: 12, family: 'Inter' },
                        padding: 8,
                        color: '#1a202c',
                        usePointStyle: true,
                        pointStyle: 'circle'
                    },
                    position: 'top',
                    align: 'center'
                },
                datalabels: {
                    font: { size: 10, family: 'Inter', weight: 'bold' },
                    color: '#1a202c',
                    anchor: 'end',
                    align: 'top',
                    formatter: function(value, context) {
                        if (context.chart.canvas.id.includes('genderChart')) {
                            const sum = context.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                            return ((value / sum) * 100).toFixed(1) + '%';
                        }
                        return value ? Math.round(value).toLocaleString('vi-VN') : '';
                    }
                }
            },
            animation: {
                duration: 800,
                easing: 'easeOutQuart'
            },
            layout: {
                padding: 6
            }
        };

        // Needle plugin for Gauge Chart
        const needlePlugin = {
            id: 'needle',
            afterDatasetDraw(chart) {
                const { ctx, chartArea: { width, height, top }, scales } = chart;
                const absencePercent = <?= $avgAbsenceRate ?>;
                const angle = (Math.PI * (absencePercent / 100));
                const cx = chart.width / 2;
                const cy = chart._metasets[0].data[0].y;
                const radius = chart._metasets[0].data[0].outerRadius - 10;

                const x = cx + radius * Math.cos(Math.PI + angle);
                const y = cy + radius * Math.sin(Math.PI + angle);

                ctx.save();
                ctx.beginPath();
                ctx.moveTo(cx, cy);
                ctx.lineTo(x, y);
                ctx.lineWidth = 2;
                ctx.strokeStyle = 'red';
                ctx.stroke();
                ctx.restore();

                // Draw needle base
                ctx.beginPath();
                ctx.arc(cx, cy, 5, 0, Math.PI * 2);
                ctx.fillStyle = 'black';
                ctx.fill();
            }
        };

        // Chart data
        // 1. Gender by Department (Multiple Pie Charts)
        const allDeptData = <?php echo json_encode($deptData); ?>;
        let currentPage = 0;
        const itemsPerPage = 5;
        let charts = [];

        function renderPieCharts(page) {
            const container = document.getElementById('pieChartsContainer');
            container.innerHTML = `
                <div class="pie-chart-row">
                    <div class="pie-chart-card" id="chart-0"></div>
                    <div class="pie-chart-card" id="chart-1"></div>
                    <div class="pie-chart-card" id="chart-2"></div>
                </div>
                <div class="pie-chart-row">
                    <div class="pie-chart-card" id="chart-3"></div>
                    <div class="pie-chart-card" id="chart-4"></div>
                </div>
            `;

            // Destroy existing charts
            charts.forEach(chart => chart.destroy());
            charts = [];

            const start = page * itemsPerPage;
            const end = start + itemsPerPage;
            const pageData = Object.entries(allDeptData).slice(start, end);

            pageData.forEach(([deptId, data], index) => {
                const chartContainer = document.getElementById(`chart-${index}`);
                chartContainer.innerHTML = `
                    <div class="total-employees">${data.ten_phong_ban}: ${data.total} nhân viên</div>
                    <canvas id="genderChart_${deptId}"></canvas>
                `;

                const genderData = {
                    labels: data.labels,
                    datasets: [{
                        data: data.data,
                        backgroundColor: [
                            chartColors.primary,
                            chartColors.success,
                            chartColors.danger
                        ],
                        borderWidth: 2,
                        borderColor: '#fff'
                    }]
                };

                if (genderData.datasets[0].data.length) {
                    const chart = new Chart(document.getElementById(`genderChart_${deptId}`), {
                        type: 'pie',
                        data: genderData,
                        options: {
                            ...chartOptions,
                            plugins: {
                                ...chartOptions.plugins,
                                legend: { position: 'bottom', labels: { padding: 5, boxWidth: 8 } },
                                tooltip: {
                                    ...chartOptions.plugins.tooltip,
                                    callbacks: {
                                        label: function(context) {
                                            const label = context.label || '';
                                            const value = context.raw || 0;
                                            const sum = context.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                                            const percentage = Math.round((value / sum) * 100);
                                            return `${label}: ${value} (${percentage}%)`;
                                        }
                                    }
                                }
                            },
                            cutout: '60%'
                        }
                    });
                    charts.push(chart);
                }
            });

            // Update pagination buttons
            const prevButton = document.getElementById('prevPage');
            prevButton.disabled = page === 0;
        }

        // 2. Gauge Chart for Absence Rate
        const gaugeData = {
            labels: ['Tỉ lệ vắng mặt'],
            datasets: [{
                label: 'Tỉ lệ vắng mặt',
                data: [<?= $avgAbsenceRate ?>, 100 - <?= $avgAbsenceRate ?>],
                backgroundColor: [
                    <?= $avgAbsenceRate ?> > <?= $targetRate ?> ? '#e74c3c' : '#2c3e50',
                    chartColors.gray
                ],
                borderWidth: 0,
                circumference: 180,
                rotation: 270,
                cutout: '80%'
            }]
        };

        // 3. Time Compliance
        const timeComplianceData = {
            labels: [<?php foreach ($timeCompliance as $row) echo "'" . addslashes($row['ten_phong_ban']) . "',"; ?>],
            datasets: [
                {
                    label: 'Đúng giờ',
                    data: [<?php foreach ($timeCompliance as $row) echo $row['dung_gio'] . ","; ?>],
                    backgroundColor: chartColors.primary,
                    borderRadius: 4
                },
                {
                    label: 'Đi trễ',
                    data: [<?php foreach ($timeCompliance as $row) echo $row['di_tre'] . ","; ?>],
                    backgroundColor: chartColors.warning,
                    borderRadius: 4
                },
                {
                    label: 'Có phép',
                    data: [<?php foreach ($timeCompliance as $row) echo $row['co_phep'] . ","; ?>],
                    backgroundColor: chartColors.success,
                    borderRadius: 4
                },
                {
                    label: 'Không phép',
                    data: [<?php foreach ($timeCompliance as $row) echo $row['khong_phep'] . ","; ?>],
                    backgroundColor: chartColors.danger,
                    borderRadius: 4
                }
            ]
        };

        // Initialize charts
        // 1. Gender by Department (Initial render)
        renderPieCharts(currentPage);

        // Pagination event listeners
        document.getElementById('prevPage').addEventListener('click', () => {
            if (currentPage > 0) {
                currentPage--;
                renderPieCharts(currentPage);
            }
        });

        document.getElementById('nextPage').addEventListener('click', () => {
            const month = document.getElementById('month').value;
            const year = document.getElementById('year').value;
            window.location.href = `baocao1.php?month=${month}&year=${year}`;
        });

        // 2. Gauge Chart
        new Chart(document.getElementById('gaugeChart'), {
            type: 'doughnut',
            data: gaugeData,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            font: { size: 12, family: 'Inter' },
                            padding: 8,
                            color: '#1a202c',
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: { enabled: false },
                    datalabels: { display: false }
                },
                layout: {
                    padding: {
                        top: 20,
                        bottom: 40
                    }
                }
            },
            plugins: [needlePlugin]
        });

        // 3. Time Compliance (Vertical Grouped Bar Chart)
        if (timeComplianceData.datasets.some(dataset => dataset.data.some(value => value > 0))) {
            new Chart(document.getElementById('timeComplianceChart'), {
                type: 'bar',
                data: timeComplianceData,
                options: {
                    ...chartOptions,
                    plugins: {
                        ...chartOptions.plugins,
                        datalabels: { align: 'top', anchor: 'end' }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 200,
                            grid: { color: '#e2e8f0', drawBorder: false },
                            ticks: {
                                font: { size: 12, family: 'Inter' },
                                color: '#718096'
                            },
                            title: {
                                display: true,
                                text: 'Số lần',
                                font: { size: 12, family: 'Inter' }
                            }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { font: { size: 12, family: 'Inter' }, color: '#718096' }
                        }
                    }
                }
            });
        }

        // Export to PDF
        function exportToPDF() {
            const element = document.querySelector('.main-content');
            const opt = {
                margin: 5,
                filename: `bao_cao_thang_${<?= $month ?>}_${<?= $year ?>}.pdf`,
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2, useCORS: true },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            html2pdf().set(opt).from(element).save();
        }
    </script>
</body>
</html>