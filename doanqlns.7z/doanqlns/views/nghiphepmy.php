<?php
require_once __DIR__ . '/../includes/check_login.php';
include(__DIR__ . '/../includes/header.php');
include(__DIR__ . '/../includes/sidebar.php');
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Nghỉ Phép Của Tôi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .leave-container {
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin: 20px;
        }

        .leave-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }

        .leave-header h1 {
            margin: 0;
            color: #2c3e50;
            font-size: 24px;
        }

        .leave-header i {
            margin-right: 10px;
            color: #3498db;
        }

        .date-filter {
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .date-filter select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        .btn-request-leave {
            background: #3498db;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: background-color 0.3s;
        }

        .btn-request-leave:hover {
            background: #2980b9;
        }

        .leave-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .leave-table th,
        .leave-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .leave-table th {
            background: #f8f9fa;
            color: #2c3e50;
            font-weight: 500;
        }

        .leave-table tr:hover {
            background: #f8f9fa;
        }

        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }

        .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-approved {
            background: #d4edda;
            color: #155724;
        }

        .status-rejected {
            background: #f8d7da;
            color: #721c24;
        }

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: white;
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
            position: relative;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }

        .modal-close {
            font-size: 24px;
            cursor: pointer;
            color: #666;
            background: none;
            border: none;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #2c3e50;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        .form-group textarea {
            height: 100px;
            resize: vertical;
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }

        .btn-save,
        .btn-cancel {
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            border: none;
        }

        .btn-save {
            background: #3498db;
            color: white;
        }

        .btn-cancel {
            background: #e9ecef;
            color: #2c3e50;
        }

        @media (max-width: 768px) {
            .leave-header {
                flex-direction: column;
                gap: 15px;
            }

            .date-filter {
                flex-direction: column;
                width: 100%;
            }

            .date-filter select {
                width: 100%;
            }

            .btn-request-leave {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="main-content">
        <div class="leave-container">
            <div class="leave-header">
                <h1><i class="fas fa-calendar-alt"></i> Nghỉ Phép Của Tôi</h1>
                <button class="btn-request-leave" onclick="showRequestLeaveModal()">
                    <i class="fas fa-plus"></i> Đăng Ký Nghỉ Phép
                </button>
            </div>

            <div class="table-responsive">
                <table class="leave-table">
                    <thead>
                        <tr>
                            <th>Ngày Bắt Đầu</th>
                            <th>Ngày Kết Thúc</th>
                            <th>Số Ngày</th>
                            <th>Loại Nghỉ</th>
                            <th>Lý Do</th>
                            <th>Trạng Thái</th>
                            <th>Lý do từ chối</th>
                        </tr>
                    </thead>
                    <tbody id="leaveTableBody">
                        <!-- Data will be loaded here -->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Modal đăng ký nghỉ phép -->
        <div id="requestLeaveModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Đăng Ký Nghỉ Phép</h2>
                    <button class="modal-close" onclick="closeRequestLeaveModal()">&times;</button>
                </div>
                <form id="leaveRequestForm">
                    <div class="form-group">
                        <label for="startDate">Ngày Bắt Đầu <span style="color: red;">*</span></label>
                        <input type="date" id="startDate" required>
                    </div>
                    <div class="form-group">
                        <label for="endDate">Ngày Kết Thúc <span style="color: red;">*</span></label>
                        <input type="date" id="endDate" required>
                    </div>
                    <div class="form-group">
                        <label for="loaiNghi">Loại Nghỉ <span style="color: red;">*</span></label>
                        <select id="loaiNghi" required>
                            <option value="Có phép">Có phép</option>
                            <option value="Không phép">Không phép</option>
                            <option value="Phép Năm">Phép Năm</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="reason">Lý Do <span style="color: red;">*</span></label>
                        <textarea id="reason" required></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn-cancel" onclick="closeRequestLeaveModal()">Hủy</button>
                        <button type="submit" class="btn-save">Gửi Yêu Cầu</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            loadLeaveData();

            // Form submission handler
            document.getElementById('leaveRequestForm').addEventListener('submit', function(e) {
                e.preventDefault();
                submitLeaveRequest();
            });
        });

        async function loadLeaveData() {
            try {
                const response = await fetch('/doanqlns/index.php/api/employee/leave');
                if (!response.ok) {
                    throw new Error('Failed to fetch leave data');
                }

                const data = await response.json();
                
                if (data.success && data.data) {
                    const tbody = document.getElementById('leaveTableBody');
                    tbody.innerHTML = '';

                    data.data.forEach(leave => {
                        const row = document.createElement('tr');
                        
                        // Calculate number of days (excluding Sundays)
                        const startDate = new Date(leave.ngay_bat_dau);
                        const endDate = new Date(leave.ngay_ket_thuc);
                        let days = 0;
                        let currentDate = new Date(startDate);
                        
                        while (currentDate <= endDate) {
                            if (currentDate.getDay() !== 0) { // Skip Sundays
                                days++;
                            }
                            currentDate.setDate(currentDate.getDate() + 1);
                        }

                        // Get status class
                        let statusClass = '';
                        let displayStatus = leave.trang_thai1;
                        switch(displayStatus) {
                            case 'Chờ duyệt':
                                statusClass = 'status-pending';
                                break;
                            case 'Đã duyệt':
                                statusClass = 'status-approved';
                                break;
                            case 'Từ chối':
                                statusClass = 'status-rejected';
                                break;
                            default:
                                statusClass = 'status-pending';
                                displayStatus = 'Chờ duyệt';
                        }

                        row.innerHTML = `
                            <td>${formatDate(leave.ngay_bat_dau)}</td>
                            <td>${formatDate(leave.ngay_ket_thuc)}</td>
                            <td>${days} ngày</td>
                            <td>${leave.loai_nghi || 'N/A'}</td>
                            <td>${leave.ly_do}</td>
                            <td><span class="status-badge ${statusClass}">${displayStatus}</span></td>
                            <td>${leave.ly_do_tu_choi || ''}</td>
                        `;

                        tbody.appendChild(row);
                    });
                } else {
                    console.error('No data received from server');
                }
            } catch (error) {
                console.error('Error loading leave data:', error);
                alert('Có lỗi xảy ra khi tải dữ liệu nghỉ phép');
            }
        }

        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('vi-VN');
        }

        function showRequestLeaveModal() {
            document.getElementById('requestLeaveModal').style.display = 'flex';
        }

        function closeRequestLeaveModal() {
            document.getElementById('requestLeaveModal').style.display = 'none';
            document.getElementById('leaveRequestForm').reset();
        }

        async function submitLeaveRequest() {
            try {
                const startDate = document.getElementById('startDate').value;
                const endDate = document.getElementById('endDate').value;
                const loaiNghi = document.getElementById('loaiNghi').value;
                const reason = document.getElementById('reason').value;

                const response = await fetch('/doanqlns/index.php/api/employee/leave', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        ngay_bat_dau: startDate,
                        ngay_ket_thuc: endDate,
                        loai_nghi: loaiNghi,
                        ly_do: reason
                    })
                });

                const data = await response.json();

                if (data.success) {
                    alert('Đăng ký nghỉ phép thành công!');
                    closeRequestLeaveModal();
                    loadLeaveData();
                } else {
                    alert(data.message || 'Có lỗi xảy ra khi đăng ký nghỉ phép');
                }
            } catch (error) {
                console.error('Error submitting leave request:', error);
                alert('Có lỗi xảy ra khi gửi yêu cầu nghỉ phép');
            }
        }
    </script>

    <?php include(__DIR__ . '/../includes/footer.php'); ?>
</body>
</html> 