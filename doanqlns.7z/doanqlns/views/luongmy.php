<?php
require_once __DIR__ . '/../includes/check_login.php';
include(__DIR__ . '/../includes/header.php');
include(__DIR__ . '/../includes/sidebar.php');
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HRM Pro - Lương Của Tôi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .salary-container {
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin: 20px;
        }

        .salary-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }

        .salary-header h1 {
            margin: 0;
            color: #2c3e50;
            font-size: 24px;
        }

        .salary-header i {
            margin-right: 10px;
            color: #3498db;
        }

        .date-filter {
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .date-filter select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        .salary-details {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }

        .salary-section {
            margin-bottom: 25px;
        }

        .salary-section h2 {
            color: #2c3e50;
            font-size: 18px;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #3498db;
        }

        .salary-section h2 i {
            margin-right: 10px;
            color: #3498db;
        }

        .salary-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .salary-item {
            background: white;
            padding: 15px;
            border-radius: 6px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .salary-label {
            color: #7f8c8d;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .salary-value {
            color: #2c3e50;
            font-size: 16px;
            font-weight: 500;
        }

        .total-salary {
            background: #2c3e50;
            color: white;
            padding: 20px;
            border-radius: 6px;
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .total-salary .salary-label {
            color: #ecf0f1;
            font-size: 16px;
        }

        .total-salary .salary-value {
            color: #ecf0f1;
            font-size: 24px;
            font-weight: 600;
        }

        @media (max-width: 768px) {
            .salary-grid {
                grid-template-columns: 1fr;
            }
            
            .date-filter {
                flex-direction: column;
                gap: 10px;
            }
            
            .date-filter select {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="main-content">
        <div class="salary-container">
            <div class="salary-header">
                <h1><i class="fas fa-money-bill-wave"></i> Lương Của Tôi</h1>
                <div class="date-filter">
                    <select id="selectMonth">
                        <?php for($i = 1; $i <= 12; $i++): ?>
                            <option value="<?= $i ?>" <?= $i == date('n') ? 'selected' : '' ?>><?= "Tháng " . $i ?></option>
                        <?php endfor; ?>
                    </select>
                    <select id="selectYear">
                        <?php 
                        $currentYear = date('Y');
                        for($i = $currentYear; $i >= $currentYear - 5; $i--): 
                        ?>
                            <option value="<?= $i ?>" <?= $i == $currentYear ? 'selected' : '' ?>><?= $i ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>

            <div class="salary-details">
                <div class="salary-section">
                    <h2><i class="fas fa-info-circle"></i> Thông Tin Cơ Bản</h2>
                    <div class="salary-grid">
                        <div class="salary-item">
                            <div class="salary-label">Lương Cơ Bản</div>
                            <div id="luongCoBan" class="salary-value">Loading...</div>
                        </div>
                        <div class="salary-item">
                            <div class="salary-label">Số Ngày Công</div>
                            <div id="soNgayCong" class="salary-value">Loading...</div>
                        </div>
                        <div class="salary-item">
                            <div class="salary-label">Lương Theo Ngày Công</div>
                            <div id="luongTheoNgayCong" class="salary-value">Loading...</div>
                        </div>
                    </div>
                </div>

                <div class="salary-section">
                    <h2><i class="fas fa-plus-circle"></i> Phụ Cấp & Thưởng</h2>
                    <div class="salary-grid">
                        <div class="salary-item">
                            <div class="salary-label">Phụ Cấp Chức Vụ</div>
                            <div id="phuCap" class="salary-value">Loading...</div>
                        </div>
                        <div class="salary-item">
                            <div class="salary-label">Thưởng</div>
                            <div id="thuong" class="salary-value">Loading...</div>
                        </div>
                    </div>
                </div>

                <div class="salary-section">
                    <h2><i class="fas fa-minus-circle"></i> Khấu Trừ</h2>
                    <div class="salary-grid">
                        <div class="salary-item">
                            <div class="salary-label">Bảo Hiểm Xã Hội (8%)</div>
                            <div id="bhxh" class="salary-value">Loading...</div>
                        </div>
                        <div class="salary-item">
                            <div class="salary-label">Bảo Hiểm Y Tế (1.5%)</div>
                            <div id="bhyt" class="salary-value">Loading...</div>
                        </div>
                        <div class="salary-item">
                            <div class="salary-label">Bảo Hiểm Thất Nghiệp (1%)</div>
                            <div id="bhtn" class="salary-value">Loading...</div>
                        </div>
                        <div class="salary-item">
                            <div class="salary-label">Thuế Thu Nhập Cá Nhân</div>
                            <div id="thue" class="salary-value">Loading...</div>
                        </div>
                        <div class="salary-item" style="grid-column: span 2;">
                            <div class="salary-label">Tổng Khấu Trừ</div>
                            <div id="tongKhauTru" class="salary-value">Loading...</div>
                        </div>
                    </div>
                </div>

                <div class="total-salary">
                    <div class="salary-label">Tổng Lương Thực Nhận</div>
                    <div id="tongLuong" class="salary-value">Loading...</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Set current month and year
            const currentDate = new Date();
            document.getElementById('selectMonth').value = currentDate.getMonth() + 1;
            document.getElementById('selectYear').value = currentDate.getFullYear();

            // Load initial data
            loadSalaryData();

            // Add event listeners for month/year changes
            document.getElementById('selectMonth').addEventListener('change', loadSalaryData);
            document.getElementById('selectYear').addEventListener('change', loadSalaryData);
        });

        async function loadSalaryData() {
            try {
                const month = document.getElementById('selectMonth').value;
                const year = document.getElementById('selectYear').value;

                const response = await fetch(`/doanqlns/index.php/api/employee/salary?month=${month}&year=${year}`);
                if (!response.ok) {
                    throw new Error('Failed to fetch salary data');
                }

                const data = await response.json();
                
                if (data.success && data.data) {
                    const salary = data.data;
                    
                    // Update salary information
                    document.getElementById('luongCoBan').textContent = salary.luong_co_ban + ' VNĐ';
                    document.getElementById('soNgayCong').textContent = salary.so_ngay_cong + ' ngày';
                    document.getElementById('luongTheoNgayCong').textContent = salary.luong_theo_ngay_cong + ' VNĐ';
                    document.getElementById('phuCap').textContent = salary.phu_cap + ' VNĐ';
                    document.getElementById('thuong').textContent = salary.thuong + ' VNĐ';
                    document.getElementById('bhxh').textContent = salary.bhxh + ' VNĐ';
                    document.getElementById('bhyt').textContent = salary.bhyt + ' VNĐ';
                    document.getElementById('bhtn').textContent = salary.bhtn + ' VNĐ';
                    document.getElementById('thue').textContent = salary.thue + ' VNĐ';
                    document.getElementById('tongKhauTru').textContent = salary.tong_khau_tru + ' VNĐ';
                    document.getElementById('tongLuong').textContent = salary.tong_luong + ' VNĐ';
                } else {
                    throw new Error(data.message || 'Không thể tải thông tin lương');
                }
            } catch (error) {
                console.error('Error loading salary data:', error);
                alert('Có lỗi xảy ra khi tải thông tin lương: ' + error.message);
            }
        }
    </script>

    <?php include(__DIR__ . '/../includes/footer.php'); ?>
</body>
</html> 