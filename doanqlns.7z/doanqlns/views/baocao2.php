<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/check_login.php';
include(__DIR__ . '/../includes/header.php');
include(__DIR__ . '/../includes/sidebar.php');

require_once __DIR__ . '/../config/Database.php';

// Initialize database connection
try {
    $database = new Database();
    $conn = $database->getConnection();
    if (!$conn) {
        throw new Exception("Không thể kết nối đến cơ sở dữ liệu.");
    }
} catch (Exception $e) {
    error_log("Database connection error: " . $e->getMessage());
    die("<div class='error-container'><div class='error-message'>Lỗi: " . htmlspecialchars($e->getMessage()) . "</div></div>");
}

// Get month and year from request (for UI, not used in queries)
$month = isset($_GET['month']) ? (int)$_GET['month'] : date('m');
$year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');

// 1. Tổng quan (Total Applicants and Recruitment Costs)
try {
    $totalApplicantsStmt = $conn->prepare("
        SELECT COUNT(DISTINCT id_dot_tuyen_dung) AS total
        FROM dot_tuyen_dung
    ");
    $totalApplicantsStmt->execute();
    $totalApplicantsResult = $totalApplicantsStmt->fetch(PDO::FETCH_ASSOC);
    $totalApplicants = $totalApplicantsResult['total'] ?? 0;
    error_log("Total Applicants Query: result=" . json_encode($totalApplicantsResult));

    $totalCostsStmt = $conn->prepare("
        SELECT SUM(so_tien) AS total_cost
        FROM chi_phi_tuyen_dung
    ");
    $totalCostsStmt->execute();
    $totalCostsResult = $totalCostsStmt->fetch(PDO::FETCH_ASSOC);
    $totalCosts = $totalCostsResult['total_cost'] ?? 0;
    error_log("Total Costs Query: result=" . json_encode($totalCostsResult));
} catch (PDOException $e) {
    error_log("Error in total overview query: " . $e->getMessage());
    $totalApplicants = 0;
    $totalCosts = 0;
}

// 2. Phễu tuyển dụng (Funnel Chart Data)
try {
    $funnelData = [
        ['stage' => 'Tổng vị trí cần tuyển', 'count' => 0],
        ['stage' => 'Tổng ứng viên nộp', 'count' => 0],
        ['stage' => 'Ứng viên chờ phân bổ', 'count' => 0],
        ['stage' => 'Ứng viên đã duyệt', 'count' => 0],
    ];

    // Total positions to be recruited
    $positionsStmt = $conn->prepare("
        SELECT SUM(so_luong_tuyen) AS count
        FROM dot_tuyen_dung
    ");
    $positionsStmt->execute();
    $funnelData[0]['count'] = $positionsStmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;

    // Total applicants
    $applicantsStmt = $conn->prepare("
        SELECT COUNT(DISTINCT id_ung_vien) AS count
        FROM ung_vien
    ");
    $applicantsStmt->execute();
    $funnelData[1]['count'] = $applicantsStmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;

    // Applicants with "Chờ phân bổ" status
    $pendingStmt = $conn->prepare("
        SELECT COUNT(*) AS count
        FROM phan_bo_ung_vien
        WHERE trang_thai = 'Chờ phân bổ'
    ");
    $pendingStmt->execute();
    $funnelData[2]['count'] = $pendingStmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;

    // Applicants with "Đã duyệt" status
    $approvedStmt = $conn->prepare("
        SELECT COUNT(*) AS count
        FROM phan_bo_ung_vien
        WHERE trang_thai = 'Đã duyệt'
    ");
    $approvedStmt->execute();
    $funnelData[3]['count'] = $approvedStmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;

    // Calculate percentages
    $total = $funnelData[0]['count'] ?: 1;
    foreach ($funnelData as &$row) {
        $row['percentage'] = ($row['count'] / $total) * 100;
    }
    unset($row);

    error_log("Funnel Data: " . json_encode($funnelData));
} catch (PDOException $e) {
    error_log("Error in funnel query: " . $e->getMessage());
    $funnelData = [];
}

// 3. Kế hoạch tuyển dụng (Recruitment Plan by Department with Status Lines)
try {
    $recruitmentPlanStmt = $conn->prepare("
        SELECT 
            pb.ten_phong_ban,
            COALESCE(dt.trang_thai, 'Không có') AS trang_thai,
            COUNT(DISTINCT uv.id_ung_vien) AS applicant_count,
            COUNT(DISTINCT dt.id_dot_tuyen_dung) AS so_luong_dot,
            COALESCE(SUM(dt.so_luong_tuyen), 0) AS so_luong_tuyen,
            SUM(CASE WHEN dt.trang_thai = 'Đang tiến hành' THEN 1 ELSE 0 END) AS dang_tien_hanh_count,
            SUM(CASE WHEN dt.trang_thai = 'Hoàn thành' THEN 1 ELSE 0 END) AS hoan_thanh_count,
            SUM(CASE WHEN dt.trang_thai = 'Hủy bỏ' THEN 1 ELSE 0 END) AS huy_bo_count
        FROM phong_ban pb
        LEFT JOIN dot_tuyen_dung dt ON dt.id_phong_ban = pb.id_phong_ban
        LEFT JOIN ung_vien uv ON uv.id_dot_tuyen_dung = dt.id_dot_tuyen_dung
        GROUP BY pb.id_phong_ban, pb.ten_phong_ban, dt.trang_thai
        ORDER BY pb.ten_phong_ban, dt.trang_thai
    ");
    $recruitmentPlanStmt->execute();
    $recruitmentPlan = $recruitmentPlanStmt->fetchAll(PDO::FETCH_ASSOC);

    // Get unique departments
    $departments = array_unique(array_column($recruitmentPlan, 'ten_phong_ban'));

    // Initialize planData with datasets for bars and lines
    $planData = [
        ['metric' => 'Số ứng viên', 'counts' => array_fill(0, count($departments), 0)],
        ['metric' => 'Số đợt tuyển dụng', 'counts' => array_fill(0, count($departments), 0)],
        ['metric' => 'Số lượng tuyển', 'counts' => array_fill(0, count($departments), 0)],
        ['metric' => 'Đang tiến hành', 'counts' => array_fill(0, count($departments), 0)],
        ['metric' => 'Hoàn thành', 'counts' => array_fill(0, count($departments), 0)],
        ['metric' => 'Hủy bỏ', 'counts' => array_fill(0, count($departments), 0)],
    ];

    // Aggregate data by department
    foreach ($recruitmentPlan as $row) {
        $deptIndex = array_search($row['ten_phong_ban'], $departments);
        $status = $row['trang_thai'] === 'Không có' ? null : $row['trang_thai'];
        if ($status === 'Đang tiến hành') {
            $planData[0]['counts'][$deptIndex] += $row['applicant_count'];
            $planData[1]['counts'][$deptIndex] += $row['so_luong_dot'];
            $planData[2]['counts'][$deptIndex] += $row['so_luong_tuyen'];
        }
        if ($status) {
            if ($status === 'Đang tiến hành') {
                $planData[3]['counts'][$deptIndex] += $row['dang_tien_hanh_count'];
            } elseif ($status === 'Hoàn thành') {
                $planData[4]['counts'][$deptIndex] += $row['hoan_thanh_count'];
            } elseif ($status === 'Hủy bỏ') {
                $planData[5]['counts'][$deptIndex] += $row['huy_bo_count'];
            }
        }
    }

    error_log("Recruitment Plan Data: " . json_encode($planData));
} catch (PDOException $e) {
    error_log("Error in recruitment plan query: " . $e->getMessage());
    $recruitmentPlan = [];
    $departments = [];
    $planData = [];
}

// 4. Nguồn tuyển dụng (Candidate Sources)
try {
    $sourceStmt = $conn->prepare("
        SELECT COALESCE(nguon_ung_tuyen, 'Không xác định') AS nguon_ung_tuyen,
               COUNT(DISTINCT id_ung_vien) AS count
        FROM ung_vien
        GROUP BY nguon_ung_tuyen
    ");
    $sourceStmt->execute();
    $candidateSources = $sourceStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error in candidate sources query: " . $e->getMessage());
    $candidateSources = [];
}

// 5. Tỷ lệ phân bổ (Allocation Status)
try {
    $allocationStatusStmt = $conn->prepare("
        SELECT trang_thai, COUNT(*) AS count
        FROM phan_bo_ung_vien
        GROUP BY trang_thai
    ");
    $allocationStatusStmt->execute();
    $allocationStatus = $allocationStatusStmt->fetchAll(PDO::FETCH_ASSOC);

    // Initialize counts for the three statuses
    $pendingCount = 0;
    $rejectedCount = 0;
    $approvedCount = 0;

    foreach ($allocationStatus as $status) {
        if ($status['trang_thai'] === 'Từ chối') {
            $rejectedCount += $status['count'];
        } elseif ($status['trang_thai'] === 'Đã duyệt') {
            $approvedCount += $status['count'];
        }
    }

    $allocationData = [
        ['status' => 'Từ chối', 'count' => $rejectedCount],
        ['status' => 'Đã duyệt', 'count' => $approvedCount]
    ];

    error_log("Allocation Data: " . json_encode($allocationData));
} catch (PDOException $e) {
    error_log("Error in allocation status query: " . $e->getMessage());
    $allocationData = [
        ['status' => 'Chờ phân bổ', 'count' => 0],
        ['status' => 'Từ chối', 'count' => 0],
        ['status' => 'Đã duyệt', 'count' => 0]
    ];
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Báo cáo nhân sự | Hệ thống quản lý nhân sự</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        :root {
            --primary-color: #5a67d8;
            --secondary-color: #4c51bf;
            --success-color: #48bb78;
            --danger-color: #f56565;
            --warning-color: #ed8936;
            --info-color: #4299e1;
            --light-color: #f7fafc;
            --dark-color: #1a202c;
            --gray-color: #718096;
            --white-color: #ffffff;
            --border-radius: 8px;
            --box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            --transition: all 0.3s ease-in-out;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f4f7fc;
            color: var(--dark-color);
            line-height: 1.6;
            margin: 0;
        }

        .main-content {
            padding: 10px;
            margin-left: 300px;
            display: grid;
            grid-template-rows: auto 1fr auto;
            gap: 16px;
            max-width: 1300px;
        }

        .charts-container {
            display: grid;
            grid-template-areas:
                "overview funnel allocation"
                "plan plan sources";
            grid-template-columns: 1fr 2fr 1fr;
            grid-template-rows: auto auto;
            gap: 16px;
        }

        .overview { grid-area: overview; }
        .funnel { grid-area: funnel; }
        .allocation { grid-area: allocation; }
        .plan { grid-area: plan; }
        .sources { grid-area: sources; }

        .page-header {
            background: #ffffff;
            padding: 16px;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        .page-title {
            font-size: 24px;
            font-weight: 600;
            color: var(--dark-color);
            margin: 0;
        }

        .filter-form {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .filter-form label {
            font-weight: 500;
            color: var(--gray-color);
            font-size: 14px;
        }

        .filter-form select,
        .filter-form button,
        .export-button {
            padding: 8px 16px;
            border-radius: 6px;
            border: 1px solid #e2e8f0;
            font-size: 14px;
            background: #ffffff;
            transition: var(--transition);
        }

        .filter-form select:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(90, 103, 216, 0.15);
        }

        .filter-form button,
        .export-button {
            background: var(--primary-color);
            color: var(--white-color);
            border: none;
            cursor: pointer;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .filter-form button:hover,
        .export-button:hover {
            background: var(--secondary-color);
            transform: translateY(-1px);
        }

        .chart-card {
            background: #ffffff;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 16px;
            position: relative;
        }

        .chart-card:hover {
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
        }

        .chart-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--dark-color);
            margin: 0 0 12px 0;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .chart-title i {
            color: var(--primary-color);
            font-size: 18px;
        }

        .chart-container {
            position: relative;
            width: 100%;
            height: 300px;
        }

        .funnel .chart-container {
            height: 250px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .funnel .chart-card {
            padding: 20px;
        }

        .funnel-container {
            width: 300px;
            background: #ffffff;
            border-radius: 8px;
            padding: 16px;
            box-shadow: var(--box-shadow);
        }

        .funnel-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 12px;
            text-align: center;
        }

        .stage {
            position: relative;
            margin-bottom: 8px;
        }

        .funnel-shape {
            width: 100%;
            height: 40px;
        }

        .stage-label {
            position: absolute;
            top: 12px;
            left: 0;
            width: 100%;
            color: var(--white-color);
            font-weight: 600;
            font-size: 12px;
            text-align: center;
        }

        .arrow-label {
            position: absolute;
            top: 12px;
            right: -50px;
            font-size: 12px;
            font-weight: 500;
            color: var(--gray-color);
        }

        .overview-stats {
            display: grid;
            grid-template-columns: 1fr;
            gap: 12px;
        }

        .stat-box {
            background: #ffffff;
            border-radius: var(--border-radius);
            padding: 12px;
            text-align: center;
            box-shadow: var(--box-shadow);
        }

        .stat-box h4 {
            font-size: 14px;
            color: var(--gray-color);
            margin: 0 0 8px 0;
        }

        .stat-box p {
            font-size: 20px;
            font-weight: 600;
            color: var(--primary-color);
            margin: 0;
        }

        .no-data {
            text-align: center;
            padding: 16px;
            color: var(--gray-color);
            font-size: 14px;
            background-color: #f9fafb;
            border-radius: var(--border-radius);
        }

        .no-data i {
            font-size: 24px;
            margin-bottom: 8px;
            color: #dee2e6;
        }

        .error-container {
            background-color: #fff5f5;
            border-radius: var(--border-radius);
            margin-bottom: 16px;
            border-left: 4px solid var(--danger-color);
        }

        .error-message {
            padding: 12px;
            color: var(--danger-color);
            font-weight: 500;
        }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 12px;
            padding: 16px 0;
        }

        .pagination button {
            padding: 8px 16px;
            border-radius: 6px;
            background: var(--primary-color);
            color: var(--white-color);
            border: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: var(--transition);
        }

        .pagination button:disabled {
            background: var(--gray-color);
            cursor: not-allowed;
        }

        .pagination button:hover:not(:disabled) {
            background: var(--secondary-color);
            transform: translateY(-1px);
        }

        @media (max-width: 1440px) {
            .main-content {
                margin-left: 220px;
                padding: 20px;
            }
            .charts-container {
                grid-template-columns: 1fr 2fr 1fr;
                gap: 12px;
            }
        }

        @media (max-width: 1200px) {
            .main-content {
                margin-left: 0;
                padding: 16px;
            }
            .charts-container {
                grid-template-areas:
                    "overview"
                    "funnel"
                    "allocation"
                    "plan"
                    "sources";
                grid-template-columns: 1fr;
                gap: 12px;
            }
            .chart-container {
                height: 250px;
            }
            .funnel-container {
                width: 100%;
                max-width: 300px;
            }
        }

        @media (max-width: 768px) {
            .page-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .filter-form {
                width: 100%;
                flex-direction: column;
                gap: 8px;
            }
            .filter-form select,
            .filter-form button,
            .export-button {
                width: 100%;
            }
            .chart-container {
                height: 200px;
            }
            .funnel-container {
                width: 100%;
                max-width: 250px;
            }
            .stage-label {
                font-size: 10px;
            }
            .arrow-label {
                font-size: 10px;
                right: -40px;
            }
            .page-title {
                font-size: 20px;
            }
            .chart-title {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <div class="main-content">
        <div class="page-header">
            <h1 class="page-title">
                <i class="fas fa-chart-line"></i>
                Báo cáo nhân sự
            </h1>
            <form method="GET" action="baocao2.php" class="filter-form">
                <div>
                    <label for="month"><i class="far fa-calendar-alt"></i> Tháng:</label>
                    <select id="month" name="month">
                        <?php for ($m = 1; $m <= 12; $m++): ?>
                            <option value="<?= $m ?>" <?= $m == $month ? 'selected' : '' ?>>
                                Tháng <?= $m ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div>
                    <label for="year"><i class="far fa-calendar"></i> Năm:</label>
                    <select id="year" name="year">
                        <?php for ($y = date('Y') - 5; $y <= date('Y') + 1; $y++): ?>
                            <option value="<?= $y ?>" <?= $y == $year ? 'selected' : '' ?>>
                                <?= $y ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <button type="submit">
                    <i class="fas fa-filter"></i>
                    Lọc dữ liệu
                </button>
                <button type="button" class="export-button" onclick="exportToPDF()">
                    <i class="fas fa-file-pdf"></i>
                    Xuất PDF
                </button>
            </form>
        </div>

        <div class="charts-container">
            <!-- Ô 1: Tổng quan -->
            <div class="overview chart-card">
                <h3 class="chart-title">
                    <i class="fas fa-tachometer-alt"></i>
                    Tổng quan
                </h3>
                <div class="overview-stats">
                    <div class="stat-box">
                        <h4>Tổng đợt tuyển dụng</h4>
                        <p><?= number_format($totalApplicants) ?></p>
                    </div>
                    <div class="stat-box">
                        <h4>Tổng chi phí</h4>
                        <p><?= number_format($totalCosts) ?> VNĐ</p>
                    </div>
                </div>
                <?php if ($totalApplicants == 0 && $totalCosts == 0): ?>
                    <div class="no-data">
                        <i class="fas fa-tachometer-alt"></i>
                        <p>Không có dữ liệu tổng quan</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Ô 2: Phễu tuyển dụng -->
            <div class="funnel chart-card">
                <h3 class="chart-title">
                    <i class="fas fa-filter"></i>
                    Tuyển dụng
                </h3>
                <div class="chart-container">
                    <div class="funnel-container">
                        <div class="funnel-title">Phễu tuyển dụng</div>
                        <?php
                        $widths = [300, 270, 240, 210]; // Chiều rộng đỉnh trên mỗi giai đoạn
                        $containerWidth = 270; // Chiều rộng khung SVG
                        $colors = [
                            'rgb(245, 156, 38)',
                            'rgba(161, 250, 98, 0.87)',
                            'rgba(65, 119, 245, 0.4)',
                            'rgba(191, 109, 239, 0.7)'
                        ];
                        foreach ($funnelData as $index => $stage):
                            $widthTop = $widths[$index];
                            $widthBottom = $index < 3 ? $widths[$index + 1] : $widths[$index];
                            $topLeft = ($containerWidth - $widthTop) / 2;
                            $topRight = ($containerWidth + $widthTop) / 2;
                            $bottomLeft = ($containerWidth - $widthBottom) / 2;
                            $bottomRight = ($containerWidth + $widthBottom) / 2;
                        ?>
                            <div class="stage">
                                <svg class="funnel-shape">
                                    <polygon points="<?= $topLeft ?>,0 <?= $topRight ?>,0 <?= $bottomRight ?>,40 <?= $bottomLeft ?>,40" fill="<?= $colors[$index] ?>"/>
                                </svg>
                                <div class="stage-label"><?= htmlspecialchars($stage['stage']) . ': ' . number_format($stage['count']) ?></div>
                                <?php if ($index < 3): ?>
                                    <div class="arrow-label"><?= number_format($stage['percentage'], 1) ?>%</div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php if (empty($funnelData) || array_sum(array_column($funnelData, 'count')) == 0): ?>
                    <div class="no-data">
                        <i class="fas fa-filter"></i>
                        <p>Không có dữ liệu phễu tuyển dụng</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Ô 5: Tỷ lệ phân bổ -->
            <div class="allocation chart-card">
                <h3 class="chart-title">
                    <i class="fas fa-check-circle"></i>
                    Tỷ lệ phân bổ
                </h3>
                <div class="chart-container">
                    <canvas id="allocationChart"></canvas>
                </div>
                <?php if (empty($allocationData) || array_sum(array_column($allocationData, 'count')) == 0): ?>
                    <div class="no-data">
                        <i class="fas fa-check-circle"></i>
                        <p>Không có dữ liệu tỷ lệ phân bổ</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Ô 3: Kế hoạch tuyển dụng -->
            <div class="plan chart-card">
                <h3 class="chart-title">
                    <i class="fas fa-tasks"></i>
                    Kế hoạch tuyển dụng theo phòng ban
                </h3>
                <div class="chart-container">
                    <canvas id="planChart"></canvas>
                </div>
                <?php if (empty($recruitmentPlan) || !array_sum(array_merge(...array_column($planData, 'counts')))): ?>
                    <div class="no-data">
                        <i class="fas fa-tasks"></i>
                        <p>Không có dữ liệu kế hoạch tuyển dụng</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Ô 4: Nguồn tuyển dụng -->
            <div class="sources chart-card">
                <h3 class="chart-title">
                    <i class="fas fa-users"></i>
                    Nguồn tuyển dụng
                </h3>
                <div class="chart-container">
                    <canvas id="sourcesChart"></canvas>
                </div>
                <?php if (empty($candidateSources)): ?>
                    <div class="no-data">
                        <i class="fas fa-users"></i>
                        <p>Không có dữ liệu nguồn tuyển dụng</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Pagination Buttons -->
        <div class="pagination">
            <button id="prevPage"><i class="fas fa-chevron-left"></i> Trang trước</button>
            <button id="nextPage"><i class="fas fa-chevron-right"></i> Trang sau</button>
        </div>
    </div>

    <script>
        // Debugging: Check if Chart.js is loaded
        if (typeof Chart === 'undefined') {
            console.error('Chart.js không được tải. Kiểm tra liên kết CDN.');
        } else {
            console.log('Chart.js đã được tải thành công.');
        }

        // Register Chart.js datalabels plugin
        try {
            Chart.register(ChartDataLabels);
            console.log('ChartDataLabels plugin đã được đăng ký.');
        } catch (e) {
            console.error('Lỗi khi đăng ký ChartDataLabels:', e);
        }

        const chartColors = {
            primary: {
                main: '#4F46E5',
                light: '#818CF8',
                dark: '#3730A3'
            },
            secondary: {
                main: '#0EA5E9',
                light: '#38BDF8',
                dark: '#0369A1'
            },
            success: {
                main: '#10B981',
                light: '#34D399',
                dark: '#059669'
            },
            danger: {
                main: '#EF4444',
                light: '#F87171',
                dark: '#DC2626'
            },
            warning: {
                main: '#F59E0B',
                light: '#FBBF24',
                dark: '#D97706'
            },
            info: {
                main: '#6366F1',
                light: '#818CF8',
                dark: '#4F46E5'
            },
            neutral: {
                100: '#F3F4F6',
                200: '#E5E7EB',
                300: '#D1D5DB',
                400: '#9CA3AF',
                500: '#6B7280',
                600: '#4B5563',
                700: '#374151',
                800: '#1F2937',
                900: '#111827'
            }
        };

        // Cấu hình chung cho tất cả biểu đồ
        const commonChartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                tooltip: {
                    enabled: true,
                    mode: 'index',
                    intersect: false,
                    backgroundColor: chartColors.neutral[800],
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    borderColor: chartColors.neutral[700],
                    borderWidth: 1,
                    padding: 12,
                    titleFont: {
                        size: 14,
                        weight: 'bold',
                        family: "'Inter', sans-serif"
                    },
                    bodyFont: {
                        size: 13,
                        family: "'Inter', sans-serif"
                    },
                    cornerRadius: 4,
                    displayColors: true,
                    boxPadding: 4
                },
                legend: {
                    position: 'bottom',
                    align: 'center',
                    labels: {
                        padding: 16,
                        font: {
                            size: 12,
                            family: "'Inter', sans-serif"
                        },
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                },
                datalabels: {
                    color: chartColors.neutral[700],
                    font: {
                        size: 11,
                        family: "'Inter', sans-serif",
                        weight: '600'
                    },
                    padding: 6
                }
            },
            animation: {
                duration: 1000,
                easing: 'easeInOutQuart'
            }
        };

        // Ô 3: Kế hoạch tuyển dụng (Mixed Chart)
        const planData = {
            labels: [<?php foreach ($departments as $dept) echo "'" . addslashes($dept) . "',"; ?>],
            datasets: [
                {
                    label: 'Số ứng viên',
                    data: [<?php echo implode(',', $planData[0]['counts']); ?>],
                    backgroundColor: chartColors.primary.light,
                    borderColor: chartColors.primary.main,
                    borderWidth: 2,
                    borderRadius: 6,
                    type: 'bar',
                    order: 2,
                    barPercentage: 0.6,
                    categoryPercentage: 0.8
                },
                {
                    label: 'Số đợt tuyển dụng',
                    data: [<?php echo implode(',', $planData[1]['counts']); ?>],
                    backgroundColor: chartColors.secondary.light,
                    borderColor: chartColors.secondary.main,
                    borderWidth: 2,
                    borderRadius: 6,
                    type: 'bar',
                    order: 2
                },
                {
                    label: 'Số lượng tuyển',
                    data: [<?php echo implode(',', $planData[2]['counts']); ?>],
                    backgroundColor: chartColors.success.light,
                    borderColor: chartColors.success.main,
                    borderWidth: 2,
                    borderRadius: 6,
                    type: 'bar',
                    order: 2
                },
                {
                    label: 'Đang tiến hành',
                    data: [<?php echo implode(',', $planData[3]['counts']); ?>],
                    borderColor: chartColors.warning.main,
                    backgroundColor: `${chartColors.warning.light}40`,
                    borderWidth: 2,
                    type: 'line',
                    fill: true,
                    tension: 0.4,
                    pointStyle: 'circle',
                    pointRadius: 4,
                    pointHoverRadius: 6,
                    order: 1
                },
                {
                    label: 'Hoàn thành',
                    data: [<?php echo implode(',', $planData[4]['counts']); ?>],
                    borderColor: chartColors.success.main,
                    backgroundColor: `${chartColors.success.light}40`,
                    borderWidth: 2,
                    type: 'line',
                    fill: true,
                    tension: 0.4,
                    pointStyle: 'rectRot',
                    pointRadius: 4,
                    pointHoverRadius: 6,
                    order: 1
                },
                {
                    label: 'Hủy bỏ',
                    data: [<?php echo implode(',', $planData[5]['counts']); ?>],
                    borderColor: chartColors.danger.main,
                    backgroundColor: `${chartColors.danger.light}40`,
                    borderWidth: 2,
                    type: 'line',
                    fill: true,
                    tension: 0.4,
                    pointStyle: 'triangle',
                    pointRadius: 4,
                    pointHoverRadius: 6,
                    order: 1
                }
            ]
        };

        // Ô 4: Nguồn tuyển dụng (Doughnut Chart)
        const sourcesData = {
            labels: [<?php foreach ($candidateSources as $row) echo "'" . addslashes($row['nguon_ung_tuyen']) . "',"; ?>],
            datasets: [{
                data: [<?php foreach ($candidateSources as $row) echo $row['count'] . ","; ?>],
                backgroundColor: [
                    chartColors.primary.main,
                    chartColors.success.main,
                    chartColors.warning.main,
                    chartColors.danger.main,
                    chartColors.info.main,
                    chartColors.secondary.main
                ],
                borderColor: '#ffffff',
                borderWidth: 2,
                hoverOffset: 4
            }]
        };

        // Ô 5: Tỷ lệ phân bổ (Pie Chart with gradient)
        const allocationData = {
            labels: [<?php foreach ($allocationData as $row) echo "'" . addslashes($row['status']) . "',"; ?>],
            datasets: [{
                data: [<?php foreach ($allocationData as $row) echo $row['count'] . ","; ?>],
                backgroundColor: [
                    chartColors.danger.main,
                    chartColors.success.main
                ],
                borderColor: '#ffffff',
                borderWidth: 2,
                hoverOffset: 4
            }]
        };

        // Khởi tạo biểu đồ kế hoạch tuyển dụng
        if (planData.labels.length && planData.datasets.some(ds => ds.data.some(val => val > 0))) {
            new Chart(document.getElementById('planChart'), {
                type: 'bar',
                data: planData,
                options: {
                    ...commonChartOptions,
                    scales: {
                        x: {
                            grid: {
                                display: false,
                                drawBorder: false
                            },
                            ticks: {
                                font: {
                                    size: 12,
                                    family: "'Inter', sans-serif"
                                },
                                color: chartColors.neutral[600],
                                maxRotation: 45,
                                minRotation: 45
                            }
                        },
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: chartColors.neutral[200],
                                drawBorder: false
                            },
                            ticks: {
                                font: {
                                    size: 12,
                                    family: "'Inter', sans-serif"
                                },
                                color: chartColors.neutral[600],
                                padding: 10
                            }
                        }
                    },
                    plugins: {
                        ...commonChartOptions.plugins,
                        datalabels: {
                            anchor: 'end',
                            align: 'top',
                            formatter: (value, context) => {
                                return context.dataset.type === 'bar' && value > 0 ? value : '';
                            },
                            color: chartColors.neutral[700]
                        }
                    }
                }
            });
        }

        // Khởi tạo biểu đồ nguồn tuyển dụng
        if (sourcesData.datasets[0].data.length && sourcesData.datasets[0].data.some(val => val > 0)) {
            new Chart(document.getElementById('sourcesChart'), {
                type: 'doughnut',
                data: sourcesData,
                options: {
                    ...commonChartOptions,
                    cutout: '60%',
                    radius: '90%',
                    plugins: {
                        ...commonChartOptions.plugins,
                        datalabels: {
                            formatter: (value, context) => {
                                const sum = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / sum) * 100).toFixed(1);
                                return percentage > 5 ? `${percentage}%` : '';
                            },
                            color: '#fff',
                            font: {
                                weight: 'bold'
                            }
                        },
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                usePointStyle: true
                            }
                        }
                    }
                }
            });
        }

        // Khởi tạo biểu đồ tỷ lệ phân bổ
        if (allocationData.datasets[0].data.length && allocationData.datasets[0].data.some(val => val > 0)) {
            new Chart(document.getElementById('allocationChart'), {
                type: 'pie',
                data: allocationData,
                options: {
                    ...commonChartOptions,
                    radius: '90%',
                    plugins: {
                        ...commonChartOptions.plugins,
                        datalabels: {
                            formatter: (value, context) => {
                                const sum = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / sum) * 100).toFixed(1);
                                return `${percentage}%\n(${value})`;
                            },
                            color: '#fff',
                            font: {
                                weight: 'bold'
                            },
                            textAlign: 'center'
                        },
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                usePointStyle: true
                            }
                        }
                    }
                }
            });
        }

        // Pagination
        document.getElementById('prevPage').addEventListener('click', () => {
            const month = document.getElementById('month').value;
            const year = document.getElementById('year').value;
            window.location.href = `baocao1.php?month=${month}&year=${year}`;
        });

        document.getElementById('nextPage').addEventListener('click', () => {
            const month = document.getElementById('month').value;
            const year = document.getElementById('year').value;
            window.location.href = `baocao.php?month=${month}&year=${year}`;
        });

        // Export to PDF
        function exportToPDF() {
            try {
                const element = document.querySelector('.main-content');
                const opt = {
                    margin: [10, 10, 10, 10],
                    filename: `bao_cao_nhan_su_${new Date().toISOString().slice(0,10)}.pdf`,
                    image: { type: 'jpeg', quality: 0.98 },
                    html2canvas: { scale: 2, useCORS: true },
                    jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
                };
                html2pdf().set(opt).from(element).save();
                console.log('Đã bắt đầu xuất PDF.');
            } catch (e) {
                console.error('Lỗi khi xuất PDF:', e);
            }
        }
    </script>
</body>
</html>