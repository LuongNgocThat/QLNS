-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th5 25, 2025 lúc 11:44 AM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `doanqlns`
--

DELIMITER $$
--
-- Thủ tục
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ApproveLeaveRequest` (IN `p_id_nghi_phep` INT, IN `p_id_nguoi_duyet` INT, IN `p_trang_thai` ENUM('Đã duyệt','Từ chối'))   BEGIN
  DECLARE v_id_nhan_vien INT;
  DECLARE v_thang VARCHAR(7);

  -- Lấy thông tin nhân viên và tháng
  SELECT `id_nhan_vien`, DATE_FORMAT(`ngay_bat_dau`, '%Y-%m')
  INTO v_id_nhan_vien, v_thang
  FROM `nghi_phep`
  WHERE `id_nghi_phep` = p_id_nghi_phep;

  -- Cập nhật yêu cầu nghỉ phép
  UPDATE `nghi_phep`
  SET
    `trang_thai` = p_trang_thai,
    `id_nguoi_duyet` = p_id_nguoi_duyet,
    `ngay_duyet` = NOW()
  WHERE `id_nghi_phep` = p_id_nghi_phep;

  -- Tính lại ngày nghỉ nếu được duyệt
  IF p_trang_thai = 'Đã duyệt' THEN
    CALL `CalculateLeaveDays`(v_id_nhan_vien, v_thang);
  END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculateInsuranceAndTax` (IN `p_id_nhan_vien` INT, IN `p_thang` VARCHAR(7), IN `p_luong_co_ban` DECIMAL(12,2))   BEGIN
  DECLARE v_bhxh DECIMAL(12,2);
  DECLARE v_bhyt DECIMAL(12,2);
  DECLARE v_bhtn DECIMAL(12,2);
  DECLARE v_thue_tncn DECIMAL(12,2);
  DECLARE v_thu_nhap_chiu_thue DECIMAL(12,2);

  -- Tính các khoản bảo hiểm
  SET v_bhxh = p_luong_co_ban * 0.08; -- 8% bảo hiểm xã hội
  SET v_bhyt = p_luong_co_ban * 0.015; -- 1.5% bảo hiểm y tế
  SET v_bhtn = p_luong_co_ban * 0.01; -- 1% bảo hiểm thất nghiệp

  -- Tính thu nhập chịu thuế
  SET v_thu_nhap_chiu_thue = p_luong_co_ban - v_bhxh - v_bhyt - v_bhtn;

  -- Tính thuế TNCN theo biểu lũy tiến (đơn giản hóa)
  SET v_thue_tncn = CASE
    WHEN v_thu_nhap_chiu_thue <= 0 THEN 0
    WHEN v_thu_nhap_chiu_thue <= 5000000 THEN v_thu_nhap_chiu_thue * 0.05
    WHEN v_thu_nhap_chiu_thue <= 10000000 THEN v_thu_nhap_chiu_thue * 0.10
    WHEN v_thu_nhap_chiu_thue <= 18000000 THEN v_thu_nhap_chiu_thue * 0.15
    WHEN v_thu_nhap_chiu_thue <= 32000000 THEN v_thu_nhap_chiu_thue * 0.20
    WHEN v_thu_nhap_chiu_thue <= 52000000 THEN v_thu_nhap_chiu_thue * 0.25
    WHEN v_thu_nhap_chiu_thue <= 80000000 THEN v_thu_nhap_chiu_thue * 0.30
    ELSE v_thu_nhap_chiu_thue * 0.35
  END;

  -- Cập nhật hoặc chèn vào bao_hiem_thue_tncn
  INSERT INTO `bao_hiem_thue_tncn` (
    `id_nhan_vien`, `thang`, `bhxh`, `bhyt`, `bhtn`, `thue_tncn`
  )
  VALUES (
    p_id_nhan_vien, p_thang, v_bhxh, v_bhyt, v_bhtn, v_thue_tncn
  )
  ON DUPLICATE KEY UPDATE
    `bhxh` = v_bhxh,
    `bhyt` = v_bhyt,
    `bhtn` = v_bhtn,
    `thue_tncn` = v_thue_tncn;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculateLeaveDays` (IN `p_id_nhan_vien` INT, IN `p_thang` VARCHAR(7))   BEGIN
  DECLARE v_ngay_nghi_phep INT DEFAULT 0;
  DECLARE v_ngay_nghi_khong_phep INT DEFAULT 0;

  -- Tính số ngày nghỉ có phép
  SELECT COUNT(DISTINCT DATE(`ngay_bat_dau`)) INTO v_ngay_nghi_phep
  FROM `nghi_phep`
  WHERE `id_nhan_vien` = p_id_nhan_vien
    AND `trang_thai` = 'Đã duyệt'
    AND `loai_nghi` = 'Có phép'
    AND `ngay_bat_dau` LIKE CONCAT(p_thang, '%');

  -- Tính số ngày nghỉ không phép
  SELECT COUNT(DISTINCT DATE(`ngay_bat_dau`)) INTO v_ngay_nghi_khong_phep
  FROM `nghi_phep`
  WHERE `id_nhan_vien` = p_id_nhan_vien
    AND `trang_thai` = 'Đã duyệt'
    AND `loai_nghi` = 'Không phép'
    AND `ngay_bat_dau` LIKE CONCAT(p_thang, '%');

  -- Cập nhật tong_hop_cong_thang
  UPDATE `tong_hop_cong_thang`
  SET
    `ngay_nghi_phep` = v_ngay_nghi_phep
  WHERE `id_nhan_vien` = p_id_nhan_vien
    AND `thang` = p_thang;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculatePayroll` (IN `p_id_nhan_vien` INT, IN `p_thang` VARCHAR(7), IN `p_lam_them` DECIMAL(5,0))   BEGIN
    DECLARE v_luong_co_ban DECIMAL(12,0);
    DECLARE v_phu_cap_chuc_vu DECIMAL(12,0);
    DECLARE v_cac_khoan_tru DECIMAL(12,0);
    DECLARE v_so_ngay_cong DECIMAL(5,2) DEFAULT 0;
    DECLARE v_tien_thuong DECIMAL(12,0) DEFAULT 0;
    DECLARE v_luong_thuc_nhan DECIMAL(12,0);
    DECLARE v_so_ngay_trong_thang INT;
    DECLARE v_diem_danh_days DECIMAL(5,2) DEFAULT 0;
    DECLARE v_nghi_days DECIMAL(5,2) DEFAULT 0;

    -- Lấy thông tin nhân viên
    SELECT n.luong_co_ban, COALESCE(cv.phu_cap, 0)
    INTO v_luong_co_ban, v_phu_cap_chuc_vu
    FROM nhan_vien n
    LEFT JOIN chuc_vu cv ON n.id_chuc_vu = cv.id_chuc_vu
    WHERE n.id_nhan_vien = p_id_nhan_vien;

    -- Xác định số ngày trong tháng
    SET v_so_ngay_trong_thang = DAY(LAST_DAY(STR_TO_DATE(CONCAT(p_thang, '-01'), '%Y-%m-%d')));

    -- Tính tổng ngày công từ bảng cham_cong
    SELECT 
        SUM(CASE 
            WHEN trang_thai = 'Đúng giờ' THEN 1
            WHEN trang_thai = 'Đi trễ' THEN 0.5
            ELSE 0
        END) AS diem_danh,
        SUM(CASE 
            WHEN trang_thai = 'Có phép' THEN 0.5
            WHEN trang_thai = 'Không phép' THEN 1
            ELSE 0
        END) AS nghi
    INTO v_diem_danh_days, v_nghi_days
    FROM cham_cong
    WHERE id_nhan_vien = p_id_nhan_vien
      AND DATE_FORMAT(ngay_lam_viec, '%Y-%m') = p_thang
      AND trang_thai IN ('Đúng giờ', 'Đi trễ', 'Có phép', 'Không phép');

    -- Tính tổng ngày công
    SET v_so_ngay_cong = COALESCE(v_diem_danh_days, 0) - COALESCE(v_nghi_days, 0);

    -- Tính lại lương cơ bản dựa trên số ngày công
    SET v_luong_co_ban = ROUND((v_luong_co_ban / v_so_ngay_trong_thang) * COALESCE(v_so_ngay_cong, 0), 0);

    -- Lấy các khoản trừ
    SELECT tong_khoan_tru INTO v_cac_khoan_tru
    FROM bao_hiem_thue_tncn
    WHERE id_nhan_vien = p_id_nhan_vien
      AND thang = p_thang;

    -- Lấy tổng tiền thưởng từ bảng thuong
    SELECT COALESCE(SUM(tien_thuong), 0) INTO v_tien_thuong
    FROM `thuong`
    WHERE id_nhan_vien = p_id_nhan_vien
      AND DATE_FORMAT(ngay, '%Y-%m') = p_thang;

    -- Tính lương thực nhận (không bao gồm lương làm thêm)
    SET v_luong_thuc_nhan = COALESCE(v_luong_co_ban, 0) +
                            COALESCE(v_phu_cap_chuc_vu, 0) +
                            COALESCE(v_tien_thuong, 0) -
                            COALESCE(v_cac_khoan_tru, 0);

    -- Cập nhật hoặc chèn vào bảng luong (không có cột luong_lam_them)
    INSERT INTO luong (
        id_nhan_vien, thang, so_ngay_cong, luong_co_ban, phu_cap_chuc_vu,
        tien_thuong, cac_khoan_tru, luong_thuc_nhan, trang_thai
    )
    VALUES (
        p_id_nhan_vien, p_thang, v_so_ngay_cong, v_luong_co_ban, v_phu_cap_chuc_vu,
        v_tien_thuong, COALESCE(v_cac_khoan_tru, 0), v_luong_thuc_nhan, 'Tạm tính'
    )
    ON DUPLICATE KEY UPDATE
        so_ngay_cong = v_so_ngay_cong,
        luong_co_ban = v_luong_co_ban,
        phu_cap_chuc_vu = v_phu_cap_chuc_vu,
        tien_thuong = v_tien_thuong,
        cac_khoan_tru = COALESCE(v_cac_khoan_tru, 0),
        luong_thuc_nhan = v_luong_thuc_nhan,
        trang_thai = 'Tạm tính';
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bao_hiem_thue_tncn`
--

CREATE TABLE `bao_hiem_thue_tncn` (
  `id` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `thang` varchar(7) NOT NULL,
  `bhxh` decimal(12,0) NOT NULL DEFAULT 0,
  `bhyt` decimal(12,0) NOT NULL DEFAULT 0,
  `bhtn` decimal(12,0) NOT NULL DEFAULT 0,
  `thue_tncn` decimal(12,0) NOT NULL DEFAULT 0,
  `tong_khoan_tru` decimal(12,0) GENERATED ALWAYS AS (`bhxh` + `bhyt` + `bhtn` + `thue_tncn`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `bao_hiem_thue_tncn`
--

INSERT INTO `bao_hiem_thue_tncn` (`id`, `id_nhan_vien`, `thang`, `bhxh`, `bhyt`, `bhtn`, `thue_tncn`) VALUES
(1, 1, '2025-05', 50000, 50000, 50000, 3000000),
(3, 3, '2025-05', 60000, 65000, 75000, 2500000);

--
-- Bẫy `bao_hiem_thue_tncn`
--
DELIMITER $$
CREATE TRIGGER `capnhat_cac_khoan_tru` AFTER UPDATE ON `bao_hiem_thue_tncn` FOR EACH ROW BEGIN
  UPDATE luong
  SET cac_khoan_tru = NEW.tong_khoan_tru
  WHERE id_nhan_vien = NEW.id_nhan_vien AND thang = NEW.thang;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cham_cong`
--

CREATE TABLE `cham_cong` (
  `id_cham_cong` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `ngay_lam_viec` date NOT NULL,
  `gio_vao` time DEFAULT NULL,
  `gio_ra` time DEFAULT NULL,
  `trang_thai` enum('Đúng giờ','Đi trễ','Có phép','Không phép') DEFAULT NULL,
  `ghi_chu` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `cham_cong`
--

INSERT INTO `cham_cong` (`id_cham_cong`, `id_nhan_vien`, `ngay_lam_viec`, `gio_vao`, `gio_ra`, `trang_thai`, `ghi_chu`) VALUES
(271, 1, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(272, 1, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(273, 1, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(274, 1, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(275, 2, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(276, 2, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(277, 2, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(278, 2, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(279, 3, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(280, 3, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(281, 3, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(282, 3, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(283, 4, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(284, 4, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(285, 4, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(286, 4, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(287, 5, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(288, 5, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(289, 5, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(290, 5, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(291, 6, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(292, 6, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(293, 6, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(294, 6, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(295, 7, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(296, 7, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(297, 7, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(298, 7, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(299, 8, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(300, 8, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(301, 8, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(302, 8, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(303, 9, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(304, 9, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(305, 9, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(306, 9, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(307, 10, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(308, 10, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(309, 10, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(310, 10, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(311, 11, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(312, 11, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(313, 11, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(314, 11, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(315, 12, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(316, 12, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(317, 12, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(318, 12, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(319, 13, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(320, 13, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(321, 13, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(322, 13, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(323, 14, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(324, 14, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(325, 14, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(326, 14, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(327, 15, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(328, 15, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(329, 15, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(330, 15, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(331, 16, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(332, 16, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(333, 16, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(334, 16, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(335, 17, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(336, 17, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(337, 17, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(338, 17, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(339, 18, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(340, 18, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(341, 18, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(342, 18, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(343, 19, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(344, 19, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(345, 19, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(346, 19, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(347, 20, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(348, 20, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(349, 20, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(350, 20, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(351, 21, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(352, 21, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(353, 21, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(354, 21, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(355, 22, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(356, 22, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(357, 22, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(358, 22, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(359, 1, '2025-05-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(360, 2, '2025-05-06', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(361, 3, '2025-05-06', '00:00:00', '00:00:00', 'Có phép', NULL),
(362, 1, '2025-05-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(363, 2, '2025-05-03', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(364, 1, '2025-05-01', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(365, 4, '2025-05-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(366, 1, '2025-05-07', '00:00:00', '00:00:00', 'Đúng giờ', NULL),
(367, 1, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(368, 1, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(369, 1, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(370, 1, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(371, 2, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(372, 2, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(373, 2, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(374, 2, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(375, 3, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(376, 3, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(377, 3, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(378, 3, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(379, 4, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(380, 4, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(381, 4, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(382, 4, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(383, 5, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(384, 5, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(385, 5, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(386, 5, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(387, 6, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(388, 6, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(389, 6, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(390, 6, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(391, 7, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(392, 7, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(393, 7, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(394, 7, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(395, 8, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(396, 8, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(397, 8, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(398, 8, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(399, 9, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(400, 9, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(401, 9, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(402, 9, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(403, 10, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(404, 10, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(405, 10, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(406, 10, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(407, 11, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(408, 11, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(409, 11, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(410, 11, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(411, 12, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(412, 12, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(413, 12, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(414, 12, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(415, 13, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(416, 13, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(417, 13, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(418, 13, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(419, 14, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(420, 14, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(421, 14, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(422, 14, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(423, 15, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(424, 15, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(425, 15, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(426, 15, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(427, 16, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(428, 16, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(429, 16, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(430, 16, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(431, 17, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(432, 17, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(433, 17, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(434, 17, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(435, 18, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(436, 18, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(437, 18, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(438, 18, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(439, 19, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(440, 19, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(441, 19, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(442, 19, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(443, 20, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(444, 20, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(445, 20, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(446, 20, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(447, 21, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(448, 21, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(449, 21, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(450, 21, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(451, 1, '2025-05-05', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(452, 1, '2025-05-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(453, 2, '2025-05-07', '08:00:00', '17:00:00', 'Đi trễ', NULL),
(454, 22, '2025-04-06', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(455, 22, '2025-04-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(456, 22, '2025-04-20', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(457, 22, '2025-04-27', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(458, 1, '2025-05-08', NULL, NULL, 'Có phép', ''),
(459, 1, '2025-05-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(460, 2, '2025-05-01', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(469, 1, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(470, 1, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(471, 1, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(472, 1, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(473, 1, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(474, 2, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(475, 2, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(476, 2, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(477, 2, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(478, 2, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(479, 3, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(480, 3, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(481, 3, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(482, 3, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(483, 3, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(484, 4, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(485, 4, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(486, 4, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(487, 4, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(488, 4, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(489, 5, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(490, 5, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(491, 5, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(492, 5, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(493, 5, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(494, 6, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(495, 6, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(496, 6, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(497, 6, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(498, 6, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(499, 7, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(500, 7, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(501, 7, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(502, 7, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(503, 7, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(504, 8, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(505, 8, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(506, 8, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(507, 8, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(508, 8, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(509, 9, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(510, 9, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(511, 9, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(512, 9, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(513, 9, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(514, 10, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(515, 10, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(516, 10, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(517, 10, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(518, 10, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(519, 11, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(520, 11, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(521, 11, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(522, 11, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(523, 11, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(524, 12, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(525, 12, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(526, 12, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(527, 12, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(528, 12, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(529, 13, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(530, 13, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(531, 13, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(532, 13, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(533, 13, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(534, 14, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(535, 14, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(536, 14, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(537, 14, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(538, 14, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(539, 15, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(540, 15, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(541, 15, '2025-03-16', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(542, 15, '2025-03-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(543, 15, '2025-03-30', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(544, 16, '2025-03-02', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(545, 16, '2025-03-09', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(550, 1, '2025-05-10', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(551, 1, '2025-05-12', NULL, NULL, 'Có phép', ''),
(560, 1, '2025-05-24', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(561, 1, '2025-05-23', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(562, 1, '2025-05-14', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(563, 1, '2025-05-16', NULL, NULL, 'Có phép', ''),
(564, 1, '2025-05-15', NULL, NULL, 'Có phép', ''),
(565, 1, '2025-05-17', NULL, NULL, 'Có phép', ''),
(566, 1, '2025-05-22', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(567, 1, '2025-05-13', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(568, 1, '2025-05-26', NULL, NULL, 'Có phép', ''),
(569, 1, '2025-05-27', NULL, NULL, 'Có phép', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chi_phi_tuyen_dung`
--

CREATE TABLE `chi_phi_tuyen_dung` (
  `id_chi_phi` int(11) NOT NULL,
  `id_dot_tuyen_dung` int(11) NOT NULL,
  `noi_dung_chi_phi` varchar(255) NOT NULL,
  `so_tien` decimal(12,2) NOT NULL,
  `ngay_chi` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `chi_phi_tuyen_dung`
--

INSERT INTO `chi_phi_tuyen_dung` (`id_chi_phi`, `id_dot_tuyen_dung`, `noi_dung_chi_phi`, `so_tien`, `ngay_chi`) VALUES
(1, 1, 'Chi phí quảng cáo tuyển dụng', 5000000.00, '2025-05-01');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chuc_vu`
--

CREATE TABLE `chuc_vu` (
  `id_chuc_vu` int(11) NOT NULL,
  `ten_chuc_vu` varchar(100) NOT NULL,
  `mo_ta` text DEFAULT NULL,
  `phu_cap` decimal(12,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `chuc_vu`
--

INSERT INTO `chuc_vu` (`id_chuc_vu`, `ten_chuc_vu`, `mo_ta`, `phu_cap`) VALUES
(1, 'Nhân viên', 'Nhân viên cấp cơ sở', 3000000.00),
(3, 'Phó trưởng phòng', 'Quản lý phòng ban', 10000000.00),
(4, 'Trưởng phòng', 'Quản lý cấp cao', 15000000.00),
(5, 'Thực tập sinh', 'Nhân viên thực tập', 0.00);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danh_gia_ung_vien`
--

CREATE TABLE `danh_gia_ung_vien` (
  `id_danh_gia` int(11) NOT NULL,
  `id_ung_vien` int(11) NOT NULL,
  `id_ke_hoach` int(11) NOT NULL,
  `vong_thi` varchar(255) NOT NULL,
  `diem` decimal(5,2) NOT NULL,
  `nhan_xet` text DEFAULT NULL,
  `ngay_danh_gia` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `danh_gia_ung_vien`
--

INSERT INTO `danh_gia_ung_vien` (`id_danh_gia`, `id_ung_vien`, `id_ke_hoach`, `vong_thi`, `diem`, `nhan_xet`, `ngay_danh_gia`) VALUES
(1, 1, 1, 'Vòng 1: Phỏng vấn kỹ năng', 9.00, 'Ứng viên có kỹ năng giao tiếp tốt', '2025-05-10');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `dot_tuyen_dung`
--

CREATE TABLE `dot_tuyen_dung` (
  `id_dot_tuyen_dung` int(11) NOT NULL,
  `ma_dot` varchar(50) NOT NULL,
  `ten_dot` varchar(255) NOT NULL,
  `so_luong_tuyen` int(11) NOT NULL,
  `id_can_bo_tuyen_dung` int(11) NOT NULL,
  `ngay_bat_dau` date NOT NULL,
  `ngay_ket_thuc` date NOT NULL,
  `yeu_cau_vi_tri` text DEFAULT NULL,
  `trang_thai` enum('Đang tiến hành','Hoàn thành','Hủy bỏ') DEFAULT 'Đang tiến hành',
  `id_phong_ban` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `dot_tuyen_dung`
--

INSERT INTO `dot_tuyen_dung` (`id_dot_tuyen_dung`, `ma_dot`, `ten_dot`, `so_luong_tuyen`, `id_can_bo_tuyen_dung`, `ngay_bat_dau`, `ngay_ket_thuc`, `yeu_cau_vi_tri`, `trang_thai`, `id_phong_ban`) VALUES
(1, 'TD2025-0122ss', 'Đợt tuyển dụng Q1 2025', 5, 1, '2025-05-01', '2025-05-15', 'Có kinh nghiệm 2 năm trở lên', 'Đang tiến hành', 1),
(8, 'TU-160s', 'CEOa', 3, 1, '2025-05-10', '2025-05-14', 'kinh nghiệm 2 năm', 'Đang tiến hành', 3);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `ke_hoach_tuyen_dung`
--

CREATE TABLE `ke_hoach_tuyen_dung` (
  `id_ke_hoach` int(11) NOT NULL,
  `id_chuc_vu` int(11) NOT NULL,
  `so_vong_thi` int(2) NOT NULL,
  `ten_vong_thi` varchar(255) NOT NULL,
  `noi_dung_thi` text DEFAULT NULL,
  `diem_chuan` decimal(5,2) NOT NULL,
  `trong_so` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `ke_hoach_tuyen_dung`
--

INSERT INTO `ke_hoach_tuyen_dung` (`id_ke_hoach`, `id_chuc_vu`, `so_vong_thi`, `ten_vong_thi`, `noi_dung_thi`, `diem_chuan`, `trong_so`) VALUES
(1, 1, 2, 'Vòng 1: Phỏng vấn kỹ năng', 'Kiểm tra kỹ năng giao tiếp và chuyên môn', 7.50, 0.60);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lich_hen_ung_vien`
--

CREATE TABLE `lich_hen_ung_vien` (
  `id_lich_hen` int(11) NOT NULL,
  `id_ung_vien` int(11) NOT NULL,
  `ngay_hen` date NOT NULL,
  `gio_hen` time NOT NULL,
  `dia_diem` varchar(255) NOT NULL,
  `ghi_chu` text DEFAULT NULL,
  `trang_thai` enum('Chờ lên lịch','Từ chối','Đã duyệt') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `lich_hen_ung_vien`
--

INSERT INTO `lich_hen_ung_vien` (`id_lich_hen`, `id_ung_vien`, `ngay_hen`, `gio_hen`, `dia_diem`, `ghi_chu`, `trang_thai`) VALUES
(1, 1, '2025-05-13', '09:00:00', 'Phòng họp 1', 'Mang theo CV và giấy tờ tùy thân', 'Đã duyệt');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `luong`
--

CREATE TABLE `luong` (
  `id_luong` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `thang` varchar(7) NOT NULL,
  `so_ngay_cong` decimal(12,2) NOT NULL,
  `luong_co_ban` decimal(12,0) NOT NULL,
  `phu_cap_chuc_vu` decimal(12,0) DEFAULT 0,
  `tien_thuong` decimal(12,0) DEFAULT 0,
  `cac_khoan_tru` decimal(12,0) DEFAULT 0,
  `luong_thuc_nhan` decimal(12,0) GENERATED ALWAYS AS (`luong_co_ban` * `so_ngay_cong` / 26 + `phu_cap_chuc_vu` + `tien_thuong` - `cac_khoan_tru`) STORED,
  `ngay_cham_cong` date NOT NULL,
  `trang_thai` enum('Tạm tính','Đã thanh toán') DEFAULT 'Tạm tính'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `luong`
--

INSERT INTO `luong` (`id_luong`, `id_nhan_vien`, `thang`, `so_ngay_cong`, `luong_co_ban`, `phu_cap_chuc_vu`, `tien_thuong`, `cac_khoan_tru`, `ngay_cham_cong`, `trang_thai`) VALUES
(1, 1, '2025-05', 20.50, 6612903, 3000000, 1500000, 3150000, '2025-05-06', 'Tạm tính'),
(2, 2, '2025-05', 7.25, 4677419, 10000000, 0, 0, '2025-05-06', ''),
(3, 3, '2025-05', 4.50, 3629032, 15000000, 0, 2700000, '2025-05-06', ''),
(4, 4, '2025-05', 5.00, 2419355, 15000000, 0, 0, '2025-05-06', ''),
(5, 5, '2025-05', 4.00, 2193548, 15000000, 0, 0, '2025-05-06', ''),
(6, 6, '2025-05', 4.00, 1806452, 3000000, 0, 0, '2025-05-06', ''),
(7, 7, '2025-05', 4.00, 2064516, 15000000, 0, 0, '2025-05-06', ''),
(8, 8, '2025-05', 4.00, 1032258, 3000000, 0, 0, '2025-05-06', ''),
(9, 9, '2025-05', 4.00, 1419355, 10000000, 0, 0, '2025-05-06', ''),
(10, 10, '2025-05', 4.00, 1806452, 10000000, 0, 0, '2025-05-06', ''),
(11, 11, '2025-05', 4.00, 645161, 0, 0, 0, '2025-05-06', ''),
(12, 12, '2025-05', 4.00, 1225806, 3000000, 0, 0, '2025-05-06', ''),
(13, 13, '2025-05', 4.00, 2322581, 10000000, 0, 0, '2025-05-06', ''),
(14, 14, '2025-05', 4.00, 1032258, 3000000, 0, 0, '2025-05-06', ''),
(15, 15, '2025-05', 4.00, 903226, 3000000, 0, 0, '2025-05-06', ''),
(16, 16, '2025-05', 4.00, 1096774, 3000000, 0, 0, '2025-05-06', ''),
(17, 17, '2025-05', 4.00, 516129, 0, 0, 0, '2025-05-06', ''),
(18, 18, '2025-05', 4.00, 903226, 0, 0, 0, '2025-05-06', ''),
(19, 19, '2025-05', 4.00, 451613, 0, 0, 0, '2025-05-06', ''),
(20, 20, '2025-05', 4.00, 387097, 0, 0, 0, '2025-05-06', ''),
(21, 21, '2025-05', 4.00, 2193548, 3000000, 0, 0, '2025-05-06', ''),
(22, 22, '2025-05', 4.00, 1290323, 10000000, 0, 0, '2025-05-06', ''),
(24, 1, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(25, 2, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(26, 3, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(27, 4, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(28, 5, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(29, 6, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(30, 7, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(31, 8, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(32, 9, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(33, 10, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(34, 11, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(35, 12, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(36, 13, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(37, 14, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(38, 15, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(39, 16, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(40, 17, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(41, 18, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(42, 19, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(43, 20, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(44, 21, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-07', ''),
(46, 22, '2025-04', 4.00, 0, 0, 0, 0, '2025-05-08', ''),
(52, 1, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(53, 2, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(54, 3, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(55, 4, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(56, 5, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(57, 6, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(58, 7, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(59, 8, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(60, 9, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(61, 10, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(62, 11, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(63, 12, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(64, 13, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(65, 14, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(66, 15, '2025-03', 5.00, 0, 0, 0, 0, '2025-05-09', ''),
(67, 16, '2025-03', 2.00, 0, 0, 0, 0, '2025-05-09', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nghi_phep`
--

CREATE TABLE `nghi_phep` (
  `id_nghi_phep` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `ngay_bat_dau` date NOT NULL,
  `ngay_ket_thuc` date NOT NULL,
  `loai_nghi` enum('Có phép','Không phép') DEFAULT 'Có phép',
  `ly_do` text DEFAULT NULL,
  `trang_thai1` enum('Chờ duyệt','Đã duyệt','Từ chối') DEFAULT 'Chờ duyệt',
  `id_nguoi_duyet` int(11) DEFAULT NULL,
  `ly_do_tu_choi` text DEFAULT NULL,
  `ngay_duyet` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `nghi_phep`
--

INSERT INTO `nghi_phep` (`id_nghi_phep`, `id_nhan_vien`, `ngay_bat_dau`, `ngay_ket_thuc`, `loai_nghi`, `ly_do`, `trang_thai1`, `id_nguoi_duyet`, `ly_do_tu_choi`, `ngay_duyet`) VALUES
(1, 1, '2025-04-03', '2025-04-03', 'Có phép', 'Nghỉ ốm', 'Từ chối', 1, 'Thiếu nhân lục', '2025-04-29 09:43:42'),
(2, 2, '2025-04-05', '2025-04-06', 'Có phép', 'Việc gia đình', 'Đã duyệt', 1, NULL, '2025-04-29 09:56:22'),
(3, 3, '2025-04-07', '2025-04-07', 'Không phép', 'Nghỉ không lý do', 'Đã duyệt', 1, NULL, '2025-04-29 10:01:53'),
(4, 4, '2025-04-10', '2025-04-11', 'Có phép', 'Nghỉ phép năm', 'Từ chối', 1, NULL, '2025-04-29 10:07:12'),
(11, 4, '2025-05-26', '2025-05-28', 'Có phép', 'Bệnh', '', NULL, NULL, NULL),
(12, 1, '2025-05-26', '2025-05-27', 'Có phép', 'Bệnh Cúm', 'Đã duyệt', 1, NULL, '2025-05-25 10:15:15'),
(13, 10, '2025-05-26', '2025-05-27', 'Có phép', 'Bệnh', '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nguoi_dung`
--

CREATE TABLE `nguoi_dung` (
  `id` int(10) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `ten_dang_nhap` varchar(50) DEFAULT NULL,
  `mat_khau` varchar(50) DEFAULT NULL,
  `quyen_them` int(1) DEFAULT 0,
  `quyen_sua` int(1) DEFAULT 0,
  `quyen_xoa` int(1) DEFAULT 0,
  `google_id` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `trang_thai` enum('Hoạt động','Không hoạt động') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `nguoi_dung`
--

INSERT INTO `nguoi_dung` (`id`, `id_nhan_vien`, `ten_dang_nhap`, `mat_khau`, `quyen_them`, `quyen_sua`, `quyen_xoa`, `google_id`, `email`, `trang_thai`) VALUES
(1, 0, 'Admin', '0192023a7bbd73250516f069df18b500', 1, 1, 1, '101975392065842316082', 'ngocthach102017@gmail.com', 'Hoạt động'),
(8, 2, 'Quanly', 'e10adc3949ba59abbe56e057f20f883e', 1, 1, 0, NULL, 'lengocthuy2020tg@gmail.com', 'Hoạt động'),
(11, 1, 'Admin1', 'e10adc3949ba59abbe56e057f20f883e', 1, 1, 1, NULL, 'kingkai15032003@gmail.com', 'Hoạt động');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nhan_vien`
--

CREATE TABLE `nhan_vien` (
  `id_nhan_vien` int(11) NOT NULL,
  `ho_ten` varchar(100) NOT NULL,
  `gioi_tinh` enum('Nam','Nữ','Khác') DEFAULT NULL,
  `ngay_sinh` date DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `so_dien_thoai` varchar(20) DEFAULT NULL,
  `dia_chi` varchar(200) DEFAULT NULL,
  `can_cuoc_cong_dan` varchar(20) DEFAULT NULL,
  `ngay_cap` date DEFAULT NULL,
  `noi_cap` varchar(100) DEFAULT NULL,
  `que_quan` varchar(200) DEFAULT NULL,
  `hinh_anh` varchar(255) DEFAULT NULL,
  `id_phong_ban` int(11) DEFAULT NULL,
  `id_chuc_vu` int(11) DEFAULT NULL,
  `loai_hop_dong` enum('Toàn thời gian','Bán thời gian','Thực tập') NOT NULL,
  `luong_co_ban` decimal(12,2) NOT NULL,
  `ngay_vao_lam` date NOT NULL,
  `ngay_nghi_viec` date DEFAULT NULL,
  `trang_thai` enum('Đang làm việc','Nghỉ phép','Đã nghỉ việc') DEFAULT 'Đang làm việc'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `nhan_vien`
--

INSERT INTO `nhan_vien` (`id_nhan_vien`, `ho_ten`, `gioi_tinh`, `ngay_sinh`, `email`, `so_dien_thoai`, `dia_chi`, `can_cuoc_cong_dan`, `ngay_cap`, `noi_cap`, `que_quan`, `hinh_anh`, `id_phong_ban`, `id_chuc_vu`, `loai_hop_dong`, `luong_co_ban`, `ngay_vao_lam`, `ngay_nghi_viec`, `trang_thai`) VALUES
(1, 'Lương Ngọc Thật', 'Nam', '2025-04-15', 'kingkai15032003@gmail.com', '0901234581', 'An quới', '012028939492', '2023-03-27', 'An GIANG', 'Đồng Tháp', '/img/user1.jpg', 1, 1, 'Toàn thời gian', 10000000.00, '2025-05-16', '0000-00-00', 'Đang làm việc'),
(2, 'Lê Thị Ngọc Thúy', 'Nữ', '2003-03-15', 'lengocthuy2020tg@gmail.com', '01202893947', 'Chợ Gạo', '0120289394929', '2024-02-01', 'Tiền Giang', 'Đồng Tháp', NULL, 1, 3, 'Toàn thời gian', 20000000.00, '2020-05-04', '0000-00-00', 'Đang làm việc'),
(3, 'Lê Văn Cường', 'Nam', '1988-05-10', 'cuong.le@example.com', '0901234563', '78 Lê Lợi, Đà Nẵng', '123456789003', '2014-03-20', 'Đà Nẵng', 'Đà Nẵng', NULL, 3, 4, 'Toàn thời gian', 25000000.00, '2023-03-01', '0000-00-00', 'Đang làm việc'),
(4, 'Phạm Thị Dung', 'Nữ', '1995-07-25', 'dung.pham@example.com', '0901234564', '12 Trần Phú, Hà Nội', '123456789004', '2017-04-25', 'Hà Nội', 'Hà Nội', NULL, 4, 4, 'Toàn thời gian', 15000000.00, '2023-04-01', '0000-00-00', 'Đang làm việc'),
(5, 'Hoàng Văn Em', 'Nam', '1993-09-30', 'em.hoang@example.com', '0901234565', '56 Nguyễn Trãi, TP.HCM', '123456789005', '2018-05-30', 'TP.HCM', 'TP.HCM', NULL, 5, 4, 'Toàn thời gian', 17000000.00, '2023-05-01', '0000-00-00', 'Đang làm việc'),
(6, 'Nguyễn Thị Fleur', 'Nữ', '1991-11-05', 'fleur.nguyen@example.com', '0901234566', '89 Hai Bà Trưng, Hà Nội', '123456789006', '2015-06-05', 'Hà Nội', 'Hà Nội', NULL, 1, 1, 'Toàn thời gian', 14000000.00, '2023-06-01', '0000-00-00', 'Đang làm việc'),
(7, 'Trần Văn Giang', 'Nam', '1989-12-12', 'giang.tran@example.com', '0901234567', '34 Lê Duẩn, Đà Nẵng', '123456789007', '2016-07-10', 'Đà Nẵng', 'Đà Nẵng', NULL, 2, 4, 'Toàn thời gian', 16000000.00, '2023-07-01', '0000-00-00', 'Đang làm việc'),
(8, 'Lê Thị Hà', 'Nữ', '1994-02-18', 'ha.le@example.com', '0901234568', '67 Nguyễn Văn Cừ, TP.HCM', '123456789008', '2017-08-15', 'TP.HCM', 'TP.HCM', NULL, 3, 1, 'Toàn thời gian', 8000000.00, '2023-08-01', NULL, 'Đang làm việc'),
(9, 'Phạm Văn Inh', 'Nam', '1990-04-22', 'inh.pham@example.com', '0901234569', '23 Lý Thường Kiệt, Hà Nội', '123456789009', '2018-09-20', 'Hà Nội', 'Hà Nội', NULL, 4, 3, 'Toàn thời gian', 11000000.00, '2023-09-01', NULL, 'Đang làm việc'),
(10, 'Hoàng Thị Kim', 'Nữ', '1996-06-28', 'kim.hoang@example.com', '0901234570', '45 Phạm Ngọc Thạch, TP.HCM', '123456789010', '2019-10-25', 'TP.HCM', 'TP.HCM', NULL, 5, 3, 'Toàn thời gian', 14000000.00, '2023-10-01', '0000-00-00', 'Đang làm việc'),
(11, 'Nguyễn Văn Long', 'Nam', '1987-08-03', 'long.nguyen@example.com', '0901234571', '78 Hùng Vương, Đà Nẵng', '123456789011', '2014-11-30', 'Đà Nẵng', 'Đà Nẵng', NULL, 1, 5, 'Thực tập', 5000000.00, '2023-11-01', '0000-00-00', 'Đang làm việc'),
(12, 'Trần Thị Mai', 'Nữ', '1993-10-09', 'mai.tran@example.com', '0901234572', '12 Nguyễn Đình Chiểu, Hà Nội', '123456789012', '2015-12-05', 'Hà Nội', 'Hà Nội', NULL, 2, 1, 'Toàn thời gian', 9500000.00, '2023-12-01', NULL, 'Đang làm việc'),
(13, 'Lê Văn Nam', 'Nam', '1991-12-15', 'nam.le@example.com', '0901234573', '56 Trần Hưng Đạo, TP.HCM', '123456789013', '2016-01-10', 'TP.HCM', 'TP.HCM', NULL, 3, 3, 'Toàn thời gian', 18000000.00, '2024-01-01', '0000-00-00', 'Đang làm việc'),
(14, 'Phạm Thị Oanh', 'Nữ', '1988-02-20', 'oanh.pham@example.com', '0901234574', '89 Nguyễn Thị Minh Khai, Hà Nội', '123456789014', '2017-02-15', 'Hà Nội', 'Hà Nội', NULL, 4, 1, 'Toàn thời gian', 8000000.00, '2024-02-01', '0000-00-00', 'Đang làm việc'),
(15, 'Hoàng Văn Phát', 'Nam', '1995-04-25', 'phat.hoang@example.com', '0901234575', '34 Lê Văn Sỹ, TP.HCM', '123456789015', '2018-03-20', 'TP.HCM', 'TP.HCM', NULL, 5, 1, 'Toàn thời gian', 7000000.00, '2024-03-01', '0000-00-00', 'Đang làm việc'),
(16, 'Nguyễn Thị Quyên', 'Nữ', '1992-06-30', 'quyen.nguyen@example.com', '0901234576', '67 Bà Triệu, Hà Nội', '123456789016', '2019-04-25', 'Hà Nội', 'Hà Nội', NULL, 1, 1, 'Toàn thời gian', 8500000.00, '2024-04-01', NULL, 'Đang làm việc'),
(17, 'Trần Văn Sơn', 'Nam', '1989-08-05', 'son.tran@example.com', '0901234577', '23 Tôn Đức Thắng, Đà Nẵng', '123456789017', '2015-05-30', 'Đà Nẵng', 'Đà Nẵng', NULL, 2, 5, 'Thực tập', 4000000.00, '2023-01-01', '2024-12-31', 'Đang làm việc'),
(18, 'Lê Thị Thanh', 'Nữ', '1994-10-10', 'thanh.le@example.com', '0901234578', '45 Nguyễn Văn Trỗi, TP.HCM', '123456789018', '2016-06-05', 'TP.HCM', 'TP.HCM', NULL, 3, 5, 'Toàn thời gian', 7000000.00, '2023-02-01', '0000-00-00', 'Đang làm việc'),
(19, 'Phạm Văn Uy', 'Nam', '1990-12-15', 'uy.pham@example.com', '0901234579', '78 Lê Đại Hành, Hà Nội', '123456789019', '2017-07-10', 'Hà Nội', 'Hà Nội', NULL, 4, 5, 'Thực tập', 3500000.00, '2023-03-01', '0000-00-00', 'Đang làm việc'),
(20, 'Hoàng Thị Vân', 'Nữ', '1996-02-20', 'van.hoang@example.com', '0901234580', '12 Võ Văn Tần, TP.HCM', '123456789020', '2018-08-15', 'TP.HCM', 'TP.HCM', NULL, 5, 5, 'Thực tập', 3000000.00, '2023-04-01', NULL, 'Đang làm việc'),
(21, 'Nguyễn Văn An ', 'Nam', '1990-01-15', 'an.nguyen@example.com', '0901234561', '123 Đường Láng, Hà Nội', '123456789001', '2015-01-10', 'Hà Nội', 'Hà Nội', 'img/1.jpg', 1, 1, 'Toàn thời gian', 17000000.00, '2023-01-01', '0000-00-00', 'Đang làm việc'),
(22, 'Trần Thị Bình', 'Nam', '1992-03-20', 'binh.tran@example.com', '0901234562', '45 Nguyễn Huệ, TP.HCM', '123456789002', '2016-02-15', 'TP.HCM', 'TP.HCM', NULL, 2, 3, 'Toàn thời gian', 10000000.00, '2023-02-01', '0000-00-00', 'Đang làm việc');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `phan_bo_ung_vien`
--

CREATE TABLE `phan_bo_ung_vien` (
  `id_phan_bo` int(11) NOT NULL,
  `id_ung_vien` int(11) NOT NULL,
  `id_phong_ban` int(11) NOT NULL,
  `trang_thai` enum('Chờ phân bổ','Từ chối','Đã duyệt') DEFAULT 'Chờ phân bổ',
  `ngay_phan_bo` date NOT NULL,
  `hop_dong_thu_viec` text DEFAULT NULL,
  `id_chuc_vu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `phan_bo_ung_vien`
--

INSERT INTO `phan_bo_ung_vien` (`id_phan_bo`, `id_ung_vien`, `id_phong_ban`, `trang_thai`, `ngay_phan_bo`, `hop_dong_thu_viec`, `id_chuc_vu`) VALUES
(17, 1, 1, 'Chờ phân bổ', '2025-05-25', '', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `phong_ban`
--

CREATE TABLE `phong_ban` (
  `id_phong_ban` int(11) NOT NULL,
  `ten_phong_ban` varchar(100) NOT NULL,
  `mo_ta` text DEFAULT NULL,
  `trang_thai` enum('Hoạt động','Ngừng hoạt động') DEFAULT 'Hoạt động'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `phong_ban`
--

INSERT INTO `phong_ban` (`id_phong_ban`, `ten_phong_ban`, `mo_ta`, `trang_thai`) VALUES
(1, 'Nhân sự', 'Quản lý nhân sự và tuyển dụng', 'Hoạt động'),
(2, 'Kế toán', 'Quản lý tài chính và kế toán', 'Hoạt động'),
(3, 'Công nghệ', 'Phát triển phần mềm và công nghệ', 'Hoạt động'),
(4, 'Kinh doanh', 'Phát triển kinh doanh và bán hàng', 'Hoạt động'),
(5, 'Marketing', 'Quảng bá thương hiệu và sản phẩm', 'Hoạt động');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `thuong`
--

CREATE TABLE `thuong` (
  `id_thuong` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `noi_dung_thuong` varchar(255) DEFAULT NULL,
  `ngay` date NOT NULL,
  `loai` enum('nghỉ lễ','thăng chức','thành tích cá nhân','phạt kỷ luật','phạt trách nhiệm công việc') NOT NULL,
  `tien_thuong` decimal(12,0) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `thuong`
--

INSERT INTO `thuong` (`id_thuong`, `id_nhan_vien`, `noi_dung_thuong`, `ngay`, `loai`, `tien_thuong`) VALUES
(1, 1, '30', '2025-05-01', 'nghỉ lễ', 1500000),
(4, 1, '36', '2025-05-01', 'phạt kỷ luật', -1000000),
(5, 1, 'Hoạn thành chỉ tiêu', '2025-05-25', 'thành tích cá nhân', 1000000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `ung_vien`
--

CREATE TABLE `ung_vien` (
  `id_ung_vien` int(11) NOT NULL,
  `ho_ten` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `so_dien_thoai` varchar(20) DEFAULT NULL,
  `id_dot_tuyen_dung` int(11) NOT NULL,
  `id_chuc_vu` int(11) NOT NULL,
  `nguon_ung_tuyen` varchar(100) DEFAULT 'Trực tiếp',
  `ho_so` text DEFAULT NULL,
  `trang_thai` enum('Mới nộp','Đang xử lý','Đạt','Không đạt') DEFAULT 'Mới nộp'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `ung_vien`
--

INSERT INTO `ung_vien` (`id_ung_vien`, `ho_ten`, `email`, `so_dien_thoai`, `id_dot_tuyen_dung`, `id_chuc_vu`, `nguon_ung_tuyen`, `ho_so`, `trang_thai`) VALUES
(1, 'Nguyễn Vănsssss', 'ngocthach102017@gmail.com', '0901234581', 1, 1, 'Website', 'CV Nguyễn Văn A', 'Mới nộp'),
(11, 'Phan Văn Toàn', 'rya07668@gmail.com', '0120289394', 8, 1, 'web', '', 'Mới nộp'),
(12, 'Lý Anh Khoa', 'luong@gmail.com', '0102893945', 8, 5, 'web', '', 'Mới nộp');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `van_tay`
--

CREATE TABLE `van_tay` (
  `id` int(11) NOT NULL,
  `id_nhan_vien` int(11) DEFAULT NULL,
  `du_lieu_van_tay` blob DEFAULT NULL,
  `trang_thai` enum('pending','completed','failed') NOT NULL DEFAULT 'pending',
  `ngay_tao` datetime NOT NULL,
  `ngay_cap_nhat` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `van_tay`
--

INSERT INTO `van_tay` (`id`, `id_nhan_vien`, `du_lieu_van_tay`, `trang_thai`, `ngay_tao`, `ngay_cap_nhat`) VALUES
(10, 1, 0x65794a705a434936496e42755253314757444530596c6b344e6c4e36633235474e3031354e45557a533274455257387a4c57396f637a564862554a785a6d51784d6a41694c434a795958644a5a434936577a45324e6977784d544d734e6a49734d6a45734d5449314c4445794d4377784d446b734d54517a4c4455344c4463314c4455354c444d354c44497a4c4445334f5377314d4377794d6a51734e7a63734d6a41794c4445304e4377304f5377304d4377794d6a4d734d6a4d304c444d7a4c4445334f5377784e4455734d5459324c4459734d5459334c4449794d5377794d5455734d5441355853776964486c775a534936496e4231596d7870597931725a586b694c434a795a584e776232357a5a53493665794a686448526c6333526864476c76626b3969616d566a64434936577a45324d7977354f5377784d4449734d5441354c4445784e6977354f5377784d5459734d5445794c4445774f5377784d444d734f5463734d5445324c4445784e6977344d7977784d5459734d5441354c4445784e6977784e6a59734f546b734f5463734d5441344c4445774d7977314e7977794e5455734d6a55304c446b354c4445784e5377784d4455734d54417a4c4467354c4445734d4377304d7977304c4449304e5377784e7a51734d544d304c4445334e6977784e4377344d7977304e6977794e4449734d5463314c4445314d4377314f4377784e6977784d5455734d6a55304c4445784e43777a4f5377314c4445314d6977784f4467734d546b324c4445324e6977784f5467734d54557a4c4449794e7977784f4441734d5467774c4445334e4377784d7a55734d54517a4c4445314d43777a4d7977784e4451734d5449314c4445794e7977784e446b734d6a4d7a4c4445784f4377794d7a4d734d546b334c444d324c4449354c444d344c4445344d7977784f4451734d5449314c4459354c4445324f5377794e446b734d5449324c4455314c4445334e7977354e6977794d7a41734d6a55784c4449774e7977794d544d734d5455314c4455324c4449774d5377314d7977784e6a55734e7a49734d544d304c44597a4c446b734d7a59734d6a6b734d546b344c4445304d7977784d444d734e5459734d7a45734f4455734d5463774c4445334c446b314c4445794d6977784e6a4d734d5451344c4445314e7977794d5449734d5441334c44497a4d4377334d6977794e4459734d544d774c4449794f4377304e7977344f4377784d446b734d6a45784c4445344e7977784e546b734d5459324c4449784e4377784d7a45734e6a45734d5445794c4445774e7977784d7a55734d5463784c446b774c4445344d4377304e7977784e6a51734e5449734d5441304c4445774d4377784f5467734d5445344c44457a4e5377324e5377784e4467734d5455734f5451734d6a41314c4449314c4463304c4451734d6a497a4c44557a4c4445304d7977784e6a51734d7a41734d544d344c4445314d7977324f43777a4e6977324d6977784d7a49734d546b304c4459314c44497a4e5377784e7a67734d6a67734d6a41794c4445314e4377784d4455734f5449734d5463794c4445784e4377784d7a67734d6a457a4c4445314e6977304e4377784e5451734d5467314c44457a4f4377304e5377784e7a4d734d54457a4c4451334c44497a4d7977354f4377354e5377784e546b734d5455344c4463354c4451314c4455784c4445314f4377344d5377314f5377794e446b734d6a51784c4449784f5377794d7a41734d54497a4c4449314e4377784d5445734d6a41774c4455344c4455354c446b354c44637a4c4459784c4459344c4449314e5377784d6a49734d6a4d7a4c4449314e43777a4e5377324c4449304d5377794d7a59734d6a41774c4451774c4445324e5377784e7977314e7977334d6977794d6a67734d544d354c4459784c4445354e4377334e6977784f4449734d5449794c4445304f4377794c4459344c4445774d43777a4f4377784e446b734d6a51354c4445794d7977784e5467734e7a4d734d5455304c4445334e4377784e7a59734d54677a4c4445314f4377784e6a63734d5459774c4445314e79777a4e5377784d6a55734d6a45354c4445314f4377794d6a63734d5463334c4459314c4445304e6977784e5441734d5463324c4445304d7977784e546b734d546b784c4445344e6977784f4377784d7a41734d6a51784c4463354c444d794c4449794e7977784e4451734d544d734e6a4d734d5459794c4449314e4377344e6977784d544d734d6a4d304c44597a4c4455784c444d794c4445314d5377784e6a59734f546b734d546b324c4445324e7977784e6a6b734d546b344c446b354c4445784f4377784d4445734d5445304c446b354c4455774c4451324c4451344c446b354c4445794d4377314d7977354f5377784d7a41734f446b734e5377784f444d734e4467734d544d774c4455734d5463354c4451344c44457a4d43777a4c4445314e5377784e6a41734d7977794c4445734d6977794c4445324c4445734e7a41734e7a49734d54517a4c4449314d5377794d4445734e7a49734d54557a4c4445334d4377794e5441734d5455774c4459324c4451304c4445784f4377784d5449734d6a6b734e4467734d544d734e6977354c4451794c44457a4e4377334d6977784d7a51734d6a51334c44457a4c4445734d5377784d5377314c4441734e4467734e6a49734e446b734e6a41734e4467734e5467734e69777a4c4467314c4451734d7977784f5377314d5377334d7977334f4377344e4377324e7977304e5377334e5377324f5377344f5377334d7977324f4377304e5377324e6977304f4377314e4377314e4377324f4377314e7977314e4377314e7977314e5377334d4377314d7977324f4377314d5377324e5377304f4377314e5377324e6977314d6977314d4377314d7977324e7977304f5377304f4377334d4377314d7977314e6977314e5377324e7977324e7977324f5377324f5377324e7977334d4377304f5377314e4377334d4377334d4377324f5377314d7977314e6977304f43777a4d4377794d7977784d7977314d4377314d7977304f4377314d7977314d4377314d5377314d4377304f4377314d5377314d5377314d6977314d5377354d4377794d7977784d7977314d5377304f4377304f4377314d7977314d4377304f5377304f5377314e7977304f5377314d5377304f4377314e4377354d4377304f4377774c4451344c44457a4d4377784c444d304c4451344c44457a4c4459734f5377304d6977784d7a51734e7a49734d544d304c4449304e7977784d7977784c4445734d5377314c4441734d7977784d7a41734d5377784e5377774c4451344c44457a4d4377784c4445774c4449734d544d774c4445734d5377774c4445344e5377784e7a63734d6a55304c4459314c4449784f5377784e6a63734d5445784c4449314e5377784d5467734d6a55774c4449794e7977794d6a67734d5455734f4451734d7a45734d5441314c4445784f5377784d6a63734f4449734d5455794c4455794c4445354d7977784f4441734d7a4d734d6a49784c4445794f4377784e544d734d5451734d5455784c4445314d5377304d4377794d6a63734d5455784c4459304c446b304c446b344c4449314d7977784e6a67734e4463734d6a49794c4449774d79777a4e5377334d4377794d6a41734d5449734d6a417a4c4445344d7977784d6a45734d54557a4c4449304f4377334f5377354e6977784d7a63734d5445334c4449794d6977354d4377314d5377794d4377354d7977794d4377794d5449734d5467794c4449794e7977784d444d734f4463734f4445734d5467734d5441334c4445344d7977784d7977784e6a45734d5459774c4449784e6977314c4449794d7977784d6977324d5377794d7a45734d5451774c4449304d7977794d4377784e4463734d6a55784c4449774e7977794d7a4d734d6a51794c4449794e4377784e4377784e5459734e5377784f5445734e7a59734d7a45734d5459304c4445324c4445334e4377784e6a67734d6a59734d6a51794c4449314d4377794d6a55734d5445304c4445324e7977784e5459734f4445734f5463734d5455354c4445794e5377784f5449734d6a55314c44497a4d7977334e4377784e446b734d6a51324c4445324d5377794d6a63734f544d734d6a55784c4449794e4377794e4445734d6a51334c4445314e5377784f4455734e7a55734e546b734d6a497a4c44497a4d5377314d4377314d7977784f4449734d5467334c44457a4c4455344c4449794e4377784e7a6b734d5459324c4445794d6977784e444d734d6a49334c44677a4c4445324d7977784f5445734d7a49734e7a49734f5455734e6a63734d6a41354c4445344f4377334d7977794e4455734f5463734e6a49734d5463784c4445304d6977784d4455734d6a49314c4449314d4377784f4467734e5467734d546b784c4467774c446b354c4459734e6a51734d5459334c4445794e7977784e5455734e546b734d5455354c4445334e43777a4d53777a4e7977794d7a51734d6a51324c4445784c4463794c4449304d7977784e6a6b734d6a457a4c4459344c44677a4c4445794e5377784e4459734d5449304c446b774c4463774c4449784c4445784e6977784d546b734f5459734d6a45774c44457a4c4445734d5463784c4445774c4445324e4377324e7977354e5377794e4377784e7a41734d6a4d314c4445314e5377784d546b734e444d734d6a51344c4445304f5377784d7a49734d6a4d7a4c4463344c4445794e4377324f4377794d4451734f5449734d5441774c4463324c4445324f5377334f5377334e4377304f5377784d5441734f5445734d5467734e6a63734d5451354c446b794c4445344f5377794e6977784d5445734d5467774c4449324c4445334e4377794e4451734d5451354c4445314d5377784e4445734d546b324c4449794f4377794e446b734d5459784c4445794f5377344f5377334f5377794e4377324d5377334e7977794e4449734d6a41334c4445774d7977794d6a49734f444d734d6a45784c4449354c4445354d7977304f4377334f4377784e4445734d69777a4c4445734d4377784c4445324d7977784d7a41734d5377794d7a4d734e4467734d544d774c4445734d6a49354c4451344c4445304c4459734d7977344e5377794f5377784e5377784c4445734d6a55314c4451734e43777a4c4449734e7977784d6a67734e4467734d5449734e69777a4c4467314c4449354c4445354c4445734d5377794e5455734e4377794c4451344c4441734e4467734d5441354c4459734d7977344e5377794f53777a4d6977784c4445734d6a55314c4451734f546b734e4467734f5463734e4467734f5455734e6977354c44517a4c4459734d5377304c4445734d544d774c4455314c4449784c444d784c4451344c4467794c4451344c4467774c4459734f4377304d7977324c4445734e5377314c4463734d6977794c4451344c4459344c444d774c4459324c4441734f4451734d4377324e7977774c4467774c4441734e6a55734d43777a4d6977774c444d794c4441734f4451734d4377784d5451734d4377784d5463734d4377784d5455734d4377784d5459734d4377784d4445734d4377784d4441734d43777a4d6977774c444d794c4441734f4441734d4377784d4467734d4377354e7977774c4445784e6977774c4445774d6977774c4445784d5377774c4445784e4377774c4445774f5377774c444d794c4441734d7a49734d4377334d7977774c4445774d4377774c4445774d5377774c4445784d4377774c4445784e6977774c4445774e5377774c4445784e6977774c4445794d5377304f4377784e6977324c444d734f4455734d6a6b734d7a63734e4377354c4451344c4463734e6977314c4445774d7977784d6a6b734e5377344c444d734e4467734f4441734e69777a4c4467314c4449354c4445334c4445734d5377794e5455734e4377334d4377304f4377324f4377784e6a51734e6a59734e4467734e6a51734e446b734d6a49734e4467734d6a41734e6977314c4445774d7977784d6a6b734e5377794c4445734d5449734d5445734d5441314c4445774d4377314f4377314d6977314e7977314d6977324f5377314d7977314d6977314d6977314d5377304f5377784e4377304f4377784d6977324c4455734d54417a4c4445794f5377314c4449734d6977784d69777a4c4467304c4463784c4463324c4451354c4449794c4451344c4449774c4459734e5377784d444d734d5449354c4455734d69777a4c4445794c4445784c4445774e5377784d4441734e5467734e4467734e5441734e544d734e5459734e4467734e4467734e4467734e5455734e4467734d7a45734e69777a4c4467314c4449354c444d314c4451734d6a51734e4467734d6a49734d5449344c4449774c4445774d6977784d5455734d54457a4c444d304c4445784f4377304e4377304d5377784d5441734e4451734d5459774c4463734d6a45354c44457a4f43777a4d6977784e7a4d734d54677a4c4451734d546b7a4c446b304c4445794d6977304f4377794f5377324c444d734f4455734d6a6b734d5451734e4377794d6977304c4449774c4467344c4449794f4377794d4449734d6a49354c4445354e7977784f5445734e4455734d5451344c446b304c444d794c4445344e5377304f5377794e53777a4d7977304e6977794d546b734d6a4d354c4449334c4449344c4445354e7977304f4377784d6a6b734d5463334c4459734f4377304d7977324c4445734e5377314c4463734d5377784c4451734d5449354c4445324e4377304f4377784d6a6b734d5459784c4451344c4445794f5377784e5467734e6977344c44517a4c4459734d5377314c4455734e7977304f4377794c44457a4e4377784d6a6b734d5451314c4445774e4377784d5459734d5445324c4445784d6977314f4377304e7977304e7977354e7977784d6a49734f546b734d5445314c4445784d6977784d5451734d5445784c4445774d4377784d4445734d5445334c4445784e5377354e7977784d4455734d5441334c4445784d6977784d5463734f5467734d5441344c4445774e5377784d5455734d5441304c4451324c446b344c4445774f4377784d5445734f5467734e4459734f546b734d5445784c4445784e4377784d4445734e4459734d5445354c4445774e5377784d5441734d5441774c4445784d5377784d546b734d5445314c4451324c4445784d4377784d4445734d5445324c4451334c4445774e5377784d5441734d5445324c446b354c4451314c4445774e7977784d4445734d5449784c4445774e5377784d4441734e4455734f5467734e4467734e5451734e5451734d5441774c4455334c4455304c4455334c4455314c4445774d6977314d7977784d4441734e5445734f5463734e4467734e5455734f5467734e5449734e5441734e544d734f546b734e446b734e4467734d5441794c44557a4c4455324c4455314c446b354c446b354c4445774d5377784d4445734f546b734d5441794c4451354c4455304c4445774d6977784d4449734d5441784c44557a4c4455324c4451314c446b354c4451334c4455794c4455784c4451344c44557a4c4445774d6977784d4441734e5463734e5455734e4455734e5455734e5455734e5445734d5441774c4451314c4455794c4455794c446b354c446b354c4451314c446b334c446b354c4451354c44557a4c4451314c4455784c4451354c4455304c4455784c4455304c4455314c4451354c4455314c4451344c4455334c4455314c446b344c4451324c446b354c4445774d5377784d5451734e4467734d544d734e6977354c4451794c44457a4e4377334d6977784d7a51734d6a51334c44457a4c4445734d5377784d5377314c4441734d7977784d7a41734d6977784c4441734d6a67734d6a41774c446b354c4445334f4377314e6977794d6a63734d6a41304c4445334e7977784d6a45734d6a457a4c4445774e4377794e4467734d6a45344c444d314c4449354c446b734d6a4d304c4449304c4445794f5377314d5377334d6977334e6977784e6a63734e7a45734d544d7a4c4449304d5377784e4449734d5467324c4467774c44457a4e53777a4d7977784d6a63734f4441734e444d734d5445784c4445784d4377344d4377344e7977304e5377304d7977304e5377794d6977784f5441734d6a45304c4463734d5455784c4445344f5377354d6977334e5377304e6977784e7a63734d54557a4c446b304c444d314c4451354c44497a4e6977304d69777a4e53777a4f5377784d544d734d6a4d314c4463314c4449304c4449314c446b794c4449784c44457a4f5377784e7977784e7a49734d5441734d5441784c4445334e4377784d6a41734d5455354c4463334c4449794d6977794e5455734d546b774c4451334c4459324c4463784c4445324e5377784e4467734d546b774c4445334d5377344f5377784d79777a4d7977794e4449734d6a45794c4459314c44597a4c4451784c4449314d4377304e7977794e4449734d5449304c4445314f4377334d5377784e4455734d6a4d734d5445324c444d774c4445794c4445784d6977784e546b734d54497a4c4445794e53777a4f4377784e5467734d7a6b734d6a4d7a4c4445794e5377354e4377794d6977784e5449734d5463354c4445314e6977344d4377784e446b734d6a55774c444d324c4467334c4445774e5377794d6a45734d544d794c44497a4d5377784f4445734d5459734d546b324c4449304e6977794d7a6b734d5455314c4449794d7977794d5377794d7a63734d6a41794c4445304c4445344c4445344e4377784e4455734d6a4d344c4445794d7977324d69777a4d7977334d43777a4d43777a4d4377794d5455734d5467784c4451334c4467734e546b734f5449734d5449324c4449784f5377794d7a63734e6a6b734d5463734d546b774c444d324c4445324e6977794d446b734d7977794d5441734e7a63734f5441734d5459344c4445314f5377794d5445734d544d7a4c4467344c4463314c4449774d7977784e6a45734d5455734d5451334c4463774c4449794f5377794e6977784e4467734d5467304c4445344c4449304f4377784f5467734d6a45344c4445314e5377784e7a59734e6a55734e5455734d54597a4c446b354c44497a4d7977784e5445734d7a41734d5441324c4445794c4445774e5377784d6a45734d54417a4c4445354d7977784e6a45734d5445304c44457a4f4377784e4377784d546b734d5467734d5449344c4449784d5377304d6977784d446b734d6a49784c4445784f5377784d444d734d6a51304c4445334d6977344c4445304e7977784d4455734e4455734d6a41794c4449794f4377784d4445734d6a49324c4455334c4445344e7977784e4441734d6a557a4c4449794d7977794e446b734e7a67734d7a49734d5459774c4445344e7977794d5463734d5459314c4445344d5377784d4467734d6a49794c4445774d4377314d5377794e7977794d446b734d5455794c44497a4d4377794d7a45734d5467354c4445794e4377784f546b734d5445304c44457a4f5377304e7977314e5377784f546b734d5467344c4455334c4449774d5377784e7977784d5441734d5455774c4445794e5377334e7977794d544d734d6a41314c4445304d6977794d7a51734d5441354c4445774d6977794d4455734e6a67734f4467734d5463354c4445334e6977324d4377784d7a67734d6a51794c4445774d6977784e7a63734d5455334c4445344e6977794d4449734d546b784c4467334c4467324c4445794f53777a4c446b324c4445324e7977784e4449734d5445314c4449784d5377784f4455734d5467784c4459774c4449774d5377794e7977794d546b734d544d774c4449304d6977784e7977784d5455734d6a517a4c4445334e6977334f5377794d4441734e6a55734d5445784c4455354c4463794c4449794e4377324f5377784e5455734d6a59734d5463314c4449304e4377794d7a4d734d7a6b734d5467324c4451314c4449794d7977344c4451794c4449354c4445794d6977324f5377784d7977324d4377794d6a63734e5441734d6a55794c4449774f4377314d4377344c4445784d5377794d544d734d546b7a4c4467774c4445334f4377344e5377354e6977794e544d734d6a4d354c4445324f5377344f4377324e6977784d4455734d5445324c4463344c4455794c444d794c4445794d6977324f4377354d4377794e4377344c4445304f5377784e6a6b734d6a41784c4449794d4377784d7a63734d7a49734d5455304c4445334e6977794d544d734f4377784f5445734f5445734d5451734f446b734d6a49304c4445784d5377354c4467774c4445334e5377794d5455734d5459334c444d7a4c4449304d7977334d7977784f5451734d6a4d314c44497a4d5377304d5377784d6a63734d5467354c44457a4d5377784f4459734e4455734d5377344f5377314d7977344d5377784d5463734d5449354c4445734d5451304c4449794e53777a4c4445324e7977784d4467734d54677a4c4463304c4467354c444d794c4449314d5377784e544d734d6a4d324c44677a4c4445314d6977784d5445734f5455734d544d794c4445344e6977784f4455734f4445734f444d734d5455734d7a6b734d5449344c4449354c4449794e7977794e4459734e4449734d544d7a4c44497a4e5377794d6a51734e7a45734d54597a4c4445334e5377784e5445734d6a4d784c444d354c44637a4c4445334f4377344e4377354d6977794d4445734d546b354c4467334c444d774c4449314d4377324f4377794e4459734d5441784c4449774f4377784d5441734d6a4d734e544d734e5463734d6a4d784c4445794d4377784d444d734d5459734d5449774c4445794f4377784d5467734d5445354c4445324e7977794e4441734d6a49334c4449784e5377784e446b734e4449734d5459734d544d784c4467794c4445344f53777a4e4377784e5445734f5445734d5445784c4445344f5377794d4445734d6a41734f4459734d7a59734d5459354c4449784f5377304e7977794d7a51734d546b314c4451344c4467314c4445774d5377784e6a49734d5445344c4445784f4377784d5463734d6a41314c4445794d5377774c44457a4e4377314d4377784f446b734d5445304c4445314f5377784e6a67734e7a45734d5441314c4445344d7977304d4377784f5463734d6a45794c4445324f4377794d7a67734d5463334c4451774c4459784c4449734e7a67734d5455354c4445314e6977344f5377324c44497a4e6977304f4377784d7a41734e6977794d7a49734e4467734d544d774c4451734d6a41344c4445324d43777a4c4449734d5377794c4449734d546b734e5445734d4377774c4467734d6a41354c4445354d5377794e444d734d7a63734d544d304c446b344c4449774d4377784e7a55734d544d334c4441734d4377774c4441734f4377794d446b734e4467734d544d734e6977354c4451794c44457a4e4377334d6977784d7a51734d6a51334c44457a4c4445734d5377784d5377314c4441734e4467734d5449354c4445304d4377304f5377784d5377304f4377354c4459734d7977344e5377304c4459734d546b734d6977344e5377344d7977304f5377784f5377304f4377784e7977324c444d734f4455734e4377344c4445354c4445774c4467334c446b334c4445784e5377784d4451734d5441314c4445784d4377784d444d734d5445324c4445784d5377784d5441734e446b734d5459734e4467734d5451734e69777a4c4467314c4451734e7977784f5377334c4467794c4445774d5377784d4441734d5441354c4445784d5377784d5441734d5441774c4451354c444d774c4451344c4449344c4459734d7977344e5377304c4445774c4445354c4449784c4463334c4445774e5377354f5377784d5451734d5445784c4445784e5377784d5445734d5441794c4445784e69777a4d6977324e7977784d5445734d5445304c4445784d6977784d5445734d5445304c446b334c4445784e6977784d4455734d5445784c4445784d4377304f5377314e4377304f4377314d6977324c444d734f4455734e43777a4c4445354c4451314c4463334c4445774e5377354f5377784d5451734d5445784c4445784e5377784d5445734d5441794c4445784e69777a4d6977344e4377344d4377334e79777a4d6977344d6977784d5445734d5445784c4445784e69777a4d6977324e7977784d4445734d5445304c4445784e6977784d4455734d5441794c4445774e5377354f5377354e7977784d5459734d5441784c444d794c4459314c4445784e7977784d5459734d5441304c4445784d5377784d5451734d5441314c4445784e6977784d6a45734d7a49734e5441734e4467734e446b734e5449734e4467734d7a41734d6a4d734d544d734e5441734e5449734e4467734e544d734e5441734e446b734e446b734e5463734e446b734e5445734e4467734e5451734f5441734d6a4d734d544d734e5445734e4467734e4467734e544d734e5441734e446b734e446b734e5463734e446b734e5445734e4467734e5451734f5441734e4467734e6a49734e446b734e6a41734e4467734e5467734e69777a4c4467314c4451734d7977784f5377314d5377334d7977334f4377344e4377324e7977304e5377334e5377324f5377344f5377334d7977324f4377304e5377324e6977304f4377314e4377314e4377324f4377314e7977314e4377314e7977314e5377334d4377314d7977324f4377314d5377324e5377304f4377314e5377324e6977314d6977314d4377314d7977324e7977304f5377304f4377334d4377314d7977314e6977314e5377324e7977324e7977324f5377324f5377324e7977334d4377304f5377314e4377334d4377334d4377324f5377314d7977314e6977304f4377784d7a41734d69777a4e4377304f4377784d7977324c446b734e4449734d544d304c4463794c44457a4e4377794e4463734d544d734d5377784c4445734e5377774c444d734d544d774c4449734d5455734d4377304f4377784d7a41734d6977784d4377794c44457a4d4377794c4445734d4377784d7a59734d5377794e4463734d5455324c4445354d7977784d4445734e5441734f5377334d4377304c4445334d5377784e4467734d6a45324c4459344c4445344d7977334f5377784d7a67734d7a59734f446b734d5441334c4445314f4377784d444d734d544d314c4449304e6977784d6a41734e7a41734e444d734d6a41334c4445794d6977784e6a6b734d6a45784c444d354c4445324f4377784f444d734d6a45314c4445354e5377344e6977794d446b734d5455344c44457a4f5377324e7977784e4467734d5467344c4463354c4445304c4445344e7977784d5449734d5445784c4445774e4377334d7977794d5459734d5441794c44497a4c44637a4c4445344e5377784e6977354e5377314f4377784d7977784e6a49734d6a51774c4449774f5377784d7a4d734d5463324c4455774c4445784e6977304e4377784f4449734d6a45334c4445774e5377794e5441734d6a55734d5459734d6a51324c44557a4c4445304f5377784f4377784e4467734e5441734d6a417a4c4445354f5377784f4449734d5455774c444d774c4445784e5377784f4445734f5467734d5459324c4449784e5377344e4377334e5377334d5377784d7a49734e6a59734d5441314c4445344d5377344e5377794e4463734d546b7a4c4459344c44457a4c4445344c4445324f43777a4d5377794d4445734d544d314c446b774c4463344c4445774d5377784d6a67734d6a51334c444d7a4c4445794e5377784d6a59734f4451734d6a45334c4445794d4377304d5377324e6977784e6a41734d546b304c44497a4f5377304e4377334e5377304e6977794d7a49734d54597a4c4445304f4377784e6a51734f5451734e5455734d6a55774c4445304e5377344e53777a4e5377784e5445734e6a4d734d6a51334c4445304d4377344d6977784d6977794d7a59734d6a49794c444d7a4c4455734f5463734d5467774c4445354e7977784e4451734e4445734e5441734d5463324c4445314d6977794d5463734e4467734d5451324c4467304c4449794e7977344e7977784d4467734d544d304c4445794d4377344f5377794d6a59734d6a41734d6a63734d5445334c4445794e4377784e7a49734d5459334c4445324e6977784f446b734d5451344c44497a4e7977794e5449734f446b734e444d734d5467324c4445334e6977314d4377784d6a67734d6a51344c4445794d4377794d5445734d5449794c4445354e5377794d4463734f4445734d5463784c4449304e5377334e5377784e4455734d5467344c4445314e7977784d6a49734d54597a4c446b354c444d314c4445774e6977344e5377784e544d734d5441734d6a4d7a4c4449304d6977784f5467734e7a4d734d6a41304c4449304d6977784d4459734d6a49304c4445344d5377334e5377344f5377794d4459734d6a45334c4445794e7977794d6a6b734e7a51734d5441774c4445314d5377794e5449734d6a417a4c4445324e5377784d6a67734d5459334c444d7a4c4445734d54557a4c4445794d4377784d6a49734d5451734e7a41734e7a49734d5451344c4449794e5377784f5449734d6a45344c4445334d4377334f5377784e544d734d6a45794c4445354e7977794d6a6b734d5445774c4449304f5377334d6977784e7a59734d6a51344c4445314d4377794d444d734d6a4d774c444d324c4449794f5377334e7977784e4377784f546b734d7a51734e7a67734d5459334c4459784c4455344c4445784d5377314e5377784d7a63734d5459794c444d774c446b314c4459794c4449304d4377784d7a6b734e7a59734d6a557a4c4445334c4449774d7977354e6977784d5467734f446b734f446b734d6a51334c4449304d6977784e5377784f4455734d6a51334c4445324d6977794d7a63734d544d334c44497a4d4377784d5459734e546b734d6a4d354c44497a4d4377314e7977784d6a51734d5449354c446b734d7a63734d546b314c4449774d5377794d4377784d7a51734d6a49734e6a45734d544d794c4441734d5441774c446b314c4445314d4377794d6a63734d6a4d344c4449784f5377784e4451734f4459734f5445734f4441734e4459734d6a45334c4445774e6977334d7977784e5467734d6a41344c4445794d7977784d6a49734d5459314c4449774c44497a4c4445784c4445324d6977324f4377784d6a41734d546b324c4451354c4445344e6977784d6a63734d6a4d314c4449784d6977794d5467734d7a51734d6a41734d546b354c444d734d5459344c44457a4d5377784e6a51734d546b794c4455354c4445354e6977784d7a6b734d5455304c44497a4f5377324f5377354d7977784d6a63734d6a55304c44457a4c444d7a4c4445784d4377334d7977314f5377784d5451734d5463324c4445354e4377324d5377794d6a51734d546b304c4451354c4449784e7977314e6977344f5377784f5377324f4377784e4459734d6a51734e7a55734d7a67734e5449734f5441734d546b7a4c44497a4d4377794d6a55734d6a45344c444d354c4449314d7977314e7977314e5377354f5377354d43777a4f5377354f5377334e5377784f546b734d6a51314c4449304e7977784d7a6b734d5459334c4449314d7977784d4451734d5455354c44497a4e5377794d6a49734d5467784c4445324e6977314c44457a4e7977354e7977324c4463794c4445344d69777a4d6977344d7977784d7a67734e6a41734d5459774c4449314e5377794d5467734d5459304c4449794d5377794d544d734d6a55314c4451314c4445784e6977794d5377784e6a6b734f5455734d6a457a4c4467334c44637a4c4449304e7977784d7a63734e7a55734d6a4d334c4449794e4377784d4451734f5463734d5441324c44497a4d6977784e7a41734d544d774c4455314c4449314c4449794d4377794d7a41734d546b304c4455334c444d334c4449784d6977794e544d734f4377784d5449734d6a4d734e7a45734d5449734d6a51734d5463794c44457a4d6977334e6977314e7977784e5463734f5451734d6a45314c4449774e6977784d6a49734f5449734d5449774c4445354f5377354f5377794d7a55734e4441734d546b354c4445324d7977794e446b734d5459324c4449774d6977784d7a6b734d544d7a4c4445774e7977304e5377304d6977784e4451734d6a41304c4445304e5377354e5377324e5377344e6977794e5451734d7a55734d6a41334c4449774e7977794d6977324d6977354e5377774c446b784c4449784c4467314c4455774c4445324e5377794e4451734e5449734d6a55774c4449794e4377794e4455734d6a45304c4445774d4377794d7a45734d5467334c4445324d5377784e7a51734d6a4d794c4463304c446b7a4c4445794f5377784d4455734d69777a4c4445734d4377784c4445324d7977784d7a41734d5377784e4449734e4467734d544d774c4445734d544d344c4451344c4445304c4459734d7977344e5377794f5377784e5377784c4445734d6a55314c4451734e43777a4c4449734d6977784d7a49734e4467734d6a63734e69777a4c4467314c4449354c444d334c4451734d6a41734e4467734d5467734e6977354c44517a4c4459734d5377304c4445734d544d774c4455314c4449784c444d324c4459734e5377784d444d734d5449354c4455734f43777a4c4451344c4449794c4459734d7977344e5377794f53777a4d6977304c4445314c4451344c44457a4c4451344c4445784c4459734f5377304d7977324c4445734e4377784c44457a4d4377314e5377794d53777a4d5377304f4377784f4377324c444d734f4455734d6a6b734d546b734d5377784c4449314e5377304c4467734e4467734e6977784c4445734d6a55314c4449734d5377774c4451344c4449354c4459734d7977344e5377794f5377784e4377304c4449794c4451734d6a41734d5441794c4445784e5377784d544d734d7a51734d5445344c4451304c4451784c4445784d4377304e4377784e6a41734e7977794d546b734d544d344c444d794c4445334d7977784f444d734e4377784f544d734f5451734d5449794c4451344c444d784c4459734d7977344e5377794f53777a4e5377304c4449304c4451344c4449794c4445794f4377794d4377784d6a49734d5451774c4445774c4449774e6977304e7977334d6977354f4377794d7977794d6a59734d5451344c4449774f5377784e7a51734f4455734d546b7a4c4467794c44497a4e6977784d544d734d5445324c4445324e4377344e6977304f4377784d5449734e69777a4c4467314c4449354c444d784c4451734d5441314c4451344c4445774d7977304f4377784d4445734d5459774c446b354c4445324d4377354e7977784d7a51734f5455734d5441304c4445784e6977784d5459734d5445794c4455344c4451334c4451334c4445784f5377784d546b734d5445354c4451324c4445774f5377784d4455734f546b734d5445304c4445784d5377784d5455734d5445784c4445774d6977784d5459734e4459734f546b734d5445784c4445774f5377304e7977784d5449734d5441334c4445774e5377784d5445734d5445794c4445784e5377304e7977354f5377784d5451734d5441344c4451334c4463334c4445774e5377354f5377784d5451734d5445784c4445784e5377784d5445734d5441794c4445784e69777a4e7977314d4377304f4377344e4377344d4377334e79777a4e7977314d4377304f4377344d6977784d5445734d5445784c4445784e69777a4e7977314d4377304f4377324e7977784d4445734d5445304c4445784e6977784d4455734d5441794c4445774e5377354f5377354e7977784d5459734d5441784c444d334c4455774c4451344c4459314c4445784e7977784d5459734d5441304c4445784d5377784d5451734d5441314c4445784e6977784d6a45734d7a63734e5441734e4467734e5441734e4467734e446b734e5449734e4459734f546b734d5445304c4445774f4377304f4377784d6a55734e6977344c44517a4c4459734d5377314c4455734e7977784c4445734e4377784d544d734e4467734d5445784c4451344c4445774f5377324c4467734e444d734e6977784c4455734e5377334c4451344c4449734d544d304c446b334c4445774e4377784d5459734d5445324c4445784d6977314f4377304e7977304e7977784d546b734d5445354c4445784f5377304e6977784d446b734d5441314c446b354c4445784e4377784d5445734d5445314c4445784d5377784d4449734d5445324c4451324c446b354c4445784d5377784d446b734e4463734d5445794c4445774e7977784d4455734d5445784c4445784d6977784d5455734e4463734f546b734d5441784c4445784e4377784d5459734d5445314c4451334c4463334c4445774e5377354f5377784d5451734d5445784c4445784e5377784d5445734d5441794c4445784e69777a4e7977314d4377304f4377344e4377344d4377334e79777a4e7977314d4377304f4377344d6977784d5445734d5445784c4445784e69777a4e7977314d4377304f4377324e7977784d4445734d5445304c4445784e6977784d4455734d5441794c4445774e5377354f5377354e7977784d5459734d5441784c444d334c4455774c4451344c4459314c4445784e7977784d5459734d5441304c4445784d5377784d5451734d5441314c4445784e6977784d6a45734d7a63734e5441734e4467734e5441734e4467734e446b734e5449734e4459734f546b734d5445304c4445784e6977304f4377784d7977324c446b734e4449734d544d304c4463794c44457a4e4377794e4463734d544d734d5377784c4445784c4455734d43777a4c44457a4d4377794c4445734d4377794e6977784d544d734d4377784f4441734d5445304c44497a4c4445774e4377794d4445734d6a51334c4445334f5377784d7a45734e4455734d5441734e7a59734d546b774c4449794e6977324e6977794e4455734d54677a4c4449774f4377324f4377794d5449734d5441324c44497a4e6977784d5445734d5459314c4445354f43777a4e79777a4d7977784d6a4d734d5463774c4445794c4467774c4445794e4377784d4441734d546b344c4445344c446b784c446b354c444d304c4445324f5377334f4377784e6a4d734e7a55734d7a6b734d5459774c4445354e6977794d5449734d6a45794c4445354e7977794e446b734d6a4d774c4449774f43777a4c4463344c4449794d6977784e5459734d6a41784c4445324e79777a4c4445794e7977354e4377784f4451734d6a4d7a4c4445784f4377784e7a6b734d5467734f4451734d5441734e6a6b734d5377794d4441734d5459344c4467354c4445354d7977784f4451734d5445334c444d304c4445774d7977784e6a63734e6a67734d5445794c4449304d5377784d6a59734e6977304d6977324e5377784e5463734d6a41354c4445774d4377794e4377784e6977784e5459734d5455354c4445354e4377784e446b734d5451314c446b324c4459334c4445354e5377344e4377794d4445734d5459794c4451324c4445324e6977794d6a55734f43777a4d6977794d5445734d5455324c446b734d5445784c446b344c4449304e53777a4c4445334e4377784e7a6b734d7a6b734d6a49314c446b304c4445344e6977784d4449734e444d734d5463354c4459334c4445334d6977344e6977334c4445774d4377784f5463734d5463314c4445324d79777a4d4377304d5377784d4451734d5459794c4455794c4467324c4451334c4445774e5377784f5451734d5459314c4459354c4449304c446b304c4445304d5377784d7977794e446b734d5449304c4445354e6977784e5377784e4451734d6a45784c446b314c4445784f5377794e5451734d5467304c4445794e5377784d6a51734e4463734e5451734d5459774c4445784e4377794d4445734d5445304c4445304e7977354f4377794e7977344d6977334d7977324d4377334e5377794d7977784d5445734d54517a4c4449774f4377344d4377784e7977344d6977344c444d324c4467324c4449324c4445354d5377344f5377304e5377324e7977314e5377794d7a55734e7a4d734d5467354c4445314e7977794d444d734d5451344c4449304d6977784d6a67734e7a6b734e7a49734d6a63734e5459734e6a59734d5445304c4445784f4377314d7977794d544d734d5441334c444d784c4459314c44497a4f5377784e5455734e5459734d5449334c4463734d6a45774c4445344d7977794d544d734d6a55734d7a4d734d6a49794c4445304d4377344d4377304e5377794d4455734e6a49734e6a49734d6a45784c4445734d5451334c4445344d6977344d6977794e5441734d5459354c4445304f5377794e4449734f5467734d5459324c4449774c4445354e69777a4c4445344e4377794d4441734e4451734d5451774c4445354d5377324f5377794e7977784e7a63734d5455774c4451774c44457a4e4377784d7a63734f4459734d6a51784c4445304e6977784d4467734d5467324c4455334c4449324c4445344d5377784f544d734d6a41344c4467304c4463334c4449794c4449784d5377794d4467734e7a49734d5451304c4445344f4377784f5445734e7a49734d54557a4c4455354c4467304c4451774c444d334c4455784c4445334f4377794d7a4d734f4463734e7a55734e4455734e4445734d5451334c44457a4d6977784d446b734d6a4d774c4445334e6977344d5377304f5377794e4463734d546b304c4445784e6977784e6a55734d544d304c44457a4c44497a4f5377354e4377784d7a51734d6a55784c4445334e6977794e4449734d5445324c4455784c4445324d4377344f5377784d6a55734d6a55314c4451734e4467734d6a49334c4449794d7977314d6977784d4463734d5445334c44457a4e4377784d7a67734d544d304c4445354e5377784d5451734d5467794c4445774d7977794e5455734d6a4d334c4445794f4377784d5459734d6a41774c4449794f4377324c44557a4c4449314d5377784e7a45734e4459734d5451794c4449324c4445784e5377794d5441734d6a63734d5459784c444d344c4467304c4459794c4449784d6977784e5467734d544d774c4449314c44457a4f4377784d4449734d54637a4c446b7a4c4449304f5377784d7a6b734d5449354c4449774d4377784f5441734d6a417a4c44497a4d6977784d7a59734d54557a4c4445784f5377794d6a63734e5377334e7977784d6a67734d6a41354c4445334c4445344e4377784d4449734d6a4d334c4449784f4377784d5441734d5451354c444d324c44497a4f4377784e7a67734f4449734d6a41734e5463734d6a45794c4445794d7977794d5451734d5455334c4449334c4449314e5377324c4449794d7977784e6977784d6a55734d5441794c4445794d7977794d6a55734d6a55304c4445344e6977794d7a59734d5467734d6a45354c446b734e6a63734d6a4d784c44457a4e4377794d6a63734d6a55304c4449794d6977784e6a63734d5441774c4445304d7977784f4451734d5455794c444d324c4445324e7977784f444d734e544d734d546b334c4449774e7977784e7977784d7a41734e6a51734d6a417a4c4459784c4445784f4377784e6a59734d6a55314c4449774c4445794e7977794e4463734d6a45334c4449304d7977794d6a4d734f4441734d5455314c4445794f4377794e4459734d6a4d334c446b314c4445304e5377314d6977784e7977784d544d734d5455354c4445784d53777a4d4377784d4441734d7a59734d6a49334c446b7a4c4445344d5377784d5451734d7977784e5455734d6a51734e5377344d7977784e7a4d734e7a63734d5445784c44637a4c4449784e6977794d5449734d5449334c4445334d7977784e4449734d5377794d5463734d54497a4c4445314f4377324f4377334d6977794d5459734d6a55794c444d774c444d354c4455324c44497a4e4377314d7977784d4451734d6a51794c4463324c4445324e7977304d6977794d546b734d7a4d734d5451304c44497a4e7977794d6a51734d6a497a4c4445304e5377794e5377354e5377324c4463334c44457a4d7977794d7a4d734d5449354c44457a4e4377784c4445784f5377784d7a4d734f5451734e7977794e4449734e4459734d5463304c4445314f5377794e5377784e6a51734e7a67734d54597a4c4445314f5377784e7a49734d5445734d5449334c44457a4f5377784d444d734d5445794c4445784e7977354f4377324e5377784d5451734d5441784c446b334c4467344c4445784f4377774c444d314c4441734d5445734d4377304c4441734d5445304c4441734d7a49734d5455334c4449314e5377794d444d734d6a517a4c4445774f4377314e6977314f4377794d7a41734d54557a4c4449314d5377784e5449734d5441304c4449794d4377784d446b734d6a417a4c44457a4e7977794d5455734d6a45734e5459734d544d794c4445354d4377304d43777a4c4445304e6977304e4377784f4377324e5377344f4377784f5445734d54637a4c444d304c4445334e4377774c4445324c4441734d5459734d43777a4c4441734d5459734d43777a4d6977794d5467734f5451734e7a63734d546b734d5463314c4449794d5377784e6a4d734d6a4d784c4449304f5377334d6977314e5377784d7a6b734e7977344d5377334f4377354e6977784f544d734f4449734e7a4d734d6a49304c4459774c4449304e4377334d4377334d5377794d4441734f4449734e4445734e4455734e6a59734d6a41774c4445794d5377794e4467734d43777a4d6977784e5455734f5441734e446b734d6a55734e7a6b734e6a45734d7a63734d6a49354c4467784c4467734e6a67734d7a49734d5459794c4463734d5459784c4451794c4463734d546b774c4445354f4377784d5451734d6a67734d546b334c44517a4c4445324f4377344c4459734e5459734d5467774c4449334c4449774e4377784e446b734d5441774c4445774e4377354f5377784d4445734d5445304c4445784e6977334d7977784d5441734d5441794c4445784d5377344f4377784e6a45734d6a55314c4467304c4459334c4463784c4445794f4377794d7977774c444d304c4441734d5445734d6a4d784c4449344c4445304d4377334e4377334d5377304d6977784f4463734e6a51734e6a63734e5445734d5455344c4445344e6977784f546b734f4441734d6a41354c4445334e7977784e6a67734d6a457a4c4445344d7977784d5467734d7a41734d6a49354c444d334c4445794e7977784d6a67734d5445314c446b784c4449794e7977334f4377784f444d734d6a45774c4449774d5377774c4449774c44497a4f4377784d4445734d5467324c4445314e7977794e5451734d5445344c44457a4e6977794d5445734e7a41734f4467734e6a4d734d4377784e7a6b734d6a41784c4449314d4377314d4377784e5449734f5459734d6a55774c446b354c4441734d4377774c4451734f444d734e5449734e7a59734d6a497a4c4445354f5377344e6977784e4449734f4449734d544d334c4463354c4445304d7977794e5451734d5377344c4445304f5377794c4449784d4377344d5377324d7977344d69777a4d5377774c444d304c4441734d5445734d6a49774c4467784c4449784e6977794d6a49734e546b734f544d734e444d734e4463734d5459314c4445314d7977784e5451734d5455324c44517a4c4445354f5377784d4377794d6a49734e5459734d7a63734d6a41334c446b794c4445354f4377784e444d734d6a4d344c4445354f5377794d446b734d54597a4c4445304e4377784d7a51734d544d774c4445334f5377304d4377784d4463734d43777a4e4377774c4445784c4463334c4449794d6977784e444d734f5455734d6a51314c4445794d6977794e5455734f5451734d6a51344c44457a4d7977784e7a63734e7a6b734d5445344c4445334c4445734e5459734d6a49354c4445344d7977784e6a59734e5445734d5467784c4455304c4445324f4377784e4451734d6a55794c4445324f5377324e79777a4f53777a4d7977784d4441734d54457a4c44497a4e7977784d4451734f5463734d5445334c4445784e6977784d4451734e6a67734f5463734d5445324c446b334c4467344c4445324e4377334d7977784e5441734d544d734d6a49354c44457a4e6977784e4377784e4441734d5441304c4445784e6977314d6977794d7977784e5377784d4441734d5445344c446b324c446b784c4445304d7977794d6a67734d5463304c4445344e5377784e6a49734d544d304c4455774c4445354f5377784e544d734f5449734d6a517a4c4445344e6977784d7a45734d6a6b734d5455784c446b354c4459354c4441734d4377774c4441734f4377784e5449734d5445794c4467344c4449774d6977794d6a41734e7a55734d5449354c4445344d6977794d6a55734e4467734d6a49794c4467774c4449794d4377784f5441734d5455774c4441734d7a49734d5459324c4445784d7977324d6977794d5377784d6a55734d5449774c4445774f5377784e444d734e5467734e7a55734e546b734d7a6b734d6a4d734d5463354c4455774c4449794e4377334e7977794d4449734d5451304c4451354c4451774c4449794d7977794d7a51734d7a4d734d5463354c4445304e5377784e6a59734e6977784e6a63734d6a49784c4449784e5377784d446b734d5459314c4445734d69777a4c444d344c444d794c4445734d7a4d734f4467734d7a49734d6a45344c446b304c4463334c4445354c4445334e5377794d6a45734d54597a4c44497a4d5377794e446b734e7a49734e5455734d544d354c4463734f4445734e7a67734f5459734d546b7a4c4467794c44637a4c4449794e4377324d4377794e4451734e7a41734e7a45734d6a41774c4467794c4451784c4451314c4459324c4449774d4377784d6a45734d6a51344c444d304c4467344c444d794c4445314e5377354d4377304f5377794e5377334f5377324d53777a4e7977794d6a6b734f4445734f4377324f43777a4d6977784e6a49734e7977784e6a45734e4449734e7977784f5441734d546b344c4445784e4377794f4377784f5463734e444d734d5459344c4467734e6977314e6977784f4441734d6a63734d6a41304c4445304f5377784d4442644c434a6a62476c6c626e524559585268536c4e5054694936577a45794d79777a4e4377784d5459734d5449784c4445784d6977784d4445734d7a51734e5467734d7a51734d5445354c4445774d5377354f4377354e7977784d5463734d5445324c4445774e4377784d5441734e4459734f546b734d5445304c4445774d5377354e7977784d5459734d5441784c444d304c4451304c444d304c446b354c4445774e4377354e7977784d4467734d5441344c4445774d5377784d5441734d54417a4c4445774d53777a4e4377314f43777a4e4377304f4377784d546b734f4451734e446b734d5445324c44557a4c446b314c4451344c4467314c4459354c4445774d6977324e6977344d7977344e6977784d5445734f446b734e7a45734e7a59734f4467734f4445734e4467734d5445344c446b334c4445774d7977344d4377784d446b734f4451734f5463734d5441334c4467784c4459314c4467354c4463314c4463324c4445794d6977334d7977334d5377344f4377354f4377784d4463734d5449784c4451344c4445784f53777a4e4377304e43777a4e4377784d5445734d5445304c4445774e5377784d444d734d5441314c4445784d43777a4e4377314f43777a4e4377784d4451734d5445324c4445784e6977784d5449734e5467734e4463734e4463734d5441344c4445784d5377354f5377354e7977784d4467734d5441304c4445784d5377784d5455734d5445324c444d304c4451304c444d304c446b354c4445784e4377784d5445734d5445314c4445784e5377334f5377784d5451734d5441314c4445774d7977784d4455734d5445774c444d304c4455344c4445774d6977354e7977784d4467734d5445314c4445774d5377304e43777a4e4377784d5445734d5445324c4445774e4377784d4445734d5445304c446b314c4445774e7977784d4445734d5449784c4445784e5377354e5377354f5377354e7977784d5441734f5455734f5467734d5441784c446b314c446b334c4445774d4377784d4441734d5441784c4445774d4377354e5377784d4451734d5441784c4445784e4377784d4445734d7a51734e5467734d7a51734d5441774c4445784d53777a4d6977784d5441734d5445784c4445784e69777a4d6977354f5377784d5445734d5441354c4445784d6977354e7977784d5451734d5441784c444d794c446b354c4445774f4377784d4455734d5441784c4445784d4377784d5459734e6a67734f5463734d5445324c446b334c4463304c44677a4c4463354c4463344c444d794c446b334c4445774d7977354e7977784d4455734d5445774c4445784e5377784d5459734d7a49734f5463734d7a49734d5445324c4445774d5377784d446b734d5445794c4445774f4377354e7977784d5459734d5441784c4451324c444d794c44677a4c4445774d5377784d4445734d7a49734d5441304c4445784e6977784d5459734d5445794c4445784e5377314f4377304e7977304e7977784d444d734d5445784c4445784d5377304e6977784d444d734d5441344c4451334c4445794d5377354e7977354f4377344d4377784d4445734d5449774c444d304c4445794e56313966513d3d, 'completed', '2025-05-25 15:04:08', NULL);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `bao_hiem_thue_tncn`
--
ALTER TABLE `bao_hiem_thue_tncn`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_nhan_vien_thang` (`id_nhan_vien`,`thang`);

--
-- Chỉ mục cho bảng `cham_cong`
--
ALTER TABLE `cham_cong`
  ADD PRIMARY KEY (`id_cham_cong`),
  ADD UNIQUE KEY `uk_nhan_vien_ngay` (`id_nhan_vien`,`ngay_lam_viec`),
  ADD KEY `idx_cham_cong_ngay_lam_viec` (`ngay_lam_viec`);

--
-- Chỉ mục cho bảng `chi_phi_tuyen_dung`
--
ALTER TABLE `chi_phi_tuyen_dung`
  ADD PRIMARY KEY (`id_chi_phi`),
  ADD KEY `id_dot_tuyen_dung` (`id_dot_tuyen_dung`);

--
-- Chỉ mục cho bảng `chuc_vu`
--
ALTER TABLE `chuc_vu`
  ADD PRIMARY KEY (`id_chuc_vu`);

--
-- Chỉ mục cho bảng `danh_gia_ung_vien`
--
ALTER TABLE `danh_gia_ung_vien`
  ADD PRIMARY KEY (`id_danh_gia`),
  ADD KEY `id_ung_vien` (`id_ung_vien`),
  ADD KEY `id_ke_hoach` (`id_ke_hoach`);

--
-- Chỉ mục cho bảng `dot_tuyen_dung`
--
ALTER TABLE `dot_tuyen_dung`
  ADD PRIMARY KEY (`id_dot_tuyen_dung`),
  ADD UNIQUE KEY `uk_ma_dot` (`ma_dot`),
  ADD KEY `id_can_bo_tuyen_dung` (`id_can_bo_tuyen_dung`),
  ADD KEY `fk_phong_ban` (`id_phong_ban`);

--
-- Chỉ mục cho bảng `ke_hoach_tuyen_dung`
--
ALTER TABLE `ke_hoach_tuyen_dung`
  ADD PRIMARY KEY (`id_ke_hoach`),
  ADD KEY `id_chuc_vu` (`id_chuc_vu`);

--
-- Chỉ mục cho bảng `lich_hen_ung_vien`
--
ALTER TABLE `lich_hen_ung_vien`
  ADD PRIMARY KEY (`id_lich_hen`),
  ADD KEY `id_ung_vien` (`id_ung_vien`);

--
-- Chỉ mục cho bảng `luong`
--
ALTER TABLE `luong`
  ADD PRIMARY KEY (`id_luong`),
  ADD UNIQUE KEY `uk_nhan_vien_thang` (`id_nhan_vien`,`thang`),
  ADD KEY `idx_luong_thang` (`thang`);

--
-- Chỉ mục cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  ADD PRIMARY KEY (`id_nghi_phep`),
  ADD KEY `id_nhan_vien` (`id_nhan_vien`),
  ADD KEY `id_nguoi_duyet` (`id_nguoi_duyet`),
  ADD KEY `idx_nghi_phep_ngay_bat_dau` (`ngay_bat_dau`);

--
-- Chỉ mục cho bảng `nguoi_dung`
--
ALTER TABLE `nguoi_dung`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  ADD PRIMARY KEY (`id_nhan_vien`),
  ADD UNIQUE KEY `uk_email` (`email`),
  ADD UNIQUE KEY `uk_can_cuoc_cong_dan` (`can_cuoc_cong_dan`),
  ADD KEY `idx_nhan_vien_phong_ban` (`id_phong_ban`),
  ADD KEY `idx_nhan_vien_chuc_vu` (`id_chuc_vu`);

--
-- Chỉ mục cho bảng `phan_bo_ung_vien`
--
ALTER TABLE `phan_bo_ung_vien`
  ADD PRIMARY KEY (`id_phan_bo`),
  ADD KEY `id_ung_vien` (`id_ung_vien`),
  ADD KEY `id_phong_ban` (`id_phong_ban`),
  ADD KEY `fk_chuc_vu` (`id_chuc_vu`);

--
-- Chỉ mục cho bảng `phong_ban`
--
ALTER TABLE `phong_ban`
  ADD PRIMARY KEY (`id_phong_ban`);

--
-- Chỉ mục cho bảng `thuong`
--
ALTER TABLE `thuong`
  ADD PRIMARY KEY (`id_thuong`),
  ADD KEY `fk_thuong_nhan_vien` (`id_nhan_vien`);

--
-- Chỉ mục cho bảng `ung_vien`
--
ALTER TABLE `ung_vien`
  ADD PRIMARY KEY (`id_ung_vien`),
  ADD UNIQUE KEY `uk_email` (`email`),
  ADD KEY `id_dot_tuyen_dung` (`id_dot_tuyen_dung`),
  ADD KEY `id_chuc_vu` (`id_chuc_vu`);

--
-- Chỉ mục cho bảng `van_tay`
--
ALTER TABLE `van_tay`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_id_nhan_vien` (`id_nhan_vien`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `bao_hiem_thue_tncn`
--
ALTER TABLE `bao_hiem_thue_tncn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `cham_cong`
--
ALTER TABLE `cham_cong`
  MODIFY `id_cham_cong` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=570;

--
-- AUTO_INCREMENT cho bảng `chi_phi_tuyen_dung`
--
ALTER TABLE `chi_phi_tuyen_dung`
  MODIFY `id_chi_phi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `chuc_vu`
--
ALTER TABLE `chuc_vu`
  MODIFY `id_chuc_vu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `danh_gia_ung_vien`
--
ALTER TABLE `danh_gia_ung_vien`
  MODIFY `id_danh_gia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `dot_tuyen_dung`
--
ALTER TABLE `dot_tuyen_dung`
  MODIFY `id_dot_tuyen_dung` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT cho bảng `ke_hoach_tuyen_dung`
--
ALTER TABLE `ke_hoach_tuyen_dung`
  MODIFY `id_ke_hoach` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `lich_hen_ung_vien`
--
ALTER TABLE `lich_hen_ung_vien`
  MODIFY `id_lich_hen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `luong`
--
ALTER TABLE `luong`
  MODIFY `id_luong` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  MODIFY `id_nghi_phep` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT cho bảng `nguoi_dung`
--
ALTER TABLE `nguoi_dung`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  MODIFY `id_nhan_vien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT cho bảng `phan_bo_ung_vien`
--
ALTER TABLE `phan_bo_ung_vien`
  MODIFY `id_phan_bo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT cho bảng `phong_ban`
--
ALTER TABLE `phong_ban`
  MODIFY `id_phong_ban` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `thuong`
--
ALTER TABLE `thuong`
  MODIFY `id_thuong` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `ung_vien`
--
ALTER TABLE `ung_vien`
  MODIFY `id_ung_vien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT cho bảng `van_tay`
--
ALTER TABLE `van_tay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `bao_hiem_thue_tncn`
--
ALTER TABLE `bao_hiem_thue_tncn`
  ADD CONSTRAINT `bao_hiem_thue_tncn_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `cham_cong`
--
ALTER TABLE `cham_cong`
  ADD CONSTRAINT `cham_cong_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `chi_phi_tuyen_dung`
--
ALTER TABLE `chi_phi_tuyen_dung`
  ADD CONSTRAINT `chi_phi_tuyen_dung_ibfk_1` FOREIGN KEY (`id_dot_tuyen_dung`) REFERENCES `dot_tuyen_dung` (`id_dot_tuyen_dung`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `danh_gia_ung_vien`
--
ALTER TABLE `danh_gia_ung_vien`
  ADD CONSTRAINT `danh_gia_ung_vien_ibfk_1` FOREIGN KEY (`id_ung_vien`) REFERENCES `ung_vien` (`id_ung_vien`) ON DELETE CASCADE,
  ADD CONSTRAINT `danh_gia_ung_vien_ibfk_2` FOREIGN KEY (`id_ke_hoach`) REFERENCES `ke_hoach_tuyen_dung` (`id_ke_hoach`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `dot_tuyen_dung`
--
ALTER TABLE `dot_tuyen_dung`
  ADD CONSTRAINT `dot_tuyen_dung_ibfk_2` FOREIGN KEY (`id_can_bo_tuyen_dung`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_phong_ban` FOREIGN KEY (`id_phong_ban`) REFERENCES `phong_ban` (`id_phong_ban`);

--
-- Các ràng buộc cho bảng `ke_hoach_tuyen_dung`
--
ALTER TABLE `ke_hoach_tuyen_dung`
  ADD CONSTRAINT `ke_hoach_tuyen_dung_ibfk_1` FOREIGN KEY (`id_chuc_vu`) REFERENCES `chuc_vu` (`id_chuc_vu`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `lich_hen_ung_vien`
--
ALTER TABLE `lich_hen_ung_vien`
  ADD CONSTRAINT `lich_hen_ung_vien_ibfk_1` FOREIGN KEY (`id_ung_vien`) REFERENCES `ung_vien` (`id_ung_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `luong`
--
ALTER TABLE `luong`
  ADD CONSTRAINT `luong_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  ADD CONSTRAINT `nghi_phep_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE,
  ADD CONSTRAINT `nghi_phep_ibfk_2` FOREIGN KEY (`id_nguoi_duyet`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE SET NULL;

--
-- Các ràng buộc cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  ADD CONSTRAINT `nhan_vien_ibfk_1` FOREIGN KEY (`id_phong_ban`) REFERENCES `phong_ban` (`id_phong_ban`) ON DELETE SET NULL,
  ADD CONSTRAINT `nhan_vien_ibfk_2` FOREIGN KEY (`id_chuc_vu`) REFERENCES `chuc_vu` (`id_chuc_vu`) ON DELETE SET NULL;

--
-- Các ràng buộc cho bảng `phan_bo_ung_vien`
--
ALTER TABLE `phan_bo_ung_vien`
  ADD CONSTRAINT `fk_chuc_vu` FOREIGN KEY (`id_chuc_vu`) REFERENCES `chuc_vu` (`id_chuc_vu`),
  ADD CONSTRAINT `phan_bo_ung_vien_ibfk_1` FOREIGN KEY (`id_ung_vien`) REFERENCES `ung_vien` (`id_ung_vien`) ON DELETE CASCADE,
  ADD CONSTRAINT `phan_bo_ung_vien_ibfk_2` FOREIGN KEY (`id_phong_ban`) REFERENCES `phong_ban` (`id_phong_ban`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `thuong`
--
ALTER TABLE `thuong`
  ADD CONSTRAINT `fk_thuong_nhan_vien` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `ung_vien`
--
ALTER TABLE `ung_vien`
  ADD CONSTRAINT `ung_vien_ibfk_1` FOREIGN KEY (`id_dot_tuyen_dung`) REFERENCES `dot_tuyen_dung` (`id_dot_tuyen_dung`) ON DELETE CASCADE,
  ADD CONSTRAINT `ung_vien_ibfk_2` FOREIGN KEY (`id_chuc_vu`) REFERENCES `chuc_vu` (`id_chuc_vu`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `van_tay`
--
ALTER TABLE `van_tay`
  ADD CONSTRAINT `fk_van_tay_nhan_vien` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
