-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th5 24, 2025 lúc 10:39 AM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `doanqlns`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bao_hiem_thue_tncn`
--

CREATE TABLE `bao_hiem_thue_tncn` (
  `id` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `thang` varchar(7) NOT NULL,
  `bhxh` decimal(12,0) NOT NULL DEFAULT 0,
  `bhyt` decimal(12,0) NOT NULL DEFAULT 0,
  `bhtn` decimal(12,0) NOT NULL DEFAULT 0,
  `thue_tncn` decimal(12,0) NOT NULL DEFAULT 0,
  `tong_khoan_tru` decimal(12,0) GENERATED ALWAYS AS (`bhxh` + `bhyt` + `bhtn` + `thue_tncn`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `bao_hiem_thue_tncn`
--

INSERT INTO `bao_hiem_thue_tncn` (`id`, `id_nhan_vien`, `thang`, `bhxh`, `bhyt`, `bhtn`, `thue_tncn`) VALUES
(1, 1, '2025-05', 60000, 50000, 50000, 500000);

--
-- Bẫy `bao_hiem_thue_tncn`
--
DELIMITER $$
CREATE TRIGGER `capnhat_cac_khoan_tru` AFTER UPDATE ON `bao_hiem_thue_tncn` FOR EACH ROW BEGIN
  UPDATE luong
  SET cac_khoan_tru = NEW.tong_khoan_tru
  WHERE id_nhan_vien = NEW.id_nhan_vien AND thang = NEW.thang;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cham_cong`
--

CREATE TABLE `cham_cong` (
  `id_cham_cong` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `ngay_lam_viec` date NOT NULL,
  `gio_vao` time DEFAULT NULL,
  `gio_ra` time DEFAULT NULL,
  `trang_thai` enum('Đúng giờ','Đi trễ','Có phép','Không phép','Phép Năm','Nghỉ Lễ') DEFAULT NULL,
  `ghi_chu` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `cham_cong`
--

INSERT INTO `cham_cong` (`id_cham_cong`, `id_nhan_vien`, `ngay_lam_viec`, `gio_vao`, `gio_ra`, `trang_thai`, `ghi_chu`) VALUES
(1, 1, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(2, 1, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(3, 1, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(4, 1, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(5, 2, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(6, 2, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(7, 2, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(8, 2, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(9, 3, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(10, 3, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(11, 3, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(12, 3, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(13, 4, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(14, 4, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(15, 4, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(16, 4, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(17, 5, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(18, 5, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(19, 5, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(20, 5, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(21, 6, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(22, 6, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(23, 6, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(24, 6, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(25, 7, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(26, 7, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(27, 7, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(28, 7, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(29, 8, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(30, 8, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(31, 8, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(32, 8, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(33, 9, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(34, 9, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(35, 9, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(36, 9, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(37, 10, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(38, 10, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(39, 10, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(40, 10, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(41, 11, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(42, 11, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(43, 11, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(44, 11, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(45, 12, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(46, 12, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(47, 12, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(48, 12, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(49, 13, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(50, 13, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(51, 13, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(52, 13, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(53, 14, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(54, 14, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(55, 14, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(56, 14, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(57, 15, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(58, 15, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(59, 15, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(60, 15, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(61, 16, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(62, 16, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(63, 16, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(64, 16, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(65, 17, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(66, 17, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(67, 17, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(68, 17, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(69, 18, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(70, 18, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(71, 18, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(72, 18, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(73, 19, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(74, 19, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(75, 19, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(76, 19, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(77, 20, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(78, 20, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(79, 20, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(80, 20, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(81, 21, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(82, 21, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(83, 21, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(84, 21, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(85, 22, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(86, 22, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(87, 22, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(88, 22, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(89, 1, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(90, 2, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(91, 6, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(92, 11, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(93, 16, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(94, 21, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(95, 7, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(96, 12, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(97, 17, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(98, 22, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(99, 3, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(100, 8, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(101, 13, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(102, 18, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(103, 4, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(104, 9, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(105, 14, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(106, 19, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(107, 5, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(108, 10, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(109, 15, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(110, 20, '2025-05-22', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(111, 1, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(112, 2, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(113, 6, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(114, 11, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(115, 16, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(116, 21, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(117, 7, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(118, 12, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(119, 17, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(120, 22, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(121, 3, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(122, 8, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(123, 13, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(124, 18, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(125, 4, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(126, 9, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(127, 14, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(128, 19, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(129, 5, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(130, 10, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(131, 15, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(132, 20, '2025-05-23', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(133, 1, '2025-05-24', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(134, 2, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(135, 6, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(136, 11, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(137, 16, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(138, 21, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(139, 7, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(140, 12, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(141, 17, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(142, 22, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(143, 3, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(144, 8, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(145, 13, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(146, 18, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(147, 4, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(148, 9, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(149, 14, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(150, 19, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(151, 5, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(152, 10, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(153, 15, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(154, 20, '2025-05-24', NULL, NULL, 'Nghỉ Lễ', 'Điểm danh nghỉ lễ'),
(155, 1, '2025-05-21', '09:00:00', '17:00:00', 'Đi trễ', NULL),
(156, 50, '2025-05-04', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(157, 50, '2025-05-11', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(158, 50, '2025-05-25', '08:00:00', '17:00:00', 'Đúng giờ', NULL),
(159, 50, '2025-05-18', '08:00:00', '17:00:00', 'Đúng giờ', NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chi_phi_tuyen_dung`
--

CREATE TABLE `chi_phi_tuyen_dung` (
  `id_chi_phi` int(11) NOT NULL,
  `id_dot_tuyen_dung` int(11) NOT NULL,
  `noi_dung_chi_phi` varchar(255) NOT NULL,
  `so_tien` decimal(12,2) NOT NULL,
  `ngay_chi` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `chi_phi_tuyen_dung`
--

INSERT INTO `chi_phi_tuyen_dung` (`id_chi_phi`, `id_dot_tuyen_dung`, `noi_dung_chi_phi`, `so_tien`, `ngay_chi`) VALUES
(1, 1, 'Chi phí quảng cáo tuyển dụng', 5000000.00, '2025-05-01');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chuc_vu`
--

CREATE TABLE `chuc_vu` (
  `id_chuc_vu` int(11) NOT NULL,
  `ten_chuc_vu` varchar(100) NOT NULL,
  `mo_ta` text DEFAULT NULL,
  `phu_cap` decimal(12,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `chuc_vu`
--

INSERT INTO `chuc_vu` (`id_chuc_vu`, `ten_chuc_vu`, `mo_ta`, `phu_cap`) VALUES
(1, 'Nhân viên', 'Nhân viên cấp cơ sở', 3000000.00),
(3, 'Phó trưởng phòng', 'Quản lý phòng ban', 10000000.00),
(4, 'Trưởng phòng', 'Quản lý cấp cao', 15000000.00),
(5, 'Thực tập sinh', 'Nhân viên thực tập', 0.00);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danh_gia_ung_vien`
--

CREATE TABLE `danh_gia_ung_vien` (
  `id_danh_gia` int(11) NOT NULL,
  `id_ung_vien` int(11) NOT NULL,
  `id_ke_hoach` int(11) NOT NULL,
  `vong_thi` varchar(255) NOT NULL,
  `diem` decimal(5,2) NOT NULL,
  `nhan_xet` text DEFAULT NULL,
  `ngay_danh_gia` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `danh_gia_ung_vien`
--

INSERT INTO `danh_gia_ung_vien` (`id_danh_gia`, `id_ung_vien`, `id_ke_hoach`, `vong_thi`, `diem`, `nhan_xet`, `ngay_danh_gia`) VALUES
(1, 1, 1, 'Vòng 1: Phỏng vấn kỹ năng', 9.00, 'Ứng viên có kỹ năng giao tiếp tốt', '2025-05-10');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `dot_tuyen_dung`
--

CREATE TABLE `dot_tuyen_dung` (
  `id_dot_tuyen_dung` int(11) NOT NULL,
  `ma_dot` varchar(50) NOT NULL,
  `ten_dot` varchar(255) NOT NULL,
  `so_luong_tuyen` int(11) NOT NULL,
  `id_can_bo_tuyen_dung` int(11) NOT NULL,
  `ngay_bat_dau` date NOT NULL,
  `ngay_ket_thuc` date NOT NULL,
  `yeu_cau_vi_tri` text DEFAULT NULL,
  `trang_thai` enum('Đang tiến hành','Hoàn thành','Hủy bỏ') DEFAULT 'Đang tiến hành',
  `id_phong_ban` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `dot_tuyen_dung`
--

INSERT INTO `dot_tuyen_dung` (`id_dot_tuyen_dung`, `ma_dot`, `ten_dot`, `so_luong_tuyen`, `id_can_bo_tuyen_dung`, `ngay_bat_dau`, `ngay_ket_thuc`, `yeu_cau_vi_tri`, `trang_thai`, `id_phong_ban`) VALUES
(1, 'TD2025-0122ss', 'Đợt tuyển dụng Q1 2025', 5, 1, '2025-05-01', '2025-05-15', 'Có kinh nghiệm 2 năm trở lên', 'Đang tiến hành', 1),
(8, 'TU-160s', 'CEOa', 3, 1, '2025-05-10', '2025-05-14', 'kinh nghiệm 2 năm', 'Đang tiến hành', 3);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `ke_hoach_tuyen_dung`
--

CREATE TABLE `ke_hoach_tuyen_dung` (
  `id_ke_hoach` int(11) NOT NULL,
  `id_chuc_vu` int(11) NOT NULL,
  `so_vong_thi` int(2) NOT NULL,
  `ten_vong_thi` varchar(255) NOT NULL,
  `noi_dung_thi` text DEFAULT NULL,
  `diem_chuan` decimal(5,2) NOT NULL,
  `trong_so` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `ke_hoach_tuyen_dung`
--

INSERT INTO `ke_hoach_tuyen_dung` (`id_ke_hoach`, `id_chuc_vu`, `so_vong_thi`, `ten_vong_thi`, `noi_dung_thi`, `diem_chuan`, `trong_so`) VALUES
(1, 1, 2, 'Vòng 1: Phỏng vấn kỹ năng', 'Kiểm tra kỹ năng giao tiếp và chuyên môn', 7.50, 0.60);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `lich_hen_ung_vien`
--

CREATE TABLE `lich_hen_ung_vien` (
  `id_lich_hen` int(11) NOT NULL,
  `id_ung_vien` int(11) NOT NULL,
  `ngay_hen` date NOT NULL,
  `gio_hen` time NOT NULL,
  `dia_diem` varchar(255) NOT NULL,
  `ghi_chu` text DEFAULT NULL,
  `trang_thai` enum('Chờ lên lịch','Từ chối','Đã duyệt') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `lich_hen_ung_vien`
--

INSERT INTO `lich_hen_ung_vien` (`id_lich_hen`, `id_ung_vien`, `ngay_hen`, `gio_hen`, `dia_diem`, `ghi_chu`, `trang_thai`) VALUES
(1, 1, '2025-05-13', '09:00:00', 'Phòng họp 1', 'Mang theo CV và giấy tờ tùy thân', 'Đã duyệt');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `luong`
--

CREATE TABLE `luong` (
  `id_luong` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `thang` varchar(7) NOT NULL,
  `so_ngay_cong` int(11) NOT NULL,
  `luong_co_ban` decimal(12,0) NOT NULL,
  `phu_cap_chuc_vu` decimal(12,0) DEFAULT 0,
  `tien_thuong` decimal(12,0) DEFAULT 0,
  `cac_khoan_tru` decimal(12,0) DEFAULT 0,
  `luong_thuc_nhan` decimal(12,0) GENERATED ALWAYS AS (`luong_co_ban` * `so_ngay_cong` / 26 + `phu_cap_chuc_vu` + `tien_thuong` - `cac_khoan_tru`) STORED,
  `ngay_cham_cong` date NOT NULL,
  `trang_thai` enum('Tạm tính','Đã thanh toán') DEFAULT 'Tạm tính'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `luong`
--

INSERT INTO `luong` (`id_luong`, `id_nhan_vien`, `thang`, `so_ngay_cong`, `luong_co_ban`, `phu_cap_chuc_vu`, `tien_thuong`, `cac_khoan_tru`, `ngay_cham_cong`, `trang_thai`) VALUES
(1, 1, '2025-05', 6, 1935484, 3000000, 1500000, 660000, '2025-05-06', 'Tạm tính'),
(2, 2, '2025-05', 4, 2580645, 10000000, 0, 0, '2025-05-06', ''),
(3, 3, '2025-05', 4, 3225806, 15000000, 0, 0, '2025-05-06', ''),
(4, 4, '2025-05', 4, 1935484, 15000000, 0, 0, '2025-05-06', ''),
(5, 5, '2025-05', 4, 2193548, 15000000, 0, 0, '2025-05-06', ''),
(6, 6, '2025-05', 4, 1806452, 3000000, 0, 0, '2025-05-06', ''),
(7, 7, '2025-05', 4, 2064516, 15000000, 0, 0, '2025-05-06', ''),
(8, 8, '2025-05', 4, 1032258, 3000000, 0, 0, '2025-05-06', ''),
(9, 9, '2025-05', 4, 1419355, 10000000, 0, 0, '2025-05-06', ''),
(10, 10, '2025-05', 4, 1806452, 10000000, 0, 0, '2025-05-06', ''),
(11, 11, '2025-05', 4, 645161, 0, 0, 0, '2025-05-06', ''),
(12, 12, '2025-05', 4, 1225806, 3000000, 0, 0, '2025-05-06', ''),
(13, 13, '2025-05', 4, 2322581, 10000000, 0, 0, '2025-05-06', ''),
(14, 14, '2025-05', 4, 1032258, 3000000, 0, 0, '2025-05-06', ''),
(15, 15, '2025-05', 4, 903226, 3000000, 0, 0, '2025-05-06', ''),
(16, 16, '2025-05', 4, 1096774, 3000000, 0, 0, '2025-05-06', ''),
(17, 17, '2025-05', 4, 516129, 0, 0, 0, '2025-05-06', ''),
(18, 18, '2025-05', 4, 903226, 0, 0, 0, '2025-05-06', ''),
(19, 19, '2025-05', 4, 451613, 0, 0, 0, '2025-05-06', ''),
(20, 20, '2025-05', 4, 387097, 0, 0, 0, '2025-05-06', ''),
(21, 21, '2025-05', 4, 2193548, 3000000, 0, 0, '2025-05-06', ''),
(22, 22, '2025-05', 4, 1290323, 10000000, 0, 0, '2025-05-06', ''),
(24, 1, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(25, 2, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(26, 3, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(27, 4, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(28, 5, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(29, 6, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(30, 7, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(31, 8, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(32, 9, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(33, 10, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(34, 11, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(35, 12, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(36, 13, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(37, 14, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(38, 15, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(39, 16, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(40, 17, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(41, 18, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(42, 19, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(43, 20, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(44, 21, '2025-04', 4, 0, 0, 0, 0, '2025-05-07', ''),
(46, 22, '2025-04', 4, 0, 0, 0, 0, '2025-05-08', ''),
(52, 1, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(53, 2, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(54, 3, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(55, 4, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(56, 5, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(57, 6, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(58, 7, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(59, 8, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(60, 9, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(61, 10, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(62, 11, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(63, 12, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(64, 13, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(65, 14, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(66, 15, '2025-03', 5, 0, 0, 0, 0, '2025-05-09', ''),
(67, 16, '2025-03', 2, 0, 0, 0, 0, '2025-05-09', ''),
(74, 50, '2025-05', 4, 0, 3000000, 0, 0, '2025-05-23', 'Tạm tính');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nghi_phep`
--

CREATE TABLE `nghi_phep` (
  `id_nghi_phep` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `ngay_bat_dau` date NOT NULL,
  `ngay_ket_thuc` date NOT NULL,
  `loai_nghi` enum('Có phép','Không phép','Phép Năm') DEFAULT 'Có phép',
  `ly_do` text DEFAULT NULL,
  `trang_thai1` enum('Chờ duyệt','Đã duyệt','Từ chối') DEFAULT 'Chờ duyệt',
  `id_nguoi_duyet` int(11) DEFAULT NULL,
  `ly_do_tu_choi` text DEFAULT NULL,
  `ngay_duyet` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `nghi_phep`
--

INSERT INTO `nghi_phep` (`id_nghi_phep`, `id_nhan_vien`, `ngay_bat_dau`, `ngay_ket_thuc`, `loai_nghi`, `ly_do`, `trang_thai1`, `id_nguoi_duyet`, `ly_do_tu_choi`, `ngay_duyet`) VALUES
(32, 1, '2025-05-21', '2025-05-23', 'Có phép', 'Bệnh', 'Từ chối', 1, 'Nghỉ quá số ngày quy định', '2025-05-22 12:21:09'),
(33, 2, '2025-05-20', '2025-05-23', 'Phép Năm', 'Bệnh', 'Đã duyệt', 1, NULL, '2025-05-22 12:15:22'),
(34, 22, '2025-05-08', '2025-05-21', 'Phép Năm', 'Bệnh', 'Đã duyệt', 1, NULL, '2025-05-22 12:27:01'),
(35, 22, '2025-05-23', '2025-05-24', 'Có phép', 'Bệnh', '', NULL, NULL, NULL),
(36, 1, '2025-05-24', '2025-05-25', 'Có phép', 'Bệnh', 'Đã duyệt', 1, NULL, '2025-05-24 08:11:45');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nguoi_dung`
--

CREATE TABLE `nguoi_dung` (
  `id` int(10) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `ten_dang_nhap` varchar(50) DEFAULT NULL,
  `mat_khau` varchar(50) DEFAULT NULL,
  `quyen_them` int(1) DEFAULT 0,
  `quyen_sua` int(1) DEFAULT 0,
  `quyen_xoa` int(1) DEFAULT 0,
  `google_id` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `trang_thai` enum('Hoạt động','Không hoạt động') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `nguoi_dung`
--

INSERT INTO `nguoi_dung` (`id`, `id_nhan_vien`, `ten_dang_nhap`, `mat_khau`, `quyen_them`, `quyen_sua`, `quyen_xoa`, `google_id`, `email`, `trang_thai`) VALUES
(1, 0, 'Admin', '0192023a7bbd73250516f069df18b500', 1, 1, 1, '101975392065842316082', 'ngocthach1012017@gmail.com', 'Hoạt động'),
(2, 2, 'Quanly', 'e10adc3949ba59abbe56e057f20f883e', 1, 1, 0, NULL, 'luongthat2003@gmail.com', 'Hoạt động');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nhan_vien`
--

CREATE TABLE `nhan_vien` (
  `id_nhan_vien` int(11) NOT NULL,
  `ho_ten` varchar(100) NOT NULL,
  `gioi_tinh` enum('Nam','Nữ','Khác') DEFAULT NULL,
  `ngay_sinh` date DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `so_dien_thoai` varchar(20) DEFAULT NULL,
  `dia_chi` varchar(200) DEFAULT NULL,
  `can_cuoc_cong_dan` varchar(20) DEFAULT NULL,
  `ngay_cap` date DEFAULT NULL,
  `noi_cap` varchar(100) DEFAULT NULL,
  `que_quan` varchar(200) DEFAULT NULL,
  `hinh_anh` varchar(255) DEFAULT NULL,
  `id_phong_ban` int(11) DEFAULT NULL,
  `id_chuc_vu` int(11) DEFAULT NULL,
  `loai_hop_dong` enum('Toàn thời gian','Bán thời gian','Thực tập') NOT NULL,
  `luong_co_ban` decimal(12,2) NOT NULL,
  `ngay_vao_lam` date NOT NULL,
  `ngay_nghi_viec` date DEFAULT NULL,
  `trang_thai` enum('Đang làm việc','Nghỉ phép','Đã nghỉ việc') DEFAULT 'Đang làm việc'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `nhan_vien`
--

INSERT INTO `nhan_vien` (`id_nhan_vien`, `ho_ten`, `gioi_tinh`, `ngay_sinh`, `email`, `so_dien_thoai`, `dia_chi`, `can_cuoc_cong_dan`, `ngay_cap`, `noi_cap`, `que_quan`, `hinh_anh`, `id_phong_ban`, `id_chuc_vu`, `loai_hop_dong`, `luong_co_ban`, `ngay_vao_lam`, `ngay_nghi_viec`, `trang_thai`) VALUES
(1, 'Lương Ngọc Thật', 'Nam', '2025-04-15', 'ngocthach102017@gmail.com', '0901234581', 'An quới', '012028939492', '2023-03-27', 'An GIANG', 'Đồng Tháp', '/img/user1.jpg', 1, 1, 'Toàn thời gian', 10000000.00, '2025-05-16', '0000-00-00', 'Đang làm việc'),
(2, 'Lê Thị Ngọc Thúy', 'Nữ', '2003-03-15', 'luongthat2003@gmail.com', '01202893947', 'Chợ Gạo', '0120289394929', '2024-02-01', 'Tiền Giang', 'Đồng Tháp', NULL, 1, 3, 'Toàn thời gian', 20000000.00, '2020-05-04', NULL, 'Đang làm việc'),
(3, 'Lê Văn Cường', 'Nam', '1988-05-10', 'kingkai15032003@gmail.com', '0901234563', '78 Lê Lợi, Đà Nẵng', '123456789003', '2014-03-20', 'Đà Nẵng', 'Đà Nẵng', NULL, 3, 4, 'Toàn thời gian', 25000000.00, '2023-03-01', '0000-00-00', 'Đang làm việc'),
(4, 'Phạm Thị Dung', 'Nữ', '1995-07-25', 'dung.pham@example.com', '0901234564', '12 Trần Phú, Hà Nội', '123456789004', '2017-04-25', 'Hà Nội', 'Hà Nội', NULL, 4, 4, 'Toàn thời gian', 15000000.00, '2023-04-01', '0000-00-00', 'Đang làm việc'),
(5, 'Hoàng Văn Em', 'Nam', '1993-09-30', 'em.hoang@example.com', '0901234565', '56 Nguyễn Trãi, TP.HCM', '123456789005', '2018-05-30', 'TP.HCM', 'TP.HCM', NULL, 5, 4, 'Toàn thời gian', 17000000.00, '2023-05-01', '0000-00-00', 'Đang làm việc'),
(6, 'Nguyễn Thị Fleur', 'Nữ', '1991-11-05', 'fleur.nguyen@example.com', '0901234566', '89 Hai Bà Trưng, Hà Nội', '123456789006', '2015-06-05', 'Hà Nội', 'Hà Nội', NULL, 1, 1, 'Toàn thời gian', 14000000.00, '2023-06-01', '0000-00-00', 'Đang làm việc'),
(7, 'Trần Văn Giang', 'Nam', '1989-12-12', 'giang.tran@example.com', '0901234567', '34 Lê Duẩn, Đà Nẵng', '123456789007', '2016-07-10', 'Đà Nẵng', 'Đà Nẵng', NULL, 2, 4, 'Toàn thời gian', 16000000.00, '2023-07-01', '0000-00-00', 'Đang làm việc'),
(8, 'Lê Thị Hà', 'Nữ', '1994-02-18', 'ha.le@example.com', '0901234568', '67 Nguyễn Văn Cừ, TP.HCM', '123456789008', '2017-08-15', 'TP.HCM', 'TP.HCM', NULL, 3, 1, 'Toàn thời gian', 8000000.00, '2023-08-01', NULL, 'Đang làm việc'),
(9, 'Phạm Văn Inh', 'Nam', '1990-04-22', 'inh.pham@example.com', '0901234569', '23 Lý Thường Kiệt, Hà Nội', '123456789009', '2018-09-20', 'Hà Nội', 'Hà Nội', NULL, 4, 3, 'Toàn thời gian', 11000000.00, '2023-09-01', NULL, 'Đang làm việc'),
(10, 'Hoàng Thị Kim', 'Nữ', '1996-06-28', 'kim.hoang@example.com', '0901234570', '45 Phạm Ngọc Thạch, TP.HCM', '123456789010', '2019-10-25', 'TP.HCM', 'TP.HCM', NULL, 5, 3, 'Toàn thời gian', 14000000.00, '2023-10-01', '0000-00-00', 'Đang làm việc'),
(11, 'Nguyễn Văn Long', 'Nam', '1987-08-03', 'long.nguyen@example.com', '0901234571', '78 Hùng Vương, Đà Nẵng', '123456789011', '2014-11-30', 'Đà Nẵng', 'Đà Nẵng', NULL, 1, 5, 'Thực tập', 5000000.00, '2023-11-01', '0000-00-00', 'Đang làm việc'),
(12, 'Trần Thị Mai', 'Nữ', '1993-10-09', 'mai.tran@example.com', '0901234572', '12 Nguyễn Đình Chiểu, Hà Nội', '123456789012', '2015-12-05', 'Hà Nội', 'Hà Nội', NULL, 2, 1, 'Toàn thời gian', 9500000.00, '2023-12-01', NULL, 'Đang làm việc'),
(13, 'Lê Văn Nam', 'Nam', '1991-12-15', 'nam.le@example.com', '0901234573', '56 Trần Hưng Đạo, TP.HCM', '123456789013', '2016-01-10', 'TP.HCM', 'TP.HCM', NULL, 3, 3, 'Toàn thời gian', 18000000.00, '2024-01-01', '0000-00-00', 'Đang làm việc'),
(14, 'Phạm Thị Oanh', 'Nữ', '1988-02-20', 'oanh.pham@example.com', '0901234574', '89 Nguyễn Thị Minh Khai, Hà Nội', '123456789014', '2017-02-15', 'Hà Nội', 'Hà Nội', NULL, 4, 1, 'Toàn thời gian', 8000000.00, '2024-02-01', '0000-00-00', 'Đang làm việc'),
(15, 'Hoàng Văn Phát', 'Nam', '1995-04-25', 'phat.hoang@example.com', '0901234575', '34 Lê Văn Sỹ, TP.HCM', '123456789015', '2018-03-20', 'TP.HCM', 'TP.HCM', NULL, 5, 1, 'Toàn thời gian', 7000000.00, '2024-03-01', '0000-00-00', 'Đang làm việc'),
(16, 'Nguyễn Thị Quyên', 'Nữ', '1992-06-30', 'quyen.nguyen@example.com', '0901234576', '67 Bà Triệu, Hà Nội', '123456789016', '2019-04-25', 'Hà Nội', 'Hà Nội', NULL, 1, 1, 'Toàn thời gian', 8500000.00, '2024-04-01', NULL, 'Đang làm việc'),
(17, 'Trần Văn Sơn', 'Nam', '1989-08-05', 'son.tran@example.com', '0901234577', '23 Tôn Đức Thắng, Đà Nẵng', '123456789017', '2015-05-30', 'Đà Nẵng', 'Đà Nẵng', NULL, 2, 5, 'Thực tập', 4000000.00, '2023-01-01', '2024-12-31', 'Đang làm việc'),
(18, 'Lê Thị Thanh', 'Nữ', '1994-10-10', 'thanh.le@example.com', '0901234578', '45 Nguyễn Văn Trỗi, TP.HCM', '123456789018', '2016-06-05', 'TP.HCM', 'TP.HCM', NULL, 3, 5, 'Toàn thời gian', 7000000.00, '2023-02-01', '0000-00-00', 'Đang làm việc'),
(19, 'Phạm Văn Uy', 'Nam', '1990-12-15', 'uy.pham@example.com', '0901234579', '78 Lê Đại Hành, Hà Nội', '123456789019', '2017-07-10', 'Hà Nội', 'Hà Nội', NULL, 4, 5, 'Thực tập', 3500000.00, '2023-03-01', '0000-00-00', 'Đang làm việc'),
(20, 'Hoàng Thị Vân', 'Nữ', '1996-02-20', 'van.hoang@example.com', '0901234580', '12 Võ Văn Tần, TP.HCM', '123456789020', '2018-08-15', 'TP.HCM', 'TP.HCM', NULL, 5, 5, 'Thực tập', 3000000.00, '2023-04-01', NULL, 'Đang làm việc'),
(21, 'Nguyễn Văn An ', 'Nam', '1990-01-15', 'an.nguyen@example.com', '0901234561', '123 Đường Láng, Hà Nội', '123456789001', '2015-01-10', 'Hà Nội', 'Hà Nội', 'img/1.jpg', 1, 1, 'Toàn thời gian', 17000000.00, '2023-01-01', '0000-00-00', 'Đang làm việc'),
(22, 'Trần Thị Bình', 'Nam', '1992-03-20', 'binh.tran@example.com', '0901234562', '45 Nguyễn Huệ, TP.HCM', '123456789002', '2016-02-15', 'TP.HCM', 'TP.HCM', NULL, 2, 3, 'Toàn thời gian', 10000000.00, '2023-02-01', '0000-00-00', 'Đang làm việc'),
(50, 'Nguyễn Vănsssss', NULL, NULL, 'ngocthach1012017@gmail.com', '0901234581', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 'Toàn thời gian', 0.00, '2025-05-23', NULL, 'Đang làm việc');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `phan_bo_ung_vien`
--

CREATE TABLE `phan_bo_ung_vien` (
  `id_phan_bo` int(11) NOT NULL,
  `id_ung_vien` int(11) NOT NULL,
  `id_phong_ban` int(11) NOT NULL,
  `trang_thai` enum('Chờ phân bổ','Từ chối','Đã duyệt') DEFAULT 'Chờ phân bổ',
  `ngay_phan_bo` date NOT NULL,
  `hop_dong_thu_viec` text DEFAULT NULL,
  `id_chuc_vu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `phan_bo_ung_vien`
--

INSERT INTO `phan_bo_ung_vien` (`id_phan_bo`, `id_ung_vien`, `id_phong_ban`, `trang_thai`, `ngay_phan_bo`, `hop_dong_thu_viec`, `id_chuc_vu`) VALUES
(18, 1, 1, 'Đã duyệt', '2025-05-18', '', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `phong_ban`
--

CREATE TABLE `phong_ban` (
  `id_phong_ban` int(11) NOT NULL,
  `ten_phong_ban` varchar(100) NOT NULL,
  `mo_ta` text DEFAULT NULL,
  `trang_thai` enum('Hoạt động','Ngừng hoạt động') DEFAULT 'Hoạt động'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `phong_ban`
--

INSERT INTO `phong_ban` (`id_phong_ban`, `ten_phong_ban`, `mo_ta`, `trang_thai`) VALUES
(1, 'Nhân sự', 'Quản lý nhân sự và tuyển dụng', 'Hoạt động'),
(2, 'Kế toán', 'Quản lý tài chính và kế toán', 'Hoạt động'),
(3, 'Công nghệ', 'Phát triển phần mềm và công nghệ', 'Hoạt động'),
(4, 'Kinh doanh', 'Phát triển kinh doanh và bán hàng', 'Hoạt động'),
(5, 'Marketing', 'Quảng bá thương hiệu và sản phẩm', 'Hoạt động');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `thuong`
--

CREATE TABLE `thuong` (
  `id_thuong` int(11) NOT NULL,
  `id_nhan_vien` int(11) NOT NULL,
  `noi_dung_thuong` varchar(255) DEFAULT NULL,
  `ngay` date NOT NULL,
  `loai` enum('nghỉ lễ','thăng chức','thành tích cá nhân','phạt kỷ luật','phạt trách nhiệm công việc') NOT NULL,
  `tien_thuong` decimal(12,0) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `thuong`
--

INSERT INTO `thuong` (`id_thuong`, `id_nhan_vien`, `noi_dung_thuong`, `ngay`, `loai`, `tien_thuong`) VALUES
(1, 1, '30', '2025-05-01', 'nghỉ lễ', 1500000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `ung_vien`
--

CREATE TABLE `ung_vien` (
  `id_ung_vien` int(11) NOT NULL,
  `ho_ten` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `so_dien_thoai` varchar(20) DEFAULT NULL,
  `id_dot_tuyen_dung` int(11) NOT NULL,
  `id_chuc_vu` int(11) NOT NULL,
  `nguon_ung_tuyen` varchar(100) DEFAULT 'Trực tiếp',
  `ho_so` text DEFAULT NULL,
  `trang_thai` enum('Mới nộp','Đang xử lý','Đạt','Không đạt') DEFAULT 'Mới nộp'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `ung_vien`
--

INSERT INTO `ung_vien` (`id_ung_vien`, `ho_ten`, `email`, `so_dien_thoai`, `id_dot_tuyen_dung`, `id_chuc_vu`, `nguon_ung_tuyen`, `ho_so`, `trang_thai`) VALUES
(1, 'Nguyễn Vănsssss', 'ngocthach1012017@gmail.com', '0901234581', 1, 1, 'Website', 'CV Nguyễn Văn A', 'Mới nộp'),
(11, 'Phan Văn Toàn', 'rya07668@gmail.com', '0120289394', 8, 1, 'web', '', 'Mới nộp'),
(12, 'Lý Anh Khoa', 'luong@gmail.com', '0102893945', 8, 5, 'web', '', 'Mới nộp');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `bao_hiem_thue_tncn`
--
ALTER TABLE `bao_hiem_thue_tncn`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_nhan_vien_thang` (`id_nhan_vien`,`thang`);

--
-- Chỉ mục cho bảng `cham_cong`
--
ALTER TABLE `cham_cong`
  ADD PRIMARY KEY (`id_cham_cong`),
  ADD UNIQUE KEY `uk_nhan_vien_ngay` (`id_nhan_vien`,`ngay_lam_viec`),
  ADD KEY `idx_cham_cong_ngay_lam_viec` (`ngay_lam_viec`);

--
-- Chỉ mục cho bảng `chi_phi_tuyen_dung`
--
ALTER TABLE `chi_phi_tuyen_dung`
  ADD PRIMARY KEY (`id_chi_phi`),
  ADD KEY `id_dot_tuyen_dung` (`id_dot_tuyen_dung`);

--
-- Chỉ mục cho bảng `chuc_vu`
--
ALTER TABLE `chuc_vu`
  ADD PRIMARY KEY (`id_chuc_vu`);

--
-- Chỉ mục cho bảng `danh_gia_ung_vien`
--
ALTER TABLE `danh_gia_ung_vien`
  ADD PRIMARY KEY (`id_danh_gia`),
  ADD KEY `id_ung_vien` (`id_ung_vien`),
  ADD KEY `id_ke_hoach` (`id_ke_hoach`);

--
-- Chỉ mục cho bảng `dot_tuyen_dung`
--
ALTER TABLE `dot_tuyen_dung`
  ADD PRIMARY KEY (`id_dot_tuyen_dung`),
  ADD UNIQUE KEY `uk_ma_dot` (`ma_dot`),
  ADD KEY `id_can_bo_tuyen_dung` (`id_can_bo_tuyen_dung`),
  ADD KEY `fk_phong_ban` (`id_phong_ban`);

--
-- Chỉ mục cho bảng `ke_hoach_tuyen_dung`
--
ALTER TABLE `ke_hoach_tuyen_dung`
  ADD PRIMARY KEY (`id_ke_hoach`),
  ADD KEY `id_chuc_vu` (`id_chuc_vu`);

--
-- Chỉ mục cho bảng `lich_hen_ung_vien`
--
ALTER TABLE `lich_hen_ung_vien`
  ADD PRIMARY KEY (`id_lich_hen`),
  ADD KEY `id_ung_vien` (`id_ung_vien`);

--
-- Chỉ mục cho bảng `luong`
--
ALTER TABLE `luong`
  ADD PRIMARY KEY (`id_luong`),
  ADD UNIQUE KEY `uk_nhan_vien_thang` (`id_nhan_vien`,`thang`),
  ADD KEY `idx_luong_thang` (`thang`);

--
-- Chỉ mục cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  ADD PRIMARY KEY (`id_nghi_phep`),
  ADD KEY `id_nhan_vien` (`id_nhan_vien`),
  ADD KEY `id_nguoi_duyet` (`id_nguoi_duyet`),
  ADD KEY `idx_nghi_phep_ngay_bat_dau` (`ngay_bat_dau`);

--
-- Chỉ mục cho bảng `nguoi_dung`
--
ALTER TABLE `nguoi_dung`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  ADD PRIMARY KEY (`id_nhan_vien`),
  ADD UNIQUE KEY `uk_email` (`email`),
  ADD UNIQUE KEY `uk_can_cuoc_cong_dan` (`can_cuoc_cong_dan`),
  ADD KEY `idx_nhan_vien_phong_ban` (`id_phong_ban`),
  ADD KEY `idx_nhan_vien_chuc_vu` (`id_chuc_vu`);

--
-- Chỉ mục cho bảng `phan_bo_ung_vien`
--
ALTER TABLE `phan_bo_ung_vien`
  ADD PRIMARY KEY (`id_phan_bo`),
  ADD KEY `id_ung_vien` (`id_ung_vien`),
  ADD KEY `id_phong_ban` (`id_phong_ban`),
  ADD KEY `fk_chuc_vu` (`id_chuc_vu`);

--
-- Chỉ mục cho bảng `phong_ban`
--
ALTER TABLE `phong_ban`
  ADD PRIMARY KEY (`id_phong_ban`);

--
-- Chỉ mục cho bảng `thuong`
--
ALTER TABLE `thuong`
  ADD PRIMARY KEY (`id_thuong`),
  ADD KEY `fk_thuong_nhan_vien` (`id_nhan_vien`);

--
-- Chỉ mục cho bảng `ung_vien`
--
ALTER TABLE `ung_vien`
  ADD PRIMARY KEY (`id_ung_vien`),
  ADD UNIQUE KEY `uk_email` (`email`),
  ADD KEY `id_dot_tuyen_dung` (`id_dot_tuyen_dung`),
  ADD KEY `id_chuc_vu` (`id_chuc_vu`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `bao_hiem_thue_tncn`
--
ALTER TABLE `bao_hiem_thue_tncn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `cham_cong`
--
ALTER TABLE `cham_cong`
  MODIFY `id_cham_cong` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=160;

--
-- AUTO_INCREMENT cho bảng `chi_phi_tuyen_dung`
--
ALTER TABLE `chi_phi_tuyen_dung`
  MODIFY `id_chi_phi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `chuc_vu`
--
ALTER TABLE `chuc_vu`
  MODIFY `id_chuc_vu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `danh_gia_ung_vien`
--
ALTER TABLE `danh_gia_ung_vien`
  MODIFY `id_danh_gia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `dot_tuyen_dung`
--
ALTER TABLE `dot_tuyen_dung`
  MODIFY `id_dot_tuyen_dung` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT cho bảng `ke_hoach_tuyen_dung`
--
ALTER TABLE `ke_hoach_tuyen_dung`
  MODIFY `id_ke_hoach` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `lich_hen_ung_vien`
--
ALTER TABLE `lich_hen_ung_vien`
  MODIFY `id_lich_hen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `luong`
--
ALTER TABLE `luong`
  MODIFY `id_luong` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  MODIFY `id_nghi_phep` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT cho bảng `nguoi_dung`
--
ALTER TABLE `nguoi_dung`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  MODIFY `id_nhan_vien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT cho bảng `phan_bo_ung_vien`
--
ALTER TABLE `phan_bo_ung_vien`
  MODIFY `id_phan_bo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT cho bảng `phong_ban`
--
ALTER TABLE `phong_ban`
  MODIFY `id_phong_ban` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `thuong`
--
ALTER TABLE `thuong`
  MODIFY `id_thuong` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `ung_vien`
--
ALTER TABLE `ung_vien`
  MODIFY `id_ung_vien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `bao_hiem_thue_tncn`
--
ALTER TABLE `bao_hiem_thue_tncn`
  ADD CONSTRAINT `bao_hiem_thue_tncn_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `cham_cong`
--
ALTER TABLE `cham_cong`
  ADD CONSTRAINT `cham_cong_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `chi_phi_tuyen_dung`
--
ALTER TABLE `chi_phi_tuyen_dung`
  ADD CONSTRAINT `chi_phi_tuyen_dung_ibfk_1` FOREIGN KEY (`id_dot_tuyen_dung`) REFERENCES `dot_tuyen_dung` (`id_dot_tuyen_dung`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `danh_gia_ung_vien`
--
ALTER TABLE `danh_gia_ung_vien`
  ADD CONSTRAINT `danh_gia_ung_vien_ibfk_1` FOREIGN KEY (`id_ung_vien`) REFERENCES `ung_vien` (`id_ung_vien`) ON DELETE CASCADE,
  ADD CONSTRAINT `danh_gia_ung_vien_ibfk_2` FOREIGN KEY (`id_ke_hoach`) REFERENCES `ke_hoach_tuyen_dung` (`id_ke_hoach`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `dot_tuyen_dung`
--
ALTER TABLE `dot_tuyen_dung`
  ADD CONSTRAINT `dot_tuyen_dung_ibfk_2` FOREIGN KEY (`id_can_bo_tuyen_dung`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_phong_ban` FOREIGN KEY (`id_phong_ban`) REFERENCES `phong_ban` (`id_phong_ban`);

--
-- Các ràng buộc cho bảng `ke_hoach_tuyen_dung`
--
ALTER TABLE `ke_hoach_tuyen_dung`
  ADD CONSTRAINT `ke_hoach_tuyen_dung_ibfk_1` FOREIGN KEY (`id_chuc_vu`) REFERENCES `chuc_vu` (`id_chuc_vu`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `lich_hen_ung_vien`
--
ALTER TABLE `lich_hen_ung_vien`
  ADD CONSTRAINT `lich_hen_ung_vien_ibfk_1` FOREIGN KEY (`id_ung_vien`) REFERENCES `ung_vien` (`id_ung_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `luong`
--
ALTER TABLE `luong`
  ADD CONSTRAINT `luong_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `nghi_phep`
--
ALTER TABLE `nghi_phep`
  ADD CONSTRAINT `nghi_phep_ibfk_1` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE,
  ADD CONSTRAINT `nghi_phep_ibfk_2` FOREIGN KEY (`id_nguoi_duyet`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE SET NULL;

--
-- Các ràng buộc cho bảng `nhan_vien`
--
ALTER TABLE `nhan_vien`
  ADD CONSTRAINT `nhan_vien_ibfk_1` FOREIGN KEY (`id_phong_ban`) REFERENCES `phong_ban` (`id_phong_ban`) ON DELETE SET NULL,
  ADD CONSTRAINT `nhan_vien_ibfk_2` FOREIGN KEY (`id_chuc_vu`) REFERENCES `chuc_vu` (`id_chuc_vu`) ON DELETE SET NULL;

--
-- Các ràng buộc cho bảng `phan_bo_ung_vien`
--
ALTER TABLE `phan_bo_ung_vien`
  ADD CONSTRAINT `fk_chuc_vu` FOREIGN KEY (`id_chuc_vu`) REFERENCES `chuc_vu` (`id_chuc_vu`),
  ADD CONSTRAINT `phan_bo_ung_vien_ibfk_1` FOREIGN KEY (`id_ung_vien`) REFERENCES `ung_vien` (`id_ung_vien`) ON DELETE CASCADE,
  ADD CONSTRAINT `phan_bo_ung_vien_ibfk_2` FOREIGN KEY (`id_phong_ban`) REFERENCES `phong_ban` (`id_phong_ban`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `thuong`
--
ALTER TABLE `thuong`
  ADD CONSTRAINT `fk_thuong_nhan_vien` FOREIGN KEY (`id_nhan_vien`) REFERENCES `nhan_vien` (`id_nhan_vien`) ON DELETE CASCADE;

--
-- Các ràng buộc cho bảng `ung_vien`
--
ALTER TABLE `ung_vien`
  ADD CONSTRAINT `ung_vien_ibfk_1` FOREIGN KEY (`id_dot_tuyen_dung`) REFERENCES `dot_tuyen_dung` (`id_dot_tuyen_dung`) ON DELETE CASCADE,
  ADD CONSTRAINT `ung_vien_ibfk_2` FOREIGN KEY (`id_chuc_vu`) REFERENCES `chuc_vu` (`id_chuc_vu`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
