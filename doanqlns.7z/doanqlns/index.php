<?php
header('Content-Type:application/json');
include_once("routes/api.php");

?>
