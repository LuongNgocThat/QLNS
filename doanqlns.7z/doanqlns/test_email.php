<?php
require_once __DIR__ . '/vendor/autoload.php';

$emailService = new \Services\EmailService();

try {
    // Kiểm tra cấu hình
    $verifyResult = $emailService->verifyEmailConfig();
    echo "Kết quả kiểm tra cấu hình:\n";
    echo "- " . ($verifyResult['success'] ? "✓ " : "✗ ") . $verifyResult['message'] . "\n\n";

    if ($verifyResult['success']) {
        // Gửi email test
        echo "Đang gửi email test...\n";
        $result = $emailService->send(
            'kingkai15032003@gmail.com',
            'Test Email từ HRM System',
            '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <div style="background: linear-gradient(90deg, #007bff, #0056b3); color: white; padding: 20px; text-align: center;">
                    <h1 style="margin: 0;">Test Email từ HRM System</h1>
                </div>
                <div style="padding: 20px; border: 1px solid #ddd;">
                    <p><strong>Xin chào!</strong></p>
                    <p>Đây là email test để kiểm tra cấu hình SendGrid.</p>
                    <p>Thông tin gửi:</p>
                    <ul>
                        <li>Thời gian: ' . date('d/m/Y H:i:s') . '</li>
                        <li>Từ: HRM - Ngọc Thật Lương</li>
                        <li>Email: kingkai15032003@gmail.com</li>
                    </ul>
                    <p>Nếu bạn nhận được email này, có nghĩa là cấu hình email đã hoạt động thành công!</p>
                    <p style="margin-top: 20px;">Trân trọng,<br>HRM System</p>
                </div>
            </div>'
        );
        
        if ($result) {
            echo "✓ Email test đã được gửi thành công!\n";
        }
    }
} catch (Exception $e) {
    echo "✗ Lỗi: " . $e->getMessage() . "\n";
    echo "Chi tiết lỗi đã được ghi vào log file.\n";
} 