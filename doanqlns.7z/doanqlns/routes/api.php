<?php
ob_start();
ini_set('display_errors', 0); // Disable error display to prevent HTML output
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/logs/php_errors.log');
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
session_start();

include_once(__DIR__ . '/../controllers/UserController.php');
include_once(__DIR__ . '/../controllers/ChamCongController.php');
include_once(__DIR__ . '/../controllers/NghiPhepController.php');
include_once(__DIR__ . '/../controllers/LuongController.php');
include_once(__DIR__ . '/../controllers/BaoHiemController.php');
include_once(__DIR__ . '/../controllers/SettingsController.php');
include_once(__DIR__ . '/../controllers/ThuongController.php');
include_once(__DIR__ . '/../controllers/TuyenDungController.php');
include_once(__DIR__ . '/../controllers/EmployeeController.php');
include_once(__DIR__ . '/../controllers/FingerprintController.php');

$userController = new UserController();
$chamCongController = new ChamCongController();
$nghiPhepController = new NghiPhepController();
$luongController = new LuongController();
$baoHiemController = new BaoHiemThueController();
$settingsController = new SettingsController();
$thuongController = new ThuongController();
$tuyenDungController = new TuyenDungController();
$employeeController = new EmployeeController();
$fingerprintController = new FingerprintController();

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    ob_end_clean();
    exit();
}

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    ob_end_clean();
    echo json_encode(["success" => false, "message" => "Vui lòng đăng nhập"]);
    exit();
}

// Check if van_tay table exists
try {
    $db = new Database();
    $conn = $db->getConnection();
    $conn->query("DESCRIBE van_tay");
} catch (Exception $e) {
    error_log("Database error: " . $e->getMessage());
    http_response_code(500);
    ob_end_clean();
    echo json_encode(["success" => false, "message" => "Lỗi cơ sở dữ liệu: Bảng van_tay không tồn tại hoặc không thể truy cập"]);
    exit();
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/users') {
            $userController->getAllUsers();
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/nhanvien') {
            $userController->getAllUsers();
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/user\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $userId = intval($matches[1]);
            $userController->getUserById($userId);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/phongban') {
            $userController->getAllPhongBan();
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/chucvu') {
            $userController->getAllChucVu();
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/baohiem(\?month=(\d+)&year=(\d+))?/', $_SERVER['REQUEST_URI'], $matches)) {
            $month = isset($matches[2]) ? intval($matches[2]) : null;
            $year = isset($matches[3]) ? intval($matches[3]) : null;
            $baoHiemController->getAllBaoHiemThue($month, $year);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/chamcong') {
            $chamCongController->getAllChamCong();
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/nghiphep') {
            $nghiPhepController->getAllNghiPhep();
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/luong(\?month=(\d+)&year=(\d+))?/', $_SERVER['REQUEST_URI'], $matches)) {
            $month = isset($matches[2]) ? intval($matches[2]) : null;
            $year = isset($matches[3]) ? intval($matches[3]) : null;
            $luongController->getAllLuong();
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/thuong') {
            $thuongController->getAllThuong();
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/thuong/types') {
            $thuongController->getBonusTypes();
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/tuyendung\?month=(\d+)&year=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $month = intval($matches[1]);
            $year = intval($matches[2]);
            $tuyenDungController->getAllData($month, $year);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/tuyendung/options') {
            $tuyenDungController->getOptions();
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/tuyendung\/(\w+)\/(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $type = $matches[1];
            $id = intval($matches[2]);
            $tuyenDungController->getRecordById($type, $id);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/ungvien') {
            $tuyenDungController->getAllUngVien();
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/tuyendung\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $dotTuyenDungId = intval($matches[1]);
            $tuyenDungController->getDotTuyenDungById($dotTuyenDungId);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/tuyendung/plans') {
            $tuyenDungController->getAllKeHoachTuyenDung();
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/tuyendung\/plan\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $planId = intval($matches[1]);
            $tuyenDungController->getKeHoachTuyenDungById($planId);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/settings/users') {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền truy cập cài đặt"]);
                exit();
            }
            $result = $settingsController->getAllUsers();
            ob_end_clean();
            echo json_encode($result);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/settings\/user-status\/(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền cập nhật trạng thái"]);
                exit();
            }
            $userId = intval($matches[1]);
            $result = $settingsController->toggleUserStatus($userId);
            ob_end_clean();
            echo json_encode($result);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/settings/fingerprints') {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền truy cập vân tay"]);
                exit();
            }
            $fingerprintController->getAllFingerprints();
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/settings\/fingerprint\/status\/(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền kiểm tra trạng thái vân tay"]);
                exit();
            }
            $enrollmentId = intval($matches[1]);
            $fingerprintController->checkStatus($enrollmentId);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/employee/profile') {
            $employeeController->getProfile($_SESSION['user_id']);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/employee\/salary(\?month=(\d+)&year=(\d+))?/', $_SERVER['REQUEST_URI'], $matches)) {
            $month = isset($matches[2]) ? intval($matches[2]) : date('n');
            $year = isset($matches[3]) ? intval($matches[3]) : date('Y');
            $employeeController->getSalary($_SESSION['user_id'], $month, $year);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/employee/leave') {
            $employeeController->getLeaveRequests($_SESSION['user_id']);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/settings/fingerprints/manage') {
            error_log("DEBUG: Accessing fingerprint management endpoint");
            error_log("DEBUG: User ID: " . $_SESSION['user_id']);
            error_log("DEBUG: User permissions: " . json_encode([
                'quyen_them' => isset($_SESSION['quyen_them']) ? $_SESSION['quyen_them'] : 'not set',
                'quyen_sua' => isset($_SESSION['quyen_sua']) ? $_SESSION['quyen_sua'] : 'not set',
                'quyen_xoa' => isset($_SESSION['quyen_xoa']) ? $_SESSION['quyen_xoa'] : 'not set'
            ]));

            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                error_log("DEBUG: Permission denied - quyen_them not set or false");
                http_response_code(403);
                header('Content-Type: application/json; charset=UTF-8');
                echo json_encode(["success" => false, "message" => "Không có quyền truy cập quản lý vân tay"]);
                exit();
            }

            try {
                error_log("DEBUG: About to call getAllFingerprintsWithDetails");
                $fingerprintController->getAllFingerprintsWithDetails();
                error_log("DEBUG: Successfully called getAllFingerprintsWithDetails");
            } catch (Exception $e) {
                error_log("ERROR in fingerprint management: " . $e->getMessage());
                error_log("ERROR stack trace: " . $e->getTraceAsString());
                http_response_code(500);
                header('Content-Type: application/json; charset=UTF-8');
                echo json_encode([
                    "success" => false, 
                    "message" => "Lỗi khi lấy danh sách vân tay: " . $e->getMessage()
                ]);
            }
        } else {
            http_response_code(404);
            ob_end_clean();
            echo json_encode(["success" => false, "message" => "Invalid route"]);
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/chamcong') {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền thêm chấm công"]);
                exit();
            }
            $data = json_decode(file_get_contents("php://input"), true);
            $chamCongController->addOrUpdateChamCong($data);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/chamcong?action=markHoliday') {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền điểm danh nghỉ lễ"]);
                exit();
            }
            $data = json_decode(file_get_contents("php://input"), true);
            $chamCongController->markHolidayAttendance($data);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/nghiphep') {
            $data = json_decode(file_get_contents("php://input"), true);
            if (isset($data['action']) && $data['action'] === 'update') {
                $nghiPhepController->updateNghiPhep($data['id_nghi_phep'], $data);
            } else {
                $nghiPhepController->addNghiPhep($data);
            }
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/user') {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền thêm nhân viên"]);
                exit();
            }
            if (!empty($_FILES) || strpos($_SERVER['CONTENT_TYPE'], 'multipart/form-data') !== false) {
                $data = $_POST;
                if (isset($_FILES['hinh_anh']) && $_FILES['hinh_anh']['error'] === UPLOAD_ERR_OK) {
                    $data['hinh_anh'] = $_FILES['hinh_anh'];
                }
                $userController->addUser($data);
            } else {
                $data = json_decode(file_get_contents("php://input"), true);
                $userController->addUser($data);
            }
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/baohiem') {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền thêm bảo hiểm/thuế"]);
                exit();
            }
            $data = json_decode(file_get_contents("php://input"), true);
            $baoHiemController->addBaoHiemThue($data);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/thuong') {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền thêm thưởng"]);
                exit();
            }
            $data = json_decode(file_get_contents("php://input"), true);
            $thuongController->addThuong($data);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/tuyendung') {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền thêm dữ liệu tuyển dụng"]);
                exit();
            }
            $data = json_decode(file_get_contents("php://input"), true);
            $tuyenDungController->handleRequest('POST', $data);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/ungvien') {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền thêm ứng viên"]);
                exit();
            }
            $data = json_decode(file_get_contents("php://input"), true);
            $tuyenDungController->addUngVien($data);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/import_employees') {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền cập nhật nhân viên"]);
                exit();
            }
            if (!empty($_FILES) && isset($_FILES['csvFile']) && isset($_POST['employeeId'])) {
                $file = $_FILES['csvFile'];
                $employeeId = intval($_POST['employeeId']);
                error_log("Received employeeId: $employeeId");
                if ($employeeId <= 0) {
                    http_response_code(400);
                    ob_end_clean();
                    echo json_encode(['success' => false, 'message' => 'ID nhân viên không hợp lệ']);
                    exit();
                }
                if ($file['error'] === UPLOAD_ERR_OK) {
                    $filePath = $file['tmp_name'];
                    $requiredColumns = ['ho_ten', 'gioi_tinh', 'ngay_sinh', 'so_dien_thoai', 'dia_chi', 'can_cuoc_cong_dan', 'ngay_cap', 'noi_cap', 'que_quan'];
                    if (($handle = fopen($filePath, 'r')) !== false) {
                        $header = fgetcsv($handle, 1000, ',');
                        $header = array_map('trim', $header);
                        $missingColumns = array_diff($requiredColumns, $header);
                        if (!empty($missingColumns)) {
                            fclose($handle);
                            http_response_code(400);
                            ob_end_clean();
                            echo json_encode(['success' => false, 'message' => 'File CSV thiếu các cột: ' . implode(', ', $missingColumns)]);
                            exit();
                        }
                        $data = [];
                        while (($row = fgetcsv($handle, 1000, ',')) !== false) {
                            $row = array_map('trim', $row);
                            if (count($row) === count($header)) {
                                $data[] = array_combine($header, $row);
                            }
                        }
                        fclose($handle);
                        if (count($data) !== 1) {
                            http_response_code(400);
                            ob_end_clean();
                            echo json_encode(['success' => false, 'message' => 'File CSV chỉ được chứa đúng một dòng dữ liệu để cập nhật nhân viên']);
                            exit();
                        }
                        try {
                            $data[0]['employeeId'] = $employeeId;
                            error_log("Processing CSV data for employeeId: $employeeId");
                            $userController->importEmployeeFromCSV($data[0]);
                            ob_end_clean();
                            echo json_encode(['success' => true, 'message' => 'Cập nhật hồ sơ nhân viên thành công']);
                        } catch (Exception $e) {
                            error_log("Error processing CSV: " . $e->getMessage());
                            http_response_code(500);
                            ob_end_clean();
                            echo json_encode(['success' => false, 'message' => 'Lỗi khi cập nhật hồ sơ: ' . $e->getMessage()]);
                        }
                    } else {
                        http_response_code(500);
                        ob_end_clean();
                        echo json_encode(['success' => false, 'message' => 'Không thể mở file CSV']);
                    }
                } else {
                    http_response_code(400);
                    ob_end_clean();
                    echo json_encode(['success' => false, 'message' => 'Lỗi khi tải file lên: ' . $file['error']]);
                }
            } else {
                http_response_code(400);
                ob_end_clean();
                echo json_encode(['success' => false, 'message' => 'Thiếu file CSV hoặc ID nhân viên']);
            }
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/settings/register-regular') {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền thêm người dùng"]);
                exit();
            }
            $data = json_decode(file_get_contents("php://input"), true);
            $result = $settingsController->registerRegularUser($data);
            ob_end_clean();
            echo json_encode($result);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/settings/register-google') {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền thêm người dùng"]);
                exit();
            }
            $data = json_decode(file_get_contents("php://input"), true);
            $result = $settingsController->registerGoogleUser($data);
            ob_end_clean();
            echo json_encode($result);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/settings\/permissions\/(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền cập nhật quyền"]);
                exit();
            }
            $userId = intval($matches[1]);
            $data = json_decode(file_get_contents("php://input"), true);
            $result = $settingsController->updateUserPermissions($userId, $data);
            ob_end_clean();
            echo json_encode($result);
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/settings/fingerprint/enroll') {
            if (!isset($_SESSION['quyen_them']) || !$_SESSION['quyen_them']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền thêm vân tay"]);
                exit();
            }
            $fingerprintController->startEnrollment();
        } elseif ($_SERVER['REQUEST_URI'] === '/doanqlns/index.php/api/employee/leave') {
            $data = json_decode(file_get_contents("php://input"), true);
            $employeeController->submitLeaveRequest($_SESSION['user_id'], $data);
        } else {
            http_response_code(404);
            ob_end_clean();
            echo json_encode(["success" => false, "message" => "Invalid route"]);
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
        if (preg_match('/\/doanqlns\/index\.php\/api\/user\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền sửa nhân viên"]);
                exit();
            }
            $userId = intval($matches[1]);
            $data = json_decode(file_get_contents("php://input"), true);
            $userController->updateUser($userId, $data);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/chamcong\?id_nhan_vien=(\d+)&ngay_cham_cong=([\d-]+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền sửa chấm công"]);
                exit();
            }
            $idNhanVien = intval($matches[1]);
            $ngayChamCong = $matches[2];
            $data = json_decode(file_get_contents("php://input"), true);
            $chamCongController->addOrUpdateChamCong($data);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/nghiphep\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $nghiPhepId = intval($matches[1]);
            $data = json_decode(file_get_contents("php://input"), true);
            $nghiPhepController->updateNghiPhep($nghiPhepId, $data);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/baohiem\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền sửa bảo hiểm/thuế"]);
                exit();
            }
            $baoHiemId = intval($matches[1]);
            $data = json_decode(file_get_contents("php://input"), true);
            $baoHiemController->updateBaoHiemThue($baoHiemId, $data);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/thuong\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền sửa thưởng"]);
                exit();
            }
            $thuongId = intval($matches[1]);
            $data = json_decode(file_get_contents("php://input"), true);
            $thuongController->updateThuong($thuongId, $data);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/luong\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền sửa trạng thái lương"]);
                exit();
            }
            $id_luong = intval($matches[1]);
            $data = json_decode(file_get_contents("php://input"), true);
            $luongController->updateLuongStatus($id_luong, $data);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/tuyendung\/(\w+)\/(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền sửa"]);
                exit();
            }
            $type = $matches[1];
            $id = intval($matches[2]);
            $data = json_decode(file_get_contents("php://input"), true);
            $tuyenDungController->handleRequest('PUT', $data, $type, $id);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/settings\/fingerprint\/(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền sửa vân tay"]);
                exit();
            }
            $fingerprintId = intval($matches[1]);
            $data = json_decode(file_get_contents("php://input"), true);
            $fingerprintController->updateFingerprint($fingerprintId, $data);
        } else {
            http_response_code(404);
            ob_end_clean();
            echo json_encode(["success" => false, "message" => "Invalid route"]);
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
        if (preg_match('/\/doanqlns\/index\.php\/api\/user\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_xoa']) || !$_SESSION['quyen_xoa']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền xóa nhân viên"]);
                exit();
            }
            $userId = intval($matches[1]);
            $userController->deleteUser($userId);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/chamcong\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_xoa']) || !$_SESSION['quyen_xoa']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền xóa chấm công"]);
                exit();
            }
            $chamCongId = intval($matches[1]);
            $chamCongController->deleteChamCong($chamCongId);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/nghiphep\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $nghiPhepId = intval($matches[1]);
            $nghiPhepController->deleteNghiPhep($nghiPhepId);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/baohiem\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            $baoHiemId = intval($matches[1]);
            $baoHiemController->deleteBaoHiemThue($baoHiemId);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/thuong\?id=(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_xoa']) || !$_SESSION['quyen_xoa']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền xóa thưởng"]);
                exit();
            }
            $thuongId = intval($matches[1]);
            $thuongController->deleteThuong($thuongId);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/tuyendung\/(\w+)\/(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_xoa']) || !$_SESSION['quyen_xoa']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền xóa"]);
                exit();
            }
            $type = $matches[1];
            $id = intval($matches[2]);
            $tuyenDungController->handleRequest('DELETE', [], $type, $id);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/settings\/user\/(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_xoa']) || !$_SESSION['quyen_xoa']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền xóa người dùng"]);
                exit();
            }
            $userId = intval($matches[1]);
            $result = $settingsController->deleteUser($userId);
            ob_end_clean();
            echo json_encode($result);
        } elseif (preg_match('/\/doanqlns\/index\.php\/api\/settings\/fingerprint\/(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
            if (!isset($_SESSION['quyen_xoa']) || !$_SESSION['quyen_xoa']) {
                http_response_code(403);
                ob_end_clean();
                echo json_encode(["success" => false, "message" => "Không có quyền xóa vân tay"]);
                exit();
            }
            $fingerprintId = intval($matches[1]);
            $fingerprintController->deleteFingerprint($fingerprintId);
        } else {
            http_response_code(404);
            ob_end_clean();
            echo json_encode(["success" => false, "message" => "Invalid route"]);
        }
    } else {
        http_response_code(405);
        ob_end_clean();
        echo json_encode(["success" => false, "message" => "Phương thức không được hỗ trợ"]);
    }
} catch (Exception $e) {
    error_log("API error: " . $e->getMessage());
    http_response_code(500);
    ob_end_clean();
    echo json_encode(["success" => false, "message" => "Đã xảy ra lỗi: " . $e->getMessage()]);
}

// User status update route
if (preg_match('/^\/doanqlns\/index\.php\/api\/settings\/user-status\/(\d+)$/', $_SERVER['REQUEST_URI'], $matches) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['quyen_sua']) || !$_SESSION['quyen_sua']) {
        http_response_code(403);
        echo json_encode(["success" => false, "message" => "Không có quyền cập nhật trạng thái"]);
        exit();
    }
    $userId = intval($matches[1]);
    $settingsController->updateUserStatus($userId);
    exit();
}

ob_end_flush();
?>