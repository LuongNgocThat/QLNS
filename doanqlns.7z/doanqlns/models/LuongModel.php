<?php
class LuongModel {
    private $conn;

    public function __construct() {
        $this->conn = new mysqli("localhost", "root", "", "doanqlns");

        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    public function getAllLuong() {
        $query = "SELECT * FROM LUONG l INNER JOIN 
    NHAN_VIEN nv ON l.id_nhan_vien = nv.id_nhan_vien";
        $result = $this->conn->query($query);

        $records = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $records[] = $row;
            }
        }
        return $records;
    }
}
?>
