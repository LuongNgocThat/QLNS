
<?php
include_once(__DIR__ . '/../config/Database.php');

class LuongModel {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Hàm tính số ngày công từ bảng cham_cong
    private function calculateAttendanceStats($id_nhan_vien, $month, $year) {
        try {
            $query = "SELECT ngay_lam_viec, trang_thai 
                      FROM cham_cong 
                      WHERE id_nhan_vien = :id_nhan_vien 
                      AND ngay_lam_viec LIKE :thang";
            $stmt = $this->conn->prepare($query);
            $thang = sprintf('%04d-%02d%%', $year, $month);
            $stmt->bindParam(':id_nhan_vien', $id_nhan_vien, PDO::PARAM_INT);
            $stmt->bindParam(':thang', $thang, PDO::PARAM_STR);
            $stmt->execute();
            $records = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $startDate = new DateTime("$year-$month-01");
            $endDate = new DateTime("$year-$month-" . $startDate->format('t'));
            $daysInMonth = $startDate->format('t');

            $diemDanhDays = 0;
            $nghiDays = 0;
            $khongPhepCount = 0;

            for ($day = 1; $day <= $daysInMonth; $day++) {
                $date = new DateTime("$year-$month-$day");
                $dateStr = $date->format('Y-m-d');
                $isSunday = $date->format('w') == 0;
                $record = array_filter($records, function($r) use ($dateStr) {
                    return $r['ngay_lam_viec'] === $dateStr;
                });
                $record = reset($record);

                if ($isSunday) {
                    $diemDanhDays += 1;
                } elseif ($record) {
                    $trang_thai = $record['trang_thai'];
                    if ($trang_thai === 'Đúng giờ') {
                        $diemDanhDays += 1;
                    } elseif ($trang_thai === 'Đi trễ') {
                        $diemDanhDays += 0.75;
                    } elseif ($trang_thai === 'Có phép') {
                        $diemDanhDays += 1;
                        $nghiDays -= 0.5;
                        $khongPhepCount += 0.5;
                    } elseif ($trang_thai === 'Không phép') {
                        $diemDanhDays += 1;
                        $nghiDays -= 1;
                        $khongPhepCount += 1;
                    }
                }
            }

            $totalWorkDays = $diemDanhDays - $khongPhepCount;
            return $totalWorkDays;
        } catch (PDOException $e) {
            error_log("Lỗi khi tính số ngày công: " . $e->getMessage());
            return 0;
        }
    }

    public function getAllLuong($month, $year) {
        try {
            // Bước 1: Lấy tất cả nhân viên để đảm bảo mỗi nhân viên có bản ghi lương
            $queryNhanVien = "SELECT id_nhan_vien FROM nhan_vien";
            $stmtNhanVien = $this->conn->prepare($queryNhanVien);
            $stmtNhanVien->execute();
            $nhanViens = $stmtNhanVien->fetchAll(PDO::FETCH_ASSOC);

            $thang = sprintf('%04d-%02d', $year, $month);

            // Bước 2: Kiểm tra và tạo bản ghi lương nếu chưa tồn tại
            foreach ($nhanViens as $nhanVien) {
                $id_nhan_vien = $nhanVien['id_nhan_vien'];
                $queryCheck = "SELECT COUNT(*) FROM luong WHERE id_nhan_vien = :id_nhan_vien AND thang = :thang";
                $stmtCheck = $this->conn->prepare($queryCheck);
                $stmtCheck->bindParam(':id_nhan_vien', $id_nhan_vien, PDO::PARAM_INT);
                $stmtCheck->bindParam(':thang', $thang, PDO::PARAM_STR);
                $stmtCheck->execute();
                $count = $stmtCheck->fetchColumn();

                if ($count == 0) {
                    // Tính số ngày công từ bảng cham_cong
                    $so_ngay_cong = $this->calculateAttendanceStats($id_nhan_vien, $month, $year);

                    // Tạo bản ghi lương mới
                    $queryInsert = "INSERT INTO luong (id_nhan_vien, thang, trang_thai, ngay_cham_cong, so_ngay_cong) 
                                    VALUES (:id_nhan_vien, :thang, 'Tạm tính', :ngay_cham_cong, :so_ngay_cong)";
                    $stmtInsert = $this->conn->prepare($queryInsert);
                    $stmtInsert->bindParam(':id_nhan_vien', $id_nhan_vien, PDO::PARAM_INT);
                    $stmtInsert->bindParam(':thang', $thang, PDO::PARAM_STR);
                    $ngay_cham_cong = date('Y-m-d');
                    $stmtInsert->bindParam(':ngay_cham_cong', $ngay_cham_cong, PDO::PARAM_STR);
                    $stmtInsert->bindParam(':so_ngay_cong', $so_ngay_cong, PDO::PARAM_STR);
                    $stmtInsert->execute();
                }
            }

            // Bước 3: Lấy dữ liệu lương và tính toán các thông số
            $query = "SELECT 
                        l.id_luong,
                        l.id_nhan_vien,
                        nv.ho_ten,
                        l.thang,
                        l.so_ngay_cong,
                        l.trang_thai,
                        l.luong_co_ban,
                        l.phu_cap_chuc_vu,
                        l.tien_thuong,
                        l.cac_khoan_tru,
                        l.luong_thuc_nhan,
                        nv.luong_co_ban AS base_salary,
                        ROUND((nv.luong_co_ban / DAY(LAST_DAY(STR_TO_DATE(CONCAT(:thang, '-01'), '%Y-%m-%d')))) * COALESCE(l.so_ngay_cong, 0), 0) AS calculated_luong_co_ban,
                        COALESCE(cv.phu_cap, 0) AS phu_cap_chuc_vu,
                        COALESCE(SUM(t.tien_thuong), 0) AS tien_thuong,
                        COALESCE(bt.tong_khoan_tru, 0) AS cac_khoan_tru
                    FROM luong l
                    INNER JOIN nhan_vien nv ON l.id_nhan_vien = nv.id_nhan_vien
                    LEFT JOIN chuc_vu cv ON nv.id_chuc_vu = cv.id_chuc_vu
                    LEFT JOIN thuong t ON l.id_nhan_vien = t.id_nhan_vien 
                        AND DATE_FORMAT(t.ngay, '%Y-%m') = :thang
                    LEFT JOIN bao_hiem_thue_tncn bt ON l.id_nhan_vien = bt.id_nhan_vien 
                        AND bt.thang = :thang
                    WHERE l.thang = :thang
                    GROUP BY l.id_luong, l.id_nhan_vien, nv.ho_ten, l.thang, l.so_ngay_cong, l.trang_thai,
                             l.luong_co_ban, l.phu_cap_chuc_vu, l.tien_thuong, l.cac_khoan_tru, l.luong_thuc_nhan,
                             nv.luong_co_ban, cv.phu_cap, bt.tong_khoan_tru";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':thang', $thang, PDO::PARAM_STR);
            $stmt->execute();

            $luongData = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Bước 4: Cập nhật số ngày công và các thông số lương
            foreach ($luongData as &$record) {
                // Tính lại số ngày công từ bảng cham_cong
                $so_ngay_cong = $this->calculateAttendanceStats($record['id_nhan_vien'], $month, $year);
                $luong_co_ban = $record['calculated_luong_co_ban'];
                $phu_cap_chuc_vu = $record['phu_cap_chuc_vu'];
                $tien_thuong = $record['tien_thuong'];
                $cac_khoan_tru = $record['cac_khoan_tru'];
                $luong_thuc_nhan = $luong_co_ban + $phu_cap_chuc_vu + $tien_thuong - $cac_khoan_tru;

                // Cập nhật bản ghi trong bảng luong
                $queryUpdate = "UPDATE luong 
                                SET so_ngay_cong = :so_ngay_cong,
                                    luong_co_ban = :luong_co_ban,
                                    phu_cap_chuc_vu = :phu_cap_chuc_vu,
                                    tien_thuong = :tien_thuong,
                                    cac_khoan_tru = :cac_khoan_tru,
                                    luong_thuc_nhan = :luong_thuc_nhan
                                WHERE id_luong = :id_luong";
                $stmtUpdate = $this->conn->prepare($queryUpdate);
                $stmtUpdate->bindParam(':so_ngay_cong', $so_ngay_cong, PDO::PARAM_STR);
                $stmtUpdate->bindParam(':luong_co_ban', $luong_co_ban, PDO::PARAM_STR);
                $stmtUpdate->bindParam(':phu_cap_chuc_vu', $phu_cap_chuc_vu, PDO::PARAM_STR);
                $stmtUpdate->bindParam(':tien_thuong', $tien_thuong, PDO::PARAM_STR);
                $stmtUpdate->bindParam(':cac_khoan_tru', $cac_khoan_tru, PDO::PARAM_STR);
                $stmtUpdate->bindParam(':luong_thuc_nhan', $luong_thuc_nhan, PDO::PARAM_STR);
                $stmtUpdate->bindParam(':id_luong', $record['id_luong'], PDO::PARAM_INT);
                $stmtUpdate->execute();

                // Cập nhật lại dữ liệu trả về
                $record['so_ngay_cong'] = $so_ngay_cong;
                $record['luong_co_ban'] = $luong_co_ban;
                $record['phu_cap_chuc_vu'] = $phu_cap_chuc_vu;
                $record['tien_thuong'] = $tien_thuong;
                $record['cac_khoan_tru'] = $cac_khoan_tru;
                $record['luong_thuc_nhan'] = $luong_thuc_nhan;
            }

            return $luongData;
        } catch (PDOException $e) {
            error_log("Lỗi khi lấy dữ liệu lương: " . $e->getMessage());
            return [];
        }
    }

    public function updateLuongStatus($id_luong, $trang_thai) {
        try {
            if (!in_array($trang_thai, ['Tạm tính', 'Đã thanh toán'])) {
                return ['success' => false, 'message' => 'Trạng thái không hợp lệ'];
            }

            $query = "UPDATE luong SET trang_thai = :trang_thai WHERE id_luong = :id_luong";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':trang_thai', $trang_thai, PDO::PARAM_STR);
            $stmt->bindParam(':id_luong', $id_luong, PDO::PARAM_INT);
            $success = $stmt->execute();

            if ($success && $stmt->rowCount() > 0) {
                return ['success' => true];
            } else {
                return ['success' => false, 'message' => 'Không tìm thấy bản ghi lương hoặc không có thay đổi'];
            }
        } catch (PDOException $e) {
            error_log("Lỗi khi cập nhật trạng thái lương: " . $e->getMessage());
            return ['success' => false, 'message' => 'Lỗi cơ sở dữ liệu: ' . $e->getMessage()];
        }
    }

    public function updateLuongDetails($id_luong, $data) {
        try {
            if ($data['so_ngay_cong'] < 0 || $data['luong_co_ban'] < 0 || 
                $data['phu_cap_chuc_vu'] < 0 || $data['tien_thuong'] < 0 || 
                $data['cac_khoan_tru'] < 0) {
                return ['success' => false, 'message' => 'Giá trị không được âm'];
            }

            $luong_thuc_nhan = $data['luong_co_ban'] + $data['phu_cap_chuc_vu'] + 
                              $data['tien_thuong'] - $data['cac_khoan_tru'];

            $query = "UPDATE luong 
                      SET so_ngay_cong = :so_ngay_cong,
                          luong_co_ban = :luong_co_ban,
                          phu_cap_chuc_vu = :phu_cap_chuc_vu,
                          tien_thuong = :tien_thuong,
                          cac_khoan_tru = :cac_khoan_tru,
                          luong_thuc_nhan = :luong_thuc_nhan
                      WHERE id_luong = :id_luong";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':so_ngay_cong', $data['so_ngay_cong'], PDO::PARAM_STR);
            $stmt->bindParam(':luong_co_ban', $data['luong_co_ban'], PDO::PARAM_STR);
            $stmt->bindParam(':phu_cap_chuc_vu', $data['phu_cap_chuc_vu'], PDO::PARAM_STR);
            $stmt->bindParam(':tien_thuong', $data['tien_thuong'], PDO::PARAM_STR);
            $stmt->bindParam(':cac_khoan_tru', $data['cac_khoan_tru'], PDO::PARAM_STR);
            $stmt->bindParam(':luong_thuc_nhan', $luong_thuc_nhan, PDO::PARAM_STR);
            $stmt->bindParam(':id_luong', $id_luong, PDO::PARAM_INT);
            $success = $stmt->execute();

            if ($success && $stmt->rowCount() > 0) {
                return ['success' => true];
            } else {
                return ['success' => false, 'message' => 'Không tìm thấy bản ghi lương hoặc không có thay đổi'];
            }
        } catch (PDOException $e) {
            error_log("Lỗi khi cập nhật chi tiết lương: " . $e->getMessage());
            return ['success' => false, 'message' => 'Lỗi cơ sở dữ liệu: ' . $e->getMessage()];
        }
    }

    public function __destruct() {
        $this->conn = null;
    }
}
?>