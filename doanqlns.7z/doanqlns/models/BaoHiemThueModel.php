<?php
include_once(__DIR__ . '/../config/Database.php');

class BaoHiemThueModel {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getAllBaoHiemThue() {
        $query = "SELECT * FROM BAO_HIEM_THUE_TNCN JOIN NHAN_VIEN ON BAO_HIEM_THUE_TNCN.id_nhan_vien = NHAN_VIEN.id_nhan_vien";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $users ?: [];
    }

    public function deleteBaoHiemThue($id) {
        $query = "DELETE FROM BAO_HIEM_THUE_TNCN WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function updateBaoHiemThue($id, $data) {
        $query = "UPDATE BAO_HIEM_THUE_TNCN bht
                  JOIN NHAN_VIEN nv ON bht.id_nhan_vien = nv.id_nhan_vien
                  SET bht.thang = :thang, 
                      bht.bhxh = :bhxh, 
                      bht.bhyt = :bhyt, 
                      bht.bhtn = :bhtn, 
                      bht.thue_tncn = :thue_tncn
                  WHERE bht.id = :id";
    
        $stmt = $this->conn->prepare($query);
    
        $stmt->bindParam(":thang", $data['thang']);
        $stmt->bindParam(":bhxh", $data['bhxh']);
        $stmt->bindParam(":bhyt", $data['bhyt']);
        $stmt->bindParam(":bhtn", $data['bhtn']);
        $stmt->bindParam(":thue_tncn", $data['thue_tncn']);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
    
        return $stmt->execute();
    }

    // Phương thức thêm mới bảo hiểm và thuế TNCN
    public function addBaoHiemThue($data) {
        $query = "INSERT INTO BAO_HIEM_THUE_TNCN (id_nhan_vien, thang, bhxh, bhyt, bhtn, thue_tncn, tong_khoan_tru) 
                  VALUES (:id_nhan_vien, :thang, :bhxh, :bhyt, :bhtn, :thue_tncn, :tong_khoan_tru)";
        
        $stmt = $this->conn->prepare($query);

        // Tính tổng khoản trừ
        $tong_khoan_tru = floatval($data['bhxh']) + floatval($data['bhyt']) + floatval($data['bhtn']) + floatval($data['thue_tncn']);

        $stmt->bindParam(":id_nhan_vien", $data['id_nhan_vien'], PDO::PARAM_INT);
        $stmt->bindParam(":thang", $data['thang']);
        $stmt->bindParam(":bhxh", $data['bhxh']);
        $stmt->bindParam(":bhyt", $data['bhyt']);
        $stmt->bindParam(":bhtn", $data['bhtn']);
        $stmt->bindParam(":thue_tncn", $data['thue_tncn']);
        $stmt->bindParam(":tong_khoan_tru", $tong_khoan_tru);

        return $stmt->execute();
    }

    public function __destruct() {
        $this->conn = null;
    }
}
?>