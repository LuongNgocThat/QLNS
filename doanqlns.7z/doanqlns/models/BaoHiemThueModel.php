<?php
class BaoHiemThueModel {
    private $conn;

    public function __construct() {
        $this->conn = new mysqli("localhost", "root", "", "doanqlns");

        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    public function getAllBaoHiemThue() {
        $query = "SELECT * FROM BAO_HIEM_THUE_TNCN join NHAN_VIEN on BAO_HIEM_THUE_TNCN.id_nhan_vien = NHAN_VIEN.id_nhan_vien";
        $result = $this->conn->query($query);

        $records = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $records[] = $row;
            }
        }
        return $records;
    }
}
?>
