<?php
class ChamCongModel {
    private $conn;

    public function __construct() {
        try {
            mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
            $this->conn = new mysqli("localhost", "root", "", "doanqlns");
            $this->conn->set_charset("utf8mb4");
        } catch (Exception $e) {
            error_log("Lỗi kết nối database: " . $e->getMessage());
            throw new Exception("Không thể kết nối đến cơ sở dữ liệu");
        }
    }

    public function getAllChamCong() {
        try {
            $query = "SELECT c.*, nv.ho_ten 
                    FROM CHAM_CONG c 
                    INNER JOIN NHAN_VIEN nv ON c.id_nhan_vien = nv.id_nhan_vien";
            $result = $this->conn->query($query);

            $records = [];
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    // Đảm bảo trạng thái được xử lý đúng
                    if (in_array($row['trang_thai'], ['Có phép', 'Không phép', 'Phép Năm', 'Chưa điểm danh', 'Đúng giờ', 'Đi trễ'])) {
                        $records[] = $row;
                    }
                }
            }
            return $records;
        } catch (Exception $e) {
            error_log("Lỗi trong getAllChamCong: " . $e->getMessage());
            throw $e;
        }
    }

    public function addChamCong($data) {
        try {
            // Kiểm tra xem đã có bản ghi chấm công cho ngày này chưa
            $checkQuery = "SELECT id_cham_cong FROM CHAM_CONG 
                         WHERE id_nhan_vien = ? AND ngay_lam_viec = ?";
            $checkStmt = $this->conn->prepare($checkQuery);
            if (!$checkStmt) {
                throw new Exception("Lỗi chuẩn bị truy vấn kiểm tra: " . $this->conn->error);
            }

            $checkStmt->bind_param("is", $data['id_nhan_vien'], $data['ngay_lam_viec']);
            $checkStmt->execute();
            $result = $checkStmt->get_result();
            $checkStmt->close();

            if ($result->num_rows > 0) {
                // Nếu đã tồn tại, cập nhật bản ghi
                $row = $result->fetch_assoc();
                $updateQuery = "UPDATE CHAM_CONG 
                              SET trang_thai = ?, ghi_chu = ?
                              WHERE id_cham_cong = ?";
                $updateStmt = $this->conn->prepare($updateQuery);
                if (!$updateStmt) {
                    throw new Exception("Lỗi chuẩn bị truy vấn cập nhật: " . $this->conn->error);
                }

                $updateStmt->bind_param("ssi", 
                    $data['trang_thai'],
                    $data['ghi_chu'],
                    $row['id_cham_cong']
                );
                $success = $updateStmt->execute();
                $updateStmt->close();
            } else {
                // Nếu chưa tồn tại, thêm mới
                $insertQuery = "INSERT INTO CHAM_CONG (id_nhan_vien, ngay_lam_viec, gio_vao, gio_ra, 
                                                     trang_thai, ghi_chu) 
                              VALUES (?, ?, ?, ?, ?, ?)";
                $insertStmt = $this->conn->prepare($insertQuery);
                if (!$insertStmt) {
                    throw new Exception("Lỗi chuẩn bị truy vấn thêm mới: " . $this->conn->error);
                }

                $insertStmt->bind_param(
                    "isssss",
                    $data['id_nhan_vien'],
                    $data['ngay_lam_viec'],
                    $data['gio_vao'],
                    $data['gio_ra'],
                    $data['trang_thai'],
                    $data['ghi_chu']
                );
                $success = $insertStmt->execute();
                $insertStmt->close();
            }

            return $success;
        } catch (Exception $e) {
            error_log("Lỗi trong addChamCong: " . $e->getMessage());
            throw $e;
        }
    }
}
?>