<?php
class ChamCongModel {
    private $conn;

    public function __construct() {
        $this->conn = new mysqli("localhost", "root", "", "doanqlns");

        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    public function getAllChamCong() {
        $query = "SELECT * FROM CHAM_CONG c INNER JOIN 
    NHAN_VIEN nv ON c.id_nhan_vien = nv.id_nhan_vien";
        $result = $this->conn->query($query);

        $records = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $records[] = $row;
            }
        }
        return $records;
    }
}
?>
