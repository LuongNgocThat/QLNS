<?php
include_once(__DIR__ . '/../config/Database.php');

class ThuongModel {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function getAllThuong() {
        $query = "SELECT * FROM THUONG t 
                  INNER JOIN NHAN_VIEN nv ON t.id_nhan_vien = nv.id_nhan_vien";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $users;
    }

    public function addThuong($data) {
        $query = "INSERT INTO THUONG (id_nhan_vien, noi_dung_thuong, ngay, loai, tien_thuong) 
                  VALUES (:id_nhan_vien, :noi_dung_thuong, :ngay, :loai, :tien_thuong)";
        $stmt = $this->conn->prepare($query);

        // Gán giá trị tiền thưởng/phạt dựa trên loại
        $tien_thuong = match ($data['loai']) {
            'nghỉ lễ' => 1500000,
            'thăng chức' => 2000000,
            'thành tích cá nhân' => 1000000,
            'phạt kỷ luật' => -1000000,
            'phạt trách nhiệm công việc' => -1500000,
            default => 0
        };

        $stmt->bindParam(':id_nhan_vien', $data['id_nhan_vien']);
        $stmt->bindParam(':noi_dung_thuong', $data['noi_dung_thuong']);
        $stmt->bindParam(':ngay', $data['ngay']);
        $stmt->bindParam(':loai', $data['loai']);
        $stmt->bindParam(':tien_thuong', $tien_thuong);

        $success = $stmt->execute();

        if ($success) {
            // Cập nhật bảng luong sau khi thêm thưởng/phạt
            $this->updateLuong($data['id_nhan_vien'], date('Y-m', strtotime($data['ngay'])));
        }

        return $success;
    }

    public function updateThuong($thuongId, $data) {
        $query = "UPDATE THUONG 
                  SET id_nhan_vien = :id_nhan_vien, 
                      noi_dung_thuong = :noi_dung_thuong, 
                      ngay = :ngay, 
                      loai = :loai, 
                      tien_thuong = :tien_thuong 
                  WHERE id_thuong = :id_thuong";
        $stmt = $this->conn->prepare($query);

        // Gán giá trị tiền thưởng/phạt dựa trên loại
        $tien_thuong = match ($data['loai']) {
            'nghỉ lễ' => 1500000,
            'thăng chức' => 2000000,
            'thành tích cá nhân' => 1000000,
            'phạt kỷ luật' => -1000000,
            'phạt trách nhiệm công việc' => 1500000,
            default => 0
        };

        $stmt->bindParam(':id_thuong', $thuongId);
        $stmt->bindParam(':id_nhan_vien', $data['id_nhan_vien']);
        $stmt->bindParam(':noi_dung_thuong', $data['noi_dung_thuong']);
        $stmt->bindParam(':ngay', $data['ngay']);
        $stmt->bindParam(':loai', $data['loai']);
        $stmt->bindParam(':tien_thuong', $tien_thuong);

        $success = $stmt->execute();

        if ($success) {
            // Cập nhật bảng luong sau khi sửa thưởng/phạt
            $this->updateLuong($data['id_nhan_vien'], date('Y-m', strtotime($data['ngay'])));
        }

        return $success;
    }

    public function deleteThuong($thuongId) {
        $query = "SELECT id_nhan_vien, ngay FROM THUONG WHERE id_thuong = :id_thuong";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_thuong', $thuongId);
        $stmt->execute();
        $thuong = $stmt->fetch(PDO::FETCH_ASSOC);

        $success = false;
        if ($thuong) {
            $query = "DELETE FROM THUONG WHERE id_thuong = :id_thuong";
            $stmt = $this->conn->prepare($query);
            $success = $stmt->execute([':id_thuong' => $thuongId]);

            if ($success) {
                // Cập nhật bảng luong sau khi xóa thưởng/phạt
                $this->updateLuong($thuong['id_nhan_vien'], date('Y-m', strtotime($thuong['ngay'])));
            }
        }

        return $success;
    }

    public function getBonusTypes() {
        try {
            $query = "SELECT COLUMN_TYPE 
                      FROM INFORMATION_SCHEMA.COLUMNS 
                      WHERE TABLE_NAME = 'thuong' 
                      AND COLUMN_NAME = 'loai'";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            // Extract ENUM values from COLUMN_TYPE
            if ($result && preg_match("/enum\('(.*?)'\)/", $result['COLUMN_TYPE'], $matches)) {
                return explode("','", $matches[1]);
            }
            return [];
        } catch (PDOException $e) {
            error_log("Lỗi khi lấy danh sách loại thưởng/phạt: " . $e->getMessage());
            return [];
        }
    }

    private function updateLuong($id_nhan_vien, $thang) {
        $query = "CALL CalculatePayroll(:id_nhan_vien, :thang, NULL)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_nhan_vien', $id_nhan_vien);
        $stmt->bindParam(':thang', $thang);
        $stmt->execute();
    }
}
?>